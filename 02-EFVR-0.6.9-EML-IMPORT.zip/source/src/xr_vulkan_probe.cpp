#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "xr_vulkan.h"
#include "eye_labels.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>

// Standalone diagnostic only: never loads EML, Unity or any game library.
// CPU rays produce TWO independent views, using the exact predicted eye poses
// and asymmetric FOV from the frame being submitted. Vulkan uploads both views
// to separate swapchains. This is deliberately a compatibility diagnostic, not
// a performance benchmark for a native GPU game renderer.
namespace {
struct V {float x,y,z;};
V operator+(V a,V b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
V operator-(V a,V b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
V operator*(V a,float b){return {a.x*b,a.y*b,a.z*b};}
float dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}
V cross(V a,V b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
V unit(V a){return a*(1.f/std::sqrt(dot(a,a)));}
V rotate(const float q[4],V p){V v{q[0],q[1],q[2]};return p+cross(v,cross(v,p)+p*q[3])*2.f;}
float sphere(V o,V d,V c,float radius){V a=o-c;float b=dot(a,d),h=b*b-dot(a,a)+radius*radius;return h<0?-1.f:-b-std::sqrt(h);}
uint8_t byte(float v){return static_cast<uint8_t>(std::clamp(v,0.f,1.f)*255.f+.5f);}

constexpr uint32_t hud_width=256,hud_height=128;
std::vector<uint8_t> synthetic_hud(){
    // Linear, top-left RGBA with premultiplied alpha. Transparent margins and
    // the faint panel let the scene remain visible behind this independent quad.
    std::vector<uint8_t> pixels(static_cast<size_t>(hud_width)*hud_height*4,0);
    for(uint32_t y=16;y<hud_height-16;++y)for(uint32_t x=16;x<hud_width-16;++x){
        const bool border=x<19||x>=hud_width-19||y<19||y>=hud_height-19;
        const int dx=std::abs(int(x)-int(hud_width/2)),dy=std::abs(int(y)-int(hud_height/2));
        const bool cross=(dx<=1&&dy<=18)||(dy<=1&&dx<=18);
        const uint8_t alpha=cross?224:(border?160:24);
        const size_t at=(static_cast<size_t>(y)*hud_width+x)*4;
        pixels[at]=cross?alpha:0;pixels[at+1]=alpha;pixels[at+2]=alpha;pixels[at+3]=alpha;
    }
    return pixels;
}

void scene(const vrvd::Eye& eye,unsigned eye_index,uint32_t size,std::vector<uint8_t>& pixels,bool diagnostic_swap=false){
    pixels.resize(static_cast<size_t>(size)*size*4);
    const float l=std::tan(eye.angleLeft),r=std::tan(eye.angleRight),u=std::tan(eye.angleUp),b=std::tan(eye.angleDown);
    const V origin{eye.position[0],eye.position[1]+1.6f,eye.position[2]};
    const V light=unit({-1,2,1});
    const V centers[2]={{-.55f,1.25f,-1.8f},{.65f,1.1f,-3.1f}};
    const V colors[2]={{1.f,.28f,.03f},{.03f,.35f,1.f}};
    const float radii[2]={.3f,.45f};
    for(uint32_t y=0;y<size;++y)for(uint32_t x=0;x<size;++x){
        float sx=(x+.5f)/size,sy=(y+.5f)/size;
        // Top-left origin: pixel row zero uses angleUp, not angleDown.
        V d=rotate(eye.orientation,unit({l+(r-l)*sx,u+(b-u)*sy,-1.f}));
        float sky=std::clamp(d.y*.5f+.5f,0.f,1.f);
        V color={.08f+.18f*sky,.12f+.28f*sky,.20f+.35f*sky};float nearest_distance=1e6f;
        if(d.y<-.0001f){float t=-origin.y/d.y;if(t>0){V point=origin+d*t;
            float gx=point.x-std::floor(point.x),gz=point.z-std::floor(point.z);
            color=(gx>.96f||gz>.96f)?V{.45f,.5f,.55f}:V{.12f,.16f,.18f};nearest_distance=t;}}
        // A world-space asymmetric color board tests channels and vertical
        // orientation. White arrow points UP. Geometry has real stereo depth.
        if(d.z<-.0001f){float t=(-4.f-origin.z)/d.z;V point=origin+d*t;
            if(t>0&&t<nearest_distance&&point.x>-1.25f&&point.x<1.25f&&point.y>.8f&&point.y<2.5f){
                float bx=point.x/1.25f,by=(point.y-1.65f)/.85f;
                if(by>0)color=bx<0?V{.85f,.02f,.02f}:V{.02f,.85f,.02f};
                else color=bx<0?V{.02f,.02f,.85f}:V{.85f,.85f,.02f};
                const bool shaft=std::abs(bx)<.035f&&by>-.55f&&by<.50f;
                const bool arrow=by>.30f&&by<.72f&&std::abs(bx)<(.72f-by)*.65f;
                if(shaft||arrow)color={1,1,1};nearest_distance=t;
            }}
        for(int s=0;s<2;++s){float t=sphere(origin,d,centers[s],radii[s]);if(t>0&&t<nearest_distance){
            V normal=unit(origin+d*t-centers[s]);color=colors[s]*(.2f+.8f*std::max(0.f,dot(normal,light)));nearest_distance=t;}}
        // Small per-eye identity strip: cyan on LEFT, magenta on RIGHT.
        if(y<3&&x<size/8)color=eye_index?V{1,0,1}:V{0,1,1};
        const size_t at=(static_cast<size_t>(y)*size+x)*4;
        pixels[at]=byte(color.x);pixels[at+1]=byte(color.y);pixels[at+2]=byte(color.z);pixels[at+3]=255;
    }
    vrvd::annotate_eye_rgba(pixels.data(),size,size,eye_index,diagnostic_swap);
}
void ppm(const std::string& path,const std::vector<uint8_t>& rgba,uint32_t size){
    std::ofstream out(path,std::ios::binary);if(!out)throw std::runtime_error("Cannot create preview file: "+path);
    out<<"P6\n"<<size<<" "<<size<<"\n255\n";
    for(size_t i=0;i<rgba.size();i+=4)out.write(reinterpret_cast<const char*>(rgba.data()+i),3);
}
std::wstring wide(const char* value){
    int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,value,-1,nullptr,0);
    if(!n)throw std::runtime_error("Invalid UTF-8 loader path");
    std::wstring result(n,L'\0');MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,value,-1,result.data(),n);return result;
}
void usage(){
    std::cout<<"VRVD standalone Vulkan stereo diagnostic. No game or EML is loaded.\n"
      "Usage: vrvd-vulkan-probe.exe --run [seconds=30] [absolute-openxr_loader.dll-path] [eye-size=512]\n"
      "P cycles scene / legacy quad-only / black projection + quad. Flat modes show the same opaque color chart.\n"
      "       vrvd-vulkan-probe.exe --preview <output-prefix>\n"
      "Without --run no XR session is created. Connect Quest 3 using Virtual Desktop first.\n"
      "R recentres, Escape exits. Expected: near orange sphere, farther blue sphere, floor grid,\n"
      "color board (red/green top, blue/yellow bottom) and a white UP arrow.\n"
      "Upper-center source markers: L (cyan) / R (magenta). Close one eye to check delivery.\n"
      "S toggles DIAGNOSTIC ONLY image swapping; NORMAL is the default. Pose/FOV metadata stays unchanged.\n"
      "H toggles a synthetic head-locked HUD (default OFF): translucent cyan frame and white cross.\n"
      "The HUD uses a separate VIEW quad/third swapchain; S changes scene images only. This does not capture game HUD.\n"
      "CPU ray rendering and readback-compatible uploads add latency; this is not a native VR performance test.\n";
}
}

int main(int argc,char** argv){
    if(argc==1||std::strcmp(argv[1],"--help")==0){usage();return 0;}
    try{
        if(std::strcmp(argv[1],"--preview")==0){
            if(argc!=3)throw std::runtime_error("--preview requires an output file prefix.");
            constexpr uint32_t size=512;std::vector<uint8_t> pixels[2];
            for(unsigned e=0;e<2;++e){vrvd::Eye eye{};eye.position[0]=e?.032f:-.032f;eye.orientation[3]=1;
                eye.angleLeft=eye.angleDown=-.8f;eye.angleRight=eye.angleUp=.8f;
                scene(eye,e,size,pixels[e]);ppm(std::string(argv[2])+(e?"-right.ppm":"-left.ppm"),pixels[e],size);}
            size_t different=0;for(size_t i=0;i<pixels[0].size();i+=4)if(std::memcmp(pixels[0].data()+i,pixels[1].data()+i,3))++different;
            std::cout<<"Offline independent-eye previews written; differing RGB pixels: "<<different<<" / "<<size*size<<"\n";
            return different?0:2;
        }
        if(std::strcmp(argv[1],"--run")!=0){usage();return 1;}
        int seconds=argc>2?std::stoi(argv[2]):30;
        int size=argc>4?std::stoi(argv[4]):512;
        if(seconds<1||seconds>300||size<128||size>1024)throw std::runtime_error("Duration must be 1..300 seconds and eye size 128..1024.");
        std::wstring loader=argc>3?wide(argv[3]):L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\SteamVR\\bin\\win64\\openxr_loader.dll";
        vrvd::XrVulkanBackend xr;std::string error;
        if(!xr.initialize_owned(loader.c_str(),static_cast<uint32_t>(size),static_cast<uint32_t>(size),error))throw std::runtime_error(error);
        uint32_t version=xr.graphics_api_version();
        std::cout<<"Runtime: "<<xr.runtime_name()<<"\nGPU: "<<xr.graphics_name()<<"\nVulkan instance API: "
            <<VK_API_VERSION_MAJOR(version)<<'.'<<VK_API_VERSION_MINOR(version)<<'.'<<VK_API_VERSION_PATCH(version)
            <<"\nEye size: "<<size<<" x "<<size<<", RGBA8 linear, two scene swapchains\nPut on the headset. R recentres, S swaps scene images, H toggles synthetic HUD, Escape exits.\n"
            <<"Image routing: NORMAL (left=L, right=R). This diagnostic switch is not a persistent fix.\n"
            <<"Synthetic HUD: OFF. H enables a head-locked translucent cyan frame/white cross, independent of Unity or game HUD.\n"<<std::flush;
        const auto hud_pixels=synthetic_hud();
        const vrvd::XrVulkanHudFrame hud{hud_pixels.data(),hud_pixels.size(),hud_width,hud_height,1.5f,1.2f,-.15f};
        auto flat_pixels=hud_pixels;
        for(unsigned y=0;y<hud_height;++y)for(unsigned x=0;x<hud_width;++x){
            size_t at=(size_t(y)*hud_width+x)*4;
            flat_pixels[at]=x<hud_width/2?255:32;flat_pixels[at+1]=y<hud_height/2?255:32;
            flat_pixels[at+2]=x>=hud_width/2?255:32;flat_pixels[at+3]=255;
        }
        vrvd::XrVulkanHudFrame flat{flat_pixels.data(),flat_pixels.size(),hud_width,hud_height,1.5f,1.8f,0.f};
        unsigned presentation=0;
        std::cout<<"P: 0 scene / 1 legacy quad-only / 2 black projection + quad. Both flat modes use identical bright color pixels.\n"<<std::flush;
        auto start=std::chrono::steady_clock::now();uint32_t frames=0;std::vector<uint8_t> pixels[2];bool diagnostic_swap=false,hud_enabled=false;
        while(std::chrono::steady_clock::now()-start<std::chrono::seconds(seconds)){
            if(GetAsyncKeyState(VK_ESCAPE)&0x8000)break;
            if(GetAsyncKeyState('R')&1)xr.request_recenter();
            if(GetAsyncKeyState('S')&1){diagnostic_swap=!diagnostic_swap;
                std::cout<<"Image routing: "<<(diagnostic_swap?"SWAPPED DIAGNOSTIC (left receives R, right receives L)":"NORMAL (left=L, right=R)")<<'\n'<<std::flush;}
            if(GetAsyncKeyState('H')&1){hud_enabled=!hud_enabled;
                std::cout<<"Synthetic HUD: "<<(hud_enabled?"ON (VIEW quad, 1.5 m ahead, 1.2 m wide, 0.15 m below center; scene swapping does not affect it)":"OFF (HUD layer omitted)")<<'\n'<<std::flush;}
            if(GetAsyncKeyState('P')&1){presentation=(presentation+1)%3;std::cout<<"Presentation: "<<presentation<<" (0=scene, 1=quad-only, 2=projection+quad)\n"<<std::flush;}
            vrvd::Eye eyes[2]{};bool render=false;
            if(!xr.begin_frame(eyes,render,error)){xr.cancel_frame();throw std::runtime_error(error);}
            if(!render){if(xr.frame_pending())xr.cancel_frame();Sleep(5);continue;}
            if(presentation){
                flat.projection_background=presentation==2;
                if(!xr.submit_panel(flat,error)){xr.cancel_frame();throw std::runtime_error(error);}
                ++frames;continue;
            }
            for(unsigned e=0;e<2;++e)scene(eyes[e],e,static_cast<uint32_t>(size),pixels[e],diagnostic_swap);
            const unsigned left_source=diagnostic_swap?1:0,right_source=diagnostic_swap?0:1;
            if(!xr.submit_rgba(pixels[left_source].data(),pixels[right_source].data(),pixels[0].size(),error,hud_enabled?&hud:nullptr)){xr.cancel_frame();throw std::runtime_error(error);}
            ++frames;
        }
        const double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
        if(!xr.shutdown())throw std::runtime_error("Vulkan GPU is still busy; shutdown retained in-flight resources.");
        std::cout<<"Submitted stereo frames: "<<frames<<"; average submissions/s: "<<(elapsed>0?frames/elapsed:0)
            <<"\nVisual stereo, orientation, colors and comfort still require headset confirmation.\n";
        return frames?0:2;
    }catch(const std::exception& e){std::cerr<<"Vulkan diagnostic failed: "<<e.what()<<"\n";return 1;}
}
