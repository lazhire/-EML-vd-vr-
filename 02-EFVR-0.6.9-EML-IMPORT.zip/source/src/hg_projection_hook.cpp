#include "hg_projection_hook.h"
#include <cmath>
#include <cstring>
#include <mutex>
#include <stdexcept>
#include <thread>

namespace vrvd {
static_assert(sizeof(HgProjectionMatrix)==64&&sizeof(void*)==8,"HG projection hook requires Windows x64");
struct HgProjectionHook::Impl {
    struct Eye {void* hg=nullptr;void* camera=nullptr;void* additional=nullptr;void* drawHg=nullptr;HgProjectionMatrix matrix{};};
    struct State {
        std::array<Eye,2> eyes{};HgProjectionSnapshot stats;uint64_t scopeGeneration=0;
        std::thread::id scopeThread;HgDrawBindingValidator validator=nullptr;void* validatorContext=nullptr;
        std::array<bool,2> prepareValidated{};
    };
    struct PrepareContext {std::shared_ptr<State> state;uint64_t generation=0;int eye=-1;};
    inline static thread_local PrepareContext* currentPrepare=nullptr;
    struct PrepareScope {
        PrepareContext context;PrepareContext* previous;
        PrepareScope(std::shared_ptr<State> state,uint64_t generation,int eye):context{state,generation,eye},previous(currentPrepare){currentPrepare=&context;}
        ~PrepareScope(){currentPrepare=previous;}
    };
    std::shared_ptr<State> state=std::make_shared<State>();
    inline static std::mutex routeMutex;
    inline static std::shared_ptr<State> owner;
    // EML publishes the original trampoline through these persistent slots
    // before its detour becomes callable, as required by create_hook's native
    // original-pointer contract. Never copy from a temporary post-install slot.
    inline static void* nextBuild=nullptr;
    inline static void* nextNonOblique=nullptr;
    inline static void* nextPrepare=nullptr;
    inline static void* nextGetOrCreate=nullptr;
    static bool same_scope(const std::shared_ptr<State>& s,int eye,uint64_t generation) {
        return s&&owner==s&&s->stats.installed&&s->stats.scope_active&&s->stats.active_eye==eye&&
            s->scopeGeneration==generation&&s->scopeThread==std::this_thread::get_id();
    }
    static void reject_binding(State& s,unsigned eye,const std::string& error,bool prepareFailure=false) {
        ++s.stats.frame_draw_binding_failures[eye];
        if(prepareFailure)++s.stats.frame_prepare_validation_failures[eye];
        if(s.stats.draw_binding_error[eye].empty())s.stats.draw_binding_error[eye]=error;
    }
    static void* getOrCreate(void* camera,int32_t multipass,const void* method) {
        HgGetOrCreateNative next=nullptr;
        {std::lock_guard<std::mutex> lock(routeMutex);next=reinterpret_cast<HgGetOrCreateNative>(nextGetOrCreate);}
        if(!next)throw std::runtime_error("HG draw binding has no GetOrCreate original trampoline");
        void* actual=next(camera,multipass,method); // Preserve original reference result and all arguments.
        std::shared_ptr<State> observed;int index=-1;uint64_t generation=0;
        void* additional=nullptr;HgDrawBindingValidator validator=nullptr;void* validatorContext=nullptr;
        {
            std::lock_guard<std::mutex> lock(routeMutex);
            const auto* context=currentPrepare;
            if(!context||!same_scope(context->state,context->eye,context->generation))return actual;
            observed=context->state;index=context->eye;generation=context->generation;
            auto& s=*observed;auto& eye=s.eyes[unsigned(index)];
            if(!s.stats.draw_binding_required||!s.stats.get_or_create_hook||camera!=eye.camera)return actual;
            if(s.stats.frame_draw_binding_failures[unsigned(index)])return actual;
            if(!actual){reject_binding(s,unsigned(index),"GetOrCreate returned null for private eye");return actual;}
            if(eye.drawHg) {
                if(eye.drawHg!=actual)reject_binding(s,unsigned(index),"GetOrCreate changed HG identity within one eye render");
                return actual;
            }
            const auto& other=s.eyes[unsigned(index)^1];
            if(actual==other.hg||actual==other.drawHg){reject_binding(s,unsigned(index),"Draw HG identity is shared with the other eye");return actual;}
            additional=eye.additional;validator=s.validator;validatorContext=s.validatorContext;
        }
        std::string reason;bool valid=false;
        try {valid=validator&&validator(validatorContext,unsigned(index),actual,camera,additional,reason);}
        catch(const std::exception& ex){reason=std::string("HG binding validation exception: ")+ex.what();}
        catch(...){reason="HG binding validation exception";}
        {
            std::lock_guard<std::mutex> lock(routeMutex);
            if(!same_scope(observed,index,generation))return actual;
            auto& s=*observed;auto& eye=s.eyes[unsigned(index)];
            if(!valid){reject_binding(s,unsigned(index),reason.empty()?"HG draw binding validation failed":reason);return actual;}
            if(eye.drawHg&&eye.drawHg!=actual){reject_binding(s,unsigned(index),"Reentrant HG binding changed the selected identity");return actual;}
            if(s.stats.frame_draw_binding_failures[unsigned(index)])return actual;
            eye.drawHg=actual;++s.stats.frame_draw_bindings[unsigned(index)];
            s.stats.frame_draw_binding_changed[unsigned(index)]=actual!=eye.hg;
            s.stats.frame_draw_multipass[unsigned(index)]=multipass;
        }
        return actual;
    }

    static uint8_t prepare(void* pipeline,void* camera,void** additional,void** hg,void* culling,const void* method) {
        HgFrameParametersNative next=nullptr;std::shared_ptr<State> observed;
        int scopedEye=-1;uint64_t generation=0;void* predictedHg=nullptr;void* expectedAdditional=nullptr;
        {
            std::lock_guard<std::mutex> lock(routeMutex);
            next=reinterpret_cast<HgFrameParametersNative>(nextPrepare);
            if(owner&&owner->stats.installed&&owner->stats.frame_parameters_observer) {
                auto& s=*owner;++s.stats.prepare_entries;
                for(unsigned i=0;i<2;++i)if(s.eyes[i].camera&&s.eyes[i].camera==camera) {
                    ++s.stats.prepare_calls[i];
                    if(s.stats.scope_active&&s.stats.active_eye==int(i)&&
                       (!s.stats.draw_binding_required||s.scopeThread==std::this_thread::get_id())) {
                        ++s.stats.frame_prepare_calls[i];observed=owner;scopedEye=int(i);generation=s.scopeGeneration;
                        predictedHg=s.eyes[i].hg;expectedAdditional=s.eyes[i].additional;
                    }
                    break;
                }
            }
        }
        // Even an unrelated/nested Prepare masks an outer context, so its
        // GetOrCreate cannot silently bind the outer eye. RAII restores on throw.
        PrepareScope scope(observed,generation,scopedEye);
        if(!next)throw std::runtime_error("HG frame-parameters observer has no original trampoline");
        uint8_t result=0;
        try {result=next(pipeline,camera,additional,hg,culling,method);}
        catch(...) {
            std::lock_guard<std::mutex> lock(routeMutex);
            if(same_scope(observed,scopedEye,generation)&&observed->stats.draw_binding_required)
                reject_binding(*observed,unsigned(scopedEye),"HG parameter preparation threw",true);
            throw;
        }
        {
            std::lock_guard<std::mutex> lock(routeMutex);
            if(observed&&owner==observed&&observed->stats.installed&&observed->stats.frame_parameters_observer&&
               observed->stats.scope_active&&observed->stats.active_eye==scopedEye&&observed->scopeGeneration==generation) {
                auto& s=*observed;const unsigned index=unsigned(scopedEye);
                if(result==1) {
                    ++s.stats.frame_prepare_successes[index];
                    void* expectedHg=s.stats.draw_binding_required?s.eyes[index].drawHg:predictedHg;
                    const bool hgMatches=hg&&*hg==expectedHg&&expectedHg;
                    const bool additionalMatches=additional&&*additional==expectedAdditional;
                    if(!hgMatches)++s.stats.frame_prepare_hg_mismatch[index];
                    if(!additionalMatches)++s.stats.frame_prepare_additional_mismatch[index];
                    if(s.stats.draw_binding_required) {
                        if(!hgMatches||!additionalMatches)
                            reject_binding(s,index,"HG preparation output does not match the validated draw binding",true);
                        else if(!s.stats.frame_draw_binding_failures[index])s.prepareValidated[index]=true;
                    }
                } else if(s.stats.draw_binding_required) {
                    // Never inspect out parameters on false or exceptional exits.
                    reject_binding(s,index,"HG parameter preparation did not return true",true);
                }
            }
        }
        return result;
    }

    static HgProjectionMatrix* route(bool build,HgProjectionMatrix* result,void* instance,void* camera,const void* method) {
        HgProjectionNative next=nullptr;HgProjectionMatrix copied{};bool override=false;
        {
            std::lock_guard<std::mutex> lock(routeMutex);
            next=reinterpret_cast<HgProjectionNative>(build?nextBuild:nextNonOblique);
            if(owner&&owner->stats.installed) {
                auto& stats=owner->stats;
                auto& calls=build?stats.build_calls:stats.non_oblique_calls;
                ++calls.entries;
                const int index=stats.active_eye;
                const bool inScope=stats.scope_active&&index>=0&&index<2;
                for(unsigned i=0;i<2;++i) {
                    const auto& eye=owner->eyes[i];
                    const void* privateInstance=build?(stats.draw_binding_required?eye.drawHg:eye.hg):eye.additional;
                    if(eye.camera&&privateInstance&&camera==eye.camera&&instance==privateInstance&&
                       (!inScope||unsigned(index)!=i))++calls.outside_scope_private[i];
                }
                if(inScope) {
                    const unsigned eyeIndex=unsigned(index);const auto& eye=owner->eyes[eyeIndex];
                    ++calls.scope_entries[eyeIndex];++calls.frame_scope_entries[eyeIndex];
                    const bool sameCamera=camera==eye.camera;
                    const void* selectedHg=stats.draw_binding_required?eye.drawHg:eye.hg;
                    const bool sameInstance=instance&&instance==(build?selectedHg:eye.additional);
                    const bool currentThread=owner->scopeThread==std::this_thread::get_id();
                    const bool inPrepare=currentPrepare&&currentPrepare->state==owner&&currentPrepare->eye==index&&
                        currentPrepare->generation==owner->scopeGeneration;
                    const bool drawReady=!stats.draw_binding_required||(currentThread&&eye.drawHg&&
                        (inPrepare||(!currentPrepare&&owner->prepareValidated[eyeIndex]))&&!stats.frame_draw_binding_failures[eyeIndex]);
                    if(sameCamera&&!sameInstance) {
                        ++calls.same_camera_wrong_instance[eyeIndex];++calls.frame_same_camera_wrong_instance[eyeIndex];
                    } else if(sameInstance&&!sameCamera) {
                        ++calls.same_instance_wrong_camera[eyeIndex];++calls.frame_same_instance_wrong_camera[eyeIndex];
                    }
                    if(stats.draw_binding_required&&(sameCamera||sameInstance)&&(!sameCamera||!sameInstance||!drawReady))
                        reject_binding(*owner,eyeIndex,(!sameCamera||!sameInstance)?"Projection used an HG/additional/Camera identity other than the validated draw binding":
                            "Projection ran outside its validated HG preparation thread/context");
                    if(sameCamera&&sameInstance&&drawReady) {
                        copied=eye.matrix;override=true;
                        if(build){++owner->stats.build_hits;++owner->stats.frame_build_hits[unsigned(index)];}
                        else {++owner->stats.non_oblique_hits;++owner->stats.frame_non_oblique_hits[unsigned(index)];}
                    }
                }
            }
        }
        // Neither original HG code nor Unity/host APIs execute under our lock.
        if(override){std::memcpy(result,&copied,sizeof(copied));return result;}
        if(next)return next(result,instance,camera,method);
        // A host claiming hook success without an original is rejected by
        // install. Avoid jumping through null if that host still invokes it.
        *result={};return result;
    }
    static HgProjectionMatrix* build(HgProjectionMatrix* out,void* hg,void* camera,const void* method){return route(true,out,hg,camera,method);}
    static HgProjectionMatrix* nonOblique(HgProjectionMatrix* out,void* additional,void* camera,const void* method){return route(false,out,additional,camera,method);}
};

HgProjectionHook::HgProjectionHook():impl_(std::make_unique<Impl>()){}
HgProjectionHook::~HgProjectionHook(){clear();}
bool HgProjectionHook::install(const BE_HostApiV1* host,std::string& error,HgDrawBindingValidator validator,void* validatorContext) {
    error.clear();clear();
    {
        std::lock_guard<std::mutex> lock(Impl::routeMutex);
        impl_->state->stats.installed=false;impl_->state->stats.frame_parameters_observer=false;
        impl_->state->stats.frame_parameters_status="not_installed";
    }
    if(!host||host->abi_version!=BETTER_ENDFIELD_MODULE_ABI_V1||!host->resolve_method||!host->create_hook||!host->release_module_hooks) {
        error="HG projection hook requires EML method resolution, native hooks and hook cleanup";return false;
    }
    const BE_MethodDescriptorV1 descriptors[]{
        {"HG.RenderPipelines.Runtime.dll","HG.Rendering.Runtime","HGCamera","BuildSceneRTAspectProjection","UnityEngine.Camera","UnityEngine.Matrix4x4",1},
        {"HG.RenderPipelines.Runtime.dll","HG.Rendering.Runtime","HGAdditionalCameraData","GetNonObliqueProjection","UnityEngine.Camera","UnityEngine.Matrix4x4",1}
    };
    BE_ResolvedMethodV1 methods[2]{};
    for(unsigned i=0;i<2;++i) {
        if(host->resolve_method(host->context,&descriptors[i],&methods[i])!=BE_Result_Ok||!methods[i].method_info||!methods[i].method_pointer) {
            error="HG projection method unavailable: "+std::string(descriptors[i].class_name)+"."+descriptors[i].method_name;return false;
        }
    }
    if(methods[0].method_pointer==methods[1].method_pointer){error="HG projection methods unexpectedly share one native target";return false;}
    {
        std::lock_guard<std::mutex> lock(Impl::routeMutex);
        if(Impl::owner){Impl::owner->stats.installed=false;Impl::owner->stats.scope_active=false;Impl::owner->stats.active_eye=-1;Impl::owner->eyes={};}
        impl_->state->stats={};impl_->state->stats.draw_binding_required=validator!=nullptr;
        impl_->state->validator=validator;impl_->state->validatorContext=validatorContext;
        impl_->state->prepareValidated={};Impl::owner=impl_->state;
        // release_module_hooks makes host nodes pass through but does not wait
        // for an already-entered detour. Keep its process-stable relay usable
        // until create_hook publishes the new original into the same slot.
        // Clearing these slots here would make an old callback see null.
    }
    const auto fail=[&](const char* name){clear();error="HG projection hook installation failed: "+std::string(name);return false;};
    if(host->create_hook(host->context,"quest3.vrvd",methods[0].method_pointer,reinterpret_cast<void*>(Impl::build),&Impl::nextBuild)!=BE_Result_Ok||!Impl::nextBuild)
        return fail("BuildSceneRTAspectProjection");
    if(host->create_hook(host->context,"quest3.vrvd",methods[1].method_pointer,reinterpret_cast<void*>(Impl::nonOblique),&Impl::nextNonOblique)!=BE_Result_Ok||!Impl::nextNonOblique)
        return fail("GetNonObliqueProjection");
    {
        std::lock_guard<std::mutex> lock(Impl::routeMutex);impl_->state->stats.installed=true;
    }
    // Optional pipeline entry observation. Missing client metadata or an
    // unavailable hook does not loosen the mandatory per-eye Build check.
    const BE_MethodDescriptorV1 prepareDescriptor{
        "HG.RenderPipelines.Runtime.dll","HG.Rendering.Runtime","HGRenderPipeline","TryCalculateFrameParameters",
        "UnityEngine.Camera|HG.Rendering.Runtime.HGAdditionalCameraData&|HG.Rendering.Runtime.HGCamera&|UnityEngine.Rendering.ScriptableCullingParameters&",
        "System.Boolean",4};
    BE_ResolvedMethodV1 prepareMethod{};
    const BE_Result resolved=host->resolve_method(host->context,&prepareDescriptor,&prepareMethod);
    std::string observerStatus="method_unavailable";bool observerInstalled=false;
    if(resolved==BE_Result_Ok&&prepareMethod.method_info&&prepareMethod.method_pointer) {
        if(prepareMethod.method_pointer==methods[0].method_pointer||prepareMethod.method_pointer==methods[1].method_pointer)
            observerStatus="unexpected_shared_target";
        else {
            const BE_Result hooked=host->create_hook(host->context,"quest3.vrvd",prepareMethod.method_pointer,
                reinterpret_cast<void*>(Impl::prepare),&Impl::nextPrepare);
            if(hooked==BE_Result_Ok&&!Impl::nextPrepare) {
                clear();std::lock_guard<std::mutex> lock(Impl::routeMutex);
                impl_->state->stats.installed=false;impl_->state->stats.frame_parameters_status="host_missing_original";
                error="HG frame-parameters observer host returned hook success without an original trampoline";return false;
            }
            observerInstalled=hooked==BE_Result_Ok&&Impl::nextPrepare;
            observerStatus=observerInstalled?"installed":"hook_installation_failed";
        }
    }
    {
        std::lock_guard<std::mutex> lock(Impl::routeMutex);
        impl_->state->stats.frame_parameters_observer=observerInstalled;
        impl_->state->stats.frame_parameters_status=observerStatus;
    }
    if(validator) {
        if(!observerInstalled){clear();std::lock_guard<std::mutex> lock(Impl::routeMutex);impl_->state->stats.installed=false;
            error="HG draw binding requires TryCalculateFrameParameters: "+observerStatus;return false;}
        const BE_MethodDescriptorV1 descriptor{ "HG.RenderPipelines.Runtime.dll","HG.Rendering.Runtime","HGCamera","GetOrCreate",
            "UnityEngine.Camera|System.Int32","HG.Rendering.Runtime.HGCamera",2};
        BE_ResolvedMethodV1 method{};
        if(host->resolve_method(host->context,&descriptor,&method)!=BE_Result_Ok||!method.method_info||!method.method_pointer||
           method.method_pointer==methods[0].method_pointer||method.method_pointer==methods[1].method_pointer||
           method.method_pointer==prepareMethod.method_pointer) {
            clear();std::lock_guard<std::mutex> lock(Impl::routeMutex);impl_->state->stats.installed=false;
            error="HG draw binding requires a distinct GetOrCreate native method";return false;
        }
        if(host->create_hook(host->context,"quest3.vrvd",method.method_pointer,reinterpret_cast<void*>(Impl::getOrCreate),&Impl::nextGetOrCreate)!=BE_Result_Ok||!Impl::nextGetOrCreate) {
            clear();std::lock_guard<std::mutex> lock(Impl::routeMutex);impl_->state->stats.installed=false;
            error="HG draw binding GetOrCreate hook installation failed";return false;
        }
        std::lock_guard<std::mutex> lock(Impl::routeMutex);impl_->state->stats.get_or_create_hook=true;
    }
    return true;
}
bool HgProjectionHook::set_eye(unsigned index,void* hg,void* camera,void* additional,const float matrix[16],std::string& error) {
    error.clear();
    if(index>1||!hg||!camera||!additional||!matrix){error="HG projection eye binding is incomplete";return false;}
    for(unsigned i=0;i<16;++i)if(!std::isfinite(matrix[i])){error="HG projection eye matrix is not finite";return false;}
    std::lock_guard<std::mutex> lock(Impl::routeMutex);auto& s=*impl_->state;
    if(Impl::owner!=impl_->state||!s.stats.installed){error="HG projection hooks are not installed";return false;}
    if(s.stats.scope_active){error="Cannot rebind HG projection during an eye render";return false;}
    const auto& other=s.eyes[index^1];
    if(other.hg==hg||other.camera==camera||other.additional==additional){error="HG projection eyes must use separate camera objects";return false;}
    auto& eye=s.eyes[index];eye.hg=hg;eye.camera=camera;eye.additional=additional;std::memcpy(eye.matrix.values,matrix,64);return true;
}
bool HgProjectionHook::begin_eye(unsigned index,std::string& error) {
    error.clear();std::lock_guard<std::mutex> lock(Impl::routeMutex);auto& s=*impl_->state;
    if(index>1||Impl::owner!=impl_->state||!s.stats.installed||!s.eyes[index].hg||!s.eyes[index].camera||!s.eyes[index].additional) {
        error="HG projection eye scope is not ready";return false;
    }
    if(s.stats.scope_active){error="HG projection eye scopes cannot overlap";return false;}
    s.stats.frame_build_hits[index]=s.stats.frame_non_oblique_hits[index]=0;
    s.eyes[index].drawHg=nullptr;s.prepareValidated[index]=false;
    s.stats.frame_draw_bindings[index]=s.stats.frame_draw_binding_failures[index]=s.stats.frame_draw_binding_changed[index]=s.stats.frame_prepare_validation_failures[index]=0;
    s.stats.frame_draw_multipass[index]=0;s.stats.draw_binding_error[index].clear();
    s.stats.frame_prepare_calls[index]=s.stats.frame_prepare_successes[index]=0;
    s.stats.frame_prepare_hg_mismatch[index]=s.stats.frame_prepare_additional_mismatch[index]=0;
    for(auto* calls:{&s.stats.build_calls,&s.stats.non_oblique_calls}) {
        calls->frame_scope_entries[index]=0;
        calls->frame_same_camera_wrong_instance[index]=0;
        calls->frame_same_instance_wrong_camera[index]=0;
    }
    ++s.scopeGeneration;s.scopeThread=std::this_thread::get_id();s.stats.active_eye=int(index);s.stats.scope_active=true;return true;
}
bool HgProjectionHook::end_eye(unsigned index,std::string& error) {
    error.clear();std::lock_guard<std::mutex> lock(Impl::routeMutex);auto& s=*impl_->state;
    const bool matching=index<2&&s.stats.scope_active&&s.stats.active_eye==int(index);
    s.stats.scope_active=false;s.stats.active_eye=-1;
    if(!matching){error="HG projection eye scope ended out of order";return false;}
    if(s.stats.draw_binding_required&&(!s.prepareValidated[index]||!s.eyes[index].drawHg||s.stats.frame_draw_binding_failures[index]||s.stats.frame_prepare_calls[index]!=s.stats.frame_prepare_successes[index])) {
        error="Eye "+std::to_string(index)+": HG draw binding rejected; stereo frame rejected [bindings="+
            std::to_string(s.stats.frame_draw_bindings[index])+" changed="+std::to_string(s.stats.frame_draw_binding_changed[index])+
            " failures="+std::to_string(s.stats.frame_draw_binding_failures[index])+" prepared="+std::to_string(s.prepareValidated[index])+
            "; "+(s.stats.draw_binding_error[index].empty()?"no validated HG parameter preparation":s.stats.draw_binding_error[index])+"]";
        return false;
    }
    if(!s.stats.frame_build_hits[index]) {
        const auto& build=s.stats.build_calls;const auto& nonOblique=s.stats.non_oblique_calls;
        const uint64_t scope=build.frame_scope_entries[index];
        const uint64_t wrongHg=build.frame_same_camera_wrong_instance[index];
        const uint64_t wrongCamera=build.frame_same_instance_wrong_camera[index];
        const char* reason=!scope?"no Build entries during eye Render":
            wrongHg||wrongCamera?"Build identity mismatch during eye Render":"Build entries observed, but none matched this private eye";
        error="Eye "+std::to_string(index)+": "+reason+"; stereo frame rejected [Build total="+std::to_string(build.entries)+
            " scope="+std::to_string(scope)+" wrongHG="+std::to_string(wrongHg)+" wrongCamera="+std::to_string(wrongCamera)+
            " outsidePrivate="+std::to_string(build.outside_scope_private[index])+"; NonOblique scope="+
            std::to_string(nonOblique.frame_scope_entries[index])+" hits="+std::to_string(s.stats.frame_non_oblique_hits[index])+
            "; Prepare "+s.stats.frame_parameters_status+" calls="+std::to_string(s.stats.frame_prepare_calls[index])+
            " true="+std::to_string(s.stats.frame_prepare_successes[index])+" wrongHG="+
            std::to_string(s.stats.frame_prepare_hg_mismatch[index])+" wrongAdditional="+
            std::to_string(s.stats.frame_prepare_additional_mismatch[index])+"]";
        return false;
    }
    return true;
}
void HgProjectionHook::clear_eye(unsigned index) {
    if(index>1)return;std::lock_guard<std::mutex> lock(Impl::routeMutex);auto& s=*impl_->state;
    if(s.stats.active_eye==int(index)){++s.scopeGeneration;s.stats.scope_active=false;s.stats.active_eye=-1;}s.eyes[index]={};
}
void HgProjectionHook::clear() {
    std::lock_guard<std::mutex> lock(Impl::routeMutex);auto& s=*impl_->state;
    ++s.scopeGeneration;s.stats.scope_active=false;s.stats.active_eye=-1;s.eyes={};
}
HgProjectionSnapshot HgProjectionHook::snapshot() const {
    std::lock_guard<std::mutex> lock(Impl::routeMutex);auto result=impl_->state->stats;
    result.installed=result.installed&&Impl::owner==impl_->state;return result;
}
}
