#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <vector>
#include <cstdint>
namespace vrvd {
// Explicit waiting feedback, never passed off as captured game UI.
inline bool make_menu_wait_panel(unsigned w,unsigned h,std::vector<uint8_t>& pixels){
 if(w<256||h<256||w>4096||h>4096)return false;
 HDC dc=CreateCompatibleDC(nullptr);if(!dc)return false;
 BITMAPINFO info{};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);info.bmiHeader.biWidth=w;info.bmiHeader.biHeight=-LONG(h);info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;info.bmiHeader.biCompression=BI_RGB;
 void* bits=nullptr;HBITMAP bmp=CreateDIBSection(dc,&info,DIB_RGB_COLORS,&bits,nullptr,0);
 if(!bmp||!bits){if(bmp)DeleteObject(bmp);DeleteDC(dc);return false;}
 auto oldBmp=SelectObject(dc,bmp);RECT r{0,0,LONG(w),LONG(h)};HBRUSH bg=CreateSolidBrush(RGB(22,32,48));FillRect(dc,&r,bg);DeleteObject(bg);
 auto font=CreateFontW(-int(h/16),0,0,0,FW_MEDIUM,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,L"Microsoft YaHei UI");auto oldFont=font?SelectObject(dc,font):nullptr;
 SetTextColor(dc,RGB(230,238,248));SetBkMode(dc,TRANSPARENT);r={LONG(w/12),LONG(h/3),LONG(w*11/12),LONG(h*3/4)};
 DrawTextW(dc,L"等待游戏菜单画面\n\n若持续显示，请查看 EML 中的菜单诊断。",-1,&r,DT_CENTER|DT_WORDBREAK|DT_NOPREFIX);
 GdiFlush();pixels.resize(size_t(w)*h*4);auto p=static_cast<const uint8_t*>(bits);
 for(size_t i=0;i<pixels.size();i+=4){pixels[i]=p[i+2];pixels[i+1]=p[i+1];pixels[i+2]=p[i];pixels[i+3]=255;}
 if(font){SelectObject(dc,oldFont);DeleteObject(font);}SelectObject(dc,oldBmp);DeleteObject(bmp);DeleteDC(dc);return true;
}
}
