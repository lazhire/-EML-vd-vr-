#pragma once
#include "managed_read.h"
#include <atomic>
#include <algorithm>
#include <chrono>

namespace vrvd {
// Game-thread owner. Persistent FinalResult extraction uses an owned RTHandle.
// No window capture, Canvas rebinding, camera rendering or guessed native offsets.
// ReadPixels is deliberately retained in this diagnostic milestone.
class EngineFinalCapture: private ManagedRead {
 BE_ResolvedMethodV1 uiCam{},mainCam{},fallbackCam{},getHG{},finalSize{},alloc{},reg{},unreg{},release{},
  rtCtor{},rtCreate{},rtRelease{},texCtor{},destroy{},blit{},getActive{},setActive{},clear{},readPixels{},raw{},length{},copy{},frame{};
 BE_ResolvedClassV1 rtClass{},texClass{};
 Root camera,hg,target,handle,scaled,cpu,activeBackup;
 bool registration_failed=false;
 bool ready=false,registered=false,active_dirty=false,valid_image=false,hook_installed=false;
 uint32_t width=0,height=0;int seed_frame=-1;
 uint64_t seed_hash=0;
 std::chrono::steady_clock::time_point requested_at{};
 using EndFn=void(*)(void*,void*,void*);
 inline static EndFn nextEnd=nullptr;
 inline static std::atomic<void*> observedCamera{nullptr};
 inline static std::atomic<uint64_t> end_calls{0},matched_ends{0};
 static void end_camera(void* context,void* cam,void* method){
  if(nextEnd)nextEnd(context,cam,method);
  ++end_calls;if(cam&&cam==observedCamera.load())++matched_ends;
 }
 bool restore(std::string& e){
  if(!active_dirty)return true;void* a[]{activeBackup.p};
  if(!call(setActive,nullptr,a,e))return false;
  active_dirty=false;activeBackup.clear();return true;
 }
 bool make_rt(Root& root,int w,int h,std::string& e){
  if(!root.set(host,host->object_new(host->context,rtClass.class_info))||!root.p){e="Cannot root engine render target";return false;}
  int depth=0,format=0,linear=1;uint8_t created=0;void* a[]{&w,&h,&depth,&format,&linear};
  return call(rtCtor,root.p,a,e)&&value(rtCreate,root.p,created,e)&&created;
 }
 bool own_images(uint32_t w,uint32_t h,std::string& e){
  if(scaled.p&&cpu.p&&width==w&&height==h)return true;
  if(scaled.p||cpu.p){e="Readback dimensions changed; stop VR before changing settings";return false;}
  width=w;height=h;if(!make_rt(scaled,int(w),int(h),e))return false;
  if(!cpu.set(host,host->object_new(host->context,texClass.class_info))||!cpu.p){e="Cannot root CPU readback texture";return false;}
  int iw=w,ih=h,format=4;uint8_t no=0,yes=1;void* a[]{&iw,&ih,&format,&no,&yes};return call(texCtor,cpu.p,a,e);
 }
 bool read_image(std::vector<uint8_t>& image,std::string& e){
  void* old=nullptr;if(!invoke(getActive,nullptr,nullptr,old,e)||!activeBackup.set(host,old))return false;
  active_dirty=true;void* a[]{target.p,scaled.p};void* set[]{scaled.p};
  bool ok=call(blit,nullptr,a,e)&&call(setActive,nullptr,set,e);
  struct Rect{float x,y,w,h;} rect{0,0,float(width),float(height)};int zero=0;uint8_t no=0;void* rp[]{&rect,&zero,&zero,&no};
  void* bytes=nullptr;Root hold;int count=0;image.resize(size_t(width)*height*4);
  ok=ok&&call(readPixels,cpu.p,rp,e)&&invoke(raw,cpu.p,nullptr,bytes,e)&&bytes&&hold.set(host,bytes)&&value(length,bytes,count,e)&&count==int(image.size());
  if(ok){intptr_t address=reinterpret_cast<intptr_t>(image.data());void* cp[]{bytes,&zero,&address,&count};ok=call(copy,nullptr,cp,e);}
  std::string restoreError;if(!restore(restoreError)){e="Engine readback could not restore active RT: "+restoreError;return false;}
  if(!ok&&e.empty())e="Engine readback returned invalid pixels";return ok;
 }
 static uint64_t hash(const std::vector<uint8_t>& p){uint64_t h=14695981039346656037ull;for(auto b:p){h^=b;h*=1099511628211ull;}return h;}
 bool seed(std::string& e){
  void* old=nullptr;if(!invoke(getActive,nullptr,nullptr,old,e)||!activeBackup.set(host,old))return false;
  active_dirty=true;void* a[]{target.p};uint8_t no=0,yes=1;float depth=1;
  struct Color{float r,g,b,a;} marker{.173f,.291f,.827f,1.f};void* c[]{&no,&yes,&marker,&depth};
  bool ok=call(setActive,nullptr,a,e)&&call(clear,nullptr,c,e);std::string restoreError;
  if(!restore(restoreError)){e="Engine seed could not restore active RT: "+restoreError;return false;}
  if(!ok)return false;std::vector<uint8_t> p;if(!read_image(p,e))return false;seed_hash=hash(p);return true;
 }
 bool choose(void* manager,const std::string& preference,void*& cam,std::string& e){
  cam=nullptr;void* p=nullptr;
  if(preference=="ui"&&!manager){e="UI camera requires CameraManager";return false;}
  if(manager&&preference!="main"){
   if(!invoke(uiCam,manager,nullptr,p,e))return false;
   if(p){cam=p;selected_source="ui";return true;}
   if(preference=="ui"){e="CameraManager.uiCamera is null";return false;}
  }
  if(manager&&!invoke(mainCam,manager,nullptr,p,e))return false;
  if(!p&&!invoke(fallbackCam,nullptr,nullptr,p,e))return false;
  if(!p){e="No game camera is available for FinalResult extraction";return false;}
  cam=p;selected_source="main";return true;
 }
 bool detach(std::string& e){
  if(!registered)return true;int type=3,duration=0;void* a[]{&type,&duration,handle.p};
  if(!call(unreg,hg.p,a,e))return false;registered=false;return true;
 }
public:
 std::string status="not_resolved",selected_source="none",stage="idle";
 uint64_t polls=0,requests=0,frames=0,seed_rejections=0,readbacks=0;
 uint32_t source_width=0,source_height=0;
 double mean_rgb=0,black_fraction=0;
 ~EngineFinalCapture(){camera.abandon();hg.abandon();target.abandon();handle.abandon();scaled.abandon();cpu.abandon();activeBackup.abandon();}
 uint64_t camera_end_calls()const{return end_calls.load();}
 uint64_t selected_camera_end_calls()const{return matched_ends.load();}
 bool ready_for_readback()const{return valid_image;}
 bool resolve(const BE_HostApiV1* api,std::string& e){
  if(ready)return true;host=api;stage="resolve_interfaces";
  auto b=[&](BE_ResolvedMethodV1& m,const char* assembly,const char* ns,const char* cls,const char* name,const char* args,const char* ret,unsigned count){return bind(m,assembly,ns,cls,name,args,ret,count,e);};
  const char* core="UnityEngine.CoreModule.dll";const char* render="Unity.RenderPipelines.Core.Runtime.dll";const char* hgrp="HG.RenderPipelines.Runtime.dll";
  bool ok=b(uiCam,"Gameplay.Beyond.dll","Beyond.Gameplay.View","CameraManager","get_uiCamera",nullptr,"UnityEngine.Camera",0)&&
   b(mainCam,"Gameplay.Beyond.dll","Beyond.Gameplay.View","CameraManager","get_mainCamera",nullptr,"UnityEngine.Camera",0)&&
   b(fallbackCam,core,"UnityEngine","Camera","get_main",nullptr,"UnityEngine.Camera",0)&&
   b(getHG,hgrp,"HG.Rendering.Runtime","HGCamera","GetOrCreate","UnityEngine.Camera|System.Int32","HG.Rendering.Runtime.HGCamera",2)&&
   b(finalSize,hgrp,"HG.Rendering.Runtime","HGCamera","get_finalRTSize",nullptr,nullptr,0)&&
   b(reg,hgrp,"HG.Rendering.Runtime","HGCamera","RegisterRTExtraction","HG.Rendering.Runtime.RTExtractionType|HG.Rendering.Runtime.RTExtractionDuration|UnityEngine.Rendering.RTHandle","System.Void",3)&&
   b(unreg,hgrp,"HG.Rendering.Runtime","HGCamera","UnRegisterRTExtraction","HG.Rendering.Runtime.RTExtractionType|HG.Rendering.Runtime.RTExtractionDuration|UnityEngine.Rendering.RTHandle","System.Void",3)&&
   b(alloc,render,"UnityEngine.Rendering","RTHandles","Alloc","UnityEngine.RenderTexture","UnityEngine.Rendering.RTHandle",1)&&
   b(release,render,"UnityEngine.Rendering","RTHandle","Release",nullptr,"System.Void",0)&&
   b(rtCtor,core,"UnityEngine","RenderTexture",".ctor","System.Int32|System.Int32|System.Int32|UnityEngine.RenderTextureFormat|UnityEngine.RenderTextureReadWrite","System.Void",5)&&
   b(rtCreate,core,"UnityEngine","RenderTexture","Create",nullptr,"System.Boolean",0)&&
   b(rtRelease,core,"UnityEngine","RenderTexture","Release",nullptr,"System.Void",0)&&
   b(texCtor,core,"UnityEngine","Texture2D",".ctor","System.Int32|System.Int32|UnityEngine.TextureFormat|System.Boolean|System.Boolean","System.Void",5)&&
   b(destroy,core,"UnityEngine","Object","Destroy","UnityEngine.Object","System.Void",1)&&
   b(blit,core,"UnityEngine","Graphics","Blit","UnityEngine.Texture|UnityEngine.RenderTexture","System.Void",2)&&
   b(getActive,core,"UnityEngine","RenderTexture","get_active",nullptr,"UnityEngine.RenderTexture",0)&&
   b(setActive,core,"UnityEngine","RenderTexture","set_active","UnityEngine.RenderTexture","System.Void",1)&&
   b(clear,core,"UnityEngine","GL","Clear","System.Boolean|System.Boolean|UnityEngine.Color|System.Single","System.Void",4)&&
   b(readPixels,core,"UnityEngine","Texture2D","ReadPixels","UnityEngine.Rect|System.Int32|System.Int32|System.Boolean","System.Void",4)&&
   b(raw,core,"UnityEngine","Texture2D","GetRawTextureData",nullptr,"System.Byte[]",0)&&
   b(length,"mscorlib.dll","System","Array","get_Length",nullptr,"System.Int32",0)&&
   b(copy,"mscorlib.dll","System.Runtime.InteropServices","Marshal","Copy","System.Byte[]|System.Int32|System.IntPtr|System.Int32","System.Void",4)&&
   b(frame,core,"UnityEngine","Time","get_frameCount",nullptr,"System.Int32",0)&&
   host->resolve_class(host->context,core,"UnityEngine","RenderTexture",&rtClass)==BE_Result_Ok&&
   host->resolve_class(host->context,core,"UnityEngine","Texture2D",&texClass)==BE_Result_Ok;
  if(!ok){status="engine_binding_error";if(e.empty())e="Engine image classes unavailable";return false;}
  if(!hook_installed){
   BE_ResolvedMethodV1 end{};
   if(b(end,core,"UnityEngine.Rendering","RenderPipelineManager","EndCameraRendering","UnityEngine.Rendering.ScriptableRenderContext|UnityEngine.Camera","System.Void",2)&&end.method_pointer){
    hook_installed=host->create_hook(host->context,"quest3.vrvd",end.method_pointer,reinterpret_cast<void*>(end_camera),reinterpret_cast<void**>(&nextEnd))==BE_Result_Ok;
   }
   e.clear(); // Optional observer never gates extraction or changes game rendering.
  }
  ready=true;status="engine_ready";return true;
 }
 bool poll(void* manager,const std::string& preference,uint32_t w,uint32_t h,std::vector<uint8_t>& out,bool& fresh,std::string& e){
  ++polls;fresh=false;e.clear();
  auto fail=[&](){status="engine_capture_error";e=stage+": "+(e.empty()?"managed operation failed":e);return false;};
  if(!ready){e="Engine interfaces unresolved";return fail();}
  stage="restore_active_target";if(!restore(e))return fail();
  if(registration_failed){stage="cleanup_failed_registration";if(!cleanup(e))return fail();}
  if(w<256||h<256||w>4096||h>4096){e="Menu readback dimensions must be 256..4096";return fail();}
  stage="select_camera";void* selected=nullptr;if(!choose(manager,preference,selected,e))return fail();
  int current=-1;if(!value(frame,nullptr,current,e))return fail();
  if(camera.p!=selected){if(!cleanup(e))return fail();}
  if(registered){
   struct Size{int w,h;} size{};stage="check_final_size";
   if(!value(finalSize,hg.p,size,e))return fail();
   if(size.w>0&&size.h>0&&(uint32_t(size.w)!=source_width||uint32_t(size.h)!=source_height)){
    if(!cleanup(e))return fail();
   }
  }
  if(!registered){
   stage="prepare_final_target";
   if(!camera.set(host,selected)){e="Cannot retain selected camera";return fail();}
   observedCamera.store(selected);int zero=0;void* a[]{selected,&zero};void* object=nullptr;
   if(!invoke(getHG,nullptr,a,object,e)||!object||!hg.set(host,object))return fail();
   struct Size{int w,h;} size{};if(!value(finalSize,hg.p,size,e))return fail();
   if(size.w<=0||size.h<=0){status="waiting_engine_camera_size";return true;}
   if(size.w>8192||size.h>8192){e="Final target exceeds diagnostic allocation limit";return fail();}
   source_width=size.w;source_height=size.h;
   if(!own_images(w,h,e))return fail();
   if(!target.p&&!make_rt(target,size.w,size.h,e))return fail();
   if(!handle.p){void* a[]{target.p};void* wrapper=nullptr;if(!invoke(alloc,nullptr,a,wrapper,e)||!wrapper||!handle.set(host,wrapper))return fail();}
   stage="seed_unwritten_target";if(!seed(e))return fail();
   stage="register_final_result";int type=3,duration=0;void* args[]{&type,&duration,handle.p};
   // Treat a throwing registration as possibly registered; cleanup must unregister.
   registered=true;if(!call(reg,hg.p,args,e)){registration_failed=true;return fail();}
   seed_frame=current;valid_image=false;requested_at=std::chrono::steady_clock::now();++requests;status="waiting_engine_final_write";return true;
  }
  if(int64_t(current)-seed_frame<2){status="waiting_engine_render_frames";return true;}
  stage="read_engine_final";std::vector<uint8_t> image;if(!read_image(image,e))return fail();++readbacks;
  if(hash(image)==seed_hash){++seed_rejections;status="waiting_engine_final_write";
   if(std::chrono::steady_clock::now()-requested_at>std::chrono::seconds(3))e="FinalResult target remains unwritten; try the other camera source after stopping VR";
   return true;
  }
  // ReadPixels performs the CPU synchronization. Changed sentinel pixels show a
  // write happened, not that every UI element or current-frame content is correct.
  out.assign(image.size(),0);for(size_t i=3;i<out.size();i+=4)out[i]=255;
  int fw=w,fh=std::max(1,int(double(w)*source_height/source_width));if(fh>int(h)){fh=h;fw=std::max(1,int(double(h)*source_width/source_height));}
  int ox=(int(w)-fw)/2,oy=(int(h)-fh)/2;uint64_t sum=0,black=0;
  if(fw==int(w)&&fh==int(h)){
   // Common 16:9 path: copy rows instead of divisions and per-pixel memcpy.
   for(uint32_t y=0;y<h;++y)std::memcpy(out.data()+size_t(y)*w*4,image.data()+size_t(h-1-y)*w*4,size_t(w)*4);
   for(size_t i=0;i<out.size();i+=4){out[i+3]=255;sum+=out[i]+out[i+1]+out[i+2];black+=out[i]<4&&out[i+1]<4&&out[i+2]<4;}
  }else for(int y=0;y<fh;++y)for(int x=0;x<fw;++x){size_t src=(size_t(h-1-uint32_t(y)*h/fh)*w+uint32_t(x)*w/fw)*4,dst=(size_t(oy+y)*w+ox+x)*4;
    std::memcpy(out.data()+dst,image.data()+src,3);sum+=image[src]+image[src+1]+image[src+2];black+=image[src]<4&&image[src+1]<4&&image[src+2]<4;
  }
  mean_rgb=double(sum)/(double(fw)*fh*3);black_fraction=double(black)/(double(fw)*fh);
  valid_image=true;fresh=true;++frames;status="engine_final_pixels_unverified";stage="complete";return true;
 }
 bool cleanup(std::string& e){
  if(!host)return true;
  if(!restore(e)||!detach(e))return false;
  observedCamera.store(nullptr);
  if(handle.p){if(!call(release,handle.p,nullptr,e))return false;handle.clear();target.clear();}
  if(target.p){void* a[]{target.p};if(!call(destroy,nullptr,a,e))return false;target.clear();}
  if(scaled.p){void* a[]{scaled.p};if(!call(destroy,nullptr,a,e))return false;scaled.clear();}
  if(cpu.p){void* a[]{cpu.p};if(!call(destroy,nullptr,a,e))return false;cpu.clear();}
  registration_failed=false;camera.clear();hg.clear();width=height=0;source_width=source_height=0;valid_image=false;seed_frame=-1;status="engine_idle";return true;
 }
 bool resources_alive()const{return registered||camera.p||hg.p||target.p||handle.p||scaled.p||cpu.p||active_dirty;}
 void hooks_released(){ready=false;hook_installed=false;observedCamera.store(nullptr);}
};
}
