#include "unity_gpu_probe.h"
#include <array>
#include <cstring>
#include <exception>

namespace vrvd {
namespace {
constexpr const char* Core = "UnityEngine.CoreModule.dll";
constexpr const char* Owner = "quest3.vrvd";
constexpr int32_t Size = 64;
constexpr int32_t RgbaUnorm = 8; // Unity 2021.3 GraphicsFormat.R8G8B8A8_UNorm.
struct Binding {
    const char* klass;
    const char* name;
    const char* params;
    const char* result;
    uint32_t count;
};
}

struct UnityGpuProbe::Impl {
    enum M {
        GraphicsType, Equals, Destroy, Hide, Ctor, Create, IsCreated, Release,
        SetAA, AA, SetMip, SetAutoMip, Format, SetFormat, Srgb, Width, Height,
        Mips, NativePtr, Black, Blit, Copy, GetActive, SetActive, Count
    };
    inline static const Binding bindings[Count] {
        {"SystemInfo", "get_graphicsDeviceType", nullptr, "UnityEngine.Rendering.GraphicsDeviceType", 0},
        {"Object", "op_Equality", "UnityEngine.Object|UnityEngine.Object", "System.Boolean", 2},
        {"Object", "Destroy", "UnityEngine.Object", "System.Void", 1},
        {"Object", "set_hideFlags", "UnityEngine.HideFlags", "System.Void", 1},
        {"RenderTexture", ".ctor", "System.Int32|System.Int32|System.Int32|UnityEngine.RenderTextureFormat|UnityEngine.RenderTextureReadWrite", "System.Void", 5},
        {"RenderTexture", "Create", nullptr, "System.Boolean", 0},
        {"RenderTexture", "IsCreated", nullptr, "System.Boolean", 0},
        {"RenderTexture", "Release", nullptr, "System.Void", 0},
        {"RenderTexture", "set_antiAliasing", "System.Int32", "System.Void", 1},
        {"RenderTexture", "get_antiAliasing", nullptr, "System.Int32", 0},
        {"RenderTexture", "set_useMipMap", "System.Boolean", "System.Void", 1},
        {"RenderTexture", "set_autoGenerateMips", "System.Boolean", "System.Void", 1},
        {"RenderTexture", "get_graphicsFormat", nullptr, "UnityEngine.Experimental.Rendering.GraphicsFormat", 0},
        {"RenderTexture", "set_graphicsFormat", "UnityEngine.Experimental.Rendering.GraphicsFormat", "System.Void", 1},
        {"RenderTexture", "get_sRGB", nullptr, "System.Boolean", 0},
        {"Texture", "get_width", nullptr, "System.Int32", 0},
        {"Texture", "get_height", nullptr, "System.Int32", 0},
        {"Texture", "get_mipmapCount", nullptr, "System.Int32", 0},
        {"Texture", "GetNativeTexturePtr", nullptr, "System.IntPtr", 0},
        {"Texture2D", "get_blackTexture", nullptr, "UnityEngine.Texture2D", 0},
        {"Graphics", "Blit", "UnityEngine.Texture|UnityEngine.RenderTexture", "System.Void", 2},
        {"Graphics", "CopyTexture", "UnityEngine.Texture|UnityEngine.Texture", "System.Void", 2},
        {"RenderTexture", "get_active", nullptr, "UnityEngine.RenderTexture", 0},
        {"RenderTexture", "set_active", "UnityEngine.RenderTexture", "System.Void", 1}
    };
    struct Ref { void* p = nullptr; uint32_t root = 0; };
    const BE_HostApiV1* host = nullptr;
    std::array<BE_ResolvedMethodV1, Count> methods{};
    BE_ResolvedClassV1 rtClass{};
    // Slot order agrees with the diagnostic layer: source L/R, marker L/R.
    std::array<Ref, 4> textures{};
    std::array<uintptr_t, 4> handles{};
    Ref savedActive;
    bool ready = false;
    bool activePending = false;

    void log(const std::string& error) {
        if (host && host->log) host->log(host->context, Owner, error.c_str());
    }
    bool invoke(M m, void* instance, void** args, void*& result, std::string& error) {
        if (!host || !methods[m].method_info) {
            error = "GPU probe binding unavailable: " + std::string(bindings[m].name);
            return false;
        }
        void* exception = nullptr;
        result = host->runtime_invoke(host->context, methods[m].method_info, instance, args, &exception);
        if (exception) {
            error = "GPU probe managed exception: " + std::string(bindings[m].klass) + "." + bindings[m].name;
            return false;
        }
        return true;
    }
    bool call(M m, void* instance, void** args, std::string& error) {
        void* ignored = nullptr;
        return invoke(m, instance, args, ignored, error);
    }
    template<class T> bool value(M m, void* instance, T& result, std::string& error, void** args = nullptr) {
        void* boxed = nullptr;
        if (!invoke(m, instance, args, boxed, error)) return false;
        void* data = boxed ? host->object_unbox(host->context, boxed) : nullptr;
        if (!data) { error = "GPU probe missing boxed result: " + std::string(bindings[m].name); return false; }
        std::memcpy(&result, data, sizeof(T));
        return true;
    }
    template<class T> bool set(M m, void* instance, T v, std::string& error) {
        void* args[]{&v};
        return call(m, instance, args, error);
    }
    bool retain(Ref& out, void* p, std::string& error) {
        if (out.p || out.root) { error = "GPU probe attempted to overwrite a retained object"; return false; }
        if (!p) return true;
        uint32_t root = host->gchandle_new(host->context, p, 0);
        if (!root) { error = "GPU probe could not retain a managed object"; return false; }
        out = {p, root};
        return true;
    }
    void unroot(Ref& ref) {
        if (ref.root) host->gchandle_free(host->context, ref.root);
        ref = {};
    }
    bool equal(void* a, void* b, bool& result, std::string& error) {
        uint8_t same = 0xff;
        void* args[]{a, b};
        if (!value(Equals, nullptr, same, error, args)) return false;
        if (same > 1) { error = "GPU probe invalid Unity equality result"; return false; }
        result = same != 0;
        return true;
    }
    bool alive(void* p, bool& result, std::string& error) {
        bool dead = true;
        if (!equal(p, nullptr, dead, error)) return false;
        result = !dead;
        return true;
    }
    bool restore(std::string& error) {
        if (!activePending) return true;
        bool living = false;
        if (!alive(savedActive.p, living, error)) return false;
        void* target = living ? savedActive.p : nullptr;
        void* args[]{target};
        if (!call(SetActive, nullptr, args, error)) return false;
        void* actual = nullptr;
        bool same = false;
        if (!invoke(GetActive, nullptr, nullptr, actual, error) || !equal(actual, target, same, error)) return false;
        if (!same) { error = "GPU probe active RenderTexture restoration did not take effect"; return false; }
        activePending = false;
        unroot(savedActive);
        return true;
    }
    bool destroy(Ref& ref, std::string& error) {
        if (!ref.p) { unroot(ref); return true; }
        bool living = false;
        if (!alive(ref.p, living, error)) return false;
        if (living) {
            if (!call(Release, ref.p, nullptr, error)) return false;
            void* args[]{ref.p};
            if (!call(Destroy, nullptr, args, error)) return false;
        }
        unroot(ref);
        return true;
    }
    bool clean() {
        handles.fill(0);
        std::string error;
        // Blit may leave a probe RT active even when it throws. Never release
        // those resources until the original global RT has been restored.
        if (!restore(error)) { log(error); return false; }
        bool ok = true;
        for (auto& texture : textures) {
            error.clear();
            if (!destroy(texture, error)) { log(error); ok = false; }
        }
        return ok;
    }
    bool validate(Ref& texture, uintptr_t& handle, std::string& error) {
        bool living = false;
        uint8_t created = 0, srgb = 0xff;
        int32_t width = 0, height = 0, format = -1, aa = 0, mips = 0;
        if (!alive(texture.p, living, error)) return false;
        if (!living) { error = "GPU probe RenderTexture was destroyed"; return false; }
        if (!value(IsCreated, texture.p, created, error) || !value(Srgb, texture.p, srgb, error) ||
            !value(Width, texture.p, width, error) || !value(Height, texture.p, height, error) ||
            !value(Format, texture.p, format, error) || !value(AA, texture.p, aa, error) ||
            !value(Mips, texture.p, mips, error)) return false;
        if (created != 1 || srgb != 0 || width != Size || height != Size || format != RgbaUnorm || aa != 1 || mips != 1) {
            error = "GPU probe requires created 64x64 linear RGBA8 RTs with one sample and one mip";
            return false;
        }
        // Copy only the IntPtr value. No dereference, VkImage cast or guessed layout.
        if (!value(NativePtr, texture.p, handle, error)) return false;
        if (!handle) { error = "GPU probe RenderTexture has no opaque native handle"; return false; }
        return true;
    }
    bool allocate(Ref& texture, std::string& error) {
        void* object = host->object_new(host->context, rtClass.class_info);
        if (!object) { error = "GPU probe could not allocate RenderTexture"; return false; }
        // Before .ctor an unrootable wrapper has no native texture to destroy.
        if (!retain(texture, object, error)) return false;
        int32_t width = Size, height = Size, depth = 0, argb32 = 0, linear = 1;
        void* args[]{&width, &height, &depth, &argb32, &linear};
        if (!call(Ctor, texture.p, args, error) || !set(Hide, texture.p, int32_t(61), error) ||
            !set(SetFormat, texture.p, RgbaUnorm, error) || !set(SetAA, texture.p, int32_t(1), error) ||
            !set(SetMip, texture.p, uint8_t(0), error) || !set(SetAutoMip, texture.p, uint8_t(0), error)) return false;
        uint8_t created = 0;
        if (!value(Create, texture.p, created, error)) return false;
        if (created != 1) { error = "GPU probe RenderTexture.Create failed"; return false; }
        return true;
    }
};

UnityGpuProbe::UnityGpuProbe() : impl_(std::make_unique<Impl>()) {}
UnityGpuProbe::~UnityGpuProbe() = default;

bool UnityGpuProbe::resolve(const BE_HostApiV1* host, std::string& error) {
    error.clear();
    auto& s = *impl_;
    if (resources_alive()) { error = "Clean up GPU probe resources before rebinding"; return false; }
    s.ready = false;
    s.handles.fill(0);
    if (!host || host->abi_version != BETTER_ENDFIELD_MODULE_ABI_V1 || !host->resolve_method || !host->resolve_class ||
        !host->object_new || !host->runtime_invoke || !host->object_unbox || !host->gchandle_new || !host->gchandle_free) {
        error = "Incomplete EML API for Unity GPU probe";
        return false;
    }
    s.host = host;
    s.methods = {};
    s.rtClass = {};
    for (size_t i = 0; i < Impl::Count; ++i) {
        const auto& b = Impl::bindings[i];
        BE_MethodDescriptorV1 desc{Core, "UnityEngine", b.klass, b.name, b.params, b.result, b.count};
        if (host->resolve_method(host->context, &desc, &s.methods[i]) != BE_Result_Ok || !s.methods[i].method_info) {
            error = "GPU probe API unavailable: " + std::string(b.klass) + "." + b.name;
            return false;
        }
    }
    if (host->resolve_class(host->context, Core, "UnityEngine", "RenderTexture", &s.rtClass) != BE_Result_Ok || !s.rtClass.class_info) {
        error = "GPU probe RenderTexture class unavailable";
        return false;
    }
    s.ready = true;
    return true;
}

bool UnityGpuProbe::ensure(std::string& error) {
    error.clear();
    auto& s = *impl_;
    if (!s.ready) { error = "Unity GPU probe is not resolved"; return false; }
    if (s.activePending) { error = "GPU probe active RT restoration is pending; retry cleanup first"; return false; }
    s.handles.fill(0);
    int32_t graphics = -1;
    if (!s.value(Impl::GraphicsType, nullptr, graphics, error)) return false;
    if (graphics != 21) { error = "GPU probe requires Unity Vulkan (GraphicsDeviceType=21), got " + std::to_string(graphics); return false; }
    const auto fail = [&]() { s.clean(); return false; };
    try {
        for (auto& texture : s.textures) {
            if (!texture.p && !s.allocate(texture, error)) return fail();
        }
        std::array<uintptr_t, 4> handles{};
        for (size_t i = 0; i < s.textures.size(); ++i) {
            if (!s.validate(s.textures[i], handles[i], error)) return fail();
            for (size_t j = 0; j < i; ++j) {
                if (handles[j] == handles[i]) { error = "GPU probe RTs unexpectedly share an opaque native handle"; return fail(); }
            }
        }
        s.handles = handles;
        return true;
    } catch (const std::exception& ex) { error = "GPU probe allocation failed: " + std::string(ex.what()); }
    catch (...) { error = "GPU probe allocation failed with an unknown native exception"; }
    return fail();
}

uintptr_t UnityGpuProbe::source_handle(unsigned eye) const { return eye < 2 ? impl_->handles[eye] : 0; }
uintptr_t UnityGpuProbe::marker_handle(unsigned eye) const { return eye < 2 ? impl_->handles[eye + 2] : 0; }

bool UnityGpuProbe::issue_copy(std::string& error) {
    if (!ensure(error)) return false;
    auto& s = *impl_;
    Impl::Ref black;
    bool ok = false;
    try {
        void* texture = nullptr;
        bool living = false;
        ok = s.invoke(Impl::Black, nullptr, nullptr, texture, error) && s.retain(black, texture, error) &&
             s.alive(black.p, living, error);
        if (ok && !living) { error = "GPU probe Texture2D.blackTexture is unavailable"; ok = false; }
        if (ok) {
            void* active = nullptr;
            ok = s.invoke(Impl::GetActive, nullptr, nullptr, active, error) && s.retain(s.savedActive, active, error);
            if (ok) s.activePending = true;
        }
        for (unsigned eye = 0; ok && eye < 2; ++eye) {
            void* blitArgs[]{black.p, s.textures[eye].p};
            void* copyArgs[]{s.textures[eye].p, s.textures[eye + 2].p};
            ok = s.call(Impl::Blit, nullptr, blitArgs, error) && s.call(Impl::Copy, nullptr, copyArgs, error);
        }
    } catch (const std::exception& ex) { error = "GPU probe copy failed: " + std::string(ex.what()); ok = false; }
    catch (...) { error = "GPU probe copy failed with an unknown native exception"; ok = false; }
    s.unroot(black); // Borrowed Unity built-in texture; never Release/Destroy it.
    std::string restoreError;
    if (!s.restore(restoreError)) {
        if (!error.empty()) error += "; ";
        error += "GPU probe restoration pending: " + restoreError;
        ok = false;
    }
    return ok;
}

void UnityGpuProbe::cleanup() { if (impl_->host) impl_->clean(); }
bool UnityGpuProbe::resources_alive() const {
    const auto& s = *impl_;
    if (s.savedActive.p || s.savedActive.root || s.activePending) return true;
    for (const auto& texture : s.textures) if (texture.p || texture.root) return true;
    return false;
}
}
