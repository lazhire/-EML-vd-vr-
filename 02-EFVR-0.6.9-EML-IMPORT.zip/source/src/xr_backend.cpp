#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#define XR_USE_PLATFORM_WIN32
#define XR_USE_GRAPHICS_API_D3D11
#define XR_NO_PROTOTYPES
#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include "xr_backend.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <sstream>
#include <vector>

namespace vrvd {
namespace {
template<class T> void release_com(T*& p) { if (p) { p->Release(); p = nullptr; } }

bool same_device(ID3D11Device* a, ID3D11Device* b) {
    if (!a || !b) return false;
    IUnknown *ia = nullptr, *ib = nullptr;
    const HRESULT ra = a->QueryInterface(__uuidof(IUnknown), reinterpret_cast<void**>(&ia));
    const HRESULT rb = b->QueryInterface(__uuidof(IUnknown), reinterpret_cast<void**>(&ib));
    const bool same = SUCCEEDED(ra) && SUCCEEDED(rb) && ia == ib;
    release_com(ia); release_com(ib);
    return same;
}

bool supported_color_format(DXGI_FORMAT f) {
    return f == DXGI_FORMAT_R8G8B8A8_UNORM || f == DXGI_FORMAT_R8G8B8A8_UNORM_SRGB ||
           f == DXGI_FORMAT_B8G8R8A8_UNORM || f == DXGI_FORMAT_B8G8R8A8_UNORM_SRGB;
}

bool same_copy_shape(const D3D11_TEXTURE2D_DESC& a, const D3D11_TEXTURE2D_DESC& b) {
    return a.Width == b.Width && a.Height == b.Height && a.MipLevels == b.MipLevels &&
           a.ArraySize == b.ArraySize && a.Format == b.Format &&
           a.SampleDesc.Count == b.SampleDesc.Count && a.SampleDesc.Quality == b.SampleDesc.Quality;
}

bool xr_copy_target(const D3D11_TEXTURE2D_DESC& source, const D3D11_TEXTURE2D_DESC& target,
                    DXGI_FORMAT requested_format) {
    // OpenXR D3D11 swapchains use TYPELESS storage where available. The exact
    // typed color interpretation remains the one passed to xrCreateSwapchain.
    // CopyResource copies bits; it never performs sRGB encoding or RGBA/BGRA
    // conversion. Only the corresponding typeless family is accepted here.
    DXGI_FORMAT storage=DXGI_FORMAT_UNKNOWN;
    switch (requested_format) {
        case DXGI_FORMAT_R8G8B8A8_UNORM:
        case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: storage=DXGI_FORMAT_R8G8B8A8_TYPELESS; break;
        case DXGI_FORMAT_B8G8R8A8_UNORM:
        case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: storage=DXGI_FORMAT_B8G8R8A8_TYPELESS; break;
        default: return false;
    }
    if (target.Format!=requested_format && target.Format!=storage) return false;
    auto shape=target; shape.Format=source.Format;
    return same_copy_shape(source,shape) && target.Usage!=D3D11_USAGE_IMMUTABLE;
}

std::string hr_text(HRESULT hr) {
    std::ostringstream s; s << "0x" << std::hex << static_cast<unsigned long>(hr); return s.str();
}
} // namespace

struct XrBackend::Impl {
    HMODULE loader = nullptr;
    PFN_xrGetInstanceProcAddr get_proc = nullptr;
#define XR_FUNCTIONS(X) \
    X(xrEnumerateInstanceExtensionProperties) X(xrCreateInstance) \
    X(xrDestroyInstance) X(xrGetInstanceProperties) X(xrGetSystem) X(xrGetSystemProperties) \
    X(xrGetD3D11GraphicsRequirementsKHR) X(xrCreateSession) X(xrDestroySession) \
    X(xrBeginSession) X(xrEndSession) X(xrRequestExitSession) \
    X(xrEnumerateViewConfigurationViews) X(xrEnumerateEnvironmentBlendModes) \
    X(xrCreateReferenceSpace) X(xrDestroySpace) X(xrEnumerateSwapchainFormats) \
    X(xrCreateSwapchain) X(xrDestroySwapchain) X(xrEnumerateSwapchainImages) \
    X(xrAcquireSwapchainImage) X(xrWaitSwapchainImage) X(xrReleaseSwapchainImage) \
    X(xrPollEvent) X(xrWaitFrame) X(xrBeginFrame) X(xrEndFrame) X(xrLocateViews) X(xrResultToString)
#define DECLARE_XR(n) PFN_##n n = nullptr;
    XR_FUNCTIONS(DECLARE_XR)
#undef DECLARE_XR
    XrInstance instance = XR_NULL_HANDLE;
    XrSystemId system = XR_NULL_SYSTEM_ID;
    XrSession session = XR_NULL_HANDLE;
    XrSpace local = XR_NULL_HANDLE;
    XrSessionState state = XR_SESSION_STATE_UNKNOWN;
    bool active = false;
    bool pending = false;
    bool faulted = false;
    bool recenter = true;
    bool origin_set = false;
    float origin[3] = {0, 0, 0};
    float origin_yaw = 0;
    std::string name;
    ID3D11Device* device = nullptr;
    ID3D11DeviceContext* context = nullptr;
    std::array<D3D11_TEXTURE2D_DESC, 2> texture_desc{};
    std::array<DXGI_FORMAT, 2> requested_formats{DXGI_FORMAT_UNKNOWN, DXGI_FORMAT_UNKNOWN};
    std::array<XrSwapchain, 2> chains{XR_NULL_HANDLE, XR_NULL_HANDLE};
    std::array<std::vector<XrSwapchainImageD3D11KHR>, 2> images;
    std::array<bool, 2> acquired{false, false};
    std::array<bool, 2> waited{false, false};
    std::array<uint32_t, 2> image_index{0, 0};
    std::array<XrView, 2> views{XrView{XR_TYPE_VIEW}, XrView{XR_TYPE_VIEW}};
    XrTime display_time = 0;
    XrTime reference_change_time = 0;

    std::string xr_error(const char* where, XrResult result) const {
        char text[XR_MAX_RESULT_STRING_SIZE]{};
        if (instance && xrResultToString && XR_SUCCEEDED(xrResultToString(instance, result, text)))
            return std::string(where) + ": " + text;
        return std::string(where) + ": XrResult " + std::to_string(static_cast<int>(result));
    }

    template<class F> bool bind(const char* symbol, F& function, XrInstance owner, std::string& error) {
        PFN_xrVoidFunction p = nullptr;
        const XrResult result = get_proc(owner, symbol, &p);
        if (XR_FAILED(result) || !p) {
            error = xr_error(symbol, result); return false;
        }
        function = reinterpret_cast<F>(p);
        return true;
    }

    bool check(XrResult result, const char* where, std::string& error) {
        if (XR_FAILED(result)) { error = xr_error(where, result); return false; }
        return true;
    }

    bool finish_empty(std::string* error = nullptr) {
        if (!pending) return true;
        XrFrameEndInfo end{XR_TYPE_FRAME_END_INFO};
        end.displayTime = display_time;
        end.environmentBlendMode = XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
        end.layerCount = 0;
        end.layers = nullptr;
        const XrResult result = xrEndFrame(session, &end);
        pending = false;
        if (XR_FAILED(result)) {
            faulted = true;
            if (error) *error = xr_error("xrEndFrame(empty)", result);
            return false;
        }
        return true;
    }

    // Called before releasing/destroying swapchains on failure. Never release an
    // image that has not successfully completed xrWaitSwapchainImage.
    void return_images() {
        for (size_t eye = 0; eye < 2; ++eye) {
            if (!acquired[eye] || !chains[eye]) continue;
            if (!waited[eye]) {
                XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};
                // Cleanup must not hang waiting for a lost runtime. An image
                // which is not immediately ready stays acquired until the
                // faulted session/swapchain is destroyed during shutdown.
                wait.timeout = 0;
                XrResult result = xrWaitSwapchainImage(chains[eye], &wait);
                waited[eye] = XR_SUCCEEDED(result) && result != XR_TIMEOUT_EXPIRED;
            }
            if (waited[eye]) {
                XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
                if (XR_SUCCEEDED(xrReleaseSwapchainImage(chains[eye], &release))) {
                    acquired[eye] = false; waited[eye] = false;
                }
            }
        }
    }

    void close() {
        if (session) {
            return_images();
            finish_empty();
            if (active && state == XR_SESSION_STATE_STOPPING && xrEndSession)
                xrEndSession(session);
            // DestroySession is also valid for a running session. There is no
            // indefinite wait for a STOPPING event during module shutdown.
            if (local && xrDestroySpace) xrDestroySpace(local);
            local = XR_NULL_HANDLE;
            for (size_t eye = 0; eye < 2; ++eye) {
                if (chains[eye] && xrDestroySwapchain) xrDestroySwapchain(chains[eye]);
                chains[eye] = XR_NULL_HANDLE;
                images[eye].clear(); acquired[eye] = false; waited[eye] = false;
            }
            if (xrDestroySession) xrDestroySession(session);
            session = XR_NULL_HANDLE;
        }
        bool may_unload = !instance;
        if (instance && xrDestroyInstance) {
            may_unload = XR_SUCCEEDED(xrDestroyInstance(instance));
            instance = XR_NULL_HANDLE;
        }
        release_com(context); release_com(device);
        // On a runtime destruction error, retain its loader reference rather
        // than unloading code which might still own runtime work.
        if (loader && may_unload) FreeLibrary(loader);
        loader = nullptr;
        get_proc = nullptr;
#define RESET_XR(n) n = nullptr;
        XR_FUNCTIONS(RESET_XR)
#undef RESET_XR
        system = XR_NULL_SYSTEM_ID;
        active = pending = faulted = false;
        state = XR_SESSION_STATE_UNKNOWN;
        origin_set = false; recenter = true; reference_change_time = 0; name.clear();
    }

    bool poll(std::string& error) {
        for (;;) {
            XrEventDataBuffer buffer{XR_TYPE_EVENT_DATA_BUFFER};
            const XrResult result = xrPollEvent(instance, &buffer);
            if (result == XR_EVENT_UNAVAILABLE) return true;
            if (!check(result, "xrPollEvent", error)) return false;
            if (buffer.type == XR_TYPE_EVENT_DATA_INSTANCE_LOSS_PENDING) {
                active = false; faulted = true;
                error = "OpenXR instance loss pending; stop and reconnect the module.";
                return false;
            }
            if (buffer.type == XR_TYPE_EVENT_DATA_REFERENCE_SPACE_CHANGE_PENDING) {
                auto* change = reinterpret_cast<const XrEventDataReferenceSpaceChangePending*>(&buffer);
                if (change->session == session && change->referenceSpaceType == XR_REFERENCE_SPACE_TYPE_LOCAL)
                    reference_change_time = change->changeTime;
                continue;
            }
            if (buffer.type != XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED) continue;
            auto* event = reinterpret_cast<const XrEventDataSessionStateChanged*>(&buffer);
            if (event->session != session) continue;
            state = event->state;
            if (state == XR_SESSION_STATE_READY && !active) {
                XrSessionBeginInfo begin{XR_TYPE_SESSION_BEGIN_INFO};
                begin.primaryViewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
                if (!check(xrBeginSession(session, &begin), "xrBeginSession", error)) return false;
                active = true;
                recenter = true;
            } else if (state == XR_SESSION_STATE_STOPPING) {
                if (!finish_empty(&error)) return false;
                if (active && !check(xrEndSession(session), "xrEndSession", error)) return false;
                active = false;
            } else if (state == XR_SESSION_STATE_EXITING || state == XR_SESSION_STATE_LOSS_PENDING) {
                active = false; faulted = true;
                error = "OpenXR session exited or was lost; stop and reconnect the module.";
                return false;
            }
        }
    }

    void recentered_eyes(Eye out[2]) {
        if (recenter || !origin_set) {
            origin[0] = (views[0].pose.position.x + views[1].pose.position.x) * 0.5f;
            origin[1] = (views[0].pose.position.y + views[1].pose.position.y) * 0.5f;
            origin[2] = (views[0].pose.position.z + views[1].pose.position.z) * 0.5f;
            XrQuaternionf q = views[0].pose.orientation;
            const XrQuaternionf r = views[1].pose.orientation;
            const float sign = q.x*r.x + q.y*r.y + q.z*r.z + q.w*r.w < 0 ? -1.f : 1.f;
            q.x += sign*r.x; q.y += sign*r.y; q.z += sign*r.z; q.w += sign*r.w;
            const float norm = std::sqrt(q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w);
            if (norm > 1e-6f) { q.x/=norm; q.y/=norm; q.z/=norm; q.w/=norm; }
            origin_yaw = std::atan2(2.f*(q.x*q.z+q.w*q.y), 1.f-2.f*(q.x*q.x+q.y*q.y));
            recenter = false; origin_set = true;
        }
        const float cy = std::cos(origin_yaw), sy = std::sin(origin_yaw);
        const float half_c = std::cos(-origin_yaw*0.5f), half_s = std::sin(-origin_yaw*0.5f);
        for (size_t eye=0; eye<2; ++eye) {
            const auto& pose = views[eye].pose;
            const float x=pose.position.x-origin[0], y=pose.position.y-origin[1], z=pose.position.z-origin[2];
            out[eye].position[0] = cy*x-sy*z;
            out[eye].position[1] = y;
            out[eye].position[2] = sy*x+cy*z;
            const auto& q = pose.orientation;
            // inverse-origin-yaw * original-eye-orientation, xyzw.
            out[eye].orientation[0] = half_c*q.x + half_s*q.z;
            out[eye].orientation[1] = half_c*q.y + half_s*q.w;
            out[eye].orientation[2] = half_c*q.z - half_s*q.x;
            out[eye].orientation[3] = half_c*q.w - half_s*q.y;
            out[eye].angleLeft = views[eye].fov.angleLeft;
            out[eye].angleRight = views[eye].fov.angleRight;
            out[eye].angleUp = views[eye].fov.angleUp;
            out[eye].angleDown = views[eye].fov.angleDown;
        }
    }
};

XrBackend::XrBackend() : impl_(new Impl) {}
XrBackend::~XrBackend() { shutdown(); }

bool XrBackend::initialize(ID3D11Texture2D* left, ID3D11Texture2D* right,
                           const wchar_t* loader_path, std::string& error,
                           bool source_linear_hint) {
    error.clear();
    auto& p=*impl_; p.close();
    const auto fail=[&](const std::string& why) { error=why; p.close(); return false; };
    if (!left || !right || left==right) return fail("Two distinct D3D11 eye textures are required.");
    if (!loader_path || !*loader_path ||
        !(loader_path[0]==L'\\' || (wcslen(loader_path)>2 && loader_path[1]==L':' &&
                                    (loader_path[2]==L'\\'||loader_path[2]==L'/'))))
        return fail("An absolute path to an installed OpenXR loader is required.");
    ID3D11Texture2D* textures[2]={left,right};
    for (size_t eye=0;eye<2;++eye) {
        textures[eye]->GetDesc(&p.texture_desc[eye]);
        const auto& d=p.texture_desc[eye];
        auto& format=p.requested_formats[eye];
        format=d.Format;
        if (source_linear_hint) {
            // This hint is a contract supplied by UnityBridge after explicitly
            // constructing RenderTextureReadWrite.Linear targets. A typeless
            // resource alone cannot tell us whether its bytes are linear/sRGB.
            if (format==DXGI_FORMAT_R8G8B8A8_TYPELESS) format=DXGI_FORMAT_R8G8B8A8_UNORM;
            else if (format==DXGI_FORMAT_B8G8R8A8_TYPELESS) format=DXGI_FORMAT_B8G8R8A8_UNORM;
            if (format==DXGI_FORMAT_R8G8B8A8_UNORM_SRGB||format==DXGI_FORMAT_B8G8R8A8_UNORM_SRGB)
                return fail("Source declared linear, but its D3D11 resource is sRGB; recreate matching eye targets.");
        }
        if (!d.Width||!d.Height||d.MipLevels!=1||d.ArraySize!=1||d.SampleDesc.Count!=1||
            d.SampleDesc.Quality!=0||!supported_color_format(format))
            return fail("Eye textures require single-sample, single-mip RGBA8/BGRA8 color storage; typeless sources require an explicit linear-target contract.");
    }
    left->GetDevice(&p.device);
    ID3D11Device* right_device=nullptr; right->GetDevice(&right_device);
    const bool compatible=same_device(p.device,right_device); release_com(right_device);
    if (!compatible) return fail("Left/right eye textures must use the same D3D11 device.");
    p.device->GetImmediateContext(&p.context);
    if (!p.context) return fail("Cannot obtain the Unity D3D11 immediate context.");
    p.loader=LoadLibraryExW(loader_path,nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    if (!p.loader) return fail("OpenXR loader could not be loaded; Windows error "+std::to_string(GetLastError()));
    p.get_proc=reinterpret_cast<PFN_xrGetInstanceProcAddr>(GetProcAddress(p.loader,"xrGetInstanceProcAddr"));
    if (!p.get_proc) return fail("The selected DLL does not export xrGetInstanceProcAddr.");
    if (!p.bind("xrEnumerateInstanceExtensionProperties",p.xrEnumerateInstanceExtensionProperties,XR_NULL_HANDLE,error)||
        !p.bind("xrCreateInstance",p.xrCreateInstance,XR_NULL_HANDLE,error)) return fail(error);
    uint32_t count=0;
    if (!p.check(p.xrEnumerateInstanceExtensionProperties(nullptr,0,&count,nullptr),"Enumerate OpenXR extensions",error)) return fail(error);
    std::vector<XrExtensionProperties> extensions(count,{XR_TYPE_EXTENSION_PROPERTIES});
    if (!p.check(p.xrEnumerateInstanceExtensionProperties(nullptr,count,&count,extensions.data()),"Read OpenXR extensions",error)) return fail(error);
    const bool d3d11=std::any_of(extensions.begin(),extensions.end(),[](const auto& e){return std::strcmp(e.extensionName,XR_KHR_D3D11_ENABLE_EXTENSION_NAME)==0;});
    if (!d3d11) return fail("The active OpenXR runtime does not expose XR_KHR_D3D11_enable.");
    const char* enabled[]={XR_KHR_D3D11_ENABLE_EXTENSION_NAME};
    XrInstanceCreateInfo create{XR_TYPE_INSTANCE_CREATE_INFO};
    std::strcpy(create.applicationInfo.applicationName,"Endfield VRVD Experimental");
    std::strcpy(create.applicationInfo.engineName,"EML First Person Bridge");
    create.applicationInfo.applicationVersion=1;
    create.applicationInfo.engineVersion=1;
    create.applicationInfo.apiVersion=XR_MAKE_VERSION(1,0,0);
    create.enabledExtensionCount=1; create.enabledExtensionNames=enabled;
    if (!p.check(p.xrCreateInstance(&create,&p.instance),"xrCreateInstance",error)) return fail(error);
    // Bind destruction first so later partial initialization remains reversible.
    if (!p.bind("xrDestroyInstance",p.xrDestroyInstance,p.instance,error)) return fail(error);
#define BIND_XR(n) if (!p.bind(#n,p.n,p.instance,error)) return fail(error);
    XR_FUNCTIONS(BIND_XR)
#undef BIND_XR
    XrInstanceProperties properties{XR_TYPE_INSTANCE_PROPERTIES};
    if (!p.check(p.xrGetInstanceProperties(p.instance,&properties),"xrGetInstanceProperties",error)) return fail(error);
    p.name=properties.runtimeName;
    XrSystemGetInfo system_info{XR_TYPE_SYSTEM_GET_INFO}; system_info.formFactor=XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
    const XrResult system_result=p.xrGetSystem(p.instance,&system_info,&p.system);
    if (system_result==XR_ERROR_FORM_FACTOR_UNAVAILABLE)
        return fail("No available VR headset. Connect Quest 3 through Virtual Desktop, then retry.");
    if (!p.check(system_result,"xrGetSystem",error)) return fail(error);
    XrSystemProperties system_properties{XR_TYPE_SYSTEM_PROPERTIES};
    if (!p.check(p.xrGetSystemProperties(p.instance,p.system,&system_properties),"xrGetSystemProperties",error)) return fail(error);
    if (!system_properties.trackingProperties.orientationTracking||!system_properties.trackingProperties.positionTracking)
        return fail("This backend requires both orientation and position tracking (6DoF).");
    XrGraphicsRequirementsD3D11KHR requirements{XR_TYPE_GRAPHICS_REQUIREMENTS_D3D11_KHR};
    if (!p.check(p.xrGetD3D11GraphicsRequirementsKHR(p.instance,p.system,&requirements),"xrGetD3D11GraphicsRequirementsKHR",error)) return fail(error);
    if (p.device->GetFeatureLevel()<requirements.minFeatureLevel)
        return fail("Unity's D3D11 device feature level is below the OpenXR runtime requirement.");
    IDXGIDevice* dxgi_device=nullptr; IDXGIAdapter* adapter=nullptr; DXGI_ADAPTER_DESC adapter_desc{};
    HRESULT hr=p.device->QueryInterface(__uuidof(IDXGIDevice),reinterpret_cast<void**>(&dxgi_device));
    if (SUCCEEDED(hr)) hr=dxgi_device->GetAdapter(&adapter);
    if (SUCCEEDED(hr)) hr=adapter->GetDesc(&adapter_desc);
    release_com(adapter); release_com(dxgi_device);
    if (FAILED(hr)) return fail("Cannot inspect Unity's graphics adapter: "+hr_text(hr));
    if (adapter_desc.AdapterLuid.LowPart!=requirements.adapterLuid.LowPart||adapter_desc.AdapterLuid.HighPart!=requirements.adapterLuid.HighPart)
        return fail("Unity and OpenXR require different graphics adapters. Select the same GPU before retrying.");
    count=0;
    if (!p.check(p.xrEnumerateViewConfigurationViews(p.instance,p.system,XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,0,&count,nullptr),"Enumerate stereo views",error)) return fail(error);
    if (count!=2) return fail("The active runtime does not provide exactly two primary stereo views.");
    std::array<XrViewConfigurationView,2> capacities{XrViewConfigurationView{XR_TYPE_VIEW_CONFIGURATION_VIEW},XrViewConfigurationView{XR_TYPE_VIEW_CONFIGURATION_VIEW}};
    if (!p.check(p.xrEnumerateViewConfigurationViews(p.instance,p.system,XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,2,&count,capacities.data()),"Read stereo view sizes",error)) return fail(error);
    for (size_t eye=0;eye<2;++eye)
        if (p.texture_desc[eye].Width>capacities[eye].maxImageRectWidth||p.texture_desc[eye].Height>capacities[eye].maxImageRectHeight)
            return fail("Configured eye texture exceeds the runtime's maximum view dimensions.");
    count=0;
    if (!p.check(p.xrEnumerateEnvironmentBlendModes(p.instance,p.system,XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,0,&count,nullptr),"Enumerate environment blend modes",error)) return fail(error);
    std::vector<XrEnvironmentBlendMode> blends(count);
    if (!p.check(p.xrEnumerateEnvironmentBlendModes(p.instance,p.system,XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,count,&count,blends.data()),"Read environment blend modes",error)) return fail(error);
    if (std::find(blends.begin(),blends.end(),XR_ENVIRONMENT_BLEND_MODE_OPAQUE)==blends.end())
        return fail("An opaque immersive OpenXR session is required.");
    XrGraphicsBindingD3D11KHR binding{XR_TYPE_GRAPHICS_BINDING_D3D11_KHR}; binding.device=p.device;
    XrSessionCreateInfo session_info{XR_TYPE_SESSION_CREATE_INFO}; session_info.next=&binding; session_info.systemId=p.system;
    if (!p.check(p.xrCreateSession(p.instance,&session_info,&p.session),"xrCreateSession",error)) return fail(error);
    XrReferenceSpaceCreateInfo space{XR_TYPE_REFERENCE_SPACE_CREATE_INFO};
    space.referenceSpaceType=XR_REFERENCE_SPACE_TYPE_LOCAL; space.poseInReferenceSpace.orientation.w=1.f;
    if (!p.check(p.xrCreateReferenceSpace(p.session,&space,&p.local),"xrCreateReferenceSpace(LOCAL)",error)) return fail(error);
    count=0;
    if (!p.check(p.xrEnumerateSwapchainFormats(p.session,0,&count,nullptr),"Enumerate swapchain formats",error)) return fail(error);
    std::vector<int64_t> formats(count);
    if (!p.check(p.xrEnumerateSwapchainFormats(p.session,count,&count,formats.data()),"Read swapchain formats",error)) return fail(error);
    for (size_t eye=0;eye<2;++eye) {
        const auto& d=p.texture_desc[eye];
        const auto format=p.requested_formats[eye];
        if (std::find(formats.begin(),formats.end(),static_cast<int64_t>(format))==formats.end())
            return fail("The runtime does not support the exact Unity eye texture format; no implicit sRGB/UNORM conversion is performed.");
        XrSwapchainCreateInfo swap{XR_TYPE_SWAPCHAIN_CREATE_INFO};
        swap.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT|XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT;
        swap.format=static_cast<int64_t>(format); swap.sampleCount=1;
        swap.width=d.Width; swap.height=d.Height; swap.faceCount=1; swap.arraySize=1; swap.mipCount=1;
        if (!p.check(p.xrCreateSwapchain(p.session,&swap,&p.chains[eye]),"xrCreateSwapchain",error)) return fail(error);
        count=0;
        if (!p.check(p.xrEnumerateSwapchainImages(p.chains[eye],0,&count,nullptr),"Enumerate swapchain images",error)) return fail(error);
        if (!count) return fail("OpenXR created a swapchain with no images.");
        p.images[eye].resize(count,{XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR});
        if (!p.check(p.xrEnumerateSwapchainImages(p.chains[eye],count,&count,reinterpret_cast<XrSwapchainImageBaseHeader*>(p.images[eye].data())),"Read swapchain images",error)) return fail(error);
        for (const auto& image:p.images[eye]) {
            if (!image.texture) return fail("OpenXR returned a null D3D11 swapchain image.");
            D3D11_TEXTURE2D_DESC target{}; image.texture->GetDesc(&target);
            if (!xr_copy_target(d,target,format)) return fail("OpenXR swapchain texture shape/format is incompatible with CopyResource.");
        }
    }
    return true;
}

bool XrBackend::begin_frame(Eye eyes[2],bool& shouldRender,std::string& error) {
    auto& p=*impl_; error.clear(); shouldRender=false;
    if (!eyes) { error="Eye output buffer is null."; return false; }
    if (!p.session) { error="OpenXR session is not initialized."; return false; }
    if (p.faulted) { error="OpenXR backend requires shutdown and reinitialization after an earlier failure."; return false; }
    if (p.pending) { error="Previous OpenXR frame has not been submitted or cancelled."; return false; }
    if (!p.poll(error)) { p.faulted=true; return false; }
    if (!p.active) return true;
    XrFrameWaitInfo wait{XR_TYPE_FRAME_WAIT_INFO}; XrFrameState frame{XR_TYPE_FRAME_STATE};
    if (!p.check(p.xrWaitFrame(p.session,&wait,&frame),"xrWaitFrame",error)) {p.faulted=true;return false;}
    XrFrameBeginInfo begin{XR_TYPE_FRAME_BEGIN_INFO};
    if (!p.check(p.xrBeginFrame(p.session,&begin),"xrBeginFrame",error)) {p.faulted=true;return false;}
    p.pending=true; p.display_time=frame.predictedDisplayTime;
    if (!frame.shouldRender) return p.finish_empty(&error);
    XrViewLocateInfo locate{XR_TYPE_VIEW_LOCATE_INFO};
    locate.viewConfigurationType=XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
    locate.displayTime=p.display_time; locate.space=p.local;
    XrViewState state{XR_TYPE_VIEW_STATE}; uint32_t count=0;
    if (!p.check(p.xrLocateViews(p.session,&locate,&state,2,&count,p.views.data()),"xrLocateViews",error)) {
        p.finish_empty(); p.faulted=true; return false;
    }
    constexpr XrViewStateFlags required=XR_VIEW_STATE_ORIENTATION_VALID_BIT|XR_VIEW_STATE_POSITION_VALID_BIT|
        XR_VIEW_STATE_ORIENTATION_TRACKED_BIT|XR_VIEW_STATE_POSITION_TRACKED_BIT;
    if (count!=2||(state.viewStateFlags&required)!=required) return p.finish_empty(&error);
    if (p.reference_change_time && p.display_time >= p.reference_change_time) {
        p.recenter = true; p.reference_change_time = 0;
    }
    p.recentered_eyes(eyes);
    shouldRender=true;
    return true;
}

bool XrBackend::submit(ID3D11Texture2D* left,ID3D11Texture2D* right,std::string& error) {
    auto& p=*impl_; error.clear();
    if (!p.pending) {error="No OpenXR frame is pending.";return false;}
    const auto fail=[&](const std::string& why) {
        error=why; p.faulted=true; p.return_images(); p.finish_empty(); return false;
    };
    if (!left||!right||left==right) return fail("Submission requires two distinct rendered eye textures.");
    ID3D11Texture2D* textures[2]={left,right};
    for(size_t eye=0;eye<2;++eye) {
        D3D11_TEXTURE2D_DESC desc{}; textures[eye]->GetDesc(&desc);
        ID3D11Device* source_device=nullptr; textures[eye]->GetDevice(&source_device);
        bool device_matches=same_device(source_device,p.device); release_com(source_device);
        if(!device_matches||!same_copy_shape(desc,p.texture_desc[eye]))
            return fail("Eye texture device/shape changed; reconnect the VR backend.");
        XrSwapchainImageAcquireInfo acquire{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
        if(!p.check(p.xrAcquireSwapchainImage(p.chains[eye],&acquire,&p.image_index[eye]),"xrAcquireSwapchainImage",error)) return fail(error);
        p.acquired[eye]=true;
        XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO}; wait.timeout=100'000'000; // 100 ms, nanoseconds.
        XrResult result=p.xrWaitSwapchainImage(p.chains[eye],&wait);
        if(result==XR_TIMEOUT_EXPIRED) return fail("OpenXR swapchain image wait timed out.");
        if(!p.check(result,"xrWaitSwapchainImage",error)) return fail(error);
        p.waited[eye]=true;
        if(p.image_index[eye]>=p.images[eye].size()) return fail("Runtime returned an invalid swapchain image index.");
        p.context->CopyResource(p.images[eye][p.image_index[eye]].texture,textures[eye]);
    }
    p.context->Flush();
    HRESULT removed=p.device->GetDeviceRemovedReason();
    if(FAILED(removed)) return fail("D3D11 device was removed: "+hr_text(removed));
    for(size_t eye=0;eye<2;++eye) {
        XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
        if(!p.check(p.xrReleaseSwapchainImage(p.chains[eye],&release),"xrReleaseSwapchainImage",error)) return fail(error);
        p.acquired[eye]=false; p.waited[eye]=false;
    }
    std::array<XrCompositionLayerProjectionView,2> projections{
        XrCompositionLayerProjectionView{XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW},
        XrCompositionLayerProjectionView{XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW}};
    for(size_t eye=0;eye<2;++eye) {
        auto& view=projections[eye]; view.pose=p.views[eye].pose; view.fov=p.views[eye].fov;
        view.subImage.swapchain=p.chains[eye]; view.subImage.imageArrayIndex=0;
        view.subImage.imageRect.offset={0,0};
        view.subImage.imageRect.extent={static_cast<int32_t>(p.texture_desc[eye].Width),static_cast<int32_t>(p.texture_desc[eye].Height)};
    }
    XrCompositionLayerProjection layer{XR_TYPE_COMPOSITION_LAYER_PROJECTION};
    layer.space=p.local; layer.viewCount=2; layer.views=projections.data();
    const XrCompositionLayerBaseHeader* layers[]={reinterpret_cast<const XrCompositionLayerBaseHeader*>(&layer)};
    XrFrameEndInfo end{XR_TYPE_FRAME_END_INFO}; end.displayTime=p.display_time;
    end.environmentBlendMode=XR_ENVIRONMENT_BLEND_MODE_OPAQUE; end.layerCount=1; end.layers=layers;
    XrResult result=p.xrEndFrame(p.session,&end); p.pending=false;
    if(!p.check(result,"xrEndFrame(stereo)",error)) {p.faulted=true;return false;}
    return true;
}

void XrBackend::cancel_frame() {impl_->finish_empty();}
void XrBackend::request_recenter() {impl_->recenter=true;}
bool XrBackend::running() const {return impl_->active&&!impl_->faulted;}
bool XrBackend::frame_pending() const {return impl_->pending;}
std::string XrBackend::runtime_name() const {return impl_->name;}
void XrBackend::shutdown() {if(impl_) impl_->close();}

#undef XR_FUNCTIONS
} // namespace vrvd
