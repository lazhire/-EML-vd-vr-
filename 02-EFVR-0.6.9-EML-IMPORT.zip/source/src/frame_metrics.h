#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>

namespace vrvd {
// Completion intervals for freshly submitted STEREO PAIRS. This measures
// application throughput, never headset presentation or GPU execution time.
struct FrameMetricsSnapshot { size_t samples=0; double stereo_pairs_hz=0,p95_interval_ms=0,p99_interval_ms=0; };
class FrameMetrics {
    std::array<double,240> intervals_{};
    size_t size_=0,next_=0;
    double previous_=0;
    bool previous_known_=false;
public:
    void reset(){size_=next_=0;previous_=0;previous_known_=false;}
    void submitted(double monotonic_ms){
        if(!std::isfinite(monotonic_ms))return;
        if(previous_known_){
            const double delta=monotonic_ms-previous_;
            if(delta<=0)return;
            intervals_[next_]=delta;next_=(next_+1)%intervals_.size();
            size_=std::min(size_+1,intervals_.size());
        }
        previous_=monotonic_ms;previous_known_=true;
    }
    FrameMetricsSnapshot snapshot()const{
        FrameMetricsSnapshot s{};s.samples=size_;if(!size_)return s;
        auto sorted=intervals_;std::sort(sorted.begin(),sorted.begin()+size_);
        double sum=0;for(size_t i=0;i<size_;++i)sum+=sorted[i];
        s.stereo_pairs_hz=1000.0*size_/sum;
        s.p95_interval_ms=sorted[static_cast<size_t>(std::ceil(size_*.95))-1];
        s.p99_interval_ms=sorted[static_cast<size_t>(std::ceil(size_*.99))-1];return s;
    }
};
}
