#pragma once
#include <algorithm>
namespace vrvd {
// Two halves per transition: old content to black, new content from black.
// Time spent waiting for ready content is excluded. Uses monotonic wall time.
class FlatTransition {
 enum Phase {World,Out,FlatIn,Flat,FlatOut,In};Phase phase=World;
 double start=0;float from=0;bool wait_world=false,wait_flat=false;
 float ramp(double now)const{float x=duration_ms<=0?1.f:std::clamp(float((now-start)*2000.0/duration_ms),0.f,1.f);return x*x*(3-2*x);}
public:
 int duration_ms=300;float last_opacity=0;
 void reset(){phase=World;start=0;from=last_opacity=0;wait_world=wait_flat=false;}
 const char* name()const{return phase==World?"stereo":phase==Out?"fading_to_flat":phase==FlatIn?"revealing_flat":phase==Flat?"flat":phase==FlatOut?"hiding_flat":"fading_to_stereo";}
 bool fading_out()const{return phase==Out;}
 bool fading_flat_out()const{return phase==FlatOut;}
 float opacity(double now)const{
  if(phase==Out||phase==FlatOut)return from+(1-from)*ramp(now);
  if(phase==In)return wait_world?from:from*(1-ramp(now));
  if(phase==FlatIn)return wait_flat?from:from*(1-ramp(now));
  return 0.f;
 }
 void target(bool flat,double now,bool cached_scene){
  if(flat){
   if(phase==World||phase==In){
    from=opacity(now);start=now;wait_world=false;
    if(cached_scene)phase=Out;else {phase=FlatIn;from=1;wait_flat=true;}
   }else if(phase==FlatOut){from=opacity(now);start=now;phase=FlatIn;wait_flat=false;}
  }else if(phase==Out){from=opacity(now);phase=In;wait_world=true;}
  else if(phase==Flat||phase==FlatIn){from=opacity(now);start=now;phase=FlatOut;wait_flat=false;}
 }
 float outgoing(double now){return last_opacity=opacity(now);}
 void submitted_black(float alpha){if(phase==Out&&alpha>=1){phase=FlatIn;from=last_opacity=1;wait_flat=true;}}
 float menu_opacity(double now){
  if(phase==FlatIn&&wait_flat){start=now;wait_flat=false;}
  return last_opacity=opacity(now);
 }
 void submitted_menu(float alpha){
  if(phase==FlatIn&&alpha<=0){phase=Flat;last_opacity=0;}
  else if(phase==FlatOut&&alpha>=1){phase=In;from=last_opacity=1;wait_world=true;}
 }
 float world_opacity(double now){
  if(phase!=In)return last_opacity=0;
  if(wait_world){start=now;wait_world=false;}
  last_opacity=opacity(now);if(last_opacity<=0)phase=World;return last_opacity;
 }
};
}
