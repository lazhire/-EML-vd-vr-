#pragma once
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
namespace vrvd {
// Native UI target is expected to contain premultiplied RGBA on transparent black.
// An alpha test is a validity check, NOT proof that every pixel is UI.
inline bool prepare_menu_overlay(const std::vector<uint8_t>& src,unsigned w,unsigned h,
 unsigned originalW,unsigned originalH,std::vector<uint8_t>& dst,std::string& e){
 dst.clear();
 if(!w||!h||!originalW||!originalH||src.size()!=size_t(w)*h*4){e="Invalid native UI dimensions";return false;}
 size_t transparent=0,visible=0,invalid=0;
 for(size_t i=0;i<src.size();i+=4){
  unsigned a=src[i+3];transparent+=a<=2;visible+=a>=8;
  invalid+=src[i]>a+3||src[i+1]>a+3||src[i+2]>a+3;
 }
 if(!visible){e="Original UI camera rendered an empty target";return false;}
 if(transparent<std::max<size_t>(1,size_t(w)*h/1000)){
  e="Native UI target has no transparent background; opaque overlay hidden";return false;
 }
 if(invalid){e="Native UI target is not premultiplied RGBA; overlay hidden";return false;}
 dst.assign(src.size(),0);
 unsigned fw=w,fh=std::max(1u,unsigned(uint64_t(w)*originalH/originalW));
 if(fh>h){fh=h;fw=std::max(1u,unsigned(uint64_t(h)*originalW/originalH));}
 const unsigned ox=(w-fw)/2,oy=(h-fh)/2;
 for(unsigned y=0;y<fh;++y)for(unsigned x=0;x<fw;++x){
  size_t from=(size_t(h-1-uint64_t(y)*h/fh)*w+uint64_t(x)*w/fw)*4;
  size_t to=(size_t(oy+y)*w+ox+x)*4;
  std::memcpy(dst.data()+to,src.data()+from,4);
 }
 return true;
}
}
