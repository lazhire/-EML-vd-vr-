#pragma once
#include <BetterEndfield/ThirdPartyModule.h>
#include <cstring>
#include <string>
#include <vector>
namespace vrvd {
struct ManagedRead {
 const BE_HostApiV1* host=nullptr;
 bool bind(BE_ResolvedMethodV1& m,const char* assembly,const char* ns,const char* cls,const char* name,
           const char* args,const char* ret,unsigned n,std::string& e) {
  BE_MethodDescriptorV1 d{assembly,ns,cls,name,args,ret,n};
  if(host->resolve_method(host->context,&d,&m)!=BE_Result_Ok||!m.method_info){e=std::string("Missing binding: ")+cls+"."+name;return false;}return true;
 }
 bool invoke(const BE_ResolvedMethodV1& m,void* o,void** a,void*& r,std::string& e) {
  if(!m.method_info){e="Unresolved managed method";return false;}
  void* ex=nullptr;r=host->runtime_invoke(host->context,m.method_info,o,a,&ex);
  if(ex){e="Managed call raised an exception";return false;}return true;
 }
 bool call(const BE_ResolvedMethodV1& m,void* o,void** a,std::string& e){void* r=nullptr;return invoke(m,o,a,r,e);}
 template<class T> bool value(const BE_ResolvedMethodV1& m,void* o,T& v,std::string& e,void** a=nullptr){
  void* r=nullptr;if(!invoke(m,o,a,r,e))return false;
  auto p=r?host->object_unbox(host->context,r):nullptr;
  if(!p){e="Missing boxed managed value";return false;}std::memcpy(&v,p,sizeof(v));return true;
 }
 std::string string(void* s){
  if(!s||!host||!host->copy_managed_string)return {};
  // EML returns 0 for a null destination; this is NOT a length-query API.
  // Its implementation returns bytes copied, excluding the trailing NUL.
  std::vector<char> b(4097,0);
  int n=host->copy_managed_string(host->context,s,b.data(),b.size());
  if(n<=0||n>=int(b.size())||b[n]!='\0')return {};
  return std::string(b.data(),size_t(n));
 }
 struct Root {
  const BE_HostApiV1* h=nullptr;void* p=nullptr;uint32_t id=0;
  Root()=default;Root(const Root&)=delete;Root& operator=(const Root&)=delete;
  ~Root(){clear();}
  void abandon(){h=nullptr;p=nullptr;id=0;}
  void clear(){if(id&&h)h->gchandle_free(h->context,id);p=nullptr;id=0;}
  bool set(const BE_HostApiV1* api,void* obj){clear();h=api;p=obj;if(obj)id=h->gchandle_new(h->context,obj,0);if(obj&&!id){p=nullptr;return false;}return true;}
 };
};
}
