#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include "window_menu_capture.h"
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>
#include <roapi.h>
#include <winstring.h>
#include <inspectable.h>
#include <algorithm>
#include <cstdio>
#include <cmath>
// Public WinRT ABI, verified against Microsoft windows-rs Windows/Graphics/Capture.
// Local declarations fill the frame-pool interfaces missing in MinGW's headers.
namespace vrvd { namespace wgc {
struct Size {INT32 Width,Height;};
struct Frame: IInspectable {virtual HRESULT STDMETHODCALLTYPE Surface(IInspectable**)=0;virtual HRESULT STDMETHODCALLTYPE Time(INT64*)=0;virtual HRESULT STDMETHODCALLTYPE ContentSize(Size*)=0;};
struct Item: IInspectable {virtual HRESULT STDMETHODCALLTYPE Name(HSTRING*)=0;virtual HRESULT STDMETHODCALLTYPE GetSize(Size*)=0;virtual HRESULT STDMETHODCALLTYPE Closed(IUnknown*,INT64*)=0;virtual HRESULT STDMETHODCALLTYPE RemoveClosed(INT64)=0;};
struct Session: IInspectable {virtual HRESULT STDMETHODCALLTYPE StartCapture()=0;};
struct Pool: IInspectable {
 virtual HRESULT STDMETHODCALLTYPE Recreate(IInspectable*,INT32,INT32,Size)=0;
 virtual HRESULT STDMETHODCALLTYPE Next(Frame**)=0;
 virtual HRESULT STDMETHODCALLTYPE Arrived(IUnknown*,INT64*)=0;
 virtual HRESULT STDMETHODCALLTYPE RemoveArrived(INT64)=0;
 virtual HRESULT STDMETHODCALLTYPE CreateSession(Item*,Session**)=0;
 virtual HRESULT STDMETHODCALLTYPE Dispatcher(IInspectable**)=0;
};
struct PoolFactory: IInspectable {virtual HRESULT STDMETHODCALLTYPE Create(IInspectable*,INT32,INT32,Size,Pool**)=0;};
struct Interop: IUnknown {virtual HRESULT STDMETHODCALLTYPE ForWindow(HWND,REFIID,void**)=0;virtual HRESULT STDMETHODCALLTYPE ForMonitor(HMONITOR,REFIID,void**)=0;};
struct Access: IUnknown {virtual HRESULT STDMETHODCALLTYPE GetInterface(REFIID,void**)=0;};
struct Closable: IInspectable {virtual HRESULT STDMETHODCALLTYPE Close()=0;};
constexpr GUID iidItem{0x79c3f95b,0x31f7,0x4ec2,{0xa4,0x64,0x63,0x2e,0xf5,0xd3,0x07,0x60}};
constexpr GUID iidInterop{0x3628e81b,0x3cac,0x4c60,{0xb7,0xf4,0x23,0xce,0x0e,0x0c,0x33,0x56}};
constexpr GUID iidFactory{0x589b103f,0x6bbc,0x5df5,{0xa9,0x91,0x02,0xe2,0x8b,0x3b,0x66,0xd5}};
constexpr GUID iidDevice{0xa37624ab,0x8d5f,0x4650,{0x9d,0x3e,0x9e,0xae,0x3d,0x9b,0xc6,0x70}};
constexpr GUID iidAccess{0xa9b3d012,0x3df2,0x4ee3,{0xb8,0xd1,0x86,0x95,0xf4,0x57,0xd3,0xc1}};
constexpr GUID iidClose{0x30d5a829,0x7fa4,0x4026,{0x83,0xbb,0xd7,0x5b,0xae,0x4e,0xa9,0x9e}};
template<class T>struct Ptr {T* p=nullptr;~Ptr(){reset();}void reset(){if(p)p->Release();p=nullptr;} T** put(){reset();return &p;} T* operator->()const{return p;} explicit operator bool()const{return p!=nullptr;}};
void close(IUnknown* p){if(!p)return;Ptr<Closable> c;if(SUCCEEDED(p->QueryInterface(iidClose,reinterpret_cast<void**>(c.put()))))c->Close();}
template<class T>HRESULT factory(const wchar_t* name,REFIID id,Ptr<T>& out){HSTRING s=nullptr;HRESULT hr=WindowsCreateString(name,UINT32(wcslen(name)),&s);if(SUCCEEDED(hr))hr=RoGetActivationFactory(s,id,reinterpret_cast<void**>(out.put()));WindowsDeleteString(s);return hr;}
INT64 now(){LARGE_INTEGER q{},f{};QueryPerformanceCounter(&q);QueryPerformanceFrequency(&f);return INT64(double(q.QuadPart)*10000000./double(f.QuadPart));}
}
struct WindowMenuCapture::Impl {
 DWORD pid=GetCurrentProcessId(),thread=0;HWND window=nullptr;bool initializedRo=false;
 wgc::Ptr<ID3D11Device> device;wgc::Ptr<ID3D11DeviceContext> context;wgc::Ptr<IInspectable> rtDevice;
 wgc::Ptr<wgc::Item> item;wgc::Ptr<wgc::Pool> pool;wgc::Ptr<wgc::Session> session;
 wgc::Ptr<ID3D11Texture2D> staging;
 wgc::Size size{};INT64 after=0;bool copy_pending=false;ULONGLONG copy_started=0;
 RECT client{};UINT stagingW=0,stagingH=0;
 void reset(){wgc::close(session.p);session.reset();wgc::close(pool.p);pool.reset();item.reset();staging.reset();rtDevice.reset();context.reset();device.reset();window=nullptr;copy_pending=false;stagingW=stagingH=0;if(initializedRo){RoUninitialize();initializedRo=false;}thread=0;}
 static BOOL CALLBACK find(HWND h,LPARAM p){auto& s=*reinterpret_cast<Impl*>(p);DWORD owner=0;GetWindowThreadProcessId(h,&owner);wchar_t cls[128]{};GetClassNameW(h,cls,128);if(owner==s.pid&&IsWindowVisible(h)&&!GetWindow(h,GW_OWNER)&&wcscmp(cls,L"UnityWndClass")==0){if(s.window){s.window=nullptr;return FALSE;}s.window=h;}return TRUE;}
 HRESULT init(){
  thread=GetCurrentThreadId();HRESULT hr=RoInitialize(RO_INIT_MULTITHREADED);initializedRo=SUCCEEDED(hr);if(FAILED(hr)&&hr!=RPC_E_CHANGED_MODE)return hr;
  EnumWindows(find,reinterpret_cast<LPARAM>(this));if(!window)return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
  wgc::Ptr<wgc::Interop> interop;hr=wgc::factory(L"Windows.Graphics.Capture.GraphicsCaptureItem",wgc::iidInterop,interop);if(FAILED(hr))return hr;
  hr=interop->ForWindow(window,wgc::iidItem,reinterpret_cast<void**>(item.put()));if(FAILED(hr))return hr;
  hr=item->GetSize(&size);if(FAILED(hr)||size.Width<=0||size.Height<=0)return E_FAIL;
  hr=D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,nullptr,0,D3D11_SDK_VERSION,device.put(),nullptr,context.put());if(FAILED(hr))return hr;
  wgc::Ptr<IDXGIDevice> dx;hr=device->QueryInterface(__uuidof(IDXGIDevice),reinterpret_cast<void**>(dx.put()));if(FAILED(hr))return hr;
  using Wrap=HRESULT(WINAPI*)(IDXGIDevice*,IInspectable**);
  auto fn=reinterpret_cast<Wrap>(GetProcAddress(GetModuleHandleW(L"d3d11.dll"),"CreateDirect3D11DeviceFromDXGIDevice"));if(!fn)return E_NOINTERFACE;
  wgc::Ptr<IInspectable> wrapped;hr=fn(dx.p,wrapped.put());if(FAILED(hr))return hr;
  hr=wrapped->QueryInterface(wgc::iidDevice,reinterpret_cast<void**>(rtDevice.put()));if(FAILED(hr))return hr;
  wgc::Ptr<wgc::PoolFactory> f;hr=wgc::factory(L"Windows.Graphics.Capture.Direct3D11CaptureFramePool",wgc::iidFactory,f);if(FAILED(hr))return hr;
  hr=f->Create(rtDevice.p,87,2,size,pool.put());if(FAILED(hr))return hr; // B8G8R8A8_UNORM
  hr=pool->CreateSession(item.p,session.put());if(FAILED(hr))return hr;
  return session->StartCapture();
 }
};
WindowMenuCapture::WindowMenuCapture():impl_(new Impl){}
WindowMenuCapture::~WindowMenuCapture(){if(!resources_alive())delete impl_;} // never COM calls under DLL detach
bool WindowMenuCapture::resources_alive()const{return impl_->thread!=0;}
void WindowMenuCapture::cleanup(){if(!impl_->thread||impl_->thread==GetCurrentThreadId()){impl_->reset();status="idle";}}
#ifdef EFVR_CAPTURE_PROBE
void WindowMenuCapture::probe_process(uint32_t p){if(!resources_alive())impl_->pid=p;}
#endif
bool WindowMenuCapture::poll(uint64_t gen,uint32_t w,uint32_t h,std::vector<uint8_t>& out,bool& fresh,std::string& error){
 auto& s=*impl_;fresh=false;++polls;
 // Release any local frame/surface before closing the pool and COM apartment.
 struct ResetAfterLocals {Impl& s;bool needed=false;~ResetAfterLocals(){if(needed)s.reset();}} reset{s};
 auto fail=[&](const char* what,HRESULT hr){char b[32];std::snprintf(b,sizeof b," (0x%08lX)",static_cast<unsigned long>(hr));error=std::string(what)+b;status="window_capture_error";reset.needed=true;return false;};
 if(w<1||h<1||w>4096||h>4096)return fail("Invalid menu dimensions",E_INVALIDARG);
 if(s.thread&&s.thread!=GetCurrentThreadId()){status="wrong_capture_thread";error="Window capture polled from wrong thread";return false;}
 if(!s.session){HRESULT hr=s.init();if(FAILED(hr))return fail("WGC game window initialization failed",hr);status="waiting_window_frame";}
 if(!IsWindow(s.window)||IsIconic(s.window)){error="Game window closed or minimized";status="window_unavailable";s.copy_pending=false;return false;}
 (void)gen; // UI ownership changes cannot cancel final-window GPU readback.
 if(s.copy_pending){
  D3D11_MAPPED_SUBRESOURCE m{};HRESULT hr=s.context->Map(s.staging.p,0,D3D11_MAP_READ,D3D11_MAP_FLAG_DO_NOT_WAIT,&m);
  if(hr==DXGI_ERROR_WAS_STILL_DRAWING){++gpu_waits;status="waiting_capture_gpu";if(GetTickCount64()-s.copy_started>500)return fail("WGC readback timeout; capture will restart",HRESULT_FROM_WIN32(ERROR_TIMEOUT));return true;}
  if(FAILED(hr))return fail("WGC staging read failed",hr);
  const int cw=s.client.right-s.client.left,ch=s.client.bottom-s.client.top;
  out.assign(size_t(w)*h*4,0);for(size_t i=3;i<out.size();i+=4)out[i]=255;
  int fw=w,fh=std::max(1,int(double(w)*ch/cw));if(fh>int(h)){fh=h;fw=std::max(1,int(double(h)*cw/ch));}
  const int ox=(int(w)-fw)/2,oy=(int(h)-fh)/2;
  // Bilinear resize, BGRA->RGBA, top-down; no second camera render or alpha guessing.
  for(int y=0;y<fh;++y)for(int x=0;x<fw;++x){double sx=std::clamp((x+.5)*cw/fw-.5,0.,double(cw-1))+s.client.left,sy=std::clamp((y+.5)*ch/fh-.5,0.,double(ch-1))+s.client.top;int x0=int(sx),y0=int(sy),x1=std::min(x0+1,int(s.client.right)-1),y1=std::min(y0+1,int(s.client.bottom)-1);double fx=sx-x0,fy=sy-y0;auto p=[&](int xx,int yy,int c){return static_cast<const uint8_t*>(m.pData)[size_t(yy)*m.RowPitch+xx*4+c];};size_t d=(size_t(oy+y)*w+ox+x)*4;for(int c=0;c<3;++c)out[d+c]=uint8_t(std::clamp((1-fy)*((1-fx)*p(x0,y0,2-c)+fx*p(x1,y0,2-c))+fy*((1-fx)*p(x0,y1,2-c)+fx*p(x1,y1,2-c)),0.,255.));}
  s.context->Unmap(s.staging.p,0);s.copy_pending=false;source_width=cw;source_height=ch;fresh=true;++frames;status="window_menu_captured";error.clear();return true;
 }
 wgc::Ptr<wgc::Frame> frame;HRESULT hr=s.pool->Next(frame.put());if(FAILED(hr))return fail("WGC frame acquisition failed",hr);if(!frame){status="waiting_wgc_frame";return true;}++received;
 struct CloseFrame {wgc::Frame* f;~CloseFrame(){wgc::close(f);}} closed{frame.p};
 INT64 stamp=0;wgc::Size content{};if(FAILED(frame->Time(&stamp))||FAILED(frame->ContentSize(&content)))return fail("WGC frame metadata failed",E_FAIL);
 if(content.Width!=s.size.Width||content.Height!=s.size.Height){if(content.Width<=0||content.Height<=0||content.Width>16384||content.Height>16384)return fail("Invalid resized window",E_FAIL);s.size=content;wgc::close(frame.p);closed.f=nullptr;frame.reset();hr=s.pool->Recreate(s.rtDevice.p,87,2,s.size);s.after=wgc::now();return FAILED(hr)?fail("WGC resize failed",hr):true;}
 if(stamp<s.after){++stale;status="discarded_previous_page_frame";return true;}
 wgc::Ptr<IInspectable> surface;wgc::Ptr<wgc::Access> access;wgc::Ptr<ID3D11Texture2D> texture;
 hr=frame->Surface(surface.put());if(SUCCEEDED(hr))hr=surface->QueryInterface(wgc::iidAccess,reinterpret_cast<void**>(access.put()));if(SUCCEEDED(hr))hr=access->GetInterface(__uuidof(ID3D11Texture2D),reinterpret_cast<void**>(texture.put()));if(FAILED(hr))return fail("WGC texture access failed",hr);
 D3D11_TEXTURE2D_DESC d{};texture->GetDesc(&d);if(d.Format!=DXGI_FORMAT_B8G8R8A8_UNORM||d.Width<UINT(content.Width)||d.Height<UINT(content.Height))return fail("Unexpected WGC texture format",E_FAIL);
 RECT bounds{},client{};POINT origin{};
 if(FAILED(DwmGetWindowAttribute(s.window,DWMWA_EXTENDED_FRAME_BOUNDS,&bounds,sizeof bounds))||!GetClientRect(s.window,&client)||!ClientToScreen(s.window,&origin))return fail("Cannot locate game client rectangle",E_FAIL);
 // Get unvirtualized physical coordinates even when the game uses DPI scaling.
 const int bw=bounds.right-bounds.left,bh=bounds.bottom-bounds.top;
 client.left=origin.x-bounds.left;client.top=origin.y-bounds.top;client.right+=client.left;client.bottom+=client.top;
 if(bw!=content.Width||bh!=content.Height||client.left<0||client.top<0||client.right>content.Width||client.bottom>content.Height||client.right<=client.left||client.bottom<=client.top){
  // Geometry may disagree during resize/DPI changes. The complete WGC window
  // remains valid: show it (possibly with borders) rather than drop every frame.
  ++bounds_mismatches;++bounds_fallbacks;
  client={0,0,content.Width,content.Height};
 }
 s.client=client;
 if(!s.staging||s.stagingW!=d.Width||s.stagingH!=d.Height){s.staging.reset();d.BindFlags=0;d.MiscFlags=0;d.Usage=D3D11_USAGE_STAGING;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;hr=s.device->CreateTexture2D(&d,nullptr,s.staging.put());if(FAILED(hr))return fail("WGC staging allocation failed",hr);s.stagingW=d.Width;s.stagingH=d.Height;}
 s.context->CopyResource(s.staging.p,texture.p);s.context->Flush();s.copy_pending=true;s.copy_started=GetTickCount64();status="capture_readback_queued";return true;
}
}
