#pragma once
#include <BetterEndfield/ThirdPartyModule.h>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include "hg_ui_camera.h"

namespace vrvd {
enum class HudComposition { Auto, Transparent, Opaque, GameUi };
// Captures actual active screen-space Canvas UI, never a camera/world screenshot.
// All functions after resolve must run on Unity's game thread. Destruction does
// not invoke Unity; cleanup must finish before unloading the module.
class UnityHud {
public:
    UnityHud();
    ~UnityHud();
    UnityHud(const UnityHud&) = delete;
    UnityHud& operator=(const UnityHud&) = delete;
    bool resolve(const BE_HostApiV1*, std::string&, HudNativeResolver resolver=nullptr);
    // Output commits only after capture AND restoration succeed. RGBA8 linear,
    // premultiplied alpha, tightly packed, TOP-LEFT origin. Never reuse output
    // from a failed call as the current frame's HUD.
    bool capture(uint32_t width, uint32_t height, std::vector<uint8_t>& rgba, std::string&, HudComposition mode=HudComposition::Auto);
    uint32_t count() const;
    uint32_t skipped_count() const;
    std::string capture_path() const;
    std::string warning() const;
    bool opaque() const;
    bool restore_pending() const;
    bool resources_alive() const;
    void cleanup();
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
}
