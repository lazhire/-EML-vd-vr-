#pragma once
#include <BetterEndfield/ThirdPartyModule.h>
#include <cstdint>
#include <memory>
#include <string>

namespace vrvd {
using DesktopNativeResolver=void*(*)(const char*);
// Windows x64: verified ScriptableRenderContext contains one pointer and is
// passed in RDX by value. Installation rechecks class_value_size == 8.
struct DesktopRenderContext { uintptr_t value=0; };
using DesktopRenderNative=void(*)(void*,DesktopRenderContext,void*,const void*);
struct DesktopFilterSnapshot {
    bool installed=false,armed=false;
    int32_t submitted_frame=-1;
    uint64_t calls=0,filtered_calls=0,filtered_cameras=0,empty_lists=0,
        pass_through_calls=0,contract_failures=0;
    std::string status="not_installed",error;
};
// Optional HG List<Camera> filter. It does not disable or change the source
// Camera. A normal HG Render receives a NEW list without the exact marked
// source; eye/HUD/reflection cameras remain untouched. Calls pass through unless
// the current game thread/frame has already submitted a successful stereo pair.
class DesktopRenderFilter {
public:
    DesktopRenderFilter();
    ~DesktopRenderFilter(); // Disarms only. Caller must finish shutdown first.
    bool install(const BE_HostApiV1*,std::string&,DesktopNativeResolver=nullptr);
    bool mark_submitted(void* source_camera,int32_t unity_frame,std::string&);
    // Immediate gate; safe from a settings/stop thread. Does not free GC roots.
    void disable();
    // Game-thread clear; false if a different thread still owns the source root.
    bool clear();
    // Disarms, clears root and releases only endfield.vr.desktop hooks.
    bool shutdown();
    bool resources_alive() const;
    DesktopFilterSnapshot snapshot() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
}
