#pragma once
#include "xr_vulkan.h"

namespace vrvd {

// An independent OpenVR scene client. This does not install a Unity XR provider.
// All methods must be serialized on the game thread. The D3D11 upload device is
// owned here and is unrelated to Unity's Vulkan/D3D graphics device.
class OpenVrBackend {
public:
    OpenVrBackend();
    ~OpenVrBackend();
    OpenVrBackend(const OpenVrBackend&) = delete;
    OpenVrBackend& operator=(const OpenVrBackend&) = delete;
    bool initialize_owned(const wchar_t* loader_path, uint32_t width, uint32_t height,
                          std::string& error);
    bool begin_frame(Eye eyes[2], bool& should_render, std::string& error);
    // Independent, tightly packed, top-left, linear RGBA8 images. HUD, if supplied,
    // uses the same pixel convention with premultiplied alpha. nullptr hides HUD.
    bool submit_rgba(const void* left, const void* right, size_t bytes_per_eye,
                     std::string& error, const XrVulkanHudFrame* hud = nullptr);
    void cancel_frame();
    void request_recenter();
    bool running() const;
    bool frame_pending() const;
    std::string runtime_name() const;
    std::string graphics_name() const;
    // Shared UI schema: submitted_frames counts successful paired OpenVR Submit
    // calls, not xrEndFrame or proof of presentation. Refresh-extension fields are
    // false; current_display_hz is a read-only SteamVR HMD property if available.
    XrVulkanDiagnostics diagnostics() const;
    // False retains resources after a bounded GPU wait. Caller must keep this
    // object and addon DLL alive, and retry shutdown before unloading the addon.
    bool shutdown();
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// Pure conversion/validation used by the backend and offline geometry fixtures.
// Raw OpenVR slots are named left/right/top/bottom. Valve's Unity provider uses
// raw bottom for geometric +Y/up, and raw top for -Y/down (see provenance).
namespace openvr_detail {
struct RecenterState { bool valid=false; float origin[3]{}; float yaw=0; };
bool convert_eyes(const float head[3][4], const float eye_to_head[2][3][4],
                  const float raw_fov[2][4], bool recenter, RecenterState& state,
                  Eye output[2], std::string& error);
bool validate_rgba(const void* left, const void* right, uint32_t width, uint32_t height,
                   size_t bytes_per_eye, std::string& error);
bool validate_hud(const XrVulkanHudFrame& hud, std::string& error);
}
} // namespace vrvd
