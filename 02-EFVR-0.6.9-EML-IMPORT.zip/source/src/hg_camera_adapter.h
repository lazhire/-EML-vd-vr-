#pragma once
#include <BetterEndfield/ThirdPartyModule.h>
#include "hg_projection_hook.h"
#include <memory>
#include <string>

namespace vrvd {
// Optional resolver injection is for game-free tests. Production resolves only
// named IL2CPP exports from the already-loaded GameAssembly.dll.
using HgNativeResolver = void* (*)(const char* name);

class HgCameraAdapter {
public:
    HgCameraAdapter();
    ~HgCameraAdapter(); // No Unity calls. Call cleanup on the game thread.
    HgCameraAdapter(const HgCameraAdapter&) = delete;
    HgCameraAdapter& operator=(const HgCameraAdapter&) = delete;
    bool resolve(const BE_HostApiV1*, std::string& error, HgNativeResolver = nullptr);
    // Game thread, after Camera.CopyFrom and before eye pose/projection setters.
    // eyeGO/eyeCamera MUST be this module's private objects. The source is read-only.
    // Absent HG types are a no-op (available=false); an incompatible HG contract
    // fails closed. Projection hooks use EML's shared hook chain and only route
    // private eyes while their explicit Render scope is active.
    bool prepare(void* mainCamera, void* eyeCamera, void* eyeGO,
                 unsigned eyeIndex, std::string& error);
    bool begin_projection(unsigned eyeIndex,const float matrix[16],std::string& error);
    bool end_projection(unsigned eyeIndex,std::string& error);
    void clear_projection();
    HgProjectionSnapshot projection_diagnostics() const;
    // Caller destroys owned eye GameObjects first, then releases both predicted
    // and draw-time HG roots. The engine's subsequent CleanUnused removes HG
    // entries for destroyed cameras even when private isPersistent was true.
    // Does not destroy/reset the original camera, components, or shared history.
    void cleanup();
    bool available() const;
    bool active() const; // Both private eye components are prepared.
    bool resources_alive() const;
    std::string status() const;
    int source_fullscreen_passthrough() const; // Cached: -1 unknown, 0/1 source flag.
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
}
