#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace vrvd {
// Window-only WGC fallback. No input injection, desktop capture or Unity writes.
class WindowMenuCapture {
 struct Impl; Impl* impl_;
public:
 WindowMenuCapture();
 // Explicit cleanup runs outside loader lock, on the polling thread.
 ~WindowMenuCapture();
 // generation is retained for probe ABI compatibility; final-window capture is continuous.
 bool poll(uint64_t generation,uint32_t w,uint32_t h,std::vector<uint8_t>& out,bool& fresh,std::string& error);
 void cleanup();
 bool resources_alive()const;
 std::string status="idle";
 uint64_t frames=0;
 uint64_t polls=0,received=0,stale=0,gpu_waits=0,bounds_mismatches=0,bounds_fallbacks=0;
 uint32_t source_width=0,source_height=0;
#ifdef EFVR_CAPTURE_PROBE
 void probe_process(uint32_t pid);
#endif
};
}
