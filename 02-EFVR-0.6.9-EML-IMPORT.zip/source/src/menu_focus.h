#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
namespace vrvd {
// Pure CPU presentation transform. The backdrop is decorative and monoscopic;
// it is never submitted as a live world or as a pair of projected eye images.
struct MenuFocusPixels {
 std::vector<uint8_t> panel,backdrop;
 void clear(){panel.clear();backdrop.clear();}
};
inline bool make_menu_focus(const std::vector<uint8_t>& rgba,unsigned w,unsigned h,
 unsigned sourceW,unsigned sourceH,unsigned radius,float brightness,unsigned feather,
 MenuFocusPixels& out,std::string& error){
 out.clear();
 constexpr unsigned N=128;
 if(!w||!h||w>4096||h>4096||rgba.size()!=size_t(w)*h*4||!sourceW||!sourceH||
    sourceW>16384||sourceH>16384||radius<1||radius>16||!std::isfinite(brightness)||brightness<.1f||brightness>1.f||feather>32){
  error="Invalid menu focus pixels or settings";return false;
 }
 unsigned fw=w,fh=std::max(1u,unsigned(uint64_t(w)*sourceH/sourceW));
 if(fh>h){fh=h;fw=std::max(1u,unsigned(uint64_t(h)*sourceW/sourceH));}
 unsigned ox=(w-fw)/2,oy=(h-fh)/2;
 std::vector<float> small(N*N*3),horizontal(small.size());
 // Bilinear downsample of the content rectangle, excluding opaque letterbox bars.
 for(unsigned y=0;y<N;++y)for(unsigned x=0;x<N;++x){
  float sx=ox+(x+.5f)*fw/N-.5f,sy=oy+(y+.5f)*fh/N-.5f;
  sx=std::clamp(sx,float(ox),float(ox+fw-1));sy=std::clamp(sy,float(oy),float(oy+fh-1));
  unsigned x0=unsigned(sx),y0=unsigned(sy),x1=std::min(x0+1,ox+fw-1),y1=std::min(y0+1,oy+fh-1);
  float fx=sx-x0,fy=sy-y0;
  for(unsigned c=0;c<3;++c){
   auto at=[&](unsigned px,unsigned py){return float(rgba[(size_t(py)*w+px)*4+c]);};
   small[(y*N+x)*3+c]=(at(x0,y0)*(1-fx)+at(x1,y0)*fx)*(1-fy)+(at(x0,y1)*(1-fx)+at(x1,y1)*fx)*fy;
  }
 }
 float sigma=std::max(1.f,radius/3.f),sum=0;std::vector<float> kernel(2*radius+1);
 for(int i=-int(radius);i<=int(radius);++i){float v=std::exp(-float(i*i)/(2*sigma*sigma));kernel[i+radius]=v;sum+=v;}
 for(auto& v:kernel)v/=sum;
 for(unsigned y=0;y<N;++y)for(unsigned x=0;x<N;++x)for(unsigned c=0;c<3;++c){
  float v=0;for(int i=-int(radius);i<=int(radius);++i)v+=small[(y*N+std::clamp(int(x)+i,0,int(N)-1))*3+c]*kernel[i+radius];
  horizontal[(y*N+x)*3+c]=v;
 }
 out.backdrop.resize(N*N*4);
 for(unsigned y=0;y<N;++y)for(unsigned x=0;x<N;++x){
  for(unsigned c=0;c<3;++c){float v=0;for(int i=-int(radius);i<=int(radius);++i)v+=horizontal[(std::clamp(int(y)+i,0,int(N)-1)*N+x)*3+c]*kernel[i+radius];
   out.backdrop[(y*N+x)*4+c]=uint8_t(std::clamp(std::lround(v*brightness),0l,255l));}
  out.backdrop[(y*N+x)*4+3]=255;
 }
 out.panel.assign(rgba.size(),0);
 const unsigned fade=std::min(feather,std::min(fw,fh)/4);
 for(unsigned y=0;y<fh;++y){
  // Native final capture is opaque. Copy its clear interior without per-pixel
  // float conversion; only the narrow feather border needs arithmetic.
  std::memcpy(out.panel.data()+(size_t(oy+y)*w+ox)*4,rgba.data()+(size_t(oy+y)*w+ox)*4,size_t(fw)*4);
  auto edge=[&](unsigned x){
  unsigned d=std::min({x,y,fw-1-x,fh-1-y});float a=fade?std::min(1.f,float(d)/fade):1.f;a=a*a*(3-2*a);
  size_t p=(size_t(oy+y)*w+ox+x)*4;
  for(unsigned c=0;c<3;++c)out.panel[p+c]=uint8_t(std::lround(rgba[p+c]*a));
  out.panel[p+3]=uint8_t(std::lround(255*a));
  };
  if(fade){
   if(y<fade||y>=fh-fade)for(unsigned x=0;x<fw;++x)edge(x);
   else {for(unsigned x=0;x<fade;++x)edge(x);for(unsigned x=fw-fade;x<fw;++x)edge(x);}
  }
 }
 return true;
}
}
