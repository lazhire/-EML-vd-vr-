#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include "openvr_backend.h"
// Use only dynamically resolved C entry points; no import-library references.
#define OPENVR_BUILD_STATIC
#include "../vendor/openvr/headers/openvr.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <cwchar>
#include <limits>
#include <sstream>

namespace vrvd {
namespace {
constexpr uint32_t kMaxDimension = 4096;
constexpr DWORD kGpuWaitMs = 2000;
template<class T> void release_com(T*& p) { if(p) { p->Release(); p=nullptr; } }
double elapsed_ms(std::chrono::steady_clock::time_point start) {
    return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
}
std::string hr_error(const char* where, HRESULT hr) {
    std::ostringstream out; out<<where<<" failed (HRESULT 0x"<<std::hex<<uint32_t(hr)<<")."; return out.str();
}
bool valid_rigid(const float m[3][4]) {
    for(int r=0;r<3;++r) for(int c=0;c<4;++c)
        if(!std::isfinite(m[r][c]) || (c==3 && std::fabs(m[r][c])>100000.f)) return false;
    // Reject scale, shear, reflections and uninitialized matrices before turning
    // a matrix into a unit quaternion. Runtime rotations may contain roundoff.
    for(int i=0;i<3;++i) for(int j=0;j<3;++j) {
        float dot=0; for(int k=0;k<3;++k) dot+=m[k][i]*m[k][j];
        if(std::fabs(dot-(i==j?1.f:0.f))>0.005f) return false;
    }
    const float det=m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])
                   -m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])
                   +m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0]);
    return std::fabs(det-1.f)<0.01f;
}
void quaternion(const float m[3][4], float q[4]) {
    const float trace=m[0][0]+m[1][1]+m[2][2];
    if(trace>0) {
        const float s=2.f*std::sqrt(trace+1.f);
        q[3]=s*.25f; q[0]=(m[2][1]-m[1][2])/s;
        q[1]=(m[0][2]-m[2][0])/s; q[2]=(m[1][0]-m[0][1])/s;
    } else {
        int i=0; if(m[1][1]>m[i][i])i=1; if(m[2][2]>m[i][i])i=2;
        const int j=(i+1)%3,k=(i+2)%3;
        const float s=2.f*std::sqrt(1.f+m[i][i]-m[j][j]-m[k][k]);
        q[i]=s*.25f; q[j]=(m[j][i]+m[i][j])/s;
        q[k]=(m[k][i]+m[i][k])/s; q[3]=(m[k][j]-m[j][k])/s;
    }
    float length=0; for(int i=0;i<4;++i)length+=q[i]*q[i];
    const float inv=1.f/std::sqrt(length);for(int i=0;i<4;++i)q[i]*=inv;
}
bool absolute_dll_path(const wchar_t* path) {
    if(!path || !*path)return false;
    const size_t n=std::wcslen(path);
    const bool drive=n>3 && ((path[0]>=L'A'&&path[0]<=L'Z')||(path[0]>=L'a'&&path[0]<=L'z'))
                     && path[1]==L':' && (path[2]==L'\\'||path[2]==L'/');
    const bool unc=n>4 && path[0]==L'\\' && path[1]==L'\\';
    const wchar_t* leaf=path;
    for(const wchar_t* p=path;*p;++p)if(*p==L'\\'||*p==L'/')leaf=p+1;
    return (drive||unc) && _wcsicmp(leaf,L"openvr_api.dll")==0;
}
} // namespace

namespace openvr_detail {
bool validate_rgba(const void* left,const void* right,uint32_t width,uint32_t height,
                   size_t bytes,std::string& error) {
    error.clear();
    if(!left || !right || left==right || !width || !height || width>kMaxDimension || height>kMaxDimension) {
        error="OpenVR requires distinct eye RGBA buffers and dimensions within 1..4096.";return false;
    }
    if(bytes!=uint64_t(width)*height*4) {
        error="OpenVR eye RGBA byte count must equal width*height*4 exactly.";return false;
    }
    return true;
}
bool validate_hud(const XrVulkanHudFrame& hud,std::string& error) {
    error.clear();
    if(!hud.rgba||!hud.width||!hud.height||hud.width>kMaxDimension||hud.height>kMaxDimension ||
       hud.bytes!=uint64_t(hud.width)*hud.height*4) {
        error="OpenVR HUD requires RGBA pixels, dimensions 1..4096, and exactly width*height*4 bytes.";return false;
    }
    const float height_m=hud.width_m*(float(hud.height)/float(hud.width));
    if(!std::isfinite(hud.distance_m)||hud.distance_m<=0 || !std::isfinite(hud.width_m)||hud.width_m<=0 ||
       !std::isfinite(hud.offset_y_m)||!std::isfinite(height_m)||height_m<=0) {
        error="OpenVR HUD distance and size must be positive finite metres; offset must be finite.";return false;
    }
    return true;
}
bool convert_eyes(const float head[3][4],const float eye_to_head[2][3][4],
                  const float raw[2][4],bool recenter,RecenterState& state,Eye output[2],std::string& error) {
    error.clear();
    if(!head||!eye_to_head||!raw||!output||!valid_rigid(head)) {
        error="OpenVR returned an invalid HMD tracking transform.";return false;
    }
    Eye eyes[2]{};
    for(int eye=0;eye<2;++eye) {
        if(!valid_rigid(eye_to_head[eye])) {
            error="OpenVR returned an invalid eye-to-head transform.";return false;
        }
        for(int i=0;i<4;++i) if(!std::isfinite(raw[eye][i])||std::fabs(raw[eye][i])>100.f) {
            error="OpenVR returned a non-finite or implausible eye FOV tangent.";return false;
        }
        if(!(raw[eye][0]<0 && raw[eye][1]>0 && raw[eye][2]<0 && raw[eye][3]>0)) {
            error="OpenVR eye FOV must enclose the forward axis (left/top negative, right/bottom positive).";return false;
        }
        float world[3][4]{};
        for(int r=0;r<3;++r)for(int c=0;c<4;++c) {
            world[r][c]=c==3?head[r][3]:0;
            for(int k=0;k<3;++k)world[r][c]+=head[r][k]*eye_to_head[eye][k][c];
        }
        quaternion(world,eyes[eye].orientation);
        for(int i=0;i<3;++i)eyes[eye].position[i]=world[i][3];
        eyes[eye].angleLeft=std::atan(raw[eye][0]);
        eyes[eye].angleRight=std::atan(raw[eye][1]);
        // Match Valve's Unity XR provider: geometric top=rawBottom and
        // bottom=rawTop. Negating rawTop would mirror an asymmetric projection.
        // See vendor/openvr/PROVENANCE.md for the pinned reference implementation.
        eyes[eye].angleUp=std::atan(raw[eye][3]);
        eyes[eye].angleDown=std::atan(raw[eye][2]);
    }
    // Validate the physical eye separation in head space; do not silently fix
    // crossed eye metadata. Rotated/canted displays retain their own rotations.
    const float dx=eye_to_head[1][0][3]-eye_to_head[0][0][3];
    const float dy=eye_to_head[1][1][3]-eye_to_head[0][1][3];
    const float dz=eye_to_head[1][2][3]-eye_to_head[0][2][3];
    const float ipd=std::sqrt(dx*dx+dy*dy+dz*dz);
    if(!(dx>0 && ipd>=0.02f && ipd<=0.12f)) {
        error="OpenVR eye transforms have invalid/crossed IPD metadata (expected 20..120 mm).";return false;
    }
    RecenterState next=state;
    if(recenter||!next.valid) {
        for(int i=0;i<3;++i)next.origin[i]=(eyes[0].position[i]+eyes[1].position[i])*.5f;
        float q[4]{},length=0;
        float dot=0;for(int i=0;i<4;++i)dot+=eyes[0].orientation[i]*eyes[1].orientation[i];
        for(int i=0;i<4;++i){q[i]=eyes[0].orientation[i]+(dot<0?-1.f:1.f)*eyes[1].orientation[i];length+=q[i]*q[i];}
        const float inv=1.f/std::sqrt(length);for(float& v:q)v*=inv;
        next.yaw=std::atan2(2.f*(q[0]*q[2]+q[3]*q[1]),1.f-2.f*(q[0]*q[0]+q[1]*q[1]));
        next.valid=true;
    }
    if(!std::isfinite(next.yaw)||!std::isfinite(next.origin[0])||!std::isfinite(next.origin[1])||!std::isfinite(next.origin[2])) {
        error="OpenVR recenter state is non-finite.";return false;
    }
    const float cy=std::cos(next.yaw),sy=std::sin(next.yaw);
    const float hc=std::cos(-next.yaw*.5f),hs=std::sin(-next.yaw*.5f);
    for(auto& eye:eyes) {
        const float x=eye.position[0]-next.origin[0],y=eye.position[1]-next.origin[1],z=eye.position[2]-next.origin[2];
        eye.position[0]=cy*x-sy*z;eye.position[1]=y;eye.position[2]=sy*x+cy*z;
        float q[4];std::memcpy(q,eye.orientation,sizeof q);
        eye.orientation[0]=hc*q[0]+hs*q[2];eye.orientation[1]=hc*q[1]+hs*q[3];
        eye.orientation[2]=hc*q[2]-hs*q[0];eye.orientation[3]=hc*q[3]-hs*q[1];
    }
    state=next;std::memcpy(output,eyes,sizeof eyes);return true;
}
} // namespace openvr_detail

struct OpenVrBackend::Impl {
    using InitFn=uint32_t(VR_CALLTYPE*)(vr::EVRInitError*,vr::EVRApplicationType,const char*);
    using InterfaceFn=void*(VR_CALLTYPE*)(const char*,vr::EVRInitError*);
    using ShutdownFn=void(VR_CALLTYPE*)();
    using ErrorFn=const char*(VR_CALLTYPE*)(vr::EVRInitError);
    HMODULE loader=nullptr;
    InitFn init=nullptr;InterfaceFn get_interface=nullptr;ShutdownFn shutdown_runtime=nullptr;ErrorFn init_error=nullptr;
    vr::IVRSystem* system=nullptr;
    vr::IVRCompositor* compositor=nullptr;
    vr::IVROverlay* overlay=nullptr;
    vr::VROverlayHandle_t hud_handle=vr::k_ulOverlayHandleInvalid;
    ID3D11Device* device=nullptr;
    ID3D11DeviceContext* context=nullptr;
    ID3D11Texture2D* texture[2]{};
    ID3D11Texture2D* hud_texture=nullptr;
    ID3D11Query* fence=nullptr;
    bool initialized=false,active=false,pending=false,renderable=false,faulted=false,recenter=true;
    bool gpu_dirty=false,fence_pending=false,scene_cleared=true;
    uint32_t width=0,height=0,hud_width=0,hud_height=0;
    DWORD owner_thread=0;
    std::string runtime,graphics;
    XrVulkanDiagnostics stats{};
    openvr_detail::RecenterState origin;

    bool on_owner(std::string& error) const {
        if(owner_thread && owner_thread!=GetCurrentThreadId()) {
            error="OpenVR upload/runtime calls must run on the initializing game thread.";return false;
        }
        return true;
    }
    std::string vr_error(const char* where,vr::EVRInitError code) const {
        const char* detail=init_error?init_error(code):nullptr;
        return std::string(where)+" failed: "+(detail?detail:std::to_string(int(code)))+
            ". Connect VD to SteamVR and ensure the installed runtime supports the requested OpenVR interface.";
    }
    bool overlay_ok(vr::EVROverlayError code,const char* where,std::string& error) const {
        if(code==vr::VROverlayError_None)return true;
        error=std::string(where)+" failed (OpenVR overlay error "+std::to_string(int(code))+").";return false;
    }
    bool hide_hud(std::string& error) {
        if(overlay && hud_handle!=vr::k_ulOverlayHandleInvalid)
            return overlay_ok(overlay->HideOverlay(hud_handle),"HideOverlay",error);
        return true;
    }
    bool wait_gpu(std::string& error) {
        if(!gpu_dirty || !context || !fence)return true;
        const auto begin=std::chrono::steady_clock::now();
        if(!fence_pending) { context->End(fence);context->Flush();fence_pending=true; }
        const ULONGLONG deadline=GetTickCount64()+kGpuWaitMs;
        HRESULT hr=S_FALSE;BOOL done=FALSE;
        do {
            hr=context->GetData(fence,&done,sizeof done,D3D11_ASYNC_GETDATA_DONOTFLUSH);
            if(hr==S_OK && done)break;
            if(FAILED(hr))break;
            Sleep(1);
        } while(GetTickCount64()<deadline);
        stats.gpu_fence_wait_cpu_known=true;stats.gpu_fence_wait_cpu_ms=elapsed_ms(begin);
        if(hr==S_OK&&done){gpu_dirty=false;fence_pending=false;return true;}
        if(FAILED(hr)) {
            // A removed device has discarded its work, so releasing its COM
            // resources is safe. Preserve the failure for the submit caller.
            if(device && FAILED(device->GetDeviceRemovedReason())) { gpu_dirty=false;fence_pending=false; }
            error=hr_error("OpenVR D3D11 upload completion",hr);return false;
        }
        ++stats.fence_timeout_count;
        error="OpenVR D3D11 upload did not complete within 2000 ms; resources retained. Stop VR and retry shutdown.";
        return false;
    }
    bool create_texture(uint32_t w,uint32_t h,ID3D11Texture2D** out,std::string& error) {
        D3D11_TEXTURE2D_DESC desc{};
        desc.Width=w;desc.Height=h;desc.MipLevels=1;desc.ArraySize=1;
        desc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;desc.SampleDesc.Count=1;
        desc.Usage=D3D11_USAGE_DEFAULT;desc.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_RENDER_TARGET;
        const HRESULT hr=device->CreateTexture2D(&desc,nullptr,out);
        if(FAILED(hr)){error=hr_error("Create OpenVR RGBA8 upload texture",hr);return false;}return true;
    }
    bool prepare_hud(const XrVulkanHudFrame& hud,std::string& error) {
        if(!overlay) {error="SteamVR IVROverlay_027 is unavailable; head-locked HUD cannot be submitted. Disable HUD or update SteamVR.";return false;}
        if(hud_texture&&(hud.width!=hud_width||hud.height!=hud_height)) {
            error="OpenVR HUD dimensions changed during a session; stop and restart VR to resize HUD.";return false;
        }
        if(!hud_texture) {
            if(!create_texture(hud.width,hud.height,&hud_texture,error))return false;
            hud_width=hud.width;hud_height=hud.height;
        }
        if(hud_handle==vr::k_ulOverlayHandleInvalid) {
            const std::string key="eml.first-person-vr.hud."+std::to_string(GetCurrentProcessId());
            if(!overlay_ok(overlay->CreateOverlay(key.c_str(),"Endfield VR HUD",&hud_handle),"CreateOverlay",error))return false;
            if(!overlay_ok(overlay->SetOverlayFlag(hud_handle,vr::VROverlayFlags_IsPremultiplied,true),"SetOverlayFlag(IsPremultiplied)",error) ||
               !overlay_ok(overlay->SetOverlayTextureColorSpace(hud_handle,vr::ColorSpace_Linear),"SetOverlayTextureColorSpace",error) ||
               !overlay_ok(overlay->SetOverlayTexelAspect(hud_handle,1.f),"SetOverlayTexelAspect",error))return false;
            const vr::VRTextureBounds_t bounds{0,0,1,1};
            if(!overlay_ok(overlay->SetOverlayTextureBounds(hud_handle,&bounds),"SetOverlayTextureBounds",error))return false;
        }
        vr::HmdMatrix34_t relative{};
        relative.m[0][0]=relative.m[1][1]=relative.m[2][2]=1.f;
        relative.m[1][3]=hud.offset_y_m;relative.m[2][3]=-hud.distance_m;
        return overlay_ok(overlay->SetOverlayWidthInMeters(hud_handle,hud.width_m),"SetOverlayWidthInMeters",error) &&
            overlay_ok(overlay->SetOverlayTransformTrackedDeviceRelative(hud_handle,vr::k_unTrackedDeviceIndex_Hmd,&relative),
                       "SetOverlayTransformTrackedDeviceRelative",error);
    }
    void abort_frame() {
        pending=false;renderable=false;faulted=true;active=false;
        if(compositor){compositor->ClearLastSubmittedFrame();scene_cleared=true;}
        std::string ignored;hide_hud(ignored);
    }
    bool close() {
        std::string ignored;
        if(!on_owner(ignored))return false;
        active=false;pending=false;renderable=false;faulted=true;
        if(compositor && !scene_cleared) {compositor->ClearLastSubmittedFrame();scene_cleared=true;}
        if(overlay && hud_handle!=vr::k_ulOverlayHandleInvalid) {
            // Unpublish resources before waiting/releasing; runtime shutdown is
            // still responsible for releasing any remaining compositor refs.
            overlay->HideOverlay(hud_handle);
            overlay->ClearOverlayTexture(hud_handle);
            if(overlay->DestroyOverlay(hud_handle)==vr::VROverlayError_None)
                hud_handle=vr::k_ulOverlayHandleInvalid;
        }
        // Detach the OpenVR client now, even when our independent upload GPU is
        // slow. In particular, VR_Shutdown must not wait for another Unity tick
        // after VREvent_Quit: SteamVR can terminate an unresponsive scene app.
        // Our own COM references keep upload resources alive until the query
        // completes; they do not require a live OpenVR client/interface.
        if(initialized&&shutdown_runtime)shutdown_runtime();
        initialized=false;system=nullptr;compositor=nullptr;overlay=nullptr;
        hud_handle=vr::k_ulOverlayHandleInvalid;
        if(!wait_gpu(ignored) && gpu_dirty)return false;
        release_com(hud_texture);for(auto& t:texture)release_com(t);
        release_com(fence);release_com(context);release_com(device);
        if(loader)FreeLibrary(loader);
        loader=nullptr;init=nullptr;get_interface=nullptr;shutdown_runtime=nullptr;init_error=nullptr;
        width=height=hud_width=hud_height=0;owner_thread=0;
        gpu_dirty=fence_pending=false;recenter=true;origin={};stats={};runtime.clear();graphics.clear();
        return true;
    }
};

OpenVrBackend::OpenVrBackend():impl_(new Impl) {}
OpenVrBackend::~OpenVrBackend() {
    // Keep timed-out COM/runtime resources alive rather than release in-flight
    // commands. The module must also refuse unloading on shutdown()==false.
    if(!shutdown())impl_.release();
}
bool OpenVrBackend::initialize_owned(const wchar_t* path,uint32_t width,uint32_t height,std::string& error) {
    error.clear();auto& p=*impl_;
    if(!p.close()){error="Previous OpenVR GPU resources are still busy; retry shutdown before restarting.";return false;}
    if(!absolute_dll_path(path)) {error="SteamVR loader must be an absolute path ending in openvr_api.dll.";return false;}
    if(!width||!height||width>kMaxDimension||height>kMaxDimension) {error="OpenVR eye dimensions must be within 1..4096.";return false;}
    p.owner_thread=GetCurrentThreadId();
    const auto fail=[&](const std::string& why){error=why;p.close();return false;};
    p.loader=LoadLibraryExW(path,nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    if(!p.loader)return fail("Unable to load SteamVR openvr_api.dll (Win32 error "+std::to_string(GetLastError())+").");
    p.init=reinterpret_cast<Impl::InitFn>(GetProcAddress(p.loader,"VR_InitInternal2"));
    p.get_interface=reinterpret_cast<Impl::InterfaceFn>(GetProcAddress(p.loader,"VR_GetGenericInterface"));
    p.shutdown_runtime=reinterpret_cast<Impl::ShutdownFn>(GetProcAddress(p.loader,"VR_ShutdownInternal"));
    p.init_error=reinterpret_cast<Impl::ErrorFn>(GetProcAddress(p.loader,"VR_GetVRInitErrorAsEnglishDescription"));
    if(!p.init||!p.get_interface||!p.shutdown_runtime)return fail("SteamVR DLL lacks the required OpenVR C exports.");
    vr::EVRInitError code=vr::VRInitError_None;
    p.init(&code,vr::VRApplication_Scene,nullptr);
    if(code!=vr::VRInitError_None)return fail(p.vr_error("VR_InitInternal2",code));
    p.initialized=true;
    p.system=static_cast<vr::IVRSystem*>(p.get_interface(vr::IVRSystem_Version,&code));
    if(!p.system||code!=vr::VRInitError_None)return fail(p.vr_error(vr::IVRSystem_Version,code));
    p.compositor=static_cast<vr::IVRCompositor*>(p.get_interface(vr::IVRCompositor_Version,&code));
    if(!p.compositor||code!=vr::VRInitError_None)return fail(p.vr_error(vr::IVRCompositor_Version,code));
    p.overlay=static_cast<vr::IVROverlay*>(p.get_interface(vr::IVROverlay_Version,&code));
    if(code!=vr::VRInitError_None)p.overlay=nullptr; // Error only if HUD requested.
    if(!p.system->IsTrackedDeviceConnected(vr::k_unTrackedDeviceIndex_Hmd))return fail("SteamVR reports no connected headset. Connect Quest 3 using VD, then launch SteamVR.");
    p.runtime="SteamVR / OpenVR";
    if(const char* version=p.system->GetRuntimeVersion())p.runtime+=" "+std::string(version);
    int32_t adapter_index=-1;p.system->GetDXGIOutputInfo(&adapter_index);
    if(adapter_index<0)return fail("SteamVR did not provide a valid DXGI adapter for the headset.");
    IDXGIFactory1* factory=nullptr;IDXGIAdapter* adapter=nullptr;
    HRESULT hr=CreateDXGIFactory1(__uuidof(IDXGIFactory1),reinterpret_cast<void**>(&factory));
    if(FAILED(hr))return fail(hr_error("CreateDXGIFactory1",hr));
    hr=factory->EnumAdapters(static_cast<UINT>(adapter_index),&adapter);release_com(factory);
    if(FAILED(hr))return fail(hr_error("Enum SteamVR DXGI adapter",hr));
    DXGI_ADAPTER_DESC adapter_desc{};
    if(SUCCEEDED(adapter->GetDesc(&adapter_desc))) {
        const int len=WideCharToMultiByte(CP_UTF8,0,adapter_desc.Description,-1,nullptr,0,nullptr,nullptr);
        if(len>1) {std::string name(static_cast<size_t>(len),0);WideCharToMultiByte(CP_UTF8,0,adapter_desc.Description,-1,&name[0],len,nullptr,nullptr);name.pop_back();p.graphics=name;}
    }
    const D3D_FEATURE_LEVEL levels[]={D3D_FEATURE_LEVEL_11_0};D3D_FEATURE_LEVEL actual{};
    hr=D3D11CreateDevice(adapter,D3D_DRIVER_TYPE_UNKNOWN,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,
                         levels,1,D3D11_SDK_VERSION,&p.device,&actual,&p.context);release_com(adapter);
    if(FAILED(hr))return fail(hr_error("Create owned SteamVR D3D11 device",hr));
    p.graphics+=" / owned D3D11 RGBA upload";
    p.width=width;p.height=height;
    for(auto& t:p.texture)if(!p.create_texture(width,height,&t,error))return fail(error);
    D3D11_QUERY_DESC query{};query.Query=D3D11_QUERY_EVENT;
    hr=p.device->CreateQuery(&query,&p.fence);
    if(FAILED(hr))return fail(hr_error("Create OpenVR upload completion query",hr));
    p.compositor->SetTrackingSpace(vr::TrackingUniverseStanding);
    uint32_t recommended_w=0,recommended_h=0;
    p.system->GetRecommendedRenderTargetSize(&recommended_w,&recommended_h);
    p.stats.view_caps_known=recommended_w>0&&recommended_h>0;
    for(auto& view:p.stats.views) {
        view.recommended_width=recommended_w;view.recommended_height=recommended_h;
        view.actual_width=width;view.actual_height=height;
        // SteamVR only supplies a recommendation, not supported maximum sizes.
        view.recommended_samples=1;
    }
    vr::ETrackedPropertyError property_error=vr::TrackedProp_Success;
    const float hz=p.system->GetFloatTrackedDeviceProperty(vr::k_unTrackedDeviceIndex_Hmd,vr::Prop_DisplayFrequency_Float,&property_error);
    if(property_error==vr::TrackedProp_Success&&std::isfinite(hz)&&hz>=20&&hz<=1000) {
        p.stats.current_display_hz_known=true;p.stats.current_display_hz=hz;
    }
    p.stats.session_created=true;p.active=true;p.faulted=false;p.recenter=true;
    return true;
}

bool OpenVrBackend::begin_frame(Eye out[2],bool& draw,std::string& error) {
    error.clear();draw=false;auto& p=*impl_;
    if(!p.on_owner(error))return false;
    if(!out){error="OpenVR requires storage for two eye poses.";return false;}
    if(!p.active||p.faulted){error="OpenVR is not running; stop and reconnect VR.";return false;}
    if(p.pending){error="OpenVR frame already pending; submit or cancel it before the next frame.";return false;}
    p.renderable=false;
    vr::VREvent_t event{};
    for(int i=0;i<64&&p.system->PollNextEvent(&event,sizeof event);++i) {
        if(event.eventType==vr::VREvent_Quit) {
            p.system->AcknowledgeQuit_Exiting();
            const bool released=p.close();
            error=released?"SteamVR requested VR shutdown; the OpenVR client was disconnected. Stop and reconnect VR.":
                "SteamVR requested VR shutdown; the OpenVR client was disconnected, but upload GPU resources are still busy. Retry shutdown before unloading the module.";
            return false;
        }
    }
    vr::TrackedDevicePose_t poses[vr::k_unMaxTrackedDeviceCount]{};
    const auto start=std::chrono::steady_clock::now();
    const auto result=p.compositor->WaitGetPoses(poses,vr::k_unMaxTrackedDeviceCount,nullptr,0);
    p.stats.wait_frame_cpu_known=true;p.stats.wait_frame_cpu_ms=elapsed_ms(start);
    if(result==vr::VRCompositorError_DoNotHaveFocus) {p.pending=true;return true;}
    if(result!=vr::VRCompositorError_None) {
        p.abort_frame();error="OpenVR WaitGetPoses failed (compositor error "+std::to_string(int(result))+").";return false;
    }
    p.pending=true;
    const auto& head=poses[vr::k_unTrackedDeviceIndex_Hmd];
    if(!head.bDeviceIsConnected||!head.bPoseIsValid||head.eTrackingResult!=vr::TrackingResult_Running_OK||!p.compositor->CanRenderScene())return true;
    float eye_m[2][3][4]{},fov[2][4]{};
    for(int eye=0;eye<2;++eye) {
        const auto m=p.system->GetEyeToHeadTransform(static_cast<vr::EVREye>(eye));
        std::memcpy(eye_m[eye],m.m,sizeof m.m);
        p.system->GetProjectionRaw(static_cast<vr::EVREye>(eye),&fov[eye][0],&fov[eye][1],&fov[eye][2],&fov[eye][3]);
    }
    if(!openvr_detail::convert_eyes(head.mDeviceToAbsoluteTracking.m,eye_m,fov,p.recenter,p.origin,out,error)) {
        p.abort_frame();return false;
    }
    p.recenter=false;p.renderable=true;draw=true;return true;
}

bool OpenVrBackend::submit_rgba(const void* left,const void* right,size_t bytes,std::string& error,const XrVulkanHudFrame* hud) {
    error.clear();auto& p=*impl_;
    if(!p.on_owner(error))return false;
    if(!p.active||p.faulted||!p.pending||!p.renderable){error="OpenVR submit requires one active, pending frame with valid tracked eye poses.";return false;}
    const auto fail=[&](){p.abort_frame();return false;};
    if(!openvr_detail::validate_rgba(left,right,p.width,p.height,bytes,error))return fail();
    if(hud&&!openvr_detail::validate_hud(*hud,error))return fail();
    if(!p.wait_gpu(error))return fail();
    if(hud) {if(!p.prepare_hud(*hud,error))return fail();}
    else if(!p.hide_hud(error))return fail();
    const void* source[2]={left,right};
    for(int eye=0;eye<2;++eye)p.context->UpdateSubresource(p.texture[eye],0,nullptr,source[eye],p.width*4,0);
    if(hud)p.context->UpdateSubresource(p.hud_texture,0,nullptr,hud->rgba,hud->width*4,0);
    p.gpu_dirty=true;p.context->Flush();
    const HRESULT device_state=p.device->GetDeviceRemovedReason();
    if(FAILED(device_state)){error=hr_error("OpenVR upload device",device_state);return fail();}
    const auto start=std::chrono::steady_clock::now();
    if(hud) {
        vr::Texture_t image{p.hud_texture,vr::TextureType_DirectX,vr::ColorSpace_Linear};
        if(!p.overlay_ok(p.overlay->SetOverlayTexture(p.hud_handle,&image),"SetOverlayTexture",error) ||
           !p.overlay_ok(p.overlay->ShowOverlay(p.hud_handle),"ShowOverlay",error))return fail();
    }
    const vr::VRTextureBounds_t bounds{0,0,1,1};
    for(int eye=0;eye<2;++eye) {
        vr::Texture_t image{p.texture[eye],vr::TextureType_DirectX,vr::ColorSpace_Linear};
        const auto result=p.compositor->Submit(static_cast<vr::EVREye>(eye),&image,&bounds,vr::Submit_Default);
        p.scene_cleared=false;
        if(result!=vr::VRCompositorError_None) {
            error="OpenVR eye "+std::to_string(eye)+" Submit failed (compositor error "+std::to_string(int(result))+"); pair rejected.";
            p.stats.end_frame_cpu_known=true;p.stats.end_frame_cpu_ms=elapsed_ms(start);return fail();
        }
    }
    // The Unity main loop cannot immediately block in the next WaitGetPoses.
    // This signals that both views are ready for the compositor's own frame.
    p.compositor->PostPresentHandoff();
    p.stats.end_frame_cpu_known=true;p.stats.end_frame_cpu_ms=elapsed_ms(start);
    p.pending=false;p.renderable=false;++p.stats.submitted_frames;return true;
}
void OpenVrBackend::cancel_frame() {
    auto& p=*impl_;std::string ignored;if(!p.on_owner(ignored))return;
    if(p.pending){p.pending=false;p.renderable=false;++p.stats.cancelled_frames;}
    if(!p.hide_hud(ignored))p.abort_frame();
}
void OpenVrBackend::request_recenter(){impl_->recenter=true;}
bool OpenVrBackend::running()const{return impl_->active&&!impl_->faulted;}
bool OpenVrBackend::frame_pending()const{return impl_->pending;}
std::string OpenVrBackend::runtime_name()const{return impl_->runtime;}
std::string OpenVrBackend::graphics_name()const{return impl_->graphics;}
XrVulkanDiagnostics OpenVrBackend::diagnostics()const{return impl_->stats;}
bool OpenVrBackend::shutdown(){return impl_->close();}
} // namespace vrvd
