#pragma once
#include <BetterEndfield/ThirdPartyModule.h>
#include <cstdint>
#include <memory>
#include <string>

namespace vrvd {
// Opt-in, game-thread diagnostic. Owns four private 64x64 linear RGBA8 RTs.
// Never reads pixels, accesses Camera.main, or interprets a native texture handle.
// The caller must activate the diagnostic Vulkan layer before starting Unity.
class UnityGpuProbe {
public:
    UnityGpuProbe();
    ~UnityGpuProbe(); // Does not call Unity; cleanup() must finish on the game thread.
    UnityGpuProbe(const UnityGpuProbe&) = delete;
    UnityGpuProbe& operator=(const UnityGpuProbe&) = delete;
    bool resolve(const BE_HostApiV1* host, std::string& error);
    bool ensure(std::string& error);
    // Opaque values returned by Unity, not asserted to be VkImage handles.
    // Invalid eye indices, unavailable resources and cleanup return zero.
    uintptr_t source_handle(unsigned eye) const;
    uintptr_t marker_handle(unsigned eye) const;
    // Queues Blit(black, source[eye]), CopyTexture(source[eye], marker[eye]).
    // Success proves only that managed calls returned and active RT was restored;
    // it is NOT evidence of GPU execution/completion or an XR-compatible device.
    bool issue_copy(std::string& error);
    // Uses Unity resource lifetime management, not native Vulkan destruction.
    // Retains roots/state on restoration or destruction failure for retry.
    void cleanup();
    bool resources_alive() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
}
