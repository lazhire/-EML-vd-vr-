#include "unity_bridge.h"
#include "hg_camera_adapter.h"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <exception>
#include <limits>
#include <utility>

namespace vrvd {
namespace {
constexpr const char* Core = "UnityEngine.CoreModule.dll";
constexpr const char* Owner = "quest3.vrvd";
constexpr float Pi = 3.14159265358979323846f;
struct V3 { float x, y, z; };
struct Q4 { float x, y, z, w; };
struct Rect4 { float x, y, width, height; };
struct M4 { float v[16]; }; // Unity Matrix4x4 is column-major in memory.
static_assert(sizeof(V3) == 12 && sizeof(Q4) == 16 && sizeof(M4) == 64);
static_assert(sizeof(void*) == 8, "This adapter supports Windows x64 only");

bool finite(float v) { return std::isfinite(v); }
bool finite(V3 v) { return finite(v.x) && finite(v.y) && finite(v.z); }
bool normalise(Q4& q) {
    const float n = q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w;
    if (!finite(n) || n < 0.5f || n > 1.5f) return false;
    const float scale = 1.0f / std::sqrt(n);
    q.x *= scale; q.y *= scale; q.z *= scale; q.w *= scale;
    return true;
}
Q4 multiply(Q4 a, Q4 b) {
    return {a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,
            a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,
            a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,
            a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z};
}
bool projection(const Eye& eye, float nearZ, float farZ, M4& result) {
    const float angles[]{eye.angleLeft,eye.angleRight,eye.angleUp,eye.angleDown};
    for (float angle : angles)
        if (!finite(angle) || std::abs(angle) >= Pi*0.5f-0.0001f) return false;
    const float l=std::tan(eye.angleLeft), r=std::tan(eye.angleRight);
    const float t=std::tan(eye.angleUp), b=std::tan(eye.angleDown);
    if (!(r-l > 0.0001f && t-b > 0.0001f && nearZ > 0 && farZ > nearZ)) return false;
    result = {};
    result.v[0]=2/(r-l); result.v[5]=2/(t-b);
    result.v[8]=(r+l)/(r-l); result.v[9]=(t+b)/(t-b);
    result.v[10]=-(farZ+nearZ)/(farZ-nearZ);
    result.v[11]=-1;
    result.v[14]=-2*farZ*nearZ/(farZ-nearZ);
    // Camera.projectionMatrix takes Unity's OpenGL-style projection. Unity
    // performs the graphics API clip-space conversion; do not pre-apply it here.
    for (float value : result.v) if (!finite(value)) return false;
    return true;
}
M4 view_matrix(V3 p,Q4 q) {
    // Inverse rigid transform, followed by Unity camera-space Z reflection.
    const float r[3][3]{
        {1-2*(q.y*q.y+q.z*q.z),2*(q.x*q.y-q.z*q.w),2*(q.x*q.z+q.y*q.w)},
        {2*(q.x*q.y+q.z*q.w),1-2*(q.x*q.x+q.z*q.z),2*(q.y*q.z-q.x*q.w)},
        {2*(q.x*q.z-q.y*q.w),2*(q.y*q.z+q.x*q.w),1-2*(q.x*q.x+q.y*q.y)}};
    M4 v{};v.v[15]=1;
    for(unsigned row=0;row<3;++row) {
        const float sign=row==2?-1.f:1.f;
        for(unsigned col=0;col<3;++col)v.v[col*4+row]=sign*r[col][row];
        v.v[12+row]=-(v.v[row]*p.x+v.v[4+row]*p.y+v.v[8+row]*p.z);
    }
    return v;
}
M4 product(const M4& a,const M4& b) {
    M4 result{};
    for(unsigned col=0;col<4;++col)for(unsigned row=0;row<4;++row)
        for(unsigned k=0;k<4;++k)result.v[col*4+row]+=a.v[k*4+row]*b.v[col*4+k];
    return result;
}
bool matrix_matches(const M4& a,const M4& b) {
    for(unsigned i=0;i<16;++i)
        if(!finite(a.v[i])||!finite(b.v[i])||std::abs(a.v[i]-b.v[i])>0.0002f)return false;
    return true;
}
}

struct UnityBinding {
    const char* klass;
    const char* name;
    const char* parameters;
    const char* result;
    uint32_t count;
    const char* assembly=Core;
    const char* nameSpace="UnityEngine";
};

struct UnityBridge::Impl {
    enum Method {
        Main, ComponentTransform, GetPosition, GetRotation, SetPosition, SetRotation,
        RtCtor, RtCreate, RtRelease, RtAA, RtMip, RtAutoMip, NativePtr, RtSrgb,
        GoCtor, AddComponent, Destroy, Equals, HideFlags, CopyFrom, CameraEnabled,
        Target, Projection, Near, Far, Render, DeviceType, PluginEvent,
        ResetView, ResetCulling, Viewport, FrameCount, OutputCamera,
        RtIsCreated, TexWidth, TexHeight, SetFov, SetAspect, SetOrthographic, SetPhysical,
        SetView, SetNonJittered, SetCulling, GetProjection, GetView, GetNonJittered, GetCulling, GetTarget,
        ReadbackFirst, RtGetActive=ReadbackFirst, RtSetActive, TexCtor, TexReadPixels,
        TexRaw, TexFormat, TexMips, TexSrgb, RtGraphicsFormat, SetRtGraphicsFormat,
        TexGraphicsFormat, ArrayLength, MarshalCopy, Count
    };
    using Binding=UnityBinding;
    inline static const Binding bindings[Count]{
        {"Camera","get_main",nullptr,"UnityEngine.Camera",0},
        {"Component","get_transform",nullptr,"UnityEngine.Transform",0},
        {"Transform","get_position",nullptr,"UnityEngine.Vector3",0},
        {"Transform","get_rotation",nullptr,"UnityEngine.Quaternion",0},
        {"Transform","set_position","UnityEngine.Vector3","System.Void",1},
        {"Transform","set_rotation","UnityEngine.Quaternion","System.Void",1},
        {"RenderTexture",".ctor","System.Int32|System.Int32|System.Int32|UnityEngine.RenderTextureFormat|UnityEngine.RenderTextureReadWrite","System.Void",5},
        {"RenderTexture","Create",nullptr,"System.Boolean",0},
        {"RenderTexture","Release",nullptr,"System.Void",0},
        {"RenderTexture","set_antiAliasing","System.Int32","System.Void",1},
        {"RenderTexture","set_useMipMap","System.Boolean","System.Void",1},
        {"RenderTexture","set_autoGenerateMips","System.Boolean","System.Void",1},
        {"Texture","GetNativeTexturePtr",nullptr,"System.IntPtr",0},
        {"RenderTexture","get_sRGB",nullptr,"System.Boolean",0},
        {"GameObject",".ctor","System.String","System.Void",1},
        {"GameObject","AddComponent","System.Type","UnityEngine.Component",1},
        {"Object","Destroy","UnityEngine.Object","System.Void",1},
        {"Object","op_Equality","UnityEngine.Object|UnityEngine.Object","System.Boolean",2},
        {"Object","set_hideFlags","UnityEngine.HideFlags","System.Void",1},
        {"Camera","CopyFrom","UnityEngine.Camera","System.Void",1},
        {"Behaviour","set_enabled","System.Boolean","System.Void",1},
        {"Camera","set_targetTexture","UnityEngine.RenderTexture","System.Void",1},
        {"Camera","set_projectionMatrix","UnityEngine.Matrix4x4","System.Void",1},
        {"Camera","get_nearClipPlane",nullptr,"System.Single",0},
        {"Camera","get_farClipPlane",nullptr,"System.Single",0},
        {"Camera","Render",nullptr,"System.Void",0},
        {"SystemInfo","get_graphicsDeviceType",nullptr,"UnityEngine.Rendering.GraphicsDeviceType",0},
        {"GL","IssuePluginEvent","System.IntPtr|System.Int32","System.Void",2},
        {"Camera","ResetWorldToCameraMatrix",nullptr,"System.Void",0},
        {"Camera","ResetCullingMatrix",nullptr,"System.Void",0},
        {"Camera","set_rect","UnityEngine.Rect","System.Void",1},
        {"Time","get_frameCount",nullptr,"System.Int32",0},
        {"CinemachineBrain","get_OutputCamera",nullptr,"UnityEngine.Camera",0,"Cinemachine.dll","Cinemachine"},
        {"RenderTexture","IsCreated",nullptr,"System.Boolean",0},
        {"Texture","get_width",nullptr,"System.Int32",0},
        {"Texture","get_height",nullptr,"System.Int32",0},
        {"Camera","set_fieldOfView","System.Single","System.Void",1},
        {"Camera","set_aspect","System.Single","System.Void",1},
        {"Camera","set_orthographic","System.Boolean","System.Void",1},
        {"Camera","set_usePhysicalProperties","System.Boolean","System.Void",1},
        {"Camera","set_worldToCameraMatrix","UnityEngine.Matrix4x4","System.Void",1},
        {"Camera","set_nonJitteredProjectionMatrix","UnityEngine.Matrix4x4","System.Void",1},
        {"Camera","set_cullingMatrix","UnityEngine.Matrix4x4","System.Void",1},
        {"Camera","get_projectionMatrix",nullptr,"UnityEngine.Matrix4x4",0},
        {"Camera","get_worldToCameraMatrix",nullptr,"UnityEngine.Matrix4x4",0},
        {"Camera","get_nonJitteredProjectionMatrix",nullptr,"UnityEngine.Matrix4x4",0},
        {"Camera","get_cullingMatrix",nullptr,"UnityEngine.Matrix4x4",0},
        {"Camera","get_targetTexture",nullptr,"UnityEngine.RenderTexture",0},
        {"RenderTexture","get_active",nullptr,"UnityEngine.RenderTexture",0},
        {"RenderTexture","set_active","UnityEngine.RenderTexture","System.Void",1},
        {"Texture2D",".ctor","System.Int32|System.Int32|UnityEngine.TextureFormat|System.Boolean|System.Boolean","System.Void",5},
        {"Texture2D","ReadPixels","UnityEngine.Rect|System.Int32|System.Int32|System.Boolean","System.Void",4},
        {"Texture2D","GetRawTextureData",nullptr,"System.Byte[]",0},
        {"Texture2D","get_format",nullptr,"UnityEngine.TextureFormat",0},
        {"Texture","get_mipmapCount",nullptr,"System.Int32",0},
        {"Texture","get_isDataSRGB",nullptr,"System.Boolean",0},
        {"RenderTexture","get_graphicsFormat",nullptr,"UnityEngine.Experimental.Rendering.GraphicsFormat",0},
        {"RenderTexture","set_graphicsFormat","UnityEngine.Experimental.Rendering.GraphicsFormat","System.Void",1},
        {"Texture","get_graphicsFormat",nullptr,"UnityEngine.Experimental.Rendering.GraphicsFormat",0},
        {"Array","get_Length",nullptr,"System.Int32",0,"mscorlib.dll","System"},
        {"Marshal","Copy","System.Byte[]|System.Int32|System.IntPtr|System.Int32","System.Void",4,"mscorlib.dll","System.Runtime.InteropServices"}
    };
    const BE_HostApiV1* host = nullptr;
    std::array<BE_ResolvedMethodV1, Count> methods{};
    BE_ResolvedClassV1 rtClass{}, goClass{}, cameraClass{}, texClass{};
    struct TargetSet {
        void* rt=nullptr;
        uint32_t rtRoot=0;
        void* go=nullptr;
        uint32_t goRoot=0;
        void* camera=nullptr;
        uint32_t cameraRoot=0;
        void* transform=nullptr;
        uint32_t transformRoot=0;
        void* native=nullptr;
        void* readback=nullptr;
        uint32_t readbackRoot=0;
    } targets[2];
    uint32_t width=0, height=0;
    bool ready=false, d3d11=false;
    bool readbackReady=false, eyesRendered=false;
    int32_t graphicsType=-1, targetGraphicsType=-1;
    void* savedActive=nullptr;
    uint32_t savedActiveRoot=0;
    bool activeRestorePending=false;
    bool lastFrameValid=false;
    int32_t lastFrame=0;
    UnityCameraDiagnostics diagnostics{};
    HgCameraAdapter hg;
    void* lastSource=nullptr;
    uint32_t acceptedSourceRoot=0;
    void* acceptedSource=nullptr;

    void log(const std::string& error) {
        if (host && host->log) host->log(host->context, Owner, error.c_str());
    }
    bool invoke(Method m, void* instance, void** args, void*& value, std::string& error) {
        if (!host || !methods[m].method_info) {
            error="Unity binding unavailable: "+std::string(bindings[m].name); return false;
        }
        void* exception=nullptr;
        value=host->runtime_invoke(host->context, methods[m].method_info, instance,args,&exception);
        if (exception) {
            error="Unity managed exception in "+std::string(bindings[m].klass)+"."+bindings[m].name;
            return false;
        }
        return true;
    }
    bool call(Method m, void* instance, void** args, std::string& error) {
        void* ignored=nullptr; return invoke(m,instance,args,ignored,error);
    }
    template<class T> bool value(Method m, void* instance, void** args, T& out, std::string& error) {
        void* boxed=nullptr;
        if (!invoke(m,instance,args,boxed,error)) return false;
        void* payload=boxed?host->object_unbox(host->context,boxed):nullptr;
        if (!payload) { error="No boxed result from "+std::string(bindings[m].name); return false; }
        std::memcpy(&out,payload,sizeof(T)); return true;
    }
    bool alive(void* object, bool& isAlive, std::string& error) {
        if (!object) {isAlive=false; return true;}
        void* args[]{object,nullptr}; uint8_t equal=0;
        if (!value(Equals,nullptr,args,equal,error) || equal>1) {
            if(error.empty()) error="Invalid Unity Object equality result";
            return false;
        }
        isAlive=equal==0; return true;
    }
    bool root(void* object, uint32_t& handle, std::string& error) {
        if (!object || !(handle=host->gchandle_new(host->context,object,0))) {
            error="Could not retain Unity object"; return false;
        }
        return true;
    }
    void unroot(uint32_t& handle) {
        if(handle) {host->gchandle_free(host->context,handle);handle=0;}
    }
    bool destroyObject(void*& object, uint32_t& rootHandle, bool release, std::string& error) {
        if(!object) {unroot(rootHandle); return true;}
        bool living=false;
        if(!alive(object,living,error)) return false;
        if(living) {
            if(release && !call(RtRelease,object,nullptr,error)) return false;
            void* args[]{object};
            if(!call(Destroy,nullptr,args,error)) return false;
        }
        unroot(rootHandle); object=nullptr; return true;
    }
    bool restoreActive(std::string& error) {
        if(!activeRestorePending) return true;
        void* args[]{savedActive};
        if(!call(RtSetActive,nullptr,args,error)) return false;
        void* current=nullptr;
        if(!invoke(RtGetActive,nullptr,nullptr,current,error)) return false;
        void* equality[]{current,savedActive};uint8_t equal=0;
        if(!value(Equals,nullptr,equality,equal,error)) return false;
        if(equal!=1) {error="RenderTexture.active restoration did not take effect";return false;}
        activeRestorePending=false;savedActive=nullptr;unroot(savedActiveRoot);
        return true;
    }
    bool resolveReadback(std::string& error) {
        if(readbackReady) return true;
        for(size_t i=ReadbackFirst;i<Count;++i) {
            const auto& b=bindings[i];
            BE_MethodDescriptorV1 descriptor{b.assembly,b.nameSpace,b.klass,b.name,b.parameters,b.result,b.count};
            methods[i]={};
            if(host->resolve_method(host->context,&descriptor,&methods[i])!=BE_Result_Ok || !methods[i].method_info) {
                error="Vulkan CPU readback API missing: "+std::string(b.klass)+"."+b.name;return false;
            }
        }
        texClass={};
        if(host->resolve_class(host->context,Core,"UnityEngine","Texture2D",&texClass)!=BE_Result_Ok ||
           !texClass.class_info || !texClass.type_object) {
            error="Vulkan CPU readback class missing: Texture2D";return false;
        }
        readbackReady=true;return true;
    }
    bool clean(bool releaseSource=true) {
        hg.clear_projection(); // No registry may retain objects that are destroyed below.
        std::string restoreError;
        // Do not destroy a RenderTexture while it may still be globally active.
        if(!restoreActive(restoreError)) {log(restoreError);return false;}
        bool complete=true;
        for(auto& t:targets) {
            t.native=nullptr;
            std::string error;
            if(destroyObject(t.go,t.goRoot,false,error)) {
                unroot(t.cameraRoot); unroot(t.transformRoot);
                t.camera=nullptr; t.transform=nullptr;
            } else {complete=false;log(error);}
            error.clear();
            if(!destroyObject(t.rt,t.rtRoot,true,error)) {complete=false;log(error);}
            error.clear();
            if(!destroyObject(t.readback,t.readbackRoot,false,error)) {complete=false;log(error);}
        }
        if(complete){hg.cleanup();diagnostics.hg_active=false;diagnostics.hg_status=hg.status();}
        if(releaseSource){unroot(acceptedSourceRoot);acceptedSource=nullptr;}
        diagnostics.targets_valid=false;
        width=height=0;
        targetGraphicsType=-1;eyesRendered=false;
        return complete;
    }
    bool check_geometry(unsigned eye,V3 position,const M4& p,const M4& v,const M4& c,const char* phase,std::string& error) {
        ++diagnostics.geometry_checks;
        auto& t=targets[eye];
        const auto reject=[&](const std::string& detail) {
            ++diagnostics.geometry_failures;diagnostics.geometry_status="rejected";
            error="Eye "+std::to_string(eye)+" "+phase+": "+detail;
            diagnostics.error=error;return false;
        };
        void* actualTarget=nullptr;
        if(!invoke(GetTarget,t.camera,nullptr,actualTarget,error))return reject(error);
        void* equality[]{actualTarget,t.rt};uint8_t same=0;
        if(!value(Equals,nullptr,equality,same,error))return reject(error);
        if(same!=1)return reject("render target changed");
        V3 observedPosition{};Q4 observedRotation{};
        if(!value(GetPosition,t.transform,nullptr,observedPosition,error)||
           !value(GetRotation,t.transform,nullptr,observedRotation,error))return reject(error);
        // Check pose components separately. Rebuilding translated view matrices
        // here amplifies harmless quaternion rounding at large world positions.
        M4 expectedRotation=v;expectedRotation.v[12]=expectedRotation.v[13]=expectedRotation.v[14]=0;
        if(!finite(observedPosition)||!normalise(observedRotation)||
           std::abs(observedPosition.x-position.x)>0.0002f||std::abs(observedPosition.y-position.y)>0.0002f||
           std::abs(observedPosition.z-position.z)>0.0002f||
           !matrix_matches(view_matrix({},observedRotation),expectedRotation))return reject("eye transform changed");
        for(const auto item:{std::pair<Method,const M4*>{GetProjection,&p},{GetNonJittered,&p},{GetView,&v},{GetCulling,&c}}) {
            M4 observed{};
            if(!value(item.first,t.camera,nullptr,observed,error))return reject(error);
            if(!matrix_matches(observed,*item.second))return reject(std::string(bindings[item.first].name)+" does not match the XR eye");
        }
        diagnostics.geometry_status="camera_properties_match";return true;
    }
    bool fields(const char* klass,const char* const* names,size_t count,std::string& error) {
        int32_t base=-1;
        for(size_t i=0;i<count;++i) {
            BE_FieldDescriptorV1 descriptor{Core,"UnityEngine",klass,names[i],"System.Single"};
            BE_ResolvedFieldV1 field{};
            if(host->resolve_field(host->context,&descriptor,&field)!=BE_Result_Ok || !field.field_info) {
                error="Unknown Unity value layout: "+std::string(klass)+"."+names[i];return false;
            }
            if(i==0) base=field.offset;
            if(base<0 || base>64 || field.offset != base+static_cast<int32_t>(i*4)) {
                error="Unexpected Unity value layout: "+std::string(klass);return false;
            }
        }
        return true;
    }
};

UnityBridge::UnityBridge():impl_(std::make_unique<Impl>()){}
UnityBridge::~UnityBridge()=default;

bool UnityBridge::resolve(const BE_HostApiV1* host,std::string& error) {
    error.clear();auto& s=*impl_;
    if(resources_alive()) {
        error="Cleanup existing Unity targets before resolving again";return false;
    }
    s.ready=false;s.d3d11=false;s.lastFrameValid=false;
    s.diagnostics={};s.lastSource=nullptr;
    s.readbackReady=false;s.eyesRendered=false;s.graphicsType=s.targetGraphicsType=-1;
    if(!host || host->abi_version!=1 || !host->resolve_method || !host->resolve_field ||
       !host->resolve_class || !host->runtime_invoke || !host->object_unbox ||
       !host->object_new || !host->string_new || !host->gchandle_new || !host->gchandle_free) {
        error="EML runtime helpers are incomplete";return false;
    }
    s.host=host;
    if(!s.hg.resolve(host,error)){s.diagnostics.hg_status=s.hg.status();s.diagnostics.error=error;return false;}
    s.diagnostics.hg_status=s.hg.status();
    // Vulkan readback APIs are resolved lazily so stripping of an unused CPU
    // readback method cannot break the established D3D11 path.
    for(size_t i=0;i<Impl::ReadbackFirst;++i) {
        const auto& b=Impl::bindings[i];
        BE_MethodDescriptorV1 descriptor{b.assembly,b.nameSpace,b.klass,b.name,b.parameters,b.result,b.count};
        s.methods[i]={};
        if(host->resolve_method(host->context,&descriptor,&s.methods[i])!=BE_Result_Ok ||
           !s.methods[i].method_info) {
            error="Required Unity API missing: "+std::string(b.klass)+"."+b.name;return false;
        }
    }
    struct ClassRequest {const char* name;BE_ResolvedClassV1* result;};
    for(const ClassRequest c: {ClassRequest{"RenderTexture",&s.rtClass},
                              ClassRequest{"GameObject",&s.goClass},ClassRequest{"Camera",&s.cameraClass}})
        if(host->resolve_class(host->context,Core,"UnityEngine",c.name,c.result)!=BE_Result_Ok ||
           !c.result->class_info || !c.result->type_object) {
            error="Required Unity class missing: "+std::string(c.name);return false;
        }
    const char* const vectorFields[]{"x","y","z"};
    const char* const quaternionFields[]{"x","y","z","w"};
    const char* const rectFields[]{"m_XMin","m_YMin","m_Width","m_Height"};
    const char* const matrixFields[]{"m00","m10","m20","m30","m01","m11","m21","m31",
                                    "m02","m12","m22","m32","m03","m13","m23","m33"};
    if(!s.fields("Vector3",vectorFields,3,error) || !s.fields("Quaternion",quaternionFields,4,error) ||
       !s.fields("Matrix4x4",matrixFields,16,error) || !s.fields("Rect",rectFields,4,error)) return false;
    s.ready=true;return true;
}

bool UnityBridge::graphics_is_d3d11(std::string& error) {
    int32_t type=-1;
    if(!graphics_type(type,error)) return false;
    if(type!=2) {error="Unity graphics API is not Direct3D11 (GraphicsDeviceType="+std::to_string(type)+")";return false;}
    return true;
}

bool UnityBridge::graphics_type(int32_t& type,std::string& error) {
    error.clear();auto& s=*impl_;type=-1;s.d3d11=false;s.graphicsType=-1;
    if(!s.ready) {error="Unity bridge is not resolved";return false;}
    if(!s.value(Impl::DeviceType,nullptr,nullptr,type,error)) return false;
    s.graphicsType=type;s.d3d11=type==2;return true;
}

bool UnityBridge::accept_frame(void* brain,bool& accepted,std::string& error) {
    accepted=false;error.clear();auto& s=*impl_;
    s.diagnostics.frame_state="not_checked";
    if(!s.ready) {error="Unity bridge is not resolved";return false;}
    bool living=false;
    if(!s.alive(brain,living,error)) return false;
    if(!living){s.diagnostics.frame_state="no_brain";return true;}
    void* output=nullptr;void* main=nullptr;
    if(!s.invoke(Impl::OutputCamera,brain,nullptr,output,error) ||
       !s.invoke(Impl::Main,nullptr,nullptr,main,error)) return false;
    if(!s.alive(output,living,error)) return false;
    if(!living){s.diagnostics.frame_state="no_output_camera";return true;}
    if(!s.alive(main,living,error)) return false;
    s.diagnostics.source_present=living;
    if(!living){s.diagnostics.frame_state="no_main_camera";s.unroot(s.acceptedSourceRoot);s.acceptedSource=nullptr;return true;}
    void* equalityArgs[]{output,main};uint8_t equal=0;
    if(!s.value(Impl::Equals,nullptr,equalityArgs,equal,error)) return false;
    if(equal>1) {error="Invalid Unity camera equality result";return false;}
    if(!equal){s.diagnostics.frame_state="non_main_brain";return true;}
    int32_t frame=0;
    if(!s.value(Impl::FrameCount,nullptr,nullptr,frame,error)) return false;
    if(s.lastFrameValid && frame==s.lastFrame){s.diagnostics.frame_state="duplicate";return true;}
    s.unroot(s.acceptedSourceRoot);s.acceptedSource=nullptr;
    if(!s.root(main,s.acceptedSourceRoot,error))return false;
    s.acceptedSource=main;
    if(s.lastSource!=main){s.lastSource=main;++s.diagnostics.source_generation;}
    s.lastFrame=frame;s.lastFrameValid=true;accepted=true;s.diagnostics.frame_state="accepted";return true;
}

UnityCameraDiagnostics UnityBridge::diagnostics() const {return impl_->diagnostics;}
bool UnityBridge::accepted_camera_identity(void*& camera,int32_t& frame) const {
    const auto& s=*impl_;camera=nullptr;frame=-1;
    if(!s.lastFrameValid||!s.acceptedSource||!s.acceptedSourceRoot)return false;
    camera=s.acceptedSource;frame=s.lastFrame;return true;
}

bool UnityBridge::validate_targets(bool& valid,std::string& error) {
    auto& s=*impl_;error.clear();valid=false;s.diagnostics.targets_valid=false;
    if(!s.ready){error="Unity bridge is not resolved";return false;}
    if(!s.width||!s.height)return true;
    int32_t currentApi=-1;
    if(!s.value(Impl::DeviceType,nullptr,nullptr,currentApi,error))return false;
    if(currentApi!=s.targetGraphicsType)return true;
    for(auto& t:s.targets) {
        for(void* object:{t.go,t.camera,t.transform,t.rt}) {
            bool living=false;if(!s.alive(object,living,error))return false;if(!living)return true;
        }
        uint8_t created=0;
        if(!s.value(Impl::RtIsCreated,t.rt,nullptr,created,error))return false;
        if(created>1){error="Invalid RenderTexture.IsCreated result";return false;}
        if(!created)return true;
        int32_t w=0,h=0;
        if(!s.value(Impl::TexWidth,t.rt,nullptr,w,error)||!s.value(Impl::TexHeight,t.rt,nullptr,h,error))return false;
        if(w!=int32_t(s.width)||h!=int32_t(s.height))return true;
        if(currentApi==21) {
            bool living=false;if(!s.alive(t.readback,living,error))return false;if(!living)return true;
            int32_t format=-1;if(!s.value(Impl::RtGraphicsFormat,t.rt,nullptr,format,error))return false;
            if(format!=8)return true;
        }
    }
    valid=true;s.diagnostics.targets_valid=true;return true;
}

bool UnityBridge::ensure_targets(uint32_t width,uint32_t height,std::string& error) {
    error.clear();auto& s=*impl_;
    int32_t api=-1;
    if(!graphics_type(api,error)) return false;
    if(api!=2 && api!=21) {error="Unsupported Unity GraphicsDeviceType="+std::to_string(api);return false;}
    if(!width || !height || width>16384 || height>16384) {error="Invalid eye texture dimensions";return false;}
    if(api==21 && (width>3072 || height>3072)) {error="Vulkan CPU readback is limited to 3072 pixels per eye dimension";return false;}
    if(api==21 && !s.resolveReadback(error)) return false;
    if(s.width==width && s.height==height && s.targetGraphicsType==api) {
        bool valid=false;if(!validate_targets(valid,error))return false;
        if(valid) return true;
    }
    if(!s.clean(false)) {error="Previous eye resources could not be cleaned up; retry on a game frame";return false;}
    const auto fail=[&](){s.clean(false);return false;};
    for(unsigned eye=0;eye<2;++eye) {
        auto& t=s.targets[eye];
        t.rt=s.host->object_new(s.host->context,s.rtClass.class_info);
        if(!s.root(t.rt,t.rtRoot,error)) return fail();
        int32_t w=static_cast<int32_t>(width),h=static_cast<int32_t>(height),depth=24,format=0,readWrite=1;
        // Unity 2021.3: ARGB32=0; RenderTextureReadWrite.Linear=1.
        // XR must expose these bytes through a linear UNORM swapchain, not SRGB.
        void* ctorArgs[]{&w,&h,&depth,&format,&readWrite};
        if(!s.call(Impl::RtCtor,t.rt,ctorArgs,error)) return fail();
        if(api==21) {
            // Avoid platform-selected BGRA storage for ARGB32: ReadPixels must
            // see the same explicit linear RGBA format as the CPU Texture2D.
            int32_t rgbaUnorm=8; // GraphicsFormat.R8G8B8A8_UNorm, Unity 2021.3.
            void* formatArgs[]{&rgbaUnorm};
            if(!s.call(Impl::SetRtGraphicsFormat,t.rt,formatArgs,error)) return fail();
        }
        int32_t aa=1;uint8_t no=0;void* aaArgs[]{&aa};void* noArgs[]{&no};
        if(!s.call(Impl::RtAA,t.rt,aaArgs,error) || !s.call(Impl::RtMip,t.rt,noArgs,error) ||
           !s.call(Impl::RtAutoMip,t.rt,noArgs,error)) return fail();
        uint8_t created=0;
        if(!s.value(Impl::RtCreate,t.rt,nullptr,created,error)) return fail();
        if(created!=1) {error="RenderTexture.Create did not create an eye texture";return fail();}
        uint8_t srgb=0xff;
        if(!s.value(Impl::RtSrgb,t.rt,nullptr,srgb,error)) return fail();
        if(srgb!=0) {error="Eye texture must be linear (RenderTexture.sRGB is not false)";return fail();}
        if(api==21) {
            int32_t actualGraphicsFormat=-1;
            if(!s.value(Impl::RtGraphicsFormat,t.rt,nullptr,actualGraphicsFormat,error)) return fail();
            if(actualGraphicsFormat!=8) {error="Vulkan eye RenderTexture must use R8G8B8A8_UNorm";return fail();}
        }
        if(api==2) {
            if(!s.value(Impl::NativePtr,t.rt,nullptr,t.native,error)) return fail();
            if(!t.native) {error="Eye RenderTexture has no native D3D11 texture";return fail();}
        } else {
            // No reinterpretation of Unity's Vulkan native pointer is used.
            t.readback=s.host->object_new(s.host->context,s.texClass.class_info);
            if(!s.root(t.readback,t.readbackRoot,error)) return fail();
            int32_t rgba32=4;uint8_t linear=1;
            void* cpuCtor[]{&w,&h,&rgba32,&no,&linear};
            if(!s.call(Impl::TexCtor,t.readback,cpuCtor,error)) return fail();
            int32_t actualFormat=-1,mips=-1,actualGraphicsFormat=-1;uint8_t dataSrgb=0xff;
            if(!s.value(Impl::TexFormat,t.readback,nullptr,actualFormat,error) ||
               !s.value(Impl::TexMips,t.readback,nullptr,mips,error) ||
               !s.value(Impl::TexSrgb,t.readback,nullptr,dataSrgb,error) ||
               !s.value(Impl::TexGraphicsFormat,t.readback,nullptr,actualGraphicsFormat,error)) return fail();
            if(actualFormat!=4 || mips!=1 || dataSrgb!=0 || actualGraphicsFormat!=8) {
                error="Vulkan readback requires RGBA32, one mip and linear Texture2D data";return fail();
            }
        }

        t.go=s.host->object_new(s.host->context,s.goClass.class_info);
        if(!s.root(t.go,t.goRoot,error)) return fail();
        void* name=s.host->string_new(s.host->context,eye?"EML VRVD Right Eye":"EML VRVD Left Eye");
        uint32_t nameRoot=0;
        if(!s.root(name,nameRoot,error)) return fail();
        void* goArgs[]{name};
        const bool made=s.call(Impl::GoCtor,t.go,goArgs,error);s.unroot(nameRoot);
        if(!made) return fail();
        int32_t flags=61;void* flagsArgs[]{&flags}; // HideAndDontSave, own objects only.
        if(!s.call(Impl::HideFlags,t.go,flagsArgs,error)) return fail();
        void* componentArgs[]{s.cameraClass.type_object};
        if(!s.invoke(Impl::AddComponent,t.go,componentArgs,t.camera,error) ||
           !s.root(t.camera,t.cameraRoot,error)) return fail();
        if(!s.call(Impl::CameraEnabled,t.camera,noArgs,error)) return fail();
        if(!s.invoke(Impl::ComponentTransform,t.camera,nullptr,t.transform,error) ||
           !s.root(t.transform,t.transformRoot,error)) return fail();
    }
    s.width=width;s.height=height;s.targetGraphicsType=api;
    ++s.diagnostics.targets_generation;s.diagnostics.targets_valid=true;return true;
}

bool UnityBridge::render_eyes(const Eye eyes[2],std::string& error) {
    error.clear();auto& s=*impl_;
    s.eyesRendered=false;
    if(!eyes || !s.ready || (s.graphicsType!=2 && s.graphicsType!=21) ||
       s.targetGraphicsType!=s.graphicsType || !s.width || !s.height) {error="Eye rendering prerequisites are not ready";return false;}
    if(!s.restoreActive(error)) return false;
    void* main=s.acceptedSource;void* transform=nullptr;
    if(!main&&!s.invoke(Impl::Main,nullptr,nullptr,main,error)) return false;
    bool living=false;
    if(!s.alive(main,living,error)) return false;
    if(!living) {error="No live main camera";return false;}
    struct FrameRoots {
        Impl& s;uint32_t camera=0,transform=0;
        ~FrameRoots(){s.unroot(transform);s.unroot(camera);}
    } roots{s};
    if(!s.root(main,roots.camera,error) ||
       !s.invoke(Impl::ComponentTransform,main,nullptr,transform,error) ||
       !s.root(transform,roots.transform,error)) return false;
    V3 base{};Q4 game{};float nearZ=0,farZ=0;
    if(!s.value(Impl::GetPosition,transform,nullptr,base,error) ||
       !s.value(Impl::GetRotation,transform,nullptr,game,error) ||
       !s.value(Impl::Near,main,nullptr,nearZ,error) || !s.value(Impl::Far,main,nullptr,farZ,error)) return false;
    if(!finite(base) || !normalise(game) || !finite(nearZ) || !finite(farZ) || nearZ<=0 || farZ<=nearZ) {
        error="Invalid main-camera pose or clipping planes";return false;
    }
    const float fx=2*(game.x*game.z+game.w*game.y), fz=1-2*(game.x*game.x+game.y*game.y);
    if(fx*fx+fz*fz<0.000001f) {error="Main-camera yaw is undefined at a vertical look direction";return false;}
    const float yaw=std::atan2(fx,fz), c=std::cos(yaw),sn=std::sin(yaw);
    const Q4 basis{0,std::sin(yaw/2),0,std::cos(yaw/2)};
    V3 positions[2]{};Q4 rotations[2]{};M4 projections[2]{},views[2]{},cullings[2]{};
    // Validate both eyes before asking Unity to render either one.
    for(unsigned i=0;i<2;++i) {
        const auto& eye=eyes[i];
        V3 local{eye.position[0],eye.position[1],-eye.position[2]};
        Q4 head{-eye.orientation[0],-eye.orientation[1],eye.orientation[2],eye.orientation[3]};
        // Reflection across Z converts OpenXR RH/-Z-forward to Unity LH/+Z.
        // Only the game's yaw is retained. XR supplies head pitch and roll.
        if(!finite(local) || !normalise(head) || !projection(eye,nearZ,farZ,projections[i])) {
            error="Invalid OpenXR eye pose or FOV";return false;
        }
        positions[i]={base.x+c*local.x+sn*local.z,base.y+local.y,base.z-sn*local.x+c*local.z};
        rotations[i]=multiply(basis,head);
        if(!finite(positions[i]) || !normalise(rotations[i])) {error="Invalid composed eye pose";return false;}
        views[i]=view_matrix(positions[i],rotations[i]);cullings[i]=product(projections[i],views[i]);
        for(void* object:{s.targets[i].go,s.targets[i].camera,s.targets[i].transform,s.targets[i].rt}) {
            if(!s.alive(object,living,error)) return false;
            if(!living) {error="An eye camera or texture was destroyed; recreate targets";return false;}
        }
    }
    for(unsigned i=0;i<2;++i) {
        auto& t=s.targets[i];uint8_t disabled=0;Rect4 viewport{0,0,1,1};
        void* copyArgs[]{main};void* disableArgs[]{&disabled};void* textureArgs[]{t.rt};
        void* positionArgs[]{&positions[i]};void* rotationArgs[]{&rotations[i]};void* projectionArgs[]{&projections[i]};
        void* viewportArgs[]{&viewport};
        float fov=2.f*std::atan(1.f/projections[i].v[5])*180.f/Pi;
        float aspect=projections[i].v[5]/projections[i].v[0];
        void* fovArgs[]{&fov};void* aspectArgs[]{&aspect};
        void* viewArgs[]{&views[i]};void* cullingArgs[]{&cullings[i]};
        // Main camera is strictly read-only. Each eye has an independent camera;
        // the game's custom temporal-history handling still needs verification.
        // No original camera matrix needs restoring.
        if(!s.call(Impl::CopyFrom,t.camera,copyArgs,error))return false;
        if(!s.hg.prepare(main,t.camera,t.go,i,error)) {
            s.diagnostics.hg_status=s.hg.status();s.diagnostics.hg_active=false;s.diagnostics.error=error;return false;
        }
        s.diagnostics.hg_status=s.hg.status();s.diagnostics.hg_active=s.hg.active();
        s.diagnostics.source_fullscreen_passthrough=s.hg.source_fullscreen_passthrough();
        if(!s.call(Impl::CameraEnabled,t.camera,disableArgs,error) ||
           !s.call(Impl::Target,t.camera,textureArgs,error) ||
           !s.call(Impl::Viewport,t.camera,viewportArgs,error) ||
            !s.call(Impl::SetOrthographic,t.camera,disableArgs,error) ||
            !s.call(Impl::SetPhysical,t.camera,disableArgs,error) ||
            !s.call(Impl::SetFov,t.camera,fovArgs,error) ||
            !s.call(Impl::SetAspect,t.camera,aspectArgs,error) ||
           !s.call(Impl::SetPosition,t.transform,positionArgs,error) ||
           !s.call(Impl::SetRotation,t.transform,rotationArgs,error) ||
            !s.call(Impl::SetView,t.camera,viewArgs,error) ||
           !s.call(Impl::Projection,t.camera,projectionArgs,error) ||
            !s.call(Impl::SetNonJittered,t.camera,projectionArgs,error) ||
            !s.call(Impl::SetCulling,t.camera,cullingArgs,error) ||
            !s.check_geometry(i,positions[i],projections[i],views[i],cullings[i],"before Render",error)) return false;
        if(!s.hg.begin_projection(i,projections[i].v,error)){s.diagnostics.error=error;return false;}
        struct ProjectionScope {
            HgCameraAdapter& hg;bool done=false;
            ~ProjectionScope(){if(!done)hg.clear_projection();}
        } scope{s.hg};
        const bool rendered=s.call(Impl::Render,t.camera,nullptr,error);
        std::string projectionError;
        const bool routed=s.hg.end_projection(i,projectionError);scope.done=true;
        const auto routing=s.hg.projection_diagnostics();
        s.diagnostics.hg_routing=routing;
        s.diagnostics.hg_projection_hook=routing.installed;
        s.diagnostics.hg_projection_hits=routing.build_hits;
        s.diagnostics.hg_non_oblique_hits=routing.non_oblique_hits;
        s.diagnostics.hg_status=s.hg.status();
        if(!rendered){s.diagnostics.error=error;return false;}
        if(!routed){error=projectionError;s.diagnostics.error=error;return false;}
        if(!s.check_geometry(i,positions[i],projections[i],views[i],cullings[i],"after Render",error))return false;
    }
    // A callback for the second camera can mutate the first camera as well.
    for(unsigned i=0;i<2;++i)
        if(!s.check_geometry(i,positions[i],projections[i],views[i],cullings[i],"pair completion",error))return false;
    s.diagnostics.error.clear();
    s.eyesRendered=true;return true;
}

bool UnityBridge::readback_eyes(std::vector<uint8_t> out[2],std::string& error) {
    error.clear();auto& s=*impl_;
    if(!out || !s.ready || !s.readbackReady || s.graphicsType!=21 ||
       s.targetGraphicsType!=21 || !s.width || !s.height || !s.eyesRendered) {
        error="Vulkan readback requires a completed independent stereo render";return false;
    }
    // Consume exactly one completed render; a failed readback cannot submit stale eyes.
    s.eyesRendered=false;
    if(!s.restoreActive(error)) return false;
    void* previous=nullptr;
    if(!s.invoke(Impl::RtGetActive,nullptr,nullptr,previous,error)) return false;
    s.savedActive=previous;
    if(previous && !s.root(previous,s.savedActiveRoot,error)) {s.savedActive=nullptr;return false;}
    // Mark before the first setter: a managed call may mutate state then throw.
    s.activeRestorePending=true;
    struct RestoreScope {
        Impl& s;
        ~RestoreScope() {
            if(s.activeRestorePending) {
                std::string restoreError;
                if(!s.restoreActive(restoreError)) s.log(restoreError);
            }
        }
    } restore{s};
    const auto finish=[&](bool success) {
        std::string restoreError;
        if(!s.restoreActive(restoreError)) {
            if(!error.empty()) error+="; ";
            error+="RenderTexture.active restore failed: "+restoreError;
            return false;
        }
        return success;
    };
    std::vector<uint8_t> pixels[2];
    try {
        const size_t rowBytes=size_t(s.width)*4,expected=rowBytes*s.height;
        if(expected>size_t(std::numeric_limits<int32_t>::max())) {
            error="Readback byte count exceeds managed array limits";return finish(false);
        }
        for(unsigned eye=0;eye<2;++eye) {
            auto& t=s.targets[eye];
            for(void* object:{t.rt,t.readback}) {
                bool living=false;
                if(!s.alive(object,living,error)) return finish(false);
                if(!living) {error="An eye readback texture was destroyed";return finish(false);}
            }
            void* activeArgs[]{t.rt};
            if(!s.call(Impl::RtSetActive,nullptr,activeArgs,error)) return finish(false);
            void* current=nullptr;
            if(!s.invoke(Impl::RtGetActive,nullptr,nullptr,current,error)) return finish(false);
            void* equals[]{current,t.rt};uint8_t equal=0;
            if(!s.value(Impl::Equals,nullptr,equals,equal,error)) return finish(false);
            if(equal!=1) {error="Could not activate the requested eye RenderTexture";return finish(false);}
            Rect4 region{0,0,float(s.width),float(s.height)};
            int32_t destinationX=0,destinationY=0;uint8_t recalculateMips=0;
            void* readArgs[]{&region,&destinationX,&destinationY,&recalculateMips};
            // ReadPixels synchronously waits for the rendered source and writes
            // the readable CPU Texture2D storage. Apply would unnecessarily
            // upload these pixels back to Unity and is intentionally omitted.
            if(!s.call(Impl::TexReadPixels,t.readback,readArgs,error)) return finish(false);
            void* raw=nullptr;
            if(!s.invoke(Impl::TexRaw,t.readback,nullptr,raw,error)) return finish(false);
            struct ArrayRoot {
                Impl& s;uint32_t handle=0;
                ~ArrayRoot(){s.unroot(handle);}
            } arrayRoot{s};
            if(!s.root(raw,arrayRoot.handle,error)) return finish(false);
            int32_t length=-1;
            if(!s.value(Impl::ArrayLength,raw,nullptr,length,error)) return finish(false);
            if(length<0 || size_t(length)!=expected) {
                error="Readback byte[] size does not match width*height*4";return finish(false);
            }
            pixels[eye].resize(expected);
            int32_t start=0;intptr_t destination=reinterpret_cast<intptr_t>(pixels[eye].data());
            void* copyArgs[]{raw,&start,&destination,&length};
            // Managed Marshal.Copy avoids guessing any IL2CPP array header,
            // moving-GC layout, or native pointer returned by a Vulkan texture.
            if(!s.call(Impl::MarshalCopy,nullptr,copyArgs,error)) return finish(false);
            // Unity CPU pixels use bottom-left origin. OpenXR upload consumes
            // top-left rows, so flip once here for BOTH independent eye images.
            for(uint32_t y=0;y<s.height/2;++y) {
                auto first=pixels[eye].begin()+size_t(y)*rowBytes;
                auto last=pixels[eye].begin()+size_t(s.height-1-y)*rowBytes;
                std::swap_ranges(first,first+rowBytes,last);
            }
        }
    } catch(const std::exception& exception) {
        error="Eye readback failed: "+std::string(exception.what());return finish(false);
    }
    if(!finish(true)) return false;
    out[0]=std::move(pixels[0]);out[1]=std::move(pixels[1]);
    return true;
}

bool UnityBridge::schedule(void(*callback)(int),int eventId,std::string& error) {
    error.clear();auto& s=*impl_;
    if(!s.ready || !callback) {error="Cannot schedule a null or unresolved Unity rendering callback";return false;}
    intptr_t pointer=reinterpret_cast<intptr_t>(callback);int32_t event=eventId;
    void* args[]{&pointer,&event};return s.call(Impl::PluginEvent,nullptr,args,error);
}

void* UnityBridge::texture(unsigned eye) const {
    return eye<2 && impl_->ready && impl_->d3d11 && impl_->width ? impl_->targets[eye].native : nullptr;
}

bool UnityBridge::retain_d3d_textures(void* out[2],std::string& error) {
    error.clear();auto& s=*impl_;
    if(!out){error="No destination for retained D3D eye resources";return false;}
    out[0]=out[1]=nullptr;
    if(!s.ready||s.targetGraphicsType!=2){error="D3D eye resources are not ready";return false;}
    bool valid=false;if(!validate_targets(valid,error))return false;
    if(!valid){error="D3D eye resources were lost before dispatch";return false;}
    ID3D11Texture2D* retained[2]{};
    for(unsigned i=0;i<2;++i) {
        void* current=nullptr;
        if(!s.value(Impl::NativePtr,s.targets[i].rt,nullptr,current,error)||!current||
           FAILED(static_cast<IUnknown*>(current)->QueryInterface(__uuidof(ID3D11Texture2D),reinterpret_cast<void**>(&retained[i])))) {
            for(auto* resource:retained)if(resource)resource->Release();
            if(error.empty())error="Current Unity eye resource is not a D3D11 texture";
            return false;
        }
        s.targets[i].native=current;
    }
    out[0]=retained[0];out[1]=retained[1];return true;
}

void UnityBridge::cleanup() {
    if(impl_->host) impl_->clean();
}

bool UnityBridge::resources_alive() const {
    if(impl_->activeRestorePending || impl_->savedActiveRoot || impl_->savedActive) return true;
    if(impl_->acceptedSourceRoot || impl_->acceptedSource) return true;
    for(const auto& t:impl_->targets)
        if(t.go || t.rt || t.camera || t.transform || t.readback ||
           t.goRoot || t.rtRoot || t.cameraRoot || t.transformRoot || t.readbackRoot) return true;
    if(impl_->hg.resources_alive())return true;
    return false;
}
} // namespace vrvd
