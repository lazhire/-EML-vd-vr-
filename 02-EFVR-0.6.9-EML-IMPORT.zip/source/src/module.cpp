#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <BetterEndfield/ThirdPartyModule.h>
#include <nlohmann/json.hpp>
#include "unity_bridge.h"
#include "unity_hud.h"
#include "ui_observer.h"
#include "native_menu_capture.h"
#include "native_ui_overlay.h"
#include "window_menu_capture.h"
#include "engine_final_capture.h"
#include "flat_transition.h"
#include "edge_hud.h"
#include "menu_pump_gate.h"
#include "menu_wait_panel.h"
#include "menu_focus.h"
#include "eye_labels.h"
#include "frame_metrics.h"
#include "unity_gpu_probe.h"
#include "xr_backend.h"
#include "xr_vulkan.h"
#include "openvr_backend.h"
#include "desktop_render_filter.h"
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <mutex>
#include <string>
#include <thread>

using json = nlohmann::json;
namespace {
constexpr char ID[] = "quest3.vrvd";
constexpr char Version[] = "0.6.9-smooth-popup";
std::recursive_mutex mutex;
std::mutex dispatch_mutex;
BE_ThirdPartyHostV1 host{};
const BE_HostApiV1* api = nullptr;
std::thread bootstrap;
std::atomic<bool> live{false}, stop_bootstrap{false};
using PushStateFn = void(*)(void*, void*, void*);
PushStateFn next_push = nullptr;
vrvd::UnityBridge unity;
vrvd::DesktopRenderFilter desktop_filter;
bool desktop_only=false,desktop_install_attempted=false;
std::string desktop_mark_error;
using FirstPersonReadyFn=bool(*)();
std::atomic<FirstPersonReadyFn> first_person_ready_callback{nullptr};
vrvd::UnityHud hud;
vrvd::UiObserver ui_observer;
vrvd::NativeMenuCapture menu_capture;
vrvd::WindowMenuCapture window_capture;
vrvd::EngineFinalCapture engine_capture;
std::string engine_camera_source="auto";
std::vector<uint8_t> window_pixels;
std::chrono::steady_clock::time_point window_last_capture{};
vrvd::NativeUiOverlay menu_overlay;
bool ui_ready=false,menu_capture_ready=false;
std::string ui_error,menu_error;
std::vector<uint8_t> menu_pixels;
vrvd::MenuFocusPixels menu_focus_pixels;
bool menu_focus_enabled=true,menu_focus_dirty=true;
unsigned menu_blur_radius=9,menu_feather=6;
float menu_background_brightness=.45f;
double menu_focus_ms=0;
uint64_t ui_generation=0;
int last_menu_frame=-1;
std::chrono::steady_clock::time_point menu_last_capture{},menu_last_request{};
uint64_t menu_submitted=0;
using UiTailFn=void(*)(void*,float,void*);
UiTailFn next_ui_tail=nullptr;
using UiClockFn=float(*)(void*);
UiClockFn next_ui_clock=nullptr;
std::atomic<DWORD> unity_thread{0};
std::atomic<uint64_t> clock_ticks{0},camera_ticks{0},tail_ticks{0};
bool clock_hook_ready=false;
thread_local bool inside_clock=false;
uint64_t menu_placeholder_frames=0;
bool menu_handoff_pending=false;
vrvd::FlatTransition flat_transition;
double transition_time(){return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool ui_capture_due=true,quality_migrated=false;
std::string hud_layout="panel";
std::chrono::steady_clock::time_point last_unknown_menu_tick{};
std::vector<uint8_t> menu_placeholder;
std::chrono::steady_clock::time_point last_diagnostic_log{};
bool paired_guard(){
    auto mod=GetModuleHandleW(L"example.first-person.dll");
    auto fn=mod?reinterpret_cast<unsigned(*)()>(GetProcAddress(mod,"EFVR_FirstPersonGuardVersion")):nullptr;
    return fn&&fn()==1;
}

bool paired_active(){
    auto mod=GetModuleHandleW(L"example.first-person.dll");
    auto fn=mod?reinterpret_cast<unsigned(*)()>(GetProcAddress(mod,"EFVR_FirstPersonActive")):nullptr;
    return fn&&fn()==1;
}
vrvd::UnityGpuProbe gpu_probe;
vrvd::FrameMetrics frame_metrics;
vrvd::XrBackend xr;
vrvd::XrVulkanBackend vk;
vrvd::OpenVrBackend ovr;
bool use_openvr = false;
bool requested = false, hooks_ready = false, targets = false;
bool xr_initialized = false, restart_required = false;
bool closing = false;
int pending = 0; // Exactly one render-thread event owns the captured resources.
// A stop remains queued even if the user presses Start before it has drained.
bool teardown_pending = false, recovery_pending = false;
std::string recovery_reason;
uint64_t recoveries = 0, source_generation = 0, session_submitted = 0;
ID3D11Texture2D* pending_eyes[2]{};
using Clock = std::chrono::steady_clock;
Clock::time_point last_camera_tick{}, last_accepted_frame{}, last_submission{}, pending_since{};
uint32_t width = 1440, height = 1440;
uint32_t vulkan_width = 2560, vulkan_height = 2560;
std::string quality_preset = "custom";
int32_t graphics = 0;
std::vector<uint8_t> readback[2];
double readback_ms = 0;
double eye_render_cpu_ms = -1, upload_submit_cpu_ms = -1;
bool swap_eyes = false, pending_swap_eyes = false;
bool eye_labels = false;
bool hud_enabled = false, hud_blocked = false, hud_resolved = false;
float hud_distance = 1.5f, hud_width = 1.8f, hud_offset = 0.f;
uint32_t hud_capture_width = 2560, hud_capture_height = 1440, hud_refresh_hz = 20;
std::string hud_composition = "game_ui";
std::vector<uint8_t> hud_pixels;
std::string hud_error;
double hud_capture_ms = 0;
std::chrono::steady_clock::time_point hud_last_capture{};
std::wstring loader;
std::wstring openvr_loader;
std::string state = "disabled", error;
json failure_context = json::object();
uint64_t submitted = 0;
bool gpu_probe_requested = false, gpu_probe_cleanup = false, gpu_probe_resolved = false;
uint64_t gpu_probe_generation = 0;
std::string gpu_probe_state = "idle", gpu_probe_error;
thread_local bool inside_camera = false;

using GpuStatusFn = uint32_t(__cdecl*)(char*,uint32_t);
using GpuMarkFn = int32_t(__cdecl*)(uint64_t,uint32_t,uint64_t);
using GpuClearFn = void(__cdecl*)();
struct GpuLayerRef {
    HMODULE handle=nullptr;
    GpuLayerRef(){GetModuleHandleExW(0,L"vrvd_gpu_diagnostic.dll",&handle);}
    ~GpuLayerRef(){if(handle)FreeLibrary(handle);}
    GpuLayerRef(const GpuLayerRef&)=delete;
    GpuLayerRef& operator=(const GpuLayerRef&)=delete;
};
json gpu_layer_status() {
    GpuLayerRef held;HMODULE library=held.handle;
    if (!library) return {{"status","layer_not_loaded"}};
    const auto fn = reinterpret_cast<GpuStatusFn>(GetProcAddress(library,"vrvd_gpu_diag_status_json_v1"));
    if (!fn) return {{"status","incompatible_layer"}};
    const uint32_t count = fn(nullptr,0);
    if (!count || count > 262144) return {{"status","invalid_status_size"}};
    std::string buffer(count,'\0');
    const uint32_t required = fn(buffer.data(),count);
    if (!required || required > count) return {{"status","snapshot_changed_retry"}};
    const auto parsed = json::parse(buffer.c_str(),nullptr,false);
    return parsed.is_object() ? parsed : json{{"status","invalid_layer_json"}};
}
void clear_gpu_marks() {
    GpuLayerRef held;
    if (HMODULE library = held.handle)
        if (auto fn = reinterpret_cast<GpuClearFn>(GetProcAddress(library,"vrvd_gpu_diag_clear_marks_v1"))) fn();
}
void cleanup_gpu_probe() {
    if (gpu_probe.resources_alive()) gpu_probe.cleanup();
    if (!gpu_probe.resources_alive()) { clear_gpu_marks(); gpu_probe_cleanup=false; if(gpu_probe_state=="cleanup_queued")gpu_probe_state="idle"; }
}
void record_submission() {
    ++submitted;
    ++session_submitted;
    last_submission = Clock::now();
    frame_metrics.submitted(std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count());
    // Vulkan CPU upload and submission execute on the game thread. D3D11's
    // graphics-thread callback must never invoke managed camera-list services.
    if(desktop_only&&graphics==21&&(use_openvr||vk.focused())&&desktop_filter.snapshot().installed){
        void* source=nullptr;int32_t frame=-1;std::string why;
        if(unity.accepted_camera_identity(source,frame)){
            if(desktop_filter.mark_submitted(source,frame,why))desktop_mark_error.clear();else desktop_mark_error=why;
        }
    }
}
double age_ms(Clock::time_point at) {
    return at == Clock::time_point{} ? -1.0 : std::chrono::duration<double,std::milli>(Clock::now()-at).count();
}
void clear_frame_observations() {
    eye_render_cpu_ms=upload_submit_cpu_ms=-1;
    frame_metrics.reset(); last_submission = {}; readback_ms = 0; hud_capture_ms = 0;
    hud_pixels.clear(); hud_last_capture = {};
    for (auto& bytes : readback) bytes.clear();
}
void queue_teardown(const std::string& reason, bool recover) {
    desktop_filter.disable();
    if (!teardown_pending) clear_frame_observations();
    teardown_pending = true;
    recovery_pending = recovery_pending || recover;
    if (!reason.empty()) recovery_reason = reason;
    state = recover ? "recovering_eye_targets" : "stopping";
}
void release_pending_eyes() {
    for (auto*& eye : pending_eyes) if (eye) { eye->Release(); eye = nullptr; }
}
bool reserve_render_event(int event, std::string& why) {
    if (pending || pending_eyes[0] || pending_eyes[1]) { why="A previous D3D11 event still owns eye resources"; return false; }
    if (event == 1 || event == 2) {
        void* retained[2]{};
        if (!unity.retain_d3d_textures(retained, why)) {
            // The bridge contract returns owned references on success only.
            return false;
        }
        pending_eyes[0] = static_cast<ID3D11Texture2D*>(retained[0]);
        pending_eyes[1] = static_cast<ID3D11Texture2D*>(retained[1]);
        if (!pending_eyes[0] || !pending_eyes[1]) {
            release_pending_eyes(); why="Unity did not retain two D3D11 eye resources"; return false;
        }
    }
    pending=event; pending_since=Clock::now(); return true;
}
bool render_game_eyes(const vrvd::Eye eyes[2], std::string& why) {
    if (!unity.render_eyes(eyes,why)) return false;
    const auto camera=unity.diagnostics();
    if (!camera.hg_active) {
        why="HG camera adapter unavailable or inactive (" + camera.hg_status + "); stereo images were not submitted";
        return false;
    }
    return true;
}
// Both CPU upload backends own their graphics device. These wrappers run on
// the game thread; Unity's D3D11 render-event path remains separate.
bool owned_initialize(std::string& why) {
    return use_openvr ? ovr.initialize_owned(openvr_loader.c_str(),vulkan_width,vulkan_height,why)
                      : vk.initialize_owned(loader.c_str(),vulkan_width,vulkan_height,why);
}
bool owned_begin(vrvd::Eye eyes[2],bool& draw,std::string& why) {
    return use_openvr ? ovr.begin_frame(eyes,draw,why) : vk.begin_frame(eyes,draw,why);
}
void owned_cancel() { if(use_openvr)ovr.cancel_frame();else vk.cancel_frame(); }
bool owned_submit(const void* left,const void* right,size_t bytes,std::string& why,const vrvd::XrVulkanHudFrame* panel) {
    return use_openvr ? ovr.submit_rgba(left,right,bytes,why,panel) : vk.submit_rgba(left,right,bytes,why,panel);
}
json ui_transition_status(){
    json panels=json::array();for(const auto& p:ui_observer.signals.panels)
        panels.push_back({{"id",p.id},{"name",p.name},{"level",p.level},{"world",p.world}});
    return {{"routing_policy","verified_interfaces_only"},{"first_person_gate",vrvd::first_person_ui_gate(true,ui_ready,ui_observer.mode,ui_observer.holds_menu())},{"presentation","same_openxr_session_flat"},{"transition_phase",flat_transition.name()},{"transition_opacity",flat_transition.last_opacity},{"transition_fade_ms",flat_transition.duration_ms},{"transition_revision",2},{"transition_total_ms",flat_transition.duration_ms},{"gameplay_hud_hidden",true},{"capture_policy","engine_final_result_cpu_readback"},{"window_capture_used",false},{"menu_handoff_pending",menu_handoff_pending},{"menu_clock_hook",clock_hook_ready},{"clock_ticks",clock_ticks.load()},{"camera_ticks",camera_ticks.load()},{"tail_ticks",tail_ticks.load()},{"placeholder_frames",menu_placeholder_frames},{"system_scene",ui_observer.signals.system_scene},{"menu_guard_latched",ui_observer.holds_menu()},{"menu_source","hg_final_result"},{"hud_source",hud_layout=="panel"?"hg_final_information_panel_with_background":"hg_final_edge_crops_with_background"},{"hud_layout",hud_layout},{"quality_migrated",quality_migrated},{"ui_quality_revision",1},{"engine_source_width",engine_capture.source_width},{"engine_source_height",engine_capture.source_height},{"menu_resolution_exceeds_source",engine_capture.source_width>0&&(hud_capture_width>engine_capture.source_width||hud_capture_height>engine_capture.source_height)},{"menu_focus_enabled",menu_focus_enabled},{"menu_focus_ms",menu_focus_ms},{"menu_blur_radius",menu_blur_radius},{"menu_background_brightness",menu_background_brightness},{"menu_feather_px",menu_feather},{"menu_backdrop_source","native_menu_decorative_monoscopic"},{"mode",ui_observer.mode},{"generation",ui_observer.generation},{"observer_ready",ui_ready},
        {"controller",ui_observer.signals.controller},{"panels",panels},{"overlay_panels",ui_observer.overlays},
        {"error",ui_error.empty()?ui_observer.signals.error:ui_error},{"paired_first_person",paired_guard()},
        {"capture_status",engine_capture.status},{"engine_capture_status",engine_capture.status},{"engine_capture_frames",engine_capture.frames},{"engine_stage",engine_capture.stage},{"engine_source",engine_capture.selected_source},{"engine_camera_source",engine_camera_source},{"engine_seed_rejections",engine_capture.seed_rejections},{"engine_mean_rgb",engine_capture.mean_rgb},{"engine_black_fraction",engine_capture.black_fraction},{"engine_camera_end_calls",engine_capture.camera_end_calls()},{"engine_selected_end_calls",engine_capture.selected_camera_end_calls()},{"gpu_only",false},{"capture_error",menu_error},{"capture_requests",engine_capture.requests},
        {"capture_completions",engine_capture.frames},{"menu_submitted_frames",menu_submitted},{"transparent_hud_ready",hud_enabled&&!hud_pixels.empty()&&!hud_blocked},{"overlay_capture_status",menu_overlay.status},{"overlay_attempts",menu_overlay.attempts},{"overlay_frames",menu_overlay.frames},{"overlay_source_width",menu_overlay.source_width()},{"overlay_source_height",menu_overlay.source_height()},{"overlay_input","native_gamepad_unchanged"}};
}
json last_menu_presentation=json::object();
json performance_status() {
    const auto d = use_openvr ? ovr.diagnostics() : vk.diagnostics();
    const auto m = frame_metrics.snapshot();
    json views = json::array();
    for (const auto& v : d.views) views.push_back({{"recommended_width",v.recommended_width},{"recommended_height",v.recommended_height},
        {"max_width",v.max_width},{"max_height",v.max_height},{"actual_width",v.actual_width},{"actual_height",v.actual_height}});
    const bool fresh = requested && !teardown_pending && age_ms(last_submission)>=0 && age_ms(last_submission)<2000;
    return {{"view_caps_known",d.view_caps_known},{"views",views},
        {"display_hz_known",d.current_display_hz_known},{"display_hz",d.current_display_hz},
        {"refresh_rates_known",d.refresh_rates_known},{"session_refresh_rates",d.session_refresh_rates},
        {"predicted_period_known",d.predicted_period_known},{"predicted_period_ns",d.predicted_period_ns},
        {"application_stereo_samples",fresh ? m.samples : 0},{"application_stereo_pairs_hz",fresh ? m.stereo_pairs_hz : 0},
        {"p95_submission_interval_ms",fresh ? m.p95_interval_ms : 0},{"p99_submission_interval_ms",fresh ? m.p99_interval_ms : 0},
        {"application_metrics_fresh",fresh},{"last_submission_age_ms",age_ms(last_submission)},
        {"wait_frame_cpu_ms",d.wait_frame_cpu_known ? json(d.wait_frame_cpu_ms) : json(nullptr)},
        {"swapchain_wait_cpu_ms",d.swapchain_wait_cpu_known ? json(d.swapchain_wait_cpu_ms) : json(nullptr)},
        {"fence_wait_cpu_ms",d.gpu_fence_wait_cpu_known ? json(d.gpu_fence_wait_cpu_ms) : json(nullptr)},
        {"end_frame_cpu_ms",d.end_frame_cpu_known ? json(d.end_frame_cpu_ms) : json(nullptr)},
        {"swapchain_timeouts",d.swapchain_timeout_count},{"fence_timeouts",d.fence_timeout_count},
        {"quest3_panel_width",2064},{"quest3_panel_height",2208},
        {"eye_render_cpu_ms",fresh && graphics==21 && eye_render_cpu_ms>=0 ? json(eye_render_cpu_ms) : json(nullptr)},
        {"eye_readback_cpu_ms",fresh && graphics==21 && eye_render_cpu_ms>=0 ? json(readback_ms) : json(nullptr)},
        {"upload_submit_cpu_ms",fresh && graphics==21 && upload_submit_cpu_ms>=0 ? json(upload_submit_cpu_ms) : json(nullptr)},
        {"timing_scope","CPU wall time; render dispatch and readback waits overlap GPU execution; not GPU timestamps"},
        {"last_layer_count",d.last_layer_count},{"flat_projection_background",d.last_flat_projection_background},{"high_resolution_gpu_path_ready",false}};
}

void cancel_frame() { xr.cancel_frame(); vk.cancel_frame(); ovr.cancel_frame(); }
bool close_backends() {
    // Owned upload backends only. Unity D3D11 teardown uses render event 3.
    const bool vk_done = vk.shutdown();
    const bool ovr_done = ovr.shutdown();
    const bool done = vk_done && ovr_done;
    xr_initialized = !done;
    if (!done) {
        restart_required = true;
        error = "VR upload GPU work is still pending; resources retained. Restart the game before reconnecting VR.";
    }
    return done;
}

std::wstring widen(const std::string& text) {
    if (text.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), (int)text.size(), nullptr, 0);
    if (!n) return {};
    std::wstring result(n, L'\0');
    MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), (int)text.size(), result.data(), n);
    return result;
}
bool file_exists(const std::wstring& path) {
    DWORD attr = GetFileAttributesW(path.c_str());
    return attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY);
}
std::wstring default_loader() {
    const wchar_t* path = L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\SteamVR\\bin\\win64\\openxr_loader.dll";
    return file_exists(path) ? path : L"";
}
std::wstring default_openvr_loader() {
    const wchar_t* path = L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\SteamVR\\bin\\win64\\openvr_api.dll";
    return file_exists(path) ? path : L"";
}
void fail(const std::string& message) {
    failure_context={{"error",message},{"graphics_api",graphics},{"targets_cleanup_owned",targets},
        {"runtime_backend",use_openvr ? "steamvr_openvr" : "openxr"},
        {"targets_valid_at_failure",unity.diagnostics().targets_valid},
        {"requested_eye_width",graphics==21?vulkan_width:graphics==2?width:0},
        {"requested_eye_height",graphics==21?vulkan_height:graphics==2?height:0}};
    if(api && api->log) api->log(api->context,"quest3.vrvd",("VR stopped: "+message).c_str());
    error = message; requested = false; queue_teardown({},false); state = "error";
}
bool configure(const char* value, std::string& why) {
    try {
        auto j = json::parse(value && *value ? value : "{}");
        if (!j.is_object()) throw std::runtime_error("Configuration must be an object");
        auto new_overlays=ui_observer.overlays;
        if(j.contains("ui_overlay_panels")){
            auto names=j.at("ui_overlay_panels").get<std::vector<std::string>>();
            if(names.size()>512)throw std::runtime_error("Too many UI overlay names");
            new_overlays.clear();for(const auto& n:names){if(n.empty()||n.size()>256)throw std::runtime_error("Invalid UI overlay name");new_overlays.insert(n);}
        }
        int w = j.value("eye_width", 1440), h = j.value("eye_height", 1440);
        int vw = j.value("vulkan_eye_width", 2560), vh = j.value("vulkan_eye_height", 2560);
        const auto quality = j.value("quality_preset",std::string("custom"));
        if (quality != "maximum" && quality != "custom")
            throw std::runtime_error("Quality preset must be maximum or custom");
        const auto desktop_mode=j.value("desktop_render_mode",std::string("normal"));
        if(desktop_mode!="normal"&&desktop_mode!="headset_only")
            throw std::runtime_error("Desktop render mode must be normal or headset_only");
        const bool swap = j.value("swap_eyes", false);
        const bool labels = j.value("eye_labels", false);
        const bool legacy_overlay=j.value("native_menu_overlay",false);
        (void)legacy_overlay;const bool menu_overlay_enabled=false; // Gameplay HUD is always hidden in this version.
        const int legacy_fade_ms=j.value("transition_fade_ms",300);
        const int fade_ms=j.value("transition_total_ms",300);
        if(legacy_fade_ms<0||legacy_fade_ms>600||fade_ms<0||fade_ms>600)throw std::runtime_error("Transition fade must be 0..600 ms");
        const bool focus_enabled=j.value("menu_focus_enabled",false);
        const int blur_radius=j.value("menu_blur_radius",9),feather=j.value("menu_feather_px",6);
        const float brightness=j.value("menu_background_brightness",.45f);
        if(blur_radius<1||blur_radius>16||feather<0||feather>32||!std::isfinite(brightness)||brightness<.1f||brightness>1.f)
            throw std::runtime_error("Menu blur radius must be 1..16, brightness 0.1..1, feather 0..32");

        const auto camera_source=j.value("engine_camera_source",std::string("auto"));
        if(camera_source!="auto"&&camera_source!="ui"&&camera_source!="main")throw std::runtime_error("Engine camera must be auto, ui or main");
        const auto hud_mode = j.value("hud_mode", std::string("off"));
        const float distance = j.value("hud_distance_m", 1.5f);
        const float panel_width = j.value("hud_width_m", 1.8f);
        const float offset = j.value("hud_offset_y_m", 0.f);
        int hud_w = j.value("hud_capture_width",2560), hud_h = j.value("hud_capture_height",1440);
        const auto layout=j.value("hud_layout",std::string("panel"));
        if(layout!="panel"&&layout!="edges")throw std::runtime_error("HUD layout must be panel or edges");
        const bool migrate=j.value("ui_quality_revision",0)<1;
        bool migrated=false;
        if(migrate&&vw==1024&&vh==1024){vw=vh=2560;migrated=true;}
        if(migrate&&hud_w==1280&&hud_h==720){hud_w=2560;hud_h=1440;migrated=true;}
        const int hud_hz = j.value("hud_refresh_hz",20);
        const auto composition = j.value("hud_composition",std::string("game_ui"));
        if (hud_w < 256 || hud_w > 4096 || hud_h < 256 || hud_h > 4096)
            throw std::runtime_error("HUD capture dimensions must each be 256..4096 pixels");
        if (hud_hz < 5 || hud_hz > 30)
            throw std::runtime_error("HUD content refresh must be 5..30 Hz");
        if (composition != "auto" && composition != "transparent" && composition != "opaque" && composition != "game_ui")
            throw std::runtime_error("HUD composition must be game_ui, auto, transparent or opaque");
        if (hud_mode != "off" && hud_mode != "head_locked")
            throw std::runtime_error("HUD mode must be off or head_locked");
        if (!std::isfinite(distance) || distance < 0.5f || distance > 4.0f ||
            !std::isfinite(panel_width) || panel_width < 0.3f || panel_width > 2.0f ||
            !std::isfinite(offset) || offset < -1.0f || offset > 1.0f)
            throw std::runtime_error("HUD distance must be 0.5..4m, width 0.3..2m and vertical offset -1..1m");
        if (w < 512 || w > 2560 || h < 512 || h > 2560)
            throw std::runtime_error("Eye resolution must be 512..2560 pixels");
        if (vw < 512 || vw > 3072 || vh < 512 || vh > 3072)
            throw std::runtime_error("Vulkan CPU-readback eye resolution must be 512..3072 pixels; larger images increase CPU transfer cost and latency");
        // Only an explicit maximum choice overrides numeric sizes. Existing
        // EML configurations without a preset keep their saved dimensions.
        if (quality == "maximum") { w=h=2560; vw=vh=3072; }
        auto path = widen(j.value("openxr_loader_path", std::string{}));
        if (path.empty()) path = default_loader();
        const auto backend = j.value("runtime_backend",std::string("openxr"));
        if (backend != "openxr" && backend != "steamvr_openvr")
            throw std::runtime_error("Runtime backend must be openxr or steamvr_openvr");
        const bool new_openvr = backend == "steamvr_openvr";
        const auto openvr_text = j.value("openvr_loader_path",std::string{});
        auto openvr_path = widen(openvr_text);
        if (!openvr_text.empty() && openvr_path.empty())
            throw std::runtime_error("OpenVR loader path must be valid UTF-8");
        if (openvr_path.empty()) openvr_path = default_openvr_loader();
        if (!openvr_path.empty() && !((openvr_path.size()>2 && openvr_path[1]==L':' &&
            (openvr_path[2]==L'\\' || openvr_path[2]==L'/')) || openvr_path.rfind(L"\\\\",0)==0))
            throw std::runtime_error("OpenVR loader path must be an absolute path to installed openvr_api.dll");
        if (requested || restart_required || targets || xr_initialized || pending || teardown_pending || unity.resources_alive() || hud.resources_alive() || menu_overlay.resources_alive() || engine_capture.resources_alive()) {
            if (engine_camera_source!=camera_source || width != (uint32_t)w || height != (uint32_t)h ||
                vulkan_width != (uint32_t)vw || vulkan_height != (uint32_t)vh || loader != path ||
                use_openvr != new_openvr || openvr_loader != openvr_path || quality_preset != quality  ||
                hud_capture_width != uint32_t(hud_w) || hud_capture_height != uint32_t(hud_h))
                throw std::runtime_error("Stop VR and wait for cleanup before changing quality preset, eye/HUD resolution, runtime backend or loader path");
        }
        engine_camera_source=camera_source;hud_layout=layout;quality_migrated=migrated;flat_transition.duration_ms=fade_ms;
        width = w; height = h; loader = path;
        use_openvr = new_openvr; openvr_loader = openvr_path;
        vulkan_width = vw; vulkan_height = vh;
        quality_preset = quality;
        const bool new_desktop_only=desktop_mode=="headset_only";
        if(new_desktop_only!=desktop_only&&!desktop_filter.snapshot().installed)desktop_install_attempted=false;
        desktop_only=new_desktop_only;if(!desktop_only)desktop_filter.disable();
        swap_eyes = swap; eye_labels = labels; hud_enabled = menu_overlay_enabled;
        menu_focus_enabled=focus_enabled;menu_blur_radius=blur_radius;menu_feather=feather;menu_background_brightness=brightness;menu_focus_dirty=true;
        hud_distance = distance; hud_width = panel_width; hud_offset = offset;
        hud_capture_width=uint32_t(hud_w);hud_capture_height=uint32_t(hud_h);hud_refresh_hz=uint32_t(hud_hz);
        hud_composition=composition;
        hud_blocked = false; hud_error.clear(); hud_pixels.clear();
        // 0.5.7: hud_enabled controls the original UI-camera overlay, never Canvas mutation.
        desktop_only=false; // Native menu extraction needs the game's original composition.
        ui_observer.overlays=std::move(new_overlays);ui_observer.invalidate();
        hud_last_capture = {};
        return true;
    } catch (const std::exception& ex) { why = ex.what(); return false; }
}
json status() {
    const auto desktop=desktop_filter.snapshot();
    const auto camera = unity.diagnostics(); // Cached values; never invokes Unity on the host worker.
    const auto calls_json=[](const vrvd::HgProjectionCallCounters& c) {
        return json{{"entries",c.entries},{"scope_entries",c.scope_entries},
            {"same_camera_wrong_instance",c.same_camera_wrong_instance},
            {"same_instance_wrong_camera",c.same_instance_wrong_camera},
            {"outside_scope_private",c.outside_scope_private},
            {"frame_scope_entries",c.frame_scope_entries},
            {"frame_same_camera_wrong_instance",c.frame_same_camera_wrong_instance},
            {"frame_same_instance_wrong_camera",c.frame_same_instance_wrong_camera}};
    };
    const auto& route=camera.hg_routing;
    const json route_status={{"build",calls_json(route.build_calls)},
        {"non_oblique",calls_json(route.non_oblique_calls)},
        {"frame_build_hits",route.frame_build_hits},{"frame_non_oblique_hits",route.frame_non_oblique_hits},
        {"frame_parameters_observer",route.frame_parameters_observer},
        {"frame_parameters_status",route.frame_parameters_status},{"prepare_entries",route.prepare_entries},
        {"prepare_calls",route.prepare_calls},{"frame_prepare_calls",route.frame_prepare_calls},
        {"frame_prepare_successes",route.frame_prepare_successes},
        {"frame_prepare_hg_mismatch",route.frame_prepare_hg_mismatch},
        {"frame_prepare_additional_mismatch",route.frame_prepare_additional_mismatch},
        {"draw_binding_required",route.draw_binding_required},{"get_or_create_hook",route.get_or_create_hook},
        {"frame_draw_bindings",route.frame_draw_bindings},
        {"frame_draw_binding_failures",route.frame_draw_binding_failures},
        {"frame_draw_binding_changed",route.frame_draw_binding_changed},
        {"frame_prepare_validation_failures",route.frame_prepare_validation_failures},
        {"frame_draw_multipass",route.frame_draw_multipass},{"draw_binding_error",route.draw_binding_error}};
    std::string reported_state = state;
    if (requested && !teardown_pending && !restart_required && state != "error") {
        if (pending && age_ms(pending_since)>2000) reported_state="waiting_render_callback";
        else if (age_ms(last_camera_tick)<0 || age_ms(last_camera_tick)>2000) reported_state="waiting_game_camera";
        else if (state=="submitting_experimental_frames" && (age_ms(last_submission)<0 || age_ms(last_submission)>2000))
            reported_state="waiting_fresh_frame";
    }
    const json camera_status = {{"frame_state",camera.frame_state},{"hg_status",camera.hg_status},
        {"geometry_status",camera.geometry_status},{"error",camera.error},
        {"source_present",camera.source_present},{"targets_valid",camera.targets_valid},
        {"hg_active",camera.hg_active},{"source_generation",camera.source_generation},
        {"hg_projection_hook",camera.hg_projection_hook},{"hg_projection_hits",camera.hg_projection_hits},
        {"hg_non_oblique_hits",camera.hg_non_oblique_hits},
        {"source_fullscreen_passthrough",camera.source_fullscreen_passthrough},
        {"hg_routing",route_status},
        {"targets_generation",camera.targets_generation},{"geometry_checks",camera.geometry_checks},
        {"geometry_failures",camera.geometry_failures},
        {"last_game_tick_age_ms",age_ms(last_camera_tick)},{"last_accepted_frame_age_ms",age_ms(last_accepted_frame)}};
    return {{"module_version",Version},{"state", reported_state}, {"error", error}, {"hooks_ready", hooks_ready},
            {"last_failure_context",failure_context},
            {"requested", requested}, {"render_event_pending", pending != 0},
            {"runtime_backend",use_openvr ? "steamvr_openvr" : "openxr"},
            {"runtime", graphics == 21 ? (use_openvr ? ovr.runtime_name() : vk.runtime_name()) : xr.runtime_name()}, {"submitted_frames", submitted},
            {"session_submitted_frames",session_submitted},{"teardown_pending",teardown_pending},
            {"recovery_pending",recovery_pending},{"recovery_reason",recovery_reason},{"recoveries",recoveries},
            {"camera_adapter",camera_status},
            {"restart_required", restart_required},
            {"performance",performance_status()},{"last_menu_presentation",last_menu_presentation},{"ui_transition",ui_transition_status()},
            {"gpu_probe_state",gpu_probe_state},{"gpu_probe_error",gpu_probe_error},
            {"gpu_probe_resources_alive",gpu_probe.resources_alive()},
            {"gpu_diagnostic",gpu_layer_status()},
            {"backend", graphics == 21 ? (use_openvr ? "Vulkan game / CPU readback / owned D3D11 upload / SteamVR OpenVR" : "Vulkan compatibility / CPU readback / OpenXR Vulkan") :
                           graphics == 2 ? (use_openvr ? "Unsupported: SteamVR/OpenVR requires Vulkan game graphics" : "D3D11 / GPU copy / OpenXR D3D11") : "Not detected"},
            {"graphics_api", graphics}, {"readback_ms", readback_ms},
            {"quality_preset",quality_preset},
            {"desktop_render_mode",desktop_only?"headset_only":"normal"},
            {"desktop_filter",{{"installed",desktop.installed},{"armed",desktop.armed},{"filtered_calls",desktop.filtered_calls},
                {"filtered_cameras",desktop.filtered_cameras},{"pass_through_calls",desktop.pass_through_calls},
                {"contract_failures",desktop.contract_failures},{"status",desktop.status},{"error",desktop.error.empty()?desktop_mark_error:desktop.error}}},
            {"configured_eye_width",width},{"configured_eye_height",height},
            {"configured_vulkan_eye_width",vulkan_width},{"configured_vulkan_eye_height",vulkan_height},
            {"swap_eyes", swap_eyes}, {"eye_labels", eye_labels}, {"hud_mode", hud_enabled ? "head_locked" : "off"},{"native_menu_overlay",hud_enabled},
            {"hud_status", !hud_enabled ? "off" : !requested || teardown_pending ? "inactive" : graphics != 21 ? "requires_vulkan" :
                hud_blocked ? "unavailable" : hud_pixels.empty() ? "waiting_capture" : "captured_pending_visual_check"},
            {"hud_error", hud_error}, {"hud_canvas_count",nullptr},
            {"hud_capture_width",hud_capture_width},{"hud_capture_height",hud_capture_height},{"hud_refresh_hz",hud_refresh_hz},
            {"hud_distance_m",hud_distance},{"hud_width_m",hud_width},{"hud_offset_y_m",hud_offset},
            {"hud_capture_path",hud_layout=="panel"?"hg_final_result_information_panel":"hg_final_result_edge_crops"},{"hud_skipped_canvas_count",0},{"hud_warning","FinalResult includes native background; information panel preserves full content, edge crops omit the center; CPU readback is used"},
            {"hud_composition_requested",hud_composition},
            {"hud_composition_actual",hud_pixels.empty() ? "none" : hud_layout=="panel"?"engine_final_information_panel_opaque":"engine_final_edge_crops_premultiplied"},
            {"hud_capture_ms", hud_capture_ms}, {"hud_restore_pending",menu_overlay.restore_pending()},
            {"active_eye_width", targets ? (graphics == 21 ? vulkan_width : width) : 0},
            {"active_eye_height", targets ? (graphics == 21 ? vulkan_height : height) : 0},
            {"performance_note", graphics == 21 ? "Actual per-eye rendering uses the configured size (512..3072). CPU readback and upload cost increase with pixel count; higher resolution does not provide a GPU bridge or guarantee 90/120 Hz." : ""},
            {"first_person_state",paired_active()?"active":"inactive"},
            {"visual_validation", "Not verified: successful frame submission does not prove HG pipeline image correctness"}};
}

// Called by Unity on its graphics thread, after both eye render commands.
void render_event(int event_id) {
    std::lock_guard<std::recursive_mutex> lock(mutex);
    if (pending != event_id) return;
    try {
        if (event_id == 3 || !live.load() || !requested || teardown_pending || closing) {
            xr.cancel_frame();
            xr.shutdown(); xr_initialized = false;
        } else if (event_id == 1 || event_id == 2) {
            std::string why;
            // Only references retained on the game thread enter this callback.
            // A scene change cannot turn these into dangling cached native pointers.
            if (!pending_eyes[0] || !pending_eyes[1]) { xr.cancel_frame(); fail("Retained D3D11 eye resources are missing"); }
            else if (event_id == 1) {
                if (!xr.initialize(pending_eyes[0], pending_eyes[1], loader.c_str(), why, true)) fail(why);
                else { xr_initialized = true; state = "waiting_session"; }
            } else if (!xr.submit(pending_eyes[pending_swap_eyes ? 1 : 0], pending_eyes[pending_swap_eyes ? 0 : 1], why)) {
                xr.cancel_frame(); fail(why);
            } else { menu_handoff_pending=false;record_submission(); state = "submitting_experimental_frames"; }
        }
    } catch (const std::exception& ex) {
        xr.cancel_frame(); fail(ex.what());
        if (event_id==3) restart_required=true;
    }
    release_pending_eyes(); pending = 0; pending_since = {};
}

// Must run on the game thread, independently of main-camera/frame acceptance.
// Returns a graphics-thread close event when a D3D11 session still owns state.
int teardown_on_game_thread() {
    flat_transition.reset();
    if(engine_capture.resources_alive()){std::string why;if(!engine_capture.cleanup(why)){menu_error=why;state="waiting_native_extraction_cleanup";return 0;}}
    menu_pixels.clear();menu_focus_pixels.clear();menu_focus_dirty=true;menu_last_capture={};menu_last_request={};last_menu_frame=-1;last_unknown_menu_tick={};menu_handoff_pending=false;
    window_capture.cleanup();window_pixels.clear();window_last_capture={};
    if(menu_overlay.resources_alive()){std::string why;if(!menu_overlay.cleanup(why)){hud_error=why;state="stopping_game_resources";return 0;}}
    if(menu_capture_ready){std::string why;if(!menu_capture.cleanup(why)){menu_error=why;state="waiting_native_extraction_cleanup";return 0;}}

    desktop_filter.disable();
    if(!desktop_filter.clear()){state="stopping_game_resources";return 0;}
    if (hud.resources_alive()) hud.cleanup();
    hud_pixels.clear();
    if (hud.restore_pending()) {
        // The HUD may still hold an original active RenderTexture. Do not
        // destroy eye targets until that game state has been restored.
        state=recovery_pending ? "recovering_game_resources" : "stopping_game_resources";
        return 0;
    }
    if (graphics==2 && (xr_initialized || xr.frame_pending())) {
        std::string why;
        if (!reserve_render_event(3,why)) {
            error=why; restart_required=true; state="restart_required"; return 0;
        }
        state=recovery_pending ? "recovering_waiting_render_thread" : "stopping_waiting_render_thread";
        return 3;
    }
    if (graphics==21) {
        owned_cancel();
        if (!close_backends()) { state="restart_required"; return 0; }
    }
    if (unity.resources_alive()) unity.cleanup();
    targets=unity.resources_alive();
    if (targets || hud.resources_alive() || gpu_probe.resources_alive()) {
        state=recovery_pending ? "recovering_game_resources" : "stopping_game_resources";
        return 0;
    }
    if (recovery_pending) ++recoveries;
    recovery_pending=false; teardown_pending=false; source_generation=0; graphics=0;
    clear_frame_observations(); last_accepted_frame={};
    state=requested ? "waiting_game_camera" : error.empty() ? "disabled" : "error";
    return 0;
}

void dispatch_render_event(int event) {
    // Do not hold the lifecycle lock across Unity's callback dispatch.
    std::lock_guard<std::mutex> dispatch_lock(dispatch_mutex);
    {
        std::lock_guard<std::recursive_mutex> lock(mutex);
        // During shutdown an already reserved event must still drain the
        // backend. Only an entirely undispatched event can be abandoned.
        if (!live.load()) { release_pending_eyes(); pending=0; pending_since={}; return; }
    }
    std::string why;
    if (!unity.schedule(render_event,event,why)) {
        std::lock_guard<std::recursive_mutex> lock(mutex);
        // A managed dispatch failure gives no proof that Unity did not enqueue
        // the callback. Keep its references alive, even if no callback arrives.
        fail("Unity render callback dispatch failed: " + why);
        restart_required=true; state="restart_required";
    }
}

void ensure_optional_desktop_filter() {
    if(!desktop_only||desktop_install_attempted||!api)return;
    desktop_install_attempted=true;
    if(desktop_filter.snapshot().installed)return;
    std::string why;
    if(!desktop_filter.install(api,why)){
        desktop_mark_error=why;
        if(api->log)api->log(api->context,ID,("Desktop filtering unavailable; normal desktop render retained: "+why).c_str());
    } else desktop_mark_error.clear();
}

void clear_owned_view(){
    if(!xr_initialized||graphics!=21||use_openvr)return;
    if(vk.frame_pending()){owned_cancel();return;}
    vrvd::Eye eyes[2]{};bool draw=false;std::string why;
    if(owned_begin(eyes,draw,why))owned_cancel();else menu_error=why;
}
bool decorate_menu_frame(vrvd::XrVulkanHudFrame& frame){
    const bool held_focus=ui_observer.mode=="gameplay"&&menu_handoff_pending&&last_menu_presentation.value("focus",false);
    if(!menu_focus_enabled||(ui_observer.mode!="menu"&&ui_observer.mode!="special_camera"&&!held_focus))return false;
    if(menu_focus_dirty){
        auto started=Clock::now();
        if(!vrvd::make_menu_focus(menu_pixels,hud_capture_width,hud_capture_height,engine_capture.source_width,engine_capture.source_height,
            menu_blur_radius,menu_background_brightness,menu_feather,menu_focus_pixels,menu_error)){
            menu_focus_pixels.clear();
        }
        menu_focus_ms=std::chrono::duration<double,std::milli>(Clock::now()-started).count();menu_focus_dirty=false;
    }
    // Decoration is optional. A bad blur result cannot suppress the raw menu.
    if(menu_focus_pixels.panel.size()!=frame.bytes||menu_focus_pixels.backdrop.size()!=size_t(vrvd::MenuBackdropSize)*vrvd::MenuBackdropSize*4)return false;
    frame.rgba=menu_focus_pixels.panel.data();frame.bytes=menu_focus_pixels.panel.size();
    frame.backdrop_rgba=menu_focus_pixels.backdrop.data();frame.backdrop_bytes=menu_focus_pixels.backdrop.size();
    return true;
}
bool poll_engine_final(uint32_t w,uint32_t h,std::vector<uint8_t>& pixels,bool& fresh,std::string& why){
    if(!engine_capture.resolve(api,why))return false;
    const bool ok=engine_capture.poll(ui_observer.manager_object(),engine_camera_source,w,h,pixels,fresh,why);
    if(!ok||!engine_capture.ready_for_readback())pixels.clear();
    return ok;
}
vrvd::XrVulkanHudFrame fade_frame(float opacity,bool keep_world){
    vrvd::XrVulkanHudFrame f{};f.width=hud_capture_width;f.height=hud_capture_height;f.black_opacity=opacity;f.keep_previous_world=keep_world;return f;
}
void menu_tick(){
    desktop_filter.disable();
    const int observed_frame=ui_observer.frame_id();
    // An incomplete UI observation must not erase an already visible menu.
    if(observed_frame>=0){
        if(observed_frame==last_menu_frame)return;
        last_menu_frame=observed_frame;
    }else{
        if(last_unknown_menu_tick!=Clock::time_point{}&&age_ms(last_unknown_menu_tick)<11)return;
        last_unknown_menu_tick=Clock::now();
    }
    if(!paired_guard()){state="waiting_paired_first_person";return;}
    std::string why;
    if(!unity.graphics_type(graphics,why)||graphics!=21||use_openvr){state="ui_requires_vulkan_openxr";menu_error="UI routing currently requires Vulkan + OpenXR";return;}
    if(!xr_initialized){
        if(!owned_initialize(why)){fail(why);return;}xr_initialized=true;state="waiting_session";return;
    }
    if(flat_transition.fading_out()){
        vrvd::Eye eyes[2]{};bool draw=false;
        if(!owned_begin(eyes,draw,why)){owned_cancel();fail(why);return;}
        if(!draw){owned_cancel();state="waiting_headset_or_visibility";return;}
        float alpha=flat_transition.outgoing(transition_time());auto mask=fade_frame(alpha,true);
        if(!vk.submit_panel(mask,why)){owned_cancel();fail(why);return;}
        flat_transition.submitted_black(alpha);++submitted;++session_submitted;last_submission=Clock::now();state="fading_stereo_to_flat";return;
    }
    bool fresh=false;
    const uint32_t menu_hz=ui_observer.mode=="radial"?30:hud_refresh_hz;
    if(ui_observer.mode!="gameplay"&&(ui_capture_due||menu_last_capture==Clock::time_point{}||age_ms(menu_last_capture)>=1000.0/menu_hz)){
        ui_capture_due=false;
        if(!poll_engine_final(hud_capture_width,hud_capture_height,menu_pixels,fresh,menu_error)){
            menu_pixels.clear();menu_focus_pixels.clear();state="menu_capture_error";
        }
        menu_last_capture=Clock::now();
        if(fresh){menu_error.clear();menu_focus_dirty=true;}
    }
    vrvd::Eye eyes[2]{};bool draw=false;
    if(!owned_begin(eyes,draw,why)){owned_cancel();fail(why);return;}
    if(!draw){owned_cancel();state="waiting_headset_or_visibility";return;}
    // Final-window stream: hold the completed image until the next image arrives.
    const bool captured=vrvd::may_present_menu(menu_pixels.size()==size_t(hud_capture_width)*hud_capture_height*4,true);
    if(!captured && menu_placeholder.size()!=size_t(hud_capture_width)*hud_capture_height*4 &&
       !vrvd::make_menu_wait_panel(hud_capture_width,hud_capture_height,menu_placeholder)){
        owned_cancel();state="menu_placeholder_error";return;
    }
    const auto& shown=captured?menu_pixels:menu_placeholder;
    vrvd::XrVulkanHudFrame frame{shown.data(),shown.size(),hud_capture_width,hud_capture_height,hud_distance,hud_width,0.f};
    const bool focus=captured&&decorate_menu_frame(frame);
    frame.content_black_opacity=flat_transition.menu_opacity(transition_time());

    if(!vk.submit_panel(frame,why)){owned_cancel();fail(why);return;}
    flat_transition.submitted_menu(frame.content_black_opacity);
    const auto menu_diag=vk.diagnostics();
    last_menu_presentation={{"mode",ui_observer.mode},{"generation",ui_observer.generation},{"content_black_opacity",frame.content_black_opacity},{"captured",captured},
        {"capture_status",engine_capture.status},{"source",engine_capture.selected_source},{"source_width",engine_capture.source_width},{"source_height",engine_capture.source_height},
        {"mean_rgb",engine_capture.mean_rgb},{"black_fraction",engine_capture.black_fraction},{"focus",focus},
        {"layer_count",menu_diag.last_layer_count},{"flat_projection_background",menu_diag.last_flat_projection_background},
        {"capture_error",menu_error},{"visual_verified",false}};
    ++submitted;++session_submitted;++menu_submitted;last_submission=Clock::now();if(!captured){++menu_placeholder_frames;state="waiting_menu_capture_visible";}else state=ui_observer.mode=="radial"?"submitting_full_radial":focus?"submitting_focus_menu":"submitting_native_menu";
}
// UI changes select presentation, but never invalidate a completed window frame
// or a GPU readback. Child panels/animations do not restart the capture stream.
void observe_ui_generation(uint64_t generation){
    if(ui_generation!=generation){ui_generation=generation;eye_render_cpu_ms=upload_submit_cpu_ms=-1;frame_metrics.reset();ui_capture_due=true;}
}
void process_ui_generation(){
    ui_observer.refresh();
    observe_ui_generation(ui_observer.generation);
}

void log_render_progress(){
    if(!api||!api->log||!requested)return;
    if(last_diagnostic_log!=Clock::time_point{}&&age_ms(last_diagnostic_log)<2000)return;
    last_diagnostic_log=Clock::now();
    json line={{"version",Version},{"state",state},{"mode",ui_observer.mode},{"generation",ui_observer.generation},
        {"capture",engine_capture.status},{"capture_polls",engine_capture.polls},{"stage",engine_capture.stage},{"source",engine_capture.selected_source},{"source_preference",engine_camera_source},{"captured",engine_capture.frames},{"source_width",engine_capture.source_width},{"source_height",engine_capture.source_height},{"eye_width",vulkan_width},{"eye_height",vulkan_height},{"menu_width",hud_capture_width},{"menu_height",hud_capture_height},{"hud_layout",hud_layout},{"transition_phase",flat_transition.name()},{"transition_opacity",flat_transition.last_opacity},{"seed_rejections",engine_capture.seed_rejections},{"mean_rgb",engine_capture.mean_rgb},{"black_fraction",engine_capture.black_fraction},{"engine_camera_ends",engine_capture.selected_camera_end_calls()},
        {"menu_submitted",menu_submitted},{"placeholder_frames",menu_placeholder_frames},{"clock_ticks",clock_ticks.load()},
        {"camera_ticks",camera_ticks.load()},{"tail_ticks",tail_ticks.load()},{"stale",window_capture.stale},{"bounds_mismatches",window_capture.bounds_mismatches},
        {"hud_error",hud_error},{"menu_error",menu_error},{"error",error},{"performance",performance_status()}};
    api->log(api->context,ID,("VR frame diagnostic: "+line.dump()).c_str());
}
void process_frame(void* brain) {

    if (inside_camera || !live.load()) return;
    inside_camera = true;
    struct Reset { ~Reset() { inside_camera = false; } } reset;
    int event = 0;
    {
        std::lock_guard<std::recursive_mutex> lock(mutex);
        struct ProgressLog {~ProgressLog(){log_render_progress();}} progress_log;
        last_camera_tick=Clock::now();
        if (!live.load() || pending || !hooks_ready) return;
        try {
            if (restart_required) {
                // HUD uses CPU copies, not borrowed GPU resources. Even if the XR
                // device cannot close, keep restoring game UI on this game thread.
                if (hud.resources_alive()) hud.cleanup();
                if(menu_overlay.resources_alive()){std::string ignored;menu_overlay.cleanup(ignored);}
                cleanup_gpu_probe();
                state = "restart_required"; return;
            }
            if (gpu_probe_cleanup || (requested && gpu_probe.resources_alive())) {
                cleanup_gpu_probe();
                if (gpu_probe.resources_alive()) {
                    gpu_probe_state="cleanup_pending";
                    state="waiting_gpu_probe_cleanup";
                    return;
                }
            }
            if (gpu_probe_requested && !requested) {
                gpu_probe_requested=false; gpu_probe_error.clear();
                std::string why; int32_t actual_api=0;
                GpuLayerRef held;HMODULE library=held.handle;
                auto mark=library ? reinterpret_cast<GpuMarkFn>(GetProcAddress(library,"vrvd_gpu_diag_mark_image_v1")) : nullptr;
                if (!mark) { gpu_probe_state="layer_not_loaded"; gpu_probe_error="Explicit Vulkan diagnostic layer is not loaded; use its opt-in launcher after installing the layer."; }
                else if (!unity.graphics_type(actual_api,why) || actual_api!=21) {
                    gpu_probe_state="failed"; gpu_probe_error=why.empty() ? "GPU diagnostic requires the game to use Vulkan" : why;
                } else {
                    if (!gpu_probe_resolved) gpu_probe_resolved=gpu_probe.resolve(api,why);
                    if (!gpu_probe_resolved || !gpu_probe.ensure(why)) { gpu_probe_state="failed"; gpu_probe_error=why; gpu_probe_cleanup=true; }
                    else {
                        clear_gpu_marks(); ++gpu_probe_generation; bool marked=true;
                        for(unsigned eye=0;eye<2;++eye) {
                            if(mark(gpu_probe.source_handle(eye),eye,gpu_probe_generation)!=0 ||
                               mark(gpu_probe.marker_handle(eye),eye+2,gpu_probe_generation)!=0)marked=false;
                        }
                        if(!marked){gpu_probe_state="handle_not_observed";gpu_probe_error="A Unity native handle did not match one unique tracked Vulkan image; no GPU pointer guess was attempted.";gpu_probe_cleanup=true;}
                        else if(!gpu_probe.issue_copy(why)){gpu_probe_state="failed";gpu_probe_error=why;gpu_probe_cleanup=true;}
                        else gpu_probe_state="copy_enqueued_wait_for_layer_submission";
                    }
                }
            }
            if (!requested && !teardown_pending && (targets || xr_initialized || unity.resources_alive() || hud.resources_alive()))
                queue_teardown({},false);
            if (teardown_pending) event=teardown_on_game_thread();
            else if (requested) {
            process_ui_generation();
            flat_transition.target(ui_observer.mode!="gameplay",transition_time(),vk.has_previous_world());
            if(ui_observer.mode!="gameplay"||flat_transition.fading_flat_out()){menu_handoff_pending=true;menu_tick();return;}
            if(!brain){if(menu_handoff_pending)menu_tick();return;}
            if(!paired_guard()){state="waiting_paired_first_person";return;}
            if(!paired_active()){if(menu_handoff_pending)menu_tick();else {clear_owned_view();state="waiting_first_person";}return;}
            // Discard completed captures left by a closed menu, without rereading them.
            if(menu_capture.pending()){std::string ignored;menu_capture.cleanup(ignored);}
            if(auto ready=first_person_ready_callback.load();ready&&!ready()){
                desktop_filter.disable();
                if(menu_handoff_pending){menu_tick();return;}
                if(targets||xr_initialized||unity.resources_alive())queue_teardown("Waiting for integrated first-person camera",true);
                else state="waiting_first_person";
                return;
            }
            std::string why;
            bool accepted = false;
            if (!unity.accept_frame(brain, accepted, why)) { fail(why); return; }
            const auto camera=unity.diagnostics();
            if (!accepted) {
                if(menu_handoff_pending){menu_tick();return;}
                if (camera.frame_state=="no_main_camera") {
                    if (state!="waiting_game_camera") clear_frame_observations();
                    state="waiting_game_camera";
                }
                return;
            }
            last_accepted_frame=Clock::now();
            desktop_filter.disable(); // Re-arm only after this frame's complete stereo pair succeeds.
            // EML's default path must not install an additional Render hook.
            // Resolve/install only after explicit opt-in and a valid game frame.
            ensure_optional_desktop_filter();
            if (source_generation && camera.source_generation!=source_generation) {
                // New main cameras must never inherit a captured HUD or old metrics.
                clear_frame_observations(); hud_blocked=false; hud_error.clear();
            }
            source_generation=camera.source_generation;
            bool valid=false;
            if (targets) {
                if (!unity.validate_targets(valid,why)) { fail(why); return; }
                if (!valid) {
                    queue_teardown("Unity eye targets were lost or released",true);
                    event=teardown_on_game_thread();
                }
            }
            if (!teardown_pending && !event) {
            if (!targets) {
                if (!unity.graphics_type(graphics, why)) { fail(why); return; }
                if (graphics != 2 && graphics != 21) {
                    fail("Supported Unity graphics APIs are Direct3D11 (2) and Vulkan (21); detected " + std::to_string(graphics)); return;
                }
                if (use_openvr && graphics != 21) {
                    fail("SteamVR/OpenVR backend requires the game to use Vulkan (21) in this build. Select OpenXR for a Direct3D11 game."); return;
                }
                // Mark ownership before attempting allocation so partial failure is cleaned.
                targets = true;
                if (!unity.ensure_targets(graphics == 21 ? vulkan_width : width,
                                          graphics == 21 ? vulkan_height : height, why)) { fail(why); return; }
            }
            if (graphics == 21) {
                // ReadPixels synchronizes Unity's rendering internally. We never
                // borrow Unity's VkImage/device/queue or dispatch a D3D callback.
                // The selected owned backend uploads two independent CPU images.
                if (!xr_initialized) {
                    state = "connecting_runtime";
                    if (!owned_initialize(why)) { fail(why); return; }
                    xr_initialized = true; state = "waiting_session"; return;
                }
                vrvd::Eye eyes[2]{}; bool draw = false;
                if (!owned_begin(eyes, draw, why)) { owned_cancel(); fail(why); return; }
                if (!draw) { owned_cancel(); state = "waiting_headset_or_visibility"; return; }
                const auto render_begin=Clock::now();
                if (!render_game_eyes(eyes, why)) { owned_cancel(); fail(why); return; }
                eye_render_cpu_ms=std::chrono::duration<double,std::milli>(Clock::now()-render_begin).count();
                const auto begin = std::chrono::steady_clock::now();
                if (!unity.readback_eyes(readback, why)) { owned_cancel(); fail(why); return; }
                readback_ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now()-begin).count();
                const size_t expected = size_t(vulkan_width) * vulkan_height * 4;
                if (readback[0].size() != expected || readback[1].size() != expected) {
                    owned_cancel(); fail("Vulkan readback returned an unexpected RGBA byte count"); return;
                }
                if (eye_labels) for (unsigned source = 0; source < 2; ++source)
                    vrvd::annotate_eye_rgba(readback[source].data(), vulkan_width, vulkan_height, source, swap_eyes);
                vrvd::XrVulkanHudFrame hud_frame{};
                const vrvd::XrVulkanHudFrame* hud_layer = nullptr;
                if (hud_enabled) {
                    const auto now=Clock::now();
                    if(ui_capture_due||window_last_capture==Clock::time_point{}||age_ms(window_last_capture)>=1000.0/hud_refresh_hz){
                        ui_capture_due=false;
                        bool fresh=false;window_last_capture=Clock::now();
                        if(!poll_engine_final(hud_capture_width,hud_capture_height,window_pixels,fresh,hud_error)){
                            hud_pixels.clear();hud_blocked=true;
                        }else if(fresh){
                            if(hud_layout=="panel")vrvd::make_info_hud(window_pixels,hud_capture_width,hud_capture_height,hud_pixels);
                            else vrvd::make_edge_hud(window_pixels,hud_capture_width,hud_capture_height,hud_pixels);
                            window_last_capture=Clock::now();hud_last_capture=window_last_capture;hud_blocked=false;hud_error.clear();
                        }
                        if(!engine_capture.ready_for_readback())hud_pixels.clear();
                        hud_capture_ms=std::chrono::duration<double,std::milli>(Clock::now()-now).count();
                    }
                    if(!hud_blocked&&!hud_pixels.empty()){
                        hud_frame={hud_pixels.data(),hud_pixels.size(),hud_capture_width,hud_capture_height,hud_distance,hud_layout=="panel"?hud_width*.78f:hud_width*1.5f,hud_layout=="panel"?hud_offset-.5f:hud_offset};
                        hud_layer=&hud_frame;
                    }
                }else {hud_pixels.clear();} // Keep the window stream alive for subsequent menus.
                // This opt-in diagnostic only reroutes image content. The runtime's
                // physical-eye pose/FOV and head-locked HUD remain untouched.
                const float world_black=flat_transition.world_opacity(transition_time());
                if(world_black>0){hud_frame=fade_frame(world_black,false);hud_layer=&hud_frame;}
                const auto upload_begin=Clock::now();
                if (!owned_submit(readback[swap_eyes ? 1 : 0].data(), readback[swap_eyes ? 0 : 1].data(), expected, why, hud_layer)) {
                    owned_cancel(); fail(why); return;
                }
                upload_submit_cpu_ms=std::chrono::duration<double,std::milli>(Clock::now()-upload_begin).count();
                menu_handoff_pending=false;record_submission(); state = world_black>0?"fading_flat_to_stereo":"submitting_experimental_frames";
                return;
            }
            if (!xr_initialized) {
                if (!reserve_render_event(1,why)) { fail(why); return; }
                event=1; state = "connecting_runtime";
            }
            else {
                vrvd::Eye eyes[2]{}; bool draw = false;
                if (!xr.begin_frame(eyes, draw, why)) { fail(why); return; }
                if (!draw) {
                    xr.cancel_frame(); state = "waiting_headset_or_visibility"; return;
                }
                if (!render_game_eyes(eyes, why)) { xr.cancel_frame(); fail(why); return; }
                pending_swap_eyes = swap_eyes;
                if (!reserve_render_event(2,why)) { xr.cancel_frame(); fail(why); return; }
                event=2;
            }
            }
            }
        } catch (const std::exception& ex) { cancel_frame(); fail(ex.what()); }
    }
    if (event) dispatch_render_event(event);
}

float ui_clock(void* method){
    const bool nested=inside_clock;
    inside_clock=true;
    struct ResetClock {bool previous;~ResetClock(){inside_clock=previous;}} reset{nested};
    float result=next_ui_clock?next_ui_clock(method):0.f;
    if(vrvd::may_pump_menu(unity_thread.load(),GetCurrentThreadId(),live.load(),nested,inside_camera)){
        ++clock_ticks;process_frame(nullptr);
    }
    return result;
}
void camera_tick(void* brain,void* camera_state,void* method){
    DWORD empty=0;unity_thread.compare_exchange_strong(empty,GetCurrentThreadId());++camera_ticks;
    if(next_push)next_push(brain,camera_state,method);
    process_frame(brain);
}
void ui_tail(void* manager,float delta,void* method){
    DWORD empty=0;unity_thread.compare_exchange_strong(empty,GetCurrentThreadId());++tail_ticks;
    if(live.load()){
        std::lock_guard<std::recursive_mutex> lock(mutex);
        if(ui_ready){ui_observer.set_manager(manager);process_ui_generation();}
    }
    if(next_ui_tail)next_ui_tail(manager,delta,method);
    process_frame(nullptr);
}
void bootstrap_impl() {
    const BE_HostApiV1* runtime = nullptr;
    for (int attempt = 0; attempt < 600 && !stop_bootstrap.load(); ++attempt) {
        runtime = host.get_runtime ? host.get_runtime(host.context) : host.runtime;
        if (runtime) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    if (stop_bootstrap.load()) return;
    if (!runtime) { std::lock_guard<std::recursive_mutex> lock(mutex); fail("EML game runtime unavailable. Offline host cannot render the game."); return; }
    using DomainGet = void*(*)(); using Attach = void*(*)(void*); using Detach = void(*)(void*);
    HMODULE game = GetModuleHandleW(L"GameAssembly.dll");
    auto domain = reinterpret_cast<DomainGet>(GetProcAddress(game, "il2cpp_domain_get"));
    auto attach = reinterpret_cast<Attach>(GetProcAddress(game, "il2cpp_thread_attach"));
    auto detach = reinterpret_cast<Detach>(GetProcAddress(game, "il2cpp_thread_detach"));
    if (!domain || !attach || !detach) { std::lock_guard<std::recursive_mutex> lock(mutex); fail("Required IL2CPP thread exports unavailable"); return; }
    void* thread = attach(domain());
    if (!thread) { std::lock_guard<std::recursive_mutex> lock(mutex); fail("IL2CPP thread attachment failed"); return; }
    struct AttachedThread { void* thread; Detach detach; ~AttachedThread(){detach(thread);} } attachment{thread,detach};
    {
        std::lock_guard<std::recursive_mutex> lock(mutex);
        if (!stop_bootstrap.load()) {
            std::string why;
            if (runtime->abi_version != 1 || !runtime->resolve_method || !runtime->create_hook || !runtime->release_module_hooks ||
                !runtime->runtime_invoke || !runtime->object_unbox || !runtime->resolve_class ||
                !runtime->object_new || !runtime->string_new || !runtime->gchandle_new || !runtime->gchandle_free)
                fail("EML runtime ABI/helpers unavailable");
            else {
                // HgCameraAdapter can register hooks before the camera hook.
                // Retain the host even on a later bootstrap failure so shutdown
                // releases every partially installed EML chain node.
                api=runtime;
                if(!unity.resolve(runtime,why))fail(why);
                else {
                BE_MethodDescriptorV1 desc{"Cinemachine.dll", "Cinemachine", "CinemachineBrain",
                    "PushStateToUnityCamera", "Cinemachine.CameraState&", "System.Void", 1};
                BE_ResolvedMethodV1 resolved{};
                if (runtime->resolve_method(runtime->context, &desc, &resolved) != BE_Result_Ok) {
                    desc.parameter_types = "Cinemachine.CameraState";
                    runtime->resolve_method(runtime->context, &desc, &resolved);
                }
                if (!resolved.method_pointer) fail("Cinemachine camera method unavailable; client is unsupported");
                else if (runtime->create_hook(runtime->context, ID, resolved.method_pointer,
                    reinterpret_cast<void*>(camera_tick), reinterpret_cast<void**>(&next_push)) != BE_Result_Ok)
                    fail("EML camera hook registration failed");
                else {
                    api=runtime;hooks_ready=true;state="ready_disabled";
                    ui_ready=ui_observer.resolve(runtime,ui_error);
                    if(ui_ready){
                        BE_MethodDescriptorV1 tail{"Gameplay.Beyond.dll","Beyond.Gameplay.View","CameraManager","TailLateTick",nullptr,"System.Void",1};
                        BE_ResolvedMethodV1 tm{};
                        ui_ready=runtime->resolve_method(runtime->context,&tail,&tm)==BE_Result_Ok && tm.method_pointer &&
                          runtime->create_hook(runtime->context,ID,tm.method_pointer,reinterpret_cast<void*>(ui_tail),reinterpret_cast<void**>(&next_ui_tail))==BE_Result_Ok;
                        if(ui_ready){
                            BE_MethodDescriptorV1 heartbeat{"UnityEngine.CoreModule.dll","UnityEngine","Time","get_unscaledDeltaTime",nullptr,"System.Single",0};
                            BE_ResolvedMethodV1 hm{};
                            clock_hook_ready=runtime->resolve_method(runtime->context,&heartbeat,&hm)==BE_Result_Ok&&hm.method_pointer&&
                              runtime->create_hook(runtime->context,ID,hm.method_pointer,reinterpret_cast<void*>(ui_clock),reinterpret_cast<void**>(&next_ui_clock))==BE_Result_Ok;
                            ui_ready=clock_hook_ready;
                        }
                        if(!ui_ready)ui_error="Menu-independent main-thread clock hook unavailable";
                    }
                }
                }
            }
        }
    }
}
void bootstrap_main() noexcept {
    try { bootstrap_impl(); }
    catch (const std::exception& ex) { std::lock_guard<std::recursive_mutex> lock(mutex); fail(ex.what()); }
    catch (...) { std::lock_guard<std::recursive_mutex> lock(mutex); fail("Unexpected native bootstrap failure"); }
}

BE_Result BE_CALL initialize(const BE_ThirdPartyHostV1* incoming, const char* config) {
    std::lock_guard<std::recursive_mutex> lock(mutex);
    if (live.load()) return BE_Result_Conflict;
    if (restart_required || pending || pending_eyes[0] || pending_eyes[1] || targets || xr_initialized ||
        unity.resources_alive() || hud.resources_alive() || engine_capture.resources_alive() || menu_capture.resources_alive() || menu_overlay.resources_alive() || gpu_probe.resources_alive() || desktop_filter.resources_alive()) return BE_Result_NotReady;
    if (!incoming || incoming->version != 1 || incoming->struct_size < sizeof(BE_ThirdPartyHostV1) || !incoming->reply)
        return BE_Result_ContractMismatch;
    host = *incoming; error.clear();failure_context=json::object();
    // Previous shutdown may leave its completed teardown request latched. All
    // owners were checked above; permit a different quality on reinitialization.
    teardown_pending=recovery_pending=false;requested=false;
    std::string why;
    if (!configure(config, why)) { error = why; return BE_Result_InvalidArgument; }
    flat_transition.reset();unity_thread.store(0);clock_ticks=0;camera_ticks=0;tail_ticks=0;clock_hook_ready=false;menu_placeholder_frames=0;last_diagnostic_log={};last_menu_presentation=json::object();
    requested = false; closing = false; hooks_ready = false; submitted = 0; graphics = 0; readback_ms = 0;
    desktop_install_attempted=false;desktop_mark_error.clear();
    teardown_pending=recovery_pending=false; recovery_reason.clear(); recoveries=source_generation=session_submitted=0;
    last_camera_tick=last_accepted_frame=last_submission=pending_since={};
    pending_swap_eyes = false; hud_capture_ms = 0; hud_resolved = false;
    frame_metrics.reset(); gpu_probe_requested=gpu_probe_cleanup=gpu_probe_resolved=false;
    gpu_probe_state="idle";gpu_probe_error.clear();
    stop_bootstrap.store(false); live.store(true); state = "waiting_game_runtime";
    try { bootstrap = std::thread(bootstrap_main); }
    catch (...) { live.store(false); state = "error"; error = "Could not start module bootstrap thread"; return BE_Result_Failed; }
    return BE_Result_Ok;
}
BE_Result BE_CALL configuration_changed(const char* config) {
    std::lock_guard<std::recursive_mutex> lock(mutex);
    std::string why;
    if (!configure(config, why)) { error = why; return BE_Result_InvalidArgument; }
    return BE_Result_Ok;
}
BE_Result BE_CALL on_message(const char* request_id, const char* body) {
    std::lock_guard<std::recursive_mutex> lock(mutex);
    if (!live.load() || closing) return BE_Result_NotReady;
    BE_Result result = BE_Result_Ok;
    try {
        const auto j = json::parse(body ? body : "{}");
        const auto action = j.value("action", std::string("status"));
        if (action == "start") {
            if (!j.value("first_person_confirmed", false)) {
                error = "Enable the first-person view in example.first-person before starting VR";
                result = BE_Result_InvalidArgument;
            } else if (use_openvr) {
                error="UI routing release requires the existing VD + OpenXR connection";result=BE_Result_NotReady;
            } else if (!paired_guard()) {
                error="Install the matching first-person UI guard package and restart the game";result=BE_Result_NotReady;
            } else if (!hooks_ready || !ui_ready) {
                error = ui_error.empty()?"Game camera / UI observer not ready":ui_error; result = BE_Result_NotReady;
            } else if (use_openvr ? (openvr_loader.empty() || !file_exists(openvr_loader)) : (loader.empty() || !file_exists(loader))) {
                error = use_openvr ? "OpenVR loader DLL not found. Select installed SteamVR bin/win64/openvr_api.dll in settings" :
                    "OpenXR loader DLL not found. Select installed openxr_loader.dll in settings";
                result = BE_Result_NotFound;
            } else if (restart_required) {
                error = "Restart the game to finish previous shutdown"; result = BE_Result_NotReady;
            } else if (!requested) {
                error.clear();failure_context=json::object(); clear_frame_observations(); session_submitted=0;
                hud_blocked = false; hud_error.clear(); requested = true;
                state=teardown_pending ? "start_queued_until_cleanup" : "starting_experimental_backend";
            }
        } else if(action=="learn_gameplay_ui"){
            ui_observer.learn_requested=true;ui_observer.invalidate();
        } else if(action=="menu_mode"){
            ui_observer.force_menu=true;ui_observer.invalidate();
        } else if(action=="auto_mode"){
            ui_observer.force_menu=false;ui_observer.invalidate();
        } else if (action == "stop") {
            requested=false; recovery_pending=false; gpu_probe_requested=false; gpu_probe_cleanup=true;
            queue_teardown({},false);
        }
        else if (action == "diagnose_gpu") {
            if(!hooks_ready || requested || pending || targets || teardown_pending || unity.resources_alive() || xr_initialized || restart_required) {
                gpu_probe_error="Wait for VR to stop and the game camera adapter to be ready";result=BE_Result_NotReady;
            } else { gpu_probe_error.clear();gpu_probe_requested=true;gpu_probe_state="queued_for_game_thread"; }
        } else if(action == "clear_gpu_diagnostic") {
            gpu_probe_requested=false;gpu_probe_cleanup=true;gpu_probe_state="cleanup_queued";
        }
        else if (action == "recenter") { xr.request_recenter(); vk.request_recenter(); ovr.request_recenter(); }
        else if (action != "status") result = BE_Result_InvalidArgument;
    } catch (const std::exception& ex) { error = ex.what(); result = BE_Result_InvalidArgument; }
    log_render_progress();
    auto response = status().dump();
    host.reply(host.context, request_id, result, response.c_str());
    return result;
}
void BE_CALL shutdown() {
    desktop_filter.disable();
    stop_bootstrap.store(true);
    { std::lock_guard<std::recursive_mutex> lock(mutex); requested=false; recovery_pending=false;
      gpu_probe_requested=false;gpu_probe_cleanup=true; closing=true; queue_teardown({},false); }
    if (bootstrap.joinable()) bootstrap.join();
    // Keep hook alive briefly so its game thread can release Unity objects.
    for (int i = 0; i < 100; ++i) {
        { std::lock_guard<std::recursive_mutex> lock(mutex); if (!pending && !targets && !xr_initialized &&
            !xr.frame_pending() && !vk.frame_pending() && !ovr.frame_pending() && !unity.resources_alive() &&
            !hud.resources_alive() && !menu_overlay.resources_alive() && !menu_capture.resources_alive() && !engine_capture.resources_alive() && !window_capture.resources_alive() && !gpu_probe.resources_alive() && !desktop_filter.resources_alive()) break; }
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    // Serialize with a possibly in-flight GL.IssuePluginEvent SDK call.
    std::lock_guard<std::mutex> dispatch_lock(dispatch_mutex);
    std::lock_guard<std::recursive_mutex> lock(mutex);
    live.store(false);
    // A worker cannot supply Unity's render-thread ownership. If the game is
    // paused, retain backend and Unity resources; never force close them here.
    restart_required = restart_required || pending != 0 || pending_eyes[0] || pending_eyes[1] ||
        xr_initialized || xr.frame_pending() || vk.frame_pending() || ovr.frame_pending() || targets || unity.resources_alive() ||
        hud.resources_alive() || menu_overlay.resources_alive() || menu_capture.resources_alive() || engine_capture.resources_alive() || window_capture.resources_alive() || gpu_probe.resources_alive() || desktop_filter.resources_alive();
    if(!desktop_filter.shutdown())restart_required=true;
    if (api && api->release_module_hooks) api->release_module_hooks(api->context, ID);
    clock_hook_ready=false;
    engine_capture.hooks_released();menu_capture.hooks_released();menu_capture_ready=false;ui_ready=false;menu_overlay.reset_bindings();
    hooks_ready = false; state = restart_required ? "restart_required" : "disabled";
    host = {}; api = nullptr;
}
const BE_ThirdPartyModuleV1 module{sizeof(BE_ThirdPartyModuleV1), 1, ID,
    initialize, configuration_changed, on_message, shutdown};
}
extern "C" __declspec(dllexport) const BE_ThirdPartyModuleV1* BE_CALL BetterEndfield_GetThirdPartyModuleV1() {
    return &module;
}
extern "C" void EndfieldVR_SetFirstPersonReadyCallback(bool(*callback)()) {first_person_ready_callback.store(callback);}

extern "C" __declspec(dllexport) unsigned EFVR_QueryFirstPersonGate(){
    std::lock_guard<std::recursive_mutex> lock(mutex);
    if(!live.load())return 0;
    process_ui_generation();
    return vrvd::first_person_ui_gate(true,ui_ready,ui_observer.mode,ui_observer.holds_menu());
}
