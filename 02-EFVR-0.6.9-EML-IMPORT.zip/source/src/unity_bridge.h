#pragma once
#include <BetterEndfield/ThirdPartyModule.h>
#include "hg_projection_hook.h"
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace vrvd {
// OpenXR LOCAL-space pose, in metres. The caller recentres the head height.
struct Eye {
    float position[3];
    float orientation[4]; // x, y, z, w
    float angleLeft, angleRight, angleUp, angleDown; // radians
};

// Cached observations only; reading this from the settings worker calls no Unity API.
struct UnityCameraDiagnostics {
    std::string frame_state="not_checked", hg_status="not_checked", geometry_status="not_checked", error;
    bool source_present=false, targets_valid=false, hg_active=false;
    bool hg_projection_hook=false;
    uint64_t hg_projection_hits=0,hg_non_oblique_hits=0;
    HgProjectionSnapshot hg_routing;
    int source_fullscreen_passthrough=-1;
    uint64_t source_generation=0, targets_generation=0, geometry_checks=0, geometry_failures=0;
};

class UnityBridge {
public:
    UnityBridge();
    ~UnityBridge(); // Does NOT call Unity. Call cleanup() on the game thread first.
    UnityBridge(const UnityBridge&) = delete;
    UnityBridge& operator=(const UnityBridge&) = delete;
    bool resolve(const BE_HostApiV1*, std::string&);
    bool ensure_targets(uint32_t width, uint32_t height, std::string&);
    // Game-thread health check only. Never destroys or recreates resources.
    bool validate_targets(bool& valid, std::string&);
    UnityCameraDiagnostics diagnostics() const;
    // Game-thread cached identity, retained by this bridge until cleanup or the
    // next accepted source. Used only after a successful stereo submission.
    bool accepted_camera_identity(void*& camera,int32_t& frame) const;
    // Returns true with accepted=false for a non-main brain or duplicate frame.
    bool accept_frame(void* brain, bool& accepted, std::string&);
    bool render_eyes(const Eye eyes[2], std::string&);
    // Game-thread compatibility path for Vulkan. Each output is independent,
    // tightly packed RGBA8 linear, width*height*4 bytes, TOP-LEFT row origin.
    // This function flips Unity's bottom-up rows exactly once; the XR upload
    // must not flip them again. Outputs are replaced only after both succeed.
    bool readback_eyes(std::vector<uint8_t> out[2], std::string&);
    bool schedule(void(*callback)(int), int eventId, std::string&);
    void* texture(unsigned eye) const;
    // Game thread: fetch current native resources and QueryInterface immediately.
    // On success the caller owns two ID3D11Texture2D references and must release
    // them only after the corresponding render callback has finished.
    bool retain_d3d_textures(void* out[2], std::string&);
    bool graphics_is_d3d11(std::string&);
    // Reads Unity's actual GraphicsDeviceType: 2=D3D11, 21=Vulkan.
    // Other values are reported to the caller, never coerced into a supported API.
    bool graphics_type(int32_t& type, std::string&);
    // Caller must first drain all render callbacks using texture() pointers.
    // Failed managed cleanup is retained for retry; errors go to the host log.
    void cleanup();
    bool resources_alive() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
} // namespace vrvd
