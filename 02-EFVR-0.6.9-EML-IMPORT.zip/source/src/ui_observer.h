#pragma once
#include "managed_read.h"
#include "ui_route.h"
#include <algorithm>
namespace vrvd {
class UiObserver: private ManagedRead {
 BE_ResolvedMethodV1 controller{},type{},fullName{},find{},length{},item{},active{},name{},id{},level{},world{},frame{},loading{},instanceId{};
 BE_ResolvedFieldV1 systemScene{},loader{};
 BE_ResolvedClassV1 panelClass{},popupClass{};
 Root manager;
 int last_frame=-1;
 bool ready=false;
 bool menu_latched=false;
 void unknown(const std::string& e){
  if(signature!="unknown"){signature="unknown";++generation;}
  signals={};signals.error=e;mode="unknown";last_frame=-1;
 }
public:
 // Process-resident owner: never call IL2CPP from DLL detach/worker destruction.
 ~UiObserver(){manager.abandon();}
 UiSignals signals;
 std::string mode="unknown",signature;
 uint64_t generation=0;
 std::set<std::string> overlays;
 bool force_menu=false,learn_requested=false;
 bool resolve(const BE_HostApiV1* api,std::string& e){
  host=api;if(!api->field_get_value_object||!api->copy_managed_string){e="UI observer helpers missing";return false;}
  auto b=[&](BE_ResolvedMethodV1& m,const char* a,const char* n,const char* c,const char* f,const char* ret,unsigned count=0,const char* args=nullptr){return bind(m,a,n,c,f,args,ret,count,e);};
  BE_FieldDescriptorV1 sd{"Gameplay.Beyond.dll","Beyond.Gameplay.View","CameraManager","isUsingSystemSceneCamera","System.Boolean"};
  BE_FieldDescriptorV1 ld{"Gameplay.Beyond.dll","Beyond.Gameplay.Core","GameLevelLoader","s_loader",nullptr};
  ready=b(controller,"Gameplay.Beyond.dll","Beyond.Gameplay.View","CameraManager","get_curActiveController","Beyond.Gameplay.View.CameraControllerBase") &&
   b(type,"mscorlib.dll","System","Object","GetType","System.Type") && b(fullName,"mscorlib.dll","System","RuntimeType","get_FullName","System.String") &&
   b(find,"UnityEngine.CoreModule.dll","UnityEngine","Object","FindObjectsOfType","UnityEngine.Object[]",1,"System.Type") &&
   b(instanceId,"UnityEngine.CoreModule.dll","UnityEngine","Object","GetInstanceID","System.Int32") &&
   b(length,"mscorlib.dll","System","Array","get_Length","System.Int32") && b(item,"mscorlib.dll","System","Array","GetValue","System.Object",1,"System.Int32") &&
   b(active,"UnityEngine.CoreModule.dll","UnityEngine","Behaviour","get_isActiveAndEnabled","System.Boolean") &&
   b(name,"UI.Beyond.dll","Beyond.UI","LuaPanel","get_panelName","System.String") && b(id,"UI.Beyond.dll","Beyond.UI","LuaPanel","get_panelId","System.Int32") &&
   b(level,"UI.Beyond.dll","Beyond.UI","LuaPanel","get_panelLevel","System.Int32") && b(world,"UI.Beyond.dll","Beyond.UI","LuaPanel","get_IsWorldUI","System.Boolean") &&
   b(frame,"UnityEngine.CoreModule.dll","UnityEngine","Time","get_frameCount","System.Int32") &&
   b(loading,"Gameplay.Beyond.dll","Beyond.Gameplay.Core","GameLevelLoader","get_isLoading","System.Boolean") &&
   api->resolve_field(api->context,&sd,&systemScene)==BE_Result_Ok && api->resolve_field(api->context,&ld,&loader)==BE_Result_Ok &&
   api->resolve_class(api->context,"UI.Beyond.dll","Beyond.UI","LuaPanel",&panelClass)==BE_Result_Ok &&
   api->resolve_class(api->context,"UI.Beyond.dll","Beyond.UI","CSPopupPanel",&popupClass)==BE_Result_Ok;
  if(!ready&&e.empty())e="UI observer field/class contracts unavailable";return ready;
 }
 void set_manager(void* p){if(p!=manager.p){manager.set(host,p);last_frame=-1;}}
 void invalidate(){last_frame=-1;}
 void* manager_object()const{return manager.p;}
 int frame_id()const{return last_frame;}
 bool holds_menu()const{return menu_latched;}
 void refresh(){
  if(!ready||!manager.p){unknown("Waiting for CameraManager / UI contracts");return;}
  std::string e;int f=-1;if(!value(frame,nullptr,f,e)){unknown(e);return;}
  if(f==last_frame)return;last_frame=f;
  UiSignals s;void *c=nullptr,*t=nullptr,*text=nullptr;
  bool camera_ok=invoke(controller,manager.p,nullptr,c,e);
  if(camera_ok&&c){
   camera_ok=invoke(type,c,nullptr,t,e)&&t&&invoke(fullName,t,nullptr,text,e);
   s.controller=string(text);
   if(s.controller.empty()){camera_ok=false;e="Camera controller type could not be read";}
  }
  // A null active controller is normal in the character/system scene.
  // Observe flags and panels independently instead of short-circuiting them.
  bool ok=true;
  void* box=host->field_get_value_object(host->context,systemScene.field_info,manager.p);
  void* data=box?host->object_unbox(host->context,box):nullptr;
  if(!data)ok=false;else s.system_scene=*static_cast<uint8_t*>(data)!=0;
  void* l=host->field_get_value_object(host->context,loader.field_info,nullptr);
  uint8_t isLoading=0;if(!l||!value(loading,l,isLoading,e))ok=false;s.loading=isLoading!=0;
  void* array=nullptr;void* args[]{panelClass.type_object};Root hold;int count=0;
  ok=ok&&invoke(find,nullptr,args,array,e)&&array&&hold.set(host,array)&&value(length,array,count,e)&&count>=0&&count<=4096;
  if(ok)for(int i=0;i<count;++i){
   void* p=nullptr;void* a[]{&i};uint8_t enabled=0,w=0;PanelInfo info;
   if(!invoke(item,array,a,p,e)||!p||!value(active,p,enabled,e)){ok=false;break;}if(!enabled)continue;
   if(!value(instanceId,p,info.instance,e)||!value(id,p,info.id,e)||!value(level,p,info.level,e)||!value(world,p,w,e)||!invoke(name,p,nullptr,text,e)){ok=false;break;}
   info.world=w!=0;info.name=string(text);s.panels.push_back(info);
  }
  if(ok){
   void* popupArgs[]{popupClass.type_object};
   ok=invoke(find,nullptr,popupArgs,array,e)&&array&&hold.set(host,array)&&value(length,array,count,e)&&count>=0&&count<=256;
   if(ok)for(int i=0;i<count;++i){void* p=nullptr;void* a[]{&i};uint8_t enabled=0;PanelInfo info;
    if(!invoke(item,array,a,p,e)||!p||!value(active,p,enabled,e)){ok=false;break;}if(!enabled)continue;
    if(!value(instanceId,p,info.instance,e)){ok=false;break;}info.name="$CSPopupPanel";s.panels.push_back(info);
   }
  }
  std::sort(s.panels.begin(),s.panels.end(),[](const auto& a,const auto& b){return a.instance<b.instance;});
  s.valid=ok&&(camera_ok||s.system_scene||s.loading);
  s.error=s.valid?"":e.empty()?"Incomplete UI/camera observation":e;
  // Explicit user calibration only. Never learn an unknown menu automatically.
  if(learn_requested){
   if(s.valid&&!s.loading&&!s.system_scene&&(s.controller=="Beyond.Gameplay.View.LevelCameraController"||s.controller=="Beyond.Gameplay.View.LevelFreeLookCameraController")) {
    for(const auto& p:s.panels)if(!p.world&&!p.name.empty()&&p.name!="$CSPopupPanel")overlays.insert(p.name);
   }
   else s.error="Calibration requires a ready gameplay controller";
   learn_requested=false;
  }
  auto next=route_ui(s,overlays,force_menu);auto key=ui_signature(s,next);
  if(next=="gameplay"||next=="radial")menu_latched=false;else if(next!="unknown")menu_latched=true;
  if(key!=signature){signature=key;++generation;if(host->log){
   std::string detail="UI transition "+std::to_string(generation)+": "+next+" / "+s.controller+" system="+(s.system_scene?"1":"0")+" panels=";
   for(const auto& p:s.panels)if(!p.name.empty())detail+=p.name+(p.world?"[world]":"[screen]")+",";
   host->log(host->context,"quest3.vrvd",detail.c_str());}}
  signals=std::move(s);mode=next;
 }
};
}
