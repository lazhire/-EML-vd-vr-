#pragma once
#include <memory>
#include <string>
#include "unity_bridge.h"

struct ID3D11Texture2D;

namespace vrvd {

// All calls are externally serialized. initialize/submit/shutdown must execute
// after the caller has drained any Unity rendering callbacks using this object.
// D3D11 copies run exclusively on Unity's rendering thread. begin_frame may run
// on the game thread; no D3D11 immediate-context commands are issued there.
class XrBackend {
public:
    XrBackend();
    ~XrBackend();
    XrBackend(const XrBackend&) = delete;
    XrBackend& operator=(const XrBackend&) = delete;

    bool initialize(ID3D11Texture2D* left, ID3D11Texture2D* right,
                    const wchar_t* loader_path, std::string& error,
                    bool source_linear_hint = false);
    bool begin_frame(Eye eyes[2], bool& shouldRender, std::string& error);
    bool submit(ID3D11Texture2D* left, ID3D11Texture2D* right, std::string& error);
    void cancel_frame();
    void request_recenter();
    bool running() const;
    bool frame_pending() const;
    std::string runtime_name() const;
    void shutdown();

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace vrvd
