#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <unknwn.h>
#include "xr_vulkan.h"
#define XR_USE_PLATFORM_WIN32
#define XR_USE_GRAPHICS_API_VULKAN
#define XR_NO_PROTOTYPES
#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstring>
#include <sstream>

namespace vrvd {
namespace {
using CpuClock=std::chrono::steady_clock;
double elapsed_ms(CpuClock::time_point start) {
    return std::chrono::duration<double,std::milli>(CpuClock::now()-start).count();
}
bool color_format(VkFormat f) {
    return f==VK_FORMAT_R8G8B8A8_UNORM || f==VK_FORMAT_R8G8B8A8_SRGB ||
           f==VK_FORMAT_B8G8R8A8_UNORM || f==VK_FORMAT_B8G8R8A8_SRGB ||
           f==VK_FORMAT_R16G16B16A16_SFLOAT;
}
bool valid_image(const XrVulkanImage& d) {
    return d.image && color_format(d.format) && d.extent.width && d.extent.height &&
        d.extent.depth==1 && d.type==VK_IMAGE_TYPE_2D && d.samples==VK_SAMPLE_COUNT_1_BIT &&
        d.mip_levels==1 && d.array_layers==1 && d.aspect==VK_IMAGE_ASPECT_COLOR_BIT &&
        (d.usage&VK_IMAGE_USAGE_TRANSFER_SRC_BIT) && d.layout==VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
}
bool same_shape(const XrVulkanImage& a,const XrVulkanImage& b) {
    return a.format==b.format && a.extent.width==b.extent.width && a.extent.height==b.extent.height &&
        a.extent.depth==b.extent.depth && a.type==b.type && a.samples==b.samples &&
        a.mip_levels==b.mip_levels && a.array_layers==b.array_layers && a.aspect==b.aspect;
}
std::vector<std::string> words(const char* text) {
    std::istringstream in(text); std::vector<std::string> out; std::string word;
    while(in>>word) out.push_back(word);
    return out;
}
bool contains_all(const std::vector<std::string>& have,const std::vector<std::string>& need,
                  const char* kind,std::string& error) {
    for(const auto& name:need) if(std::find(have.begin(),have.end(),name)==have.end()) {
        error=std::string("Unity Vulkan ")+kind+" was not confirmed created with required extension "+name+". Restart with an early, supported Vulkan initialization bridge.";
        return false;
    }
    return true;
}
uint32_t vk_version(XrVersion version) {
    return VK_MAKE_API_VERSION(0,static_cast<uint32_t>(XR_VERSION_MAJOR(version)),
        static_cast<uint32_t>(XR_VERSION_MINOR(version)),static_cast<uint32_t>(XR_VERSION_PATCH(version)));
}
} // namespace

bool validate_vulkan_hud_frame(const XrVulkanHudFrame& hud,std::string& error) {
    error.clear();
    if(!std::isfinite(hud.content_black_opacity)||hud.content_black_opacity<0||hud.content_black_opacity>1){error="Invalid menu fade opacity";return false;}
    const bool solid=std::isfinite(hud.black_opacity)&&hud.black_opacity>=0.f&&hud.black_opacity<=1.f;
    if((hud.black_opacity!=-1.f&&!solid)||(hud.keep_previous_world&&!solid)||(solid&&(hud.rgba||hud.bytes||hud.backdrop_rgba||hud.backdrop_bytes))){error="Invalid GPU fade mask contract";return false;}
    if((!hud.rgba&&!solid) || !hud.width || !hud.height || hud.width>4096 || hud.height>4096) {
        error="HUD requires non-null RGBA pixels and dimensions within 1..4096.";return false;
    }
    if((hud.backdrop_rgba && (hud.backdrop_bytes!=size_t(MenuBackdropSize)*MenuBackdropSize*4 || hud.width<MenuBackdropGutterSize)) ||
       (!hud.backdrop_rgba && hud.backdrop_bytes)) {error="Invalid menu backdrop RGBA size or atlas width";return false;}
    const uint64_t expected=uint64_t(hud.width)*hud.height*4;
    if(!solid&&hud.bytes!=expected) {
        error="HUD RGBA byte count must equal width*height*4 exactly.";return false;
    }
    const float height_m=hud.width_m*(float(hud.height)/float(hud.width));
    if(!std::isfinite(hud.distance_m)||hud.distance_m<=0 ||
       !std::isfinite(hud.width_m)||hud.width_m<=0 ||
       !std::isfinite(hud.offset_y_m)||!std::isfinite(height_m)||height_m<=0) {
        error="HUD distance and size must be positive finite metres; offset must be finite.";return false;
    }
    return true;
}

struct XrVulkanBackend::Impl {
    bool panel_only=false,reuse_previous_world=false,previous_world_valid=false;
    bool flat_projection_background=false;
    float content_black_opacity=0;bool content_cover=false;
    float hud_black_opacity=-1.f;
    std::array<XrCompositionLayerProjectionView,2> previous_projection{};

    HMODULE loader=nullptr;
    PFN_xrGetInstanceProcAddr get_proc=nullptr;
#define XR_VK_FUNCTIONS(X) \
    X(xrEnumerateInstanceExtensionProperties) X(xrCreateInstance) X(xrDestroyInstance) \
    X(xrGetInstanceProperties) X(xrGetSystem) X(xrGetSystemProperties) \
    X(xrGetVulkanGraphicsRequirementsKHR) X(xrGetVulkanInstanceExtensionsKHR) \
    X(xrGetVulkanDeviceExtensionsKHR) X(xrGetVulkanGraphicsDeviceKHR) \
    X(xrCreateSession) X(xrDestroySession) X(xrBeginSession) X(xrEndSession) \
    X(xrEnumerateViewConfigurationViews) X(xrEnumerateEnvironmentBlendModes) \
    X(xrCreateReferenceSpace) X(xrDestroySpace) X(xrEnumerateSwapchainFormats) \
    X(xrCreateSwapchain) X(xrDestroySwapchain) X(xrEnumerateSwapchainImages) \
    X(xrAcquireSwapchainImage) X(xrWaitSwapchainImage) X(xrReleaseSwapchainImage) \
    X(xrPollEvent) X(xrWaitFrame) X(xrBeginFrame) X(xrEndFrame) X(xrLocateViews) X(xrResultToString)
#define DECLARE_XR(n) PFN_##n n=nullptr;
    XR_VK_FUNCTIONS(DECLARE_XR)
#undef DECLARE_XR
    // Optional read-only extension. Missing functions never block VR startup.
    PFN_xrEnumerateDisplayRefreshRatesFB xrEnumerateDisplayRefreshRatesFB=nullptr;
    PFN_xrGetDisplayRefreshRateFB xrGetDisplayRefreshRateFB=nullptr;
    XrVulkanDiagnostics diag;
#define VK_DEVICE_FUNCTIONS(X) \
    X(vkGetDeviceQueue) X(vkCreateCommandPool) X(vkDestroyCommandPool) \
    X(vkAllocateCommandBuffers) X(vkResetCommandBuffer) X(vkBeginCommandBuffer) X(vkEndCommandBuffer) \
    X(vkCmdPipelineBarrier) X(vkCmdCopyImage) X(vkCreateFence) X(vkDestroyFence) \
    X(vkResetFences) X(vkWaitForFences) X(vkQueueSubmit)
#define DECLARE_VK(n) PFN_##n n=nullptr;
    VK_DEVICE_FUNCTIONS(DECLARE_VK)
#undef DECLARE_VK
    XrInstance instance=XR_NULL_HANDLE;
    XrSystemId system=XR_NULL_SYSTEM_ID;
    XrSession session=XR_NULL_HANDLE;
    XrSpace local=XR_NULL_HANDLE;
    XrSessionState state=XR_SESSION_STATE_UNKNOWN;
    bool active=false, pending=false, begun=false, renderable=false, faulted=false;
    bool recenter=true,origin_set=false;
    bool gpu_pending=false,device_lost=false;
    bool runtime_queue_needs_drain=false, teardown_submitted=false;
    float origin[3]={0,0,0}; float origin_yaw=0;
    std::string name;
    std::string gpu_name;
    XrVulkanRequirements requirements;
    XrVulkanContext context;
    std::array<XrVulkanImage,2> sources{};
    std::array<XrSwapchain,2> chains{XR_NULL_HANDLE,XR_NULL_HANDLE};
    std::array<std::vector<XrSwapchainImageVulkanKHR>,2> images;
    std::array<bool,2> acquired{false,false},waited{false,false};
    std::array<uint32_t,2> image_index{0,0};
    std::array<XrView,2> views{XrView{XR_TYPE_VIEW},XrView{XR_TYPE_VIEW}};
    XrTime display_time=0,reference_change_time=0;
    VkCommandPool pool=VK_NULL_HANDLE;
    VkCommandBuffer command=VK_NULL_HANDLE;
    VkFence fence=VK_NULL_HANDLE;
    // Owned compatibility path: CPU readback uploads, with no foreign-device
    // handles and no assumptions about Unity's opaque native texture pointers.
    bool owned=false, owned_images_ready=false, upload_pending=false, staging_coherent=false;
    HMODULE vulkan_loader=nullptr;
    VkInstance owned_instance=VK_NULL_HANDLE;
    VkDevice owned_device=VK_NULL_HANDLE;
    PFN_vkDestroyInstance vkDestroyInstance=nullptr;
    PFN_vkDestroyDevice vkDestroyDevice=nullptr;
    PFN_vkCreateImage vkCreateImage=nullptr;
    PFN_vkDestroyImage vkDestroyImage=nullptr;
    PFN_vkGetImageMemoryRequirements vkGetImageMemoryRequirements=nullptr;
    PFN_vkAllocateMemory vkAllocateMemory=nullptr;
    PFN_vkFreeMemory vkFreeMemory=nullptr;
    PFN_vkBindImageMemory vkBindImageMemory=nullptr;
    PFN_vkCreateBuffer vkCreateBuffer=nullptr;
    PFN_vkDestroyBuffer vkDestroyBuffer=nullptr;
    PFN_vkGetBufferMemoryRequirements vkGetBufferMemoryRequirements=nullptr;
    PFN_vkBindBufferMemory vkBindBufferMemory=nullptr;
    PFN_vkMapMemory vkMapMemory=nullptr;
    PFN_vkUnmapMemory vkUnmapMemory=nullptr;
    PFN_vkFlushMappedMemoryRanges vkFlushMappedMemoryRanges=nullptr;
    PFN_vkCmdCopyBufferToImage vkCmdCopyBufferToImage=nullptr;
    PFN_vkCmdClearColorImage vkCmdClearColorImage=nullptr;
    std::array<VkImage,2> owned_images{VK_NULL_HANDLE,VK_NULL_HANDLE};
    std::array<VkDeviceMemory,2> owned_memory{VK_NULL_HANDLE,VK_NULL_HANDLE};
    VkBuffer staging=VK_NULL_HANDLE;
    VkDeviceMemory staging_memory=VK_NULL_HANDLE;
    void* staging_map=nullptr;
    size_t eye_bytes=0;
    // HUD has independent source/staging/swapchain storage; never aliases eyes.
    XrSpace hud_view=XR_NULL_HANDLE;
    XrSwapchain hud_chain=XR_NULL_HANDLE;
    std::vector<XrSwapchainImageVulkanKHR> hud_images;
    bool hud_acquired=false,hud_waited=false,hud_ready=false;
    bool hud_image_ready=false,hud_frame=false,hud_coherent=false,hud_backdrop=false;
    uint32_t hud_index=0,hud_width=0,hud_height=0;
    uint32_t max_layers=0,max_swap_width=0,max_swap_height=0;
    size_t hud_bytes=0;
    float hud_distance=1.5f,hud_width_m=1.6f,hud_offset_y=0.f;
    VkImage hud_image=VK_NULL_HANDLE;
    VkDeviceMemory hud_memory=VK_NULL_HANDLE,hud_staging_memory=VK_NULL_HANDLE;
    VkBuffer hud_staging=VK_NULL_HANDLE;
    void* hud_map=nullptr;
    VkPhysicalDeviceMemoryProperties owned_memory_properties{};

    bool ensure_hud(const XrVulkanHudFrame& data,std::string& error) {
        if(!owned || !session || gpu_pending) {error="HUD requires an idle owned Vulkan backend.";return false;}
        if(max_layers<2 || data.width>max_swap_width || uint64_t(data.height)+MenuBackdropRows>max_swap_height) {
            error="HUD exceeds the OpenXR runtime layer count or swapchain dimensions.";return false;
        }
        if(hud_ready) {
            if(hud_width!=data.width || hud_height!=data.height) {
                error="HUD dimensions changed; stop VR and recreate its session before resizing.";return false;
            }
            return true;
        }
        if(hud_view || hud_chain || hud_image || hud_staging) {
            error="Partial HUD initialization requires a complete backend shutdown.";return false;
        }
        hud_width=data.width;hud_height=data.height;hud_bytes=size_t(hud_width)*(hud_height+MenuBackdropRows)*4;
        const auto memory_type=[&](uint32_t bits,VkMemoryPropertyFlags required,VkMemoryPropertyFlags preferred) {
            for(int pass=0;pass<2;++pass)for(uint32_t i=0;i<owned_memory_properties.memoryTypeCount;++i)
                if((bits&(1u<<i)) && (owned_memory_properties.memoryTypes[i].propertyFlags&required)==required &&
                   (pass || (owned_memory_properties.memoryTypes[i].propertyFlags&preferred)==preferred)) return i;
            return UINT32_MAX;
        };
        XrReferenceSpaceCreateInfo space{XR_TYPE_REFERENCE_SPACE_CREATE_INFO};
        space.referenceSpaceType=XR_REFERENCE_SPACE_TYPE_VIEW;space.poseInReferenceSpace.orientation.w=1.f;
        if(!check(xrCreateReferenceSpace(session,&space,&hud_view),"xrCreateReferenceSpace(HUD VIEW)",error))return false;
        XrSwapchainCreateInfo swap{XR_TYPE_SWAPCHAIN_CREATE_INFO};
        swap.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT|XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT;
        swap.format=VK_FORMAT_R8G8B8A8_UNORM;swap.sampleCount=1;
        swap.width=hud_width;swap.height=hud_height+MenuBackdropRows;swap.faceCount=swap.arraySize=swap.mipCount=1;
        if(!check(xrCreateSwapchain(session,&swap,&hud_chain),"xrCreateSwapchain(HUD)",error))return false;
        uint32_t count=0;
        if(!check(xrEnumerateSwapchainImages(hud_chain,0,&count,nullptr),"Count HUD swapchain images",error))return false;
        if(!count){error="OpenXR returned an empty HUD swapchain.";return false;}
        hud_images.resize(count,{XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR});
        if(!check(xrEnumerateSwapchainImages(hud_chain,count,&count,
            reinterpret_cast<XrSwapchainImageBaseHeader*>(hud_images.data())),"Read HUD swapchain images",error))return false;
        for(const auto& image:hud_images)if(!image.image){error="OpenXR returned a null HUD image.";return false;}
        VkImageCreateInfo image{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
        image.imageType=VK_IMAGE_TYPE_2D;image.format=VK_FORMAT_R8G8B8A8_UNORM;
        image.extent={hud_width,hud_height+MenuBackdropRows,1};image.mipLevels=image.arrayLayers=1;
        image.samples=VK_SAMPLE_COUNT_1_BIT;image.tiling=VK_IMAGE_TILING_OPTIMAL;
        image.usage=VK_IMAGE_USAGE_TRANSFER_SRC_BIT|VK_IMAGE_USAGE_TRANSFER_DST_BIT;
        image.sharingMode=VK_SHARING_MODE_EXCLUSIVE;image.initialLayout=VK_IMAGE_LAYOUT_UNDEFINED;
        if(!vkcheck(vkCreateImage(owned_device,&image,nullptr,&hud_image),"vkCreateImage(HUD)",error))return false;
        VkMemoryRequirements req{};vkGetImageMemoryRequirements(owned_device,hud_image,&req);
        uint32_t type=memory_type(req.memoryTypeBits,0,VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        if(type==UINT32_MAX){error="No compatible HUD image memory type.";return false;}
        VkMemoryAllocateInfo alloc{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};alloc.allocationSize=req.size;alloc.memoryTypeIndex=type;
        if(!vkcheck(vkAllocateMemory(owned_device,&alloc,nullptr,&hud_memory),"vkAllocateMemory(HUD)",error) ||
           !vkcheck(vkBindImageMemory(owned_device,hud_image,hud_memory,0),"vkBindImageMemory(HUD)",error))return false;
        VkBufferCreateInfo buffer{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};buffer.size=hud_bytes;
        buffer.usage=VK_BUFFER_USAGE_TRANSFER_SRC_BIT;buffer.sharingMode=VK_SHARING_MODE_EXCLUSIVE;
        if(!vkcheck(vkCreateBuffer(owned_device,&buffer,nullptr,&hud_staging),"vkCreateBuffer(HUD)",error))return false;
        vkGetBufferMemoryRequirements(owned_device,hud_staging,&req);
        type=memory_type(req.memoryTypeBits,VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT,VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        if(type==UINT32_MAX){error="No host-visible HUD staging memory type.";return false;}
        hud_coherent=(owned_memory_properties.memoryTypes[type].propertyFlags&VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)!=0;
        alloc.allocationSize=req.size;alloc.memoryTypeIndex=type;
        if(!vkcheck(vkAllocateMemory(owned_device,&alloc,nullptr,&hud_staging_memory),"vkAllocateMemory(HUD staging)",error) ||
           !vkcheck(vkBindBufferMemory(owned_device,hud_staging,hud_staging_memory,0),"vkBindBufferMemory(HUD)",error) ||
           !vkcheck(vkMapMemory(owned_device,hud_staging_memory,0,VK_WHOLE_SIZE,0,&hud_map),"vkMapMemory(HUD)",error))return false;
        hud_ready=true;return true;
    }

    void stage_hud(const XrVulkanHudFrame& data) {
        content_black_opacity=data.content_black_opacity;content_cover=false;
        hud_black_opacity=data.black_opacity;
        if(hud_black_opacity>=0){hud_backdrop=false;return;}
        std::memcpy(hud_map,data.rgba,data.bytes);
        auto* atlas=static_cast<uint8_t*>(hud_map);
        std::memset(atlas+data.bytes,0,size_t(hud_width)*MenuBackdropRows*4);
        hud_backdrop=data.backdrop_rgba!=nullptr;
        if(content_black_opacity>0){
            // Four-pixel gutter patch, copied with the existing atlas upload.
            // Three layers suffice for black projection + menu + fade cover.
            content_cover=max_layers>=3&&hud_width>=4;
            if(content_cover){
                const auto alpha=uint8_t(std::lround(content_black_opacity*255.f));
                for(unsigned y=0;y<4;++y)for(unsigned x=hud_width-4;x<hud_width;++x)
                    atlas[(size_t(hud_height+y)*hud_width+x)*4+3]=alpha;
            }else{
                // Very low layer cap fallback; opaque black outside the panel.
                const float light=1-content_black_opacity;
                for(size_t i=0;i<data.bytes;i+=4)for(unsigned c=0;c<3;++c)atlas[i+c]=uint8_t(std::lround(atlas[i+c]*light));
                hud_backdrop=false;
            }
        }

        if(hud_backdrop){
            const auto* src=static_cast<const uint8_t*>(data.backdrop_rgba);
            // Duplicate the outer texels into a two-pixel filtering gutter.
            for(unsigned y=0;y<MenuBackdropGutterSize;++y)for(unsigned x=0;x<MenuBackdropGutterSize;++x){
                unsigned sx=std::clamp(int(x)-2,0,int(MenuBackdropSize)-1),sy=std::clamp(int(y)-2,0,int(MenuBackdropSize)-1);
                std::memcpy(atlas+(size_t(hud_height+MenuBackdropGap+y)*hud_width+x)*4,src+(size_t(sy)*MenuBackdropSize+sx)*4,4);
            }
        }
    }

    std::string xr_error(const char* where,XrResult result) const {
        char text[XR_MAX_RESULT_STRING_SIZE]{};
        if(instance&&xrResultToString&&XR_SUCCEEDED(xrResultToString(instance,result,text)))
            return std::string(where)+": "+text;
        return std::string(where)+": XrResult "+std::to_string(static_cast<int>(result));
    }
    template<class F> bool bind(const char* symbol,F& function,XrInstance owner,std::string& error) {
        PFN_xrVoidFunction p=nullptr; XrResult r=get_proc(owner,symbol,&p);
        if(XR_FAILED(r)||!p){error=xr_error(symbol,r);return false;}
        function=reinterpret_cast<F>(p);return true;
    }
    bool check(XrResult r,const char* where,std::string& error) {
        if(XR_FAILED(r)){error=xr_error(where,r);return false;}return true;
    }
    bool vkcheck(VkResult r,const char* where,std::string& error) {
        if(r==VK_ERROR_DEVICE_LOST)device_lost=true;
        if(r!=VK_SUCCESS){error=std::string(where)+": VkResult "+std::to_string(static_cast<int>(r));return false;}
        return true;
    }
    bool complete_gpu(uint64_t timeout,std::string* error=nullptr) {
        if(!gpu_pending)return true;
        const auto start=CpuClock::now();
        VkResult r=vkWaitForFences(context.device,1,&fence,VK_TRUE,timeout);
        diag.gpu_fence_wait_cpu_ms=elapsed_ms(start);diag.gpu_fence_wait_cpu_known=true;
        if(r==VK_TIMEOUT)++diag.fence_timeout_count;
        if(r==VK_SUCCESS||r==VK_ERROR_DEVICE_LOST){gpu_pending=false;if(r==VK_ERROR_DEVICE_LOST)device_lost=true;return true;}
        if(error)*error=r==VK_TIMEOUT?"Vulkan copy is still in flight; resources are retained until GPU completion.":"vkWaitForFences failed: "+std::to_string(static_cast<int>(r));
        return false;
    }
    void read_refresh(bool enumerate) {
        diag.current_display_hz=0.f;diag.current_display_hz_known=false;
        if(!session||!diag.refresh_extension_enabled)return;
        if(enumerate){
            diag.session_refresh_rates.clear();diag.refresh_rates_known=false;
            if(xrEnumerateDisplayRefreshRatesFB){
                uint32_t count=0;
                if(XR_SUCCEEDED(xrEnumerateDisplayRefreshRatesFB(session,0,&count,nullptr))&&count>0&&count<=64){
                    std::array<float,64> rates{};const uint32_t capacity=count;
                    if(XR_SUCCEEDED(xrEnumerateDisplayRefreshRatesFB(session,capacity,&count,rates.data()))&&count>0&&count<=capacity){
                        bool valid=true;for(uint32_t i=0;i<count;++i)valid&=std::isfinite(rates[i])&&rates[i]>0;
                        if(valid){
                            // An optional diagnostic must not turn an allocation
                            // failure into a failure of the rendering path.
                            try {diag.session_refresh_rates.assign(rates.begin(),rates.begin()+count);diag.refresh_rates_known=true;}
                            catch(...) {diag.session_refresh_rates.clear();}
                        }
                    }
                }
            }
        }
        if(xrGetDisplayRefreshRateFB){float hz=0;
            if(XR_SUCCEEDED(xrGetDisplayRefreshRateFB(session,&hz))&&std::isfinite(hz)&&hz>0){
                diag.current_display_hz=hz;diag.current_display_hz_known=true;
            }
        }
    }
    XrResult wait_swapchain(XrSwapchain chain,const XrSwapchainImageWaitInfo& info) {
        const auto start=CpuClock::now();const XrResult r=xrWaitSwapchainImage(chain,&info);
        diag.swapchain_wait_cpu_ms+=elapsed_ms(start);diag.swapchain_wait_cpu_known=true;
        if(r==XR_TIMEOUT_EXPIRED)++diag.swapchain_timeout_count;
        return r;
    }
    XrResult end_frame(const XrFrameEndInfo& info) {
        const auto start=CpuClock::now();const XrResult r=xrEndFrame(session,&info);
        diag.end_frame_cpu_ms=elapsed_ms(start);diag.end_frame_cpu_known=true;
        if(XR_SUCCEEDED(r)){if(info.layerCount)++diag.submitted_frames;else ++diag.cancelled_frames;}
        return r;
    }
    bool begin_on_queue(std::string* error=nullptr) {
        if(!pending||begun)return true;
        XrFrameBeginInfo info{XR_TYPE_FRAME_BEGIN_INFO};
        XrResult r=xrBeginFrame(session,&info);
        if(XR_FAILED(r)){faulted=true;pending=false;if(error)*error=xr_error("xrBeginFrame",r);return false;}
        begun=true;return true;
    }
    bool finish_empty(std::string* error=nullptr) {
        if(!pending)return true;
        if(!complete_gpu(100'000'000,error))return false;
        if(!begin_on_queue(error))return false;
        XrFrameEndInfo end{XR_TYPE_FRAME_END_INFO};end.displayTime=display_time;
        end.environmentBlendMode=XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
        XrResult r=end_frame(end);pending=begun=renderable=hud_frame=false;
        if(XR_FAILED(r)){faulted=true;if(error)*error=xr_error("xrEndFrame(empty)",r);return false;}return true;
    }
    void return_images() {
        if(gpu_pending)return; // Never release a swapchain image still touched by our GPU copy.
        for(size_t eye=0;eye<2;++eye){
            if(!acquired[eye]||!chains[eye])continue;
            if(!waited[eye]){XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};wait.timeout=0;
                XrResult r=xrWaitSwapchainImage(chains[eye],&wait);waited[eye]=XR_SUCCEEDED(r)&&r!=XR_TIMEOUT_EXPIRED;}
            if(waited[eye]){XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
                if(XR_SUCCEEDED(xrReleaseSwapchainImage(chains[eye],&release))){acquired[eye]=waited[eye]=false;}}
        }
        if(hud_acquired&&hud_chain){
            if(!hud_waited){XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};wait.timeout=0;
                XrResult r=xrWaitSwapchainImage(hud_chain,&wait);hud_waited=XR_SUCCEEDED(r)&&r!=XR_TIMEOUT_EXPIRED;}
            if(hud_waited){XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
                if(XR_SUCCEEDED(xrReleaseSwapchainImage(hud_chain,&release)))hud_acquired=hud_waited=false;}
        }
    }
    bool close() {
        // Never use vkDeviceWaitIdle on a game-owned device. It can wait for
        // unrelated work indefinitely. A timeout retains all owned resources.
        if(!complete_gpu(500'000'000))return false;
        if(session){
            return_images();finish_empty();
            if(active&&state==XR_SESSION_STATE_STOPPING&&xrEndSession)xrEndSession(session);
            // DestroySession also destroys its spaces/swapchains. Do not free
            // the device if the runtime failed to release its session ownership.
            if(!xrDestroySession||XR_FAILED(xrDestroySession(session))){faulted=true;return false;}
            session=XR_NULL_HANDLE;local=XR_NULL_HANDLE;
            diag.session_created=false;diag.session_refresh_rates.clear();diag.refresh_rates_known=false;
            diag.current_display_hz=0.f;diag.current_display_hz_known=false;
            diag.predicted_period_ns=0;diag.predicted_period_known=false;
            for(auto& view:diag.views)view.actual_width=view.actual_height=0;
            for(size_t e=0;e<2;++e){chains[e]=XR_NULL_HANDLE;images[e].clear();acquired[e]=waited[e]=false;}
            hud_view=XR_NULL_HANDLE;hud_chain=XR_NULL_HANDLE;hud_images.clear();hud_acquired=hud_waited=false;
            active=pending=begun=renderable=false;
        }
        if(owned&&runtime_queue_needs_drain&&!device_lost){
            // Our copy fence precedes xrEndFrame. The runtime may enqueue more
            // work there, so signal a separate queue-tail operation after it has
            // released its session. Preserve this phase across bounded retries.
            if(!teardown_submitted){
                if(!fence){VkFenceCreateInfo create{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
                    if(!vkCreateFence||vkCreateFence(context.device,&create,nullptr,&fence)!=VK_SUCCESS)return false;}
                if(vkResetFences(context.device,1,&fence)!=VK_SUCCESS)return false;
                VkSubmitInfo tail{VK_STRUCTURE_TYPE_SUBMIT_INFO};
                VkResult r=vkQueueSubmit(context.queue,1,&tail,fence);
                if(r==VK_ERROR_DEVICE_LOST)device_lost=true;
                else if(r!=VK_SUCCESS)return false;
                else {gpu_pending=true;teardown_submitted=true;}
            }
            if(!complete_gpu(500'000'000))return false;
            runtime_queue_needs_drain=teardown_submitted=false;
        }
        if(instance){
            // A failed runtime teardown retains the loader and all owned Vulkan
            // objects, allowing a later explicit shutdown retry.
            if(!xrDestroyInstance||XR_FAILED(xrDestroyInstance(instance))){faulted=true;return false;}
            instance=XR_NULL_HANDLE;
        }
        if(fence&&vkDestroyFence)vkDestroyFence(context.device,fence,nullptr);fence=VK_NULL_HANDLE;
        if(pool&&vkDestroyCommandPool)vkDestroyCommandPool(context.device,pool,nullptr);pool=VK_NULL_HANDLE;command=VK_NULL_HANDLE;
        if(owned_device){
            if(hud_map&&vkUnmapMemory)vkUnmapMemory(owned_device,hud_staging_memory);hud_map=nullptr;
            if(hud_staging&&vkDestroyBuffer)vkDestroyBuffer(owned_device,hud_staging,nullptr);hud_staging=VK_NULL_HANDLE;
            if(hud_staging_memory&&vkFreeMemory)vkFreeMemory(owned_device,hud_staging_memory,nullptr);hud_staging_memory=VK_NULL_HANDLE;
            if(hud_image&&vkDestroyImage)vkDestroyImage(owned_device,hud_image,nullptr);hud_image=VK_NULL_HANDLE;
            if(hud_memory&&vkFreeMemory)vkFreeMemory(owned_device,hud_memory,nullptr);hud_memory=VK_NULL_HANDLE;
            if(staging_map&&vkUnmapMemory)vkUnmapMemory(owned_device,staging_memory);staging_map=nullptr;
            if(staging&&vkDestroyBuffer)vkDestroyBuffer(owned_device,staging,nullptr);staging=VK_NULL_HANDLE;
            if(staging_memory&&vkFreeMemory)vkFreeMemory(owned_device,staging_memory,nullptr);staging_memory=VK_NULL_HANDLE;
            for(size_t e=0;e<2;++e){
                if(owned_images[e]&&vkDestroyImage)vkDestroyImage(owned_device,owned_images[e],nullptr);owned_images[e]=VK_NULL_HANDLE;
                if(owned_memory[e]&&vkFreeMemory)vkFreeMemory(owned_device,owned_memory[e],nullptr);owned_memory[e]=VK_NULL_HANDLE;
            }
            if(vkDestroyDevice)vkDestroyDevice(owned_device,nullptr);owned_device=VK_NULL_HANDLE;
        }
        if(owned_instance&&vkDestroyInstance)vkDestroyInstance(owned_instance,nullptr);owned_instance=VK_NULL_HANDLE;
        if(vulkan_loader)FreeLibrary(vulkan_loader);vulkan_loader=nullptr;
        if(loader)FreeLibrary(loader);loader=nullptr;get_proc=nullptr;
#define RESET_XR(n) n=nullptr;
        XR_VK_FUNCTIONS(RESET_XR)
#undef RESET_XR
        xrEnumerateDisplayRefreshRatesFB=nullptr;xrGetDisplayRefreshRateFB=nullptr;diag={};
#define RESET_VK(n) n=nullptr;
        VK_DEVICE_FUNCTIONS(RESET_VK)
#undef RESET_VK
        context={};requirements={};system=XR_NULL_SYSTEM_ID;
        active=pending=begun=renderable=faulted=device_lost=false;
        panel_only=reuse_previous_world=previous_world_valid=false;previous_projection={};hud_black_opacity=-1;vkCmdClearColorImage=nullptr;
        owned=owned_images_ready=upload_pending=staging_coherent=false;eye_bytes=0;
        hud_ready=hud_image_ready=hud_frame=hud_coherent=hud_backdrop=false;
        hud_width=hud_height=hud_index=0;hud_bytes=0;owned_memory_properties={};
        max_layers=max_swap_width=max_swap_height=0;
        runtime_queue_needs_drain=teardown_submitted=false;
        state=XR_SESSION_STATE_UNKNOWN;origin_set=false;recenter=true;reference_change_time=0;name.clear();
        gpu_name.clear();
        return true;
    }
    bool poll(std::string& error) {
        for (;;) {
            XrEventDataBuffer buffer{XR_TYPE_EVENT_DATA_BUFFER};
            const XrResult result = xrPollEvent(instance, &buffer);
            if (result == XR_EVENT_UNAVAILABLE) return true;
            if (!check(result, "xrPollEvent", error)) return false;
            if (buffer.type == XR_TYPE_EVENT_DATA_INSTANCE_LOSS_PENDING) {
                active = false; faulted = true;
                error = "OpenXR instance loss pending; stop and reconnect the module.";
                return false;
            }
            if (buffer.type == XR_TYPE_EVENT_DATA_REFERENCE_SPACE_CHANGE_PENDING) {
                auto* change = reinterpret_cast<const XrEventDataReferenceSpaceChangePending*>(&buffer);
                if (change->session == session && change->referenceSpaceType == XR_REFERENCE_SPACE_TYPE_LOCAL)
                    reference_change_time = change->changeTime;
                continue;
            }
            if(buffer.type==XR_TYPE_EVENT_DATA_DISPLAY_REFRESH_RATE_CHANGED_FB){
                read_refresh(false);continue;
            }
            if (buffer.type != XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED) continue;
            auto* event = reinterpret_cast<const XrEventDataSessionStateChanged*>(&buffer);
            if (event->session != session) continue;
            state = event->state;
            if (state == XR_SESSION_STATE_READY && !active) {
                XrSessionBeginInfo begin{XR_TYPE_SESSION_BEGIN_INFO};
                begin.primaryViewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
                if (!check(xrBeginSession(session, &begin), "xrBeginSession", error)) return false;
                active = true;
                recenter = true;
            } else if (state == XR_SESSION_STATE_STOPPING) {
                if (pending) { error="Cannot end Vulkan XR session while a frame still awaits queue completion."; return false; }
                if (active && !check(xrEndSession(session), "xrEndSession", error)) return false;
                active = false;previous_world_valid=false;
            } else if (state == XR_SESSION_STATE_EXITING || state == XR_SESSION_STATE_LOSS_PENDING) {
                active = false; faulted = true;
                error = "OpenXR session exited or was lost; stop and reconnect the module.";
                return false;
            }
        }
    }

    void recentered_eyes(Eye out[2]) {
        if (recenter || !origin_set) {
            origin[0] = (views[0].pose.position.x + views[1].pose.position.x) * 0.5f;
            origin[1] = (views[0].pose.position.y + views[1].pose.position.y) * 0.5f;
            origin[2] = (views[0].pose.position.z + views[1].pose.position.z) * 0.5f;
            XrQuaternionf q = views[0].pose.orientation;
            const XrQuaternionf r = views[1].pose.orientation;
            const float sign = q.x*r.x + q.y*r.y + q.z*r.z + q.w*r.w < 0 ? -1.f : 1.f;
            q.x += sign*r.x; q.y += sign*r.y; q.z += sign*r.z; q.w += sign*r.w;
            const float norm = std::sqrt(q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w);
            if (norm > 1e-6f) { q.x/=norm; q.y/=norm; q.z/=norm; q.w/=norm; }
            origin_yaw = std::atan2(2.f*(q.x*q.z+q.w*q.y), 1.f-2.f*(q.x*q.x+q.y*q.y));
            recenter = false; origin_set = true;
        }
        const float cy = std::cos(origin_yaw), sy = std::sin(origin_yaw);
        const float half_c = std::cos(-origin_yaw*0.5f), half_s = std::sin(-origin_yaw*0.5f);
        for (size_t eye=0; eye<2; ++eye) {
            const auto& pose = views[eye].pose;
            const float x=pose.position.x-origin[0], y=pose.position.y-origin[1], z=pose.position.z-origin[2];
            out[eye].position[0] = cy*x-sy*z;
            out[eye].position[1] = y;
            out[eye].position[2] = sy*x+cy*z;
            const auto& q = pose.orientation;
            // inverse-origin-yaw * original-eye-orientation, xyzw.
            out[eye].orientation[0] = half_c*q.x + half_s*q.z;
            out[eye].orientation[1] = half_c*q.y + half_s*q.w;
            out[eye].orientation[2] = half_c*q.z - half_s*q.x;
            out[eye].orientation[3] = half_c*q.w - half_s*q.y;
            out[eye].angleLeft = views[eye].fov.angleLeft;
            out[eye].angleRight = views[eye].fov.angleRight;
            out[eye].angleUp = views[eye].fov.angleUp;
            out[eye].angleDown = views[eye].fov.angleDown;
        }
    }
};

XrVulkanBackend::XrVulkanBackend():impl_(new Impl){}
XrVulkanBackend::~XrVulkanBackend(){
    // A dead/stalled GPU must not cause destruction of in-flight resources.
    // Normal owners call shutdown explicitly and retain the backend on false.
    if(impl_&&!impl_->close())(void)impl_.release();
}

bool XrVulkanBackend::prepare(const wchar_t* loader_path,std::string& error) {
    auto& p=*impl_;error.clear();
    if(!p.close()){error="Previous Vulkan GPU submission still owns backend resources; retry shutdown before initialization.";return false;}
    const auto fail=[&](const std::string& why){error=why;p.close();return false;};
    if(!loader_path||!*loader_path||!(loader_path[0]==L'\\'||(wcslen(loader_path)>2&&loader_path[1]==L':'&&(loader_path[2]==L'\\'||loader_path[2]==L'/'))))
        return fail("An absolute path to an installed OpenXR loader is required.");
    p.loader=LoadLibraryExW(loader_path,nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    if(!p.loader)return fail("OpenXR loader could not be loaded; Windows error "+std::to_string(GetLastError()));
    p.get_proc=reinterpret_cast<PFN_xrGetInstanceProcAddr>(GetProcAddress(p.loader,"xrGetInstanceProcAddr"));
    if(!p.get_proc)return fail("The selected DLL does not export xrGetInstanceProcAddr.");
    if(!p.bind("xrEnumerateInstanceExtensionProperties",p.xrEnumerateInstanceExtensionProperties,XR_NULL_HANDLE,error)||
       !p.bind("xrCreateInstance",p.xrCreateInstance,XR_NULL_HANDLE,error))return fail(error);
    uint32_t count=0;
    if(!p.check(p.xrEnumerateInstanceExtensionProperties(nullptr,0,&count,nullptr),"Enumerate OpenXR extensions",error))return fail(error);
    std::vector<XrExtensionProperties> extensions(count,{XR_TYPE_EXTENSION_PROPERTIES});
    if(!p.check(p.xrEnumerateInstanceExtensionProperties(nullptr,count,&count,extensions.data()),"Read OpenXR extensions",error))return fail(error);
    if(std::none_of(extensions.begin(),extensions.end(),[](const auto& e){return std::strcmp(e.extensionName,XR_KHR_VULKAN_ENABLE_EXTENSION_NAME)==0;}))
        return fail("The active OpenXR runtime does not expose XR_KHR_vulkan_enable. This backend cannot bind Vulkan through a D3D-only runtime.");
    p.diag.refresh_extension_available=std::any_of(extensions.begin(),extensions.end(),[](const auto& e){
        return std::strcmp(e.extensionName,XR_FB_DISPLAY_REFRESH_RATE_EXTENSION_NAME)==0;
    });
    const char* enabled[]={XR_KHR_VULKAN_ENABLE_EXTENSION_NAME,XR_FB_DISPLAY_REFRESH_RATE_EXTENSION_NAME};
    XrInstanceCreateInfo create{XR_TYPE_INSTANCE_CREATE_INFO};
    std::strcpy(create.applicationInfo.applicationName,"Endfield VRVD Vulkan Experimental");
    std::strcpy(create.applicationInfo.engineName,"EML Stereo Bridge");
    create.applicationInfo.applicationVersion=1;create.applicationInfo.engineVersion=1;
    create.applicationInfo.apiVersion=XR_MAKE_VERSION(1,0,0);
    create.enabledExtensionCount=p.diag.refresh_extension_available?2u:1u;create.enabledExtensionNames=enabled;
    XrResult created=p.xrCreateInstance(&create,&p.instance);
    // An optional extension advertised inconsistently must not remove the
    // previously working Vulkan-only startup path.
    if(created==XR_ERROR_EXTENSION_NOT_PRESENT&&create.enabledExtensionCount==2&&p.instance==XR_NULL_HANDLE){
        create.enabledExtensionCount=1;created=p.xrCreateInstance(&create,&p.instance);
    }
    if(!p.check(created,"xrCreateInstance",error))return fail(error);
    p.diag.refresh_extension_enabled=create.enabledExtensionCount==2;
    if(!p.bind("xrDestroyInstance",p.xrDestroyInstance,p.instance,error))return fail(error);
#define BIND_XR(n) if(!p.bind(#n,p.n,p.instance,error))return fail(error);
    XR_VK_FUNCTIONS(BIND_XR)
#undef BIND_XR
    if(p.diag.refresh_extension_enabled){
        PFN_xrVoidFunction function=nullptr;
        if(XR_SUCCEEDED(p.get_proc(p.instance,"xrEnumerateDisplayRefreshRatesFB",&function))&&function)
            p.xrEnumerateDisplayRefreshRatesFB=reinterpret_cast<PFN_xrEnumerateDisplayRefreshRatesFB>(function);
        function=nullptr;
        if(XR_SUCCEEDED(p.get_proc(p.instance,"xrGetDisplayRefreshRateFB",&function))&&function)
            p.xrGetDisplayRefreshRateFB=reinterpret_cast<PFN_xrGetDisplayRefreshRateFB>(function);
        p.diag.refresh_functions_available=p.xrEnumerateDisplayRefreshRatesFB&&p.xrGetDisplayRefreshRateFB;
    }
    XrInstanceProperties properties{XR_TYPE_INSTANCE_PROPERTIES};
    if(!p.check(p.xrGetInstanceProperties(p.instance,&properties),"xrGetInstanceProperties",error))return fail(error);
    p.name=properties.runtimeName;
    XrSystemGetInfo sys{XR_TYPE_SYSTEM_GET_INFO};sys.formFactor=XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
    const XrResult result=p.xrGetSystem(p.instance,&sys,&p.system);
    if(result==XR_ERROR_FORM_FACTOR_UNAVAILABLE)return fail("No available VR headset. Connect Quest 3 through Virtual Desktop, then retry.");
    if(!p.check(result,"xrGetSystem",error))return fail(error);
    XrSystemProperties system_properties{XR_TYPE_SYSTEM_PROPERTIES};
    if(!p.check(p.xrGetSystemProperties(p.instance,p.system,&system_properties),"xrGetSystemProperties",error))return fail(error);
    p.max_layers=system_properties.graphicsProperties.maxLayerCount;
    p.max_swap_width=system_properties.graphicsProperties.maxSwapchainImageWidth;
    p.max_swap_height=system_properties.graphicsProperties.maxSwapchainImageHeight;
    if(!system_properties.trackingProperties.orientationTracking||!system_properties.trackingProperties.positionTracking)
        return fail("This backend requires orientation and position tracking (6DoF).");
    XrGraphicsRequirementsVulkanKHR req{XR_TYPE_GRAPHICS_REQUIREMENTS_VULKAN_KHR};
    if(!p.check(p.xrGetVulkanGraphicsRequirementsKHR(p.instance,p.system,&req),"xrGetVulkanGraphicsRequirementsKHR",error))return fail(error);
    p.requirements.min_api_version=vk_version(req.minApiVersionSupported);
    p.requirements.max_api_version=vk_version(req.maxApiVersionSupported);
    for(int kind=0;kind<2;++kind){
        auto function=kind?p.xrGetVulkanDeviceExtensionsKHR:p.xrGetVulkanInstanceExtensionsKHR;
        count=0;if(!p.check(function(p.instance,p.system,0,&count,nullptr),"Query required Vulkan extensions",error))return fail(error);
        std::vector<char> buffer(count?count:1,0);
        if(count&&!p.check(function(p.instance,p.system,count,&count,buffer.data()),"Read required Vulkan extensions",error))return fail(error);
        if(buffer.back()!=0)return fail("OpenXR returned an unterminated Vulkan extension list.");
        (kind?p.requirements.device_extensions:p.requirements.instance_extensions)=words(buffer.data());
    }
    return true;
}

const XrVulkanRequirements& XrVulkanBackend::requirements()const{return impl_->requirements;}
bool XrVulkanBackend::graphics_device(VkInstance instance,VkPhysicalDevice& device,std::string& error){
    auto& p=*impl_;error.clear();device=VK_NULL_HANDLE;
    if(!p.instance||!p.system||!instance){error="Prepare OpenXR and create a matching Vulkan instance before querying its GPU.";return false;}
    return p.check(p.xrGetVulkanGraphicsDeviceKHR(p.instance,p.system,instance,&device),"xrGetVulkanGraphicsDeviceKHR",error)&&device;
}

bool XrVulkanBackend::initialize(const XrVulkanContext& context,const XrVulkanImage eyes[2],std::string& error){
    auto& p=*impl_;error.clear();
    const auto fail=[&](const std::string& why){error=why;p.close();return false;};
    if(!p.instance||!p.system)return fail("Call prepare before initializing the Vulkan graphics session.");
    if(p.session)return fail("Vulkan graphics session is already initialized; shutdown before reinitializing.");
    if(!eyes||!valid_image(eyes[0])||!valid_image(eyes[1])||eyes[0].image==eyes[1].image)
        return fail("Two independent single-mip single-sample 2D color images with TRANSFER_SRC usage and TRANSFER_SRC_OPTIMAL layout are required.");
    if(!context.instance||!context.physical_device||!context.device||!context.queue||!context.get_instance_proc_addr)
        return fail("Incomplete Vulkan graphics context. Unity native texture pointers are not Vulkan image handles.");
    if(!context.api_version)return fail("The Vulkan instance creation API version is unknown; GPU supported version is not proof of the instance's enabled version.");
    if(context.api_version<p.requirements.min_api_version||context.api_version>p.requirements.max_api_version)
        return fail("The Vulkan instance API version is outside the active OpenXR runtime's allowed range.");
    if(!context.extension_lists_known&&(!p.requirements.instance_extensions.empty()||!p.requirements.device_extensions.empty()))
        return fail("The Vulkan instance/device enabled extension lists were not captured at creation. Runtime requirements cannot safely be verified from supported-extension lists.");
    if(!contains_all(context.enabled_instance_extensions,p.requirements.instance_extensions,"instance",error)||
       !contains_all(context.enabled_device_extensions,p.requirements.device_extensions,"device",error))return fail(error);
    VkPhysicalDevice expected=VK_NULL_HANDLE;
    if(!graphics_device(context.instance,expected,error))return fail(error);
    if(expected!=context.physical_device)return fail("The supplied Vulkan GPU is not the physical device selected by the active OpenXR runtime.");
    p.context=context;p.sources={eyes[0],eyes[1]};
    const auto get_device=reinterpret_cast<PFN_vkGetDeviceProcAddr>(context.get_instance_proc_addr(context.instance,"vkGetDeviceProcAddr"));
    const auto properties=reinterpret_cast<PFN_vkGetPhysicalDeviceProperties>(context.get_instance_proc_addr(context.instance,"vkGetPhysicalDeviceProperties"));
    const auto families=reinterpret_cast<PFN_vkGetPhysicalDeviceQueueFamilyProperties>(context.get_instance_proc_addr(context.instance,"vkGetPhysicalDeviceQueueFamilyProperties"));
    if(!get_device||!properties||!families)return fail("Vulkan loader cannot resolve required device-query functions.");
    VkPhysicalDeviceProperties gpu{};properties(context.physical_device,&gpu);
    p.gpu_name=gpu.deviceName;
    if(gpu.apiVersion<context.api_version)return fail("The Vulkan physical device API version is below the selected instance version.");
    uint32_t count=0;families(context.physical_device,&count,nullptr);std::vector<VkQueueFamilyProperties> queues(count);families(context.physical_device,&count,queues.data());
    if(context.queue_family>=count||!(queues[context.queue_family].queueFlags&VK_QUEUE_GRAPHICS_BIT)||context.queue_index>=queues[context.queue_family].queueCount)
        return fail("A valid Vulkan graphics queue family/index is required.");
#define BIND_VK(n) p.n=reinterpret_cast<PFN_##n>(get_device(context.device,#n));if(!p.n)return fail("Missing Vulkan device function: " #n);
    VK_DEVICE_FUNCTIONS(BIND_VK)
#undef BIND_VK
    VkQueue expected_queue=VK_NULL_HANDLE;p.vkGetDeviceQueue(context.device,context.queue_family,context.queue_index,&expected_queue);
    if(expected_queue!=context.queue)return fail("The supplied Vulkan queue does not match its device/family/index.");
    count=0;
    if(!p.check(p.xrEnumerateViewConfigurationViews(p.instance,p.system,XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,0,&count,nullptr),"Enumerate stereo views",error))return fail(error);
    if(count!=2)return fail("The runtime must expose exactly two primary stereo views.");
    std::array<XrViewConfigurationView,2> caps{XrViewConfigurationView{XR_TYPE_VIEW_CONFIGURATION_VIEW},XrViewConfigurationView{XR_TYPE_VIEW_CONFIGURATION_VIEW}};
    if(!p.check(p.xrEnumerateViewConfigurationViews(p.instance,p.system,XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,2,&count,caps.data()),"Read stereo view limits",error))return fail(error);
    if(count!=2)return fail("The runtime changed the primary stereo view count.");
    for(size_t e=0;e<2;++e){
        auto& view=p.diag.views[e];view.recommended_width=caps[e].recommendedImageRectWidth;
        view.recommended_height=caps[e].recommendedImageRectHeight;view.max_width=caps[e].maxImageRectWidth;
        view.max_height=caps[e].maxImageRectHeight;view.recommended_samples=caps[e].recommendedSwapchainSampleCount;
        view.max_samples=caps[e].maxSwapchainSampleCount;
    }
    p.diag.view_caps_known=true;
    for(size_t e=0;e<2;++e)if(eyes[e].extent.width>caps[e].maxImageRectWidth||eyes[e].extent.height>caps[e].maxImageRectHeight)return fail("Eye texture exceeds OpenXR view limits.");
    if(!p.check(p.xrEnumerateEnvironmentBlendModes(p.instance,p.system,XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,0,&count,nullptr),"Enumerate blend modes",error))return fail(error);
    std::vector<XrEnvironmentBlendMode> blends(count);
    if(!p.check(p.xrEnumerateEnvironmentBlendModes(p.instance,p.system,XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,count,&count,blends.data()),"Read blend modes",error))return fail(error);
    if(std::find(blends.begin(),blends.end(),XR_ENVIRONMENT_BLEND_MODE_OPAQUE)==blends.end())return fail("An opaque immersive OpenXR session is required.");
    XrGraphicsBindingVulkanKHR binding{XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR};
    binding.instance=context.instance;binding.physicalDevice=context.physical_device;binding.device=context.device;
    binding.queueFamilyIndex=context.queue_family;binding.queueIndex=context.queue_index;
    XrSessionCreateInfo session{XR_TYPE_SESSION_CREATE_INFO};session.next=&binding;session.systemId=p.system;
    p.runtime_queue_needs_drain=p.owned;
    if(!p.check(p.xrCreateSession(p.instance,&session,&p.session),"xrCreateSession(Vulkan)",error))return fail(error);
    p.diag.session_created=true;p.read_refresh(true);
    XrReferenceSpaceCreateInfo space{XR_TYPE_REFERENCE_SPACE_CREATE_INFO};space.referenceSpaceType=XR_REFERENCE_SPACE_TYPE_LOCAL;space.poseInReferenceSpace.orientation.w=1.f;
    if(!p.check(p.xrCreateReferenceSpace(p.session,&space,&p.local),"xrCreateReferenceSpace",error))return fail(error);
    count=0;if(!p.check(p.xrEnumerateSwapchainFormats(p.session,0,&count,nullptr),"Enumerate formats",error))return fail(error);
    std::vector<int64_t> formats(count);if(!p.check(p.xrEnumerateSwapchainFormats(p.session,count,&count,formats.data()),"Read formats",error))return fail(error);
    for(size_t e=0;e<2;++e){
        const auto& source=eyes[e];
        if(std::find(formats.begin(),formats.end(),static_cast<int64_t>(source.format))==formats.end())return fail("OpenXR does not support the exact eye image format. No implicit linear/sRGB or RGBA/BGRA conversion is performed.");
        XrSwapchainCreateInfo swap{XR_TYPE_SWAPCHAIN_CREATE_INFO};swap.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT|XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT;
        swap.format=source.format;swap.sampleCount=1;swap.width=source.extent.width;swap.height=source.extent.height;swap.faceCount=swap.arraySize=swap.mipCount=1;
        if(!p.check(p.xrCreateSwapchain(p.session,&swap,&p.chains[e]),"xrCreateSwapchain(Vulkan)",error))return fail(error);
        count=0;if(!p.check(p.xrEnumerateSwapchainImages(p.chains[e],0,&count,nullptr),"Count Vulkan swapchain images",error))return fail(error);
        if(!count)return fail("OpenXR returned an empty Vulkan swapchain.");
        p.images[e].resize(count,{XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR});
        if(!p.check(p.xrEnumerateSwapchainImages(p.chains[e],count,&count,reinterpret_cast<XrSwapchainImageBaseHeader*>(p.images[e].data())),"Read Vulkan swapchain images",error))return fail(error);
        for(const auto& im:p.images[e])if(!im.image)return fail("OpenXR returned a null Vulkan image.");
    }
    VkCommandPoolCreateInfo pool{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};pool.queueFamilyIndex=context.queue_family;pool.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    if(!p.vkcheck(p.vkCreateCommandPool(context.device,&pool,nullptr,&p.pool),"vkCreateCommandPool",error))return fail(error);
    VkCommandBufferAllocateInfo allocate{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};allocate.commandPool=p.pool;allocate.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;allocate.commandBufferCount=1;
    if(!p.vkcheck(p.vkAllocateCommandBuffers(context.device,&allocate,&p.command),"vkAllocateCommandBuffers",error))return fail(error);
    VkFenceCreateInfo fence{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    if(!p.vkcheck(p.vkCreateFence(context.device,&fence,nullptr,&p.fence),"vkCreateFence",error))return fail(error);
    for(size_t e=0;e<2;++e){p.diag.views[e].actual_width=eyes[e].extent.width;p.diag.views[e].actual_height=eyes[e].extent.height;}
    return true;
}

bool XrVulkanBackend::initialize_owned(const wchar_t* loader_path,uint32_t width,uint32_t height,std::string& error){
    if(!prepare(loader_path,error))return false;
    auto& p=*impl_;
    const auto fail=[&](const std::string& why){error=why;p.close();return false;};
    if(!width||!height||width>8192||height>8192)return fail("Owned Vulkan eye dimensions must be within 1..8192.");
    p.vulkan_loader=LoadLibraryExW(L"vulkan-1.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
    if(!p.vulkan_loader)return fail("System Vulkan loader is unavailable. Install the GPU vendor's Vulkan driver.");
    auto gipa=reinterpret_cast<PFN_vkGetInstanceProcAddr>(GetProcAddress(p.vulkan_loader,"vkGetInstanceProcAddr"));
    if(!gipa)return fail("System Vulkan loader does not export vkGetInstanceProcAddr.");
    auto create_instance=reinterpret_cast<PFN_vkCreateInstance>(gipa(VK_NULL_HANDLE,"vkCreateInstance"));
    auto instance_version=reinterpret_cast<PFN_vkEnumerateInstanceVersion>(gipa(VK_NULL_HANDLE,"vkEnumerateInstanceVersion"));
    if(!create_instance)return fail("System Vulkan loader does not resolve vkCreateInstance.");
    uint32_t available=VK_API_VERSION_1_0;
    if(instance_version&&!p.vkcheck(instance_version(&available),"vkEnumerateInstanceVersion",error))return fail(error);
    const uint32_t version=std::min({available,p.requirements.max_api_version,VK_API_VERSION_1_3});
    if(version<p.requirements.min_api_version)return fail("System Vulkan version is below OpenXR's required minimum.");
    std::vector<const char*> instance_extensions,device_extensions;
    for(const auto& s:p.requirements.instance_extensions)instance_extensions.push_back(s.c_str());
    for(const auto& s:p.requirements.device_extensions)device_extensions.push_back(s.c_str());
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};app.pApplicationName="Endfield VRVD CPU-upload compatibility";app.applicationVersion=1;app.apiVersion=version;
    VkInstanceCreateInfo create{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};create.pApplicationInfo=&app;
    create.enabledExtensionCount=static_cast<uint32_t>(instance_extensions.size());create.ppEnabledExtensionNames=instance_extensions.data();
    if(!p.vkcheck(create_instance(&create,nullptr,&p.owned_instance),"vkCreateInstance(OpenXR requirements)",error))return fail(error);
    p.vkDestroyInstance=reinterpret_cast<PFN_vkDestroyInstance>(gipa(p.owned_instance,"vkDestroyInstance"));
    if(!p.vkDestroyInstance)return fail("Missing vkDestroyInstance.");
    VkPhysicalDevice gpu=VK_NULL_HANDLE;if(!graphics_device(p.owned_instance,gpu,error))return fail(error);
    const auto families=reinterpret_cast<PFN_vkGetPhysicalDeviceQueueFamilyProperties>(gipa(p.owned_instance,"vkGetPhysicalDeviceQueueFamilyProperties"));
    const auto create_device=reinterpret_cast<PFN_vkCreateDevice>(gipa(p.owned_instance,"vkCreateDevice"));
    const auto memory_properties=reinterpret_cast<PFN_vkGetPhysicalDeviceMemoryProperties>(gipa(p.owned_instance,"vkGetPhysicalDeviceMemoryProperties"));
    const auto get_device=reinterpret_cast<PFN_vkGetDeviceProcAddr>(gipa(p.owned_instance,"vkGetDeviceProcAddr"));
    if(!families||!create_device||!memory_properties||!get_device)return fail("Missing Vulkan instance/device creation functions.");
    uint32_t count=0;families(gpu,&count,nullptr);std::vector<VkQueueFamilyProperties> queues(count);families(gpu,&count,queues.data());
    uint32_t family=count;for(uint32_t i=0;i<count;++i)if(queues[i].queueCount&&(queues[i].queueFlags&VK_QUEUE_GRAPHICS_BIT)){family=i;break;}
    if(family==count)return fail("The OpenXR-selected GPU has no usable graphics queue.");
    float priority=1.f;VkDeviceQueueCreateInfo queue{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};queue.queueFamilyIndex=family;queue.queueCount=1;queue.pQueuePriorities=&priority;
    VkDeviceCreateInfo device{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};device.queueCreateInfoCount=1;device.pQueueCreateInfos=&queue;
    device.enabledExtensionCount=static_cast<uint32_t>(device_extensions.size());device.ppEnabledExtensionNames=device_extensions.data();
    if(!p.vkcheck(create_device(gpu,&device,nullptr,&p.owned_device),"vkCreateDevice(OpenXR requirements)",error))return fail(error);
    p.owned=true;
#define OWNED_VK(n) p.n=reinterpret_cast<PFN_##n>(get_device(p.owned_device,#n));if(!p.n)return fail("Missing owned Vulkan function: " #n);
    OWNED_VK(vkDestroyDevice) OWNED_VK(vkGetDeviceQueue)
    OWNED_VK(vkCreateImage) OWNED_VK(vkDestroyImage) OWNED_VK(vkGetImageMemoryRequirements)
    OWNED_VK(vkAllocateMemory) OWNED_VK(vkFreeMemory) OWNED_VK(vkBindImageMemory)
    OWNED_VK(vkCreateBuffer) OWNED_VK(vkDestroyBuffer) OWNED_VK(vkGetBufferMemoryRequirements)
    OWNED_VK(vkBindBufferMemory) OWNED_VK(vkMapMemory) OWNED_VK(vkUnmapMemory)
    OWNED_VK(vkFlushMappedMemoryRanges) OWNED_VK(vkCmdCopyBufferToImage) OWNED_VK(vkCmdClearColorImage)
#undef OWNED_VK
    XrVulkanContext context;context.instance=p.owned_instance;context.physical_device=gpu;context.device=p.owned_device;
    context.queue_family=family;context.queue_index=0;context.api_version=version;context.get_instance_proc_addr=gipa;
    context.extension_lists_known=true;context.enabled_instance_extensions=p.requirements.instance_extensions;context.enabled_device_extensions=p.requirements.device_extensions;
    p.vkGetDeviceQueue(context.device,family,0,&context.queue);
    VkPhysicalDeviceMemoryProperties memory{};memory_properties(gpu,&memory);
    p.owned_memory_properties=memory;
    const auto memory_type=[&](uint32_t bits,VkMemoryPropertyFlags required,VkMemoryPropertyFlags preferred)->uint32_t{
        for(int pass=0;pass<2;++pass)for(uint32_t i=0;i<memory.memoryTypeCount;++i)
            if((bits&(1u<<i))&&(memory.memoryTypes[i].propertyFlags&required)==required&&
               (pass||(memory.memoryTypes[i].propertyFlags&preferred)==preferred))return i;
        return UINT32_MAX;
    };
    XrVulkanImage sources[2];
    for(size_t e=0;e<2;++e){
        VkImageCreateInfo image{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};image.imageType=VK_IMAGE_TYPE_2D;image.format=VK_FORMAT_R8G8B8A8_UNORM;
        image.extent={width,height,1};image.mipLevels=image.arrayLayers=1;image.samples=VK_SAMPLE_COUNT_1_BIT;image.tiling=VK_IMAGE_TILING_OPTIMAL;
        image.usage=VK_IMAGE_USAGE_TRANSFER_SRC_BIT|VK_IMAGE_USAGE_TRANSFER_DST_BIT;image.sharingMode=VK_SHARING_MODE_EXCLUSIVE;image.initialLayout=VK_IMAGE_LAYOUT_UNDEFINED;
        if(!p.vkcheck(p.vkCreateImage(context.device,&image,nullptr,&p.owned_images[e]),"vkCreateImage(eye)",error))return fail(error);
        VkMemoryRequirements req{};p.vkGetImageMemoryRequirements(context.device,p.owned_images[e],&req);
        uint32_t type=memory_type(req.memoryTypeBits,0,VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        if(type==UINT32_MAX)return fail("No compatible Vulkan eye image memory type.");
        VkMemoryAllocateInfo alloc{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};alloc.allocationSize=req.size;alloc.memoryTypeIndex=type;
        if(!p.vkcheck(p.vkAllocateMemory(context.device,&alloc,nullptr,&p.owned_memory[e]),"vkAllocateMemory(eye)",error)||
           !p.vkcheck(p.vkBindImageMemory(context.device,p.owned_images[e],p.owned_memory[e],0),"vkBindImageMemory",error))return fail(error);
        sources[e].image=p.owned_images[e];sources[e].format=image.format;sources[e].extent=image.extent;
        // First submission transitions from UNDEFINED before uploading; the
        // declared interface layout is the state at the subsequent image copy.
        sources[e].layout=VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;sources[e].usage=image.usage;sources[e].aspect=VK_IMAGE_ASPECT_COLOR_BIT;
    }
    p.eye_bytes=static_cast<size_t>(width)*height*4;
    VkBufferCreateInfo buffer{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};buffer.size=static_cast<VkDeviceSize>(p.eye_bytes)*2;
    buffer.usage=VK_BUFFER_USAGE_TRANSFER_SRC_BIT;buffer.sharingMode=VK_SHARING_MODE_EXCLUSIVE;
    if(!p.vkcheck(p.vkCreateBuffer(context.device,&buffer,nullptr,&p.staging),"vkCreateBuffer(staging)",error))return fail(error);
    VkMemoryRequirements req{};p.vkGetBufferMemoryRequirements(context.device,p.staging,&req);
    uint32_t type=memory_type(req.memoryTypeBits,VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT,VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    if(type==UINT32_MAX)return fail("No host-visible Vulkan staging memory type.");
    p.staging_coherent=(memory.memoryTypes[type].propertyFlags&VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)!=0;
    VkMemoryAllocateInfo alloc{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};alloc.allocationSize=req.size;alloc.memoryTypeIndex=type;
    if(!p.vkcheck(p.vkAllocateMemory(context.device,&alloc,nullptr,&p.staging_memory),"vkAllocateMemory(staging)",error)||
       !p.vkcheck(p.vkBindBufferMemory(context.device,p.staging,p.staging_memory,0),"vkBindBufferMemory",error)||
       !p.vkcheck(p.vkMapMemory(context.device,p.staging_memory,0,VK_WHOLE_SIZE,0,&p.staging_map),"vkMapMemory(staging)",error))return fail(error);
    return initialize(context,sources,error);
}

bool XrVulkanBackend::begin_frame(Eye eyes[2],bool& shouldRender,std::string& error){
    auto& p=*impl_;error.clear();shouldRender=false;
    if(!eyes){error="Eye pose output is null.";return false;}
    if(!p.session){error="OpenXR Vulkan session is not initialized.";return false;}
    if(p.faulted){error="OpenXR Vulkan backend requires shutdown after an earlier failure.";return false;}
    if(p.pending){error="Previous OpenXR Vulkan frame still awaits submit/cancel on the graphics queue.";return false;}
    if(!p.poll(error)){p.faulted=true;return false;}
    if(!p.active)return true;
    p.diag.swapchain_wait_cpu_ms=p.diag.gpu_fence_wait_cpu_ms=p.diag.end_frame_cpu_ms=0;
    p.diag.swapchain_wait_cpu_known=p.diag.gpu_fence_wait_cpu_known=p.diag.end_frame_cpu_known=false;
    p.diag.predicted_period_ns=0;p.diag.predicted_period_known=false;
    XrFrameWaitInfo wait{XR_TYPE_FRAME_WAIT_INFO};XrFrameState frame{XR_TYPE_FRAME_STATE};
    const auto start=CpuClock::now();const XrResult waited=p.xrWaitFrame(p.session,&wait,&frame);
    p.diag.wait_frame_cpu_ms=elapsed_ms(start);p.diag.wait_frame_cpu_known=true;
    if(!p.check(waited,"xrWaitFrame",error)){p.faulted=true;return false;}
    if(frame.predictedDisplayPeriod>0){p.diag.predicted_period_ns=frame.predictedDisplayPeriod;p.diag.predicted_period_known=true;}
    p.read_refresh(false);
    p.pending=true;p.begun=false;p.renderable=false;p.hud_frame=false;p.display_time=frame.predictedDisplayTime;
    // xrBeginFrame may use VkQueue; defer until submit/cancel owns that queue.
    if(!frame.shouldRender)return true;
    XrViewLocateInfo locate{XR_TYPE_VIEW_LOCATE_INFO};locate.viewConfigurationType=XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;locate.displayTime=p.display_time;locate.space=p.local;
    XrViewState state{XR_TYPE_VIEW_STATE};uint32_t count=0;
    if(!p.check(p.xrLocateViews(p.session,&locate,&state,2,&count,p.views.data()),"xrLocateViews",error)){p.faulted=true;return false;}
    constexpr XrViewStateFlags required=XR_VIEW_STATE_ORIENTATION_VALID_BIT|XR_VIEW_STATE_POSITION_VALID_BIT|XR_VIEW_STATE_ORIENTATION_TRACKED_BIT|XR_VIEW_STATE_POSITION_TRACKED_BIT;
    if(count!=2||(state.viewStateFlags&required)!=required)return true;
    if(p.reference_change_time&&p.display_time>=p.reference_change_time){p.recenter=true;p.reference_change_time=0;p.previous_world_valid=false;}
    p.recentered_eyes(eyes);shouldRender=p.renderable=true;return true;
}

bool XrVulkanBackend::submit(const XrVulkanImage eyes[2],std::string& error){
    auto& p=*impl_;error.clear();
    if(!p.pending){error="No OpenXR Vulkan frame is pending.";return false;}
    const auto fail=[&](const std::string& why){error=why;p.faulted=true;
        if(!p.gpu_pending){p.return_images();p.finish_empty();}return false;};
    if(p.faulted)return fail("The Vulkan backend is faulted; cancel the pending frame and shut down.");
    if(!p.renderable)return p.finish_empty(&error);
    if(!eyes||!valid_image(eyes[0])||!valid_image(eyes[1])||eyes[0].image==eyes[1].image||
       !same_shape(eyes[0],p.sources[0])||!same_shape(eyes[1],p.sources[1]))
        return fail("Submitted eye image format/shape/layout changed; recreate the Vulkan session.");
    if(!p.panel_only&&p.owned&&(!p.upload_pending||eyes[0].image!=p.owned_images[0]||eyes[1].image!=p.owned_images[1]))
        return fail("Owned Vulkan backend requires submit_rgba with fresh pixels for both eyes.");
    const bool flat_base=p.panel_only&&p.flat_projection_background&&!p.reuse_previous_world;
    const bool submit_eyes=!p.panel_only||flat_base;
    if(!p.begin_on_queue(&error))return fail(error);
    for(size_t e=0;e<(submit_eyes?2u:0u);++e){
        XrSwapchainImageAcquireInfo acquire{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
        if(!p.check(p.xrAcquireSwapchainImage(p.chains[e],&acquire,&p.image_index[e]),"xrAcquireSwapchainImage",error))return fail(error);
        p.acquired[e]=true;
        XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};wait.timeout=100'000'000;
        XrResult result=p.wait_swapchain(p.chains[e],wait);
        if(result==XR_TIMEOUT_EXPIRED)return fail("OpenXR Vulkan swapchain image wait timed out.");
        if(!p.check(result,"xrWaitSwapchainImage",error))return fail(error);
        p.waited[e]=true;
        if(p.image_index[e]>=p.images[e].size())return fail("Invalid Vulkan swapchain image index from runtime.");
    }
    if(p.hud_frame){
        XrSwapchainImageAcquireInfo acquire{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
        if(!p.check(p.xrAcquireSwapchainImage(p.hud_chain,&acquire,&p.hud_index),"xrAcquireSwapchainImage(HUD)",error))return fail(error);
        p.hud_acquired=true;
        XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};wait.timeout=100'000'000;
        const XrResult result=p.wait_swapchain(p.hud_chain,wait);
        if(result==XR_TIMEOUT_EXPIRED)return fail("OpenXR HUD swapchain image wait timed out.");
        if(!p.check(result,"xrWaitSwapchainImage(HUD)",error))return fail(error);
        p.hud_waited=true;
        if(p.hud_index>=p.hud_images.size())return fail("Invalid HUD swapchain image index from runtime.");
    }
    if(!p.vkcheck(p.vkResetCommandBuffer(p.command,0),"vkResetCommandBuffer",error))return fail(error);
    VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};begin.flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    if(!p.vkcheck(p.vkBeginCommandBuffer(p.command,&begin),"vkBeginCommandBuffer",error))return fail(error);
    for(size_t e=0;e<(submit_eyes?2u:0u);++e){
        if(p.owned&&!flat_base){
            VkImageMemoryBarrier upload{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
            upload.srcAccessMask=p.owned_images_ready?VK_ACCESS_TRANSFER_READ_BIT:0;upload.dstAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;
            upload.oldLayout=p.owned_images_ready?VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:VK_IMAGE_LAYOUT_UNDEFINED;
            upload.newLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
            upload.srcQueueFamilyIndex=upload.dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;upload.image=p.owned_images[e];
            upload.subresourceRange={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
            p.vkCmdPipelineBarrier(p.command,p.owned_images_ready?VK_PIPELINE_STAGE_TRANSFER_BIT:VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,0,nullptr,0,nullptr,1,&upload);
            VkBufferImageCopy region{};region.bufferOffset=e*p.eye_bytes;region.imageSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};region.imageExtent=eyes[e].extent;
            p.vkCmdCopyBufferToImage(p.command,p.staging,p.owned_images[e],VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&region);
            upload.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;upload.dstAccessMask=VK_ACCESS_TRANSFER_READ_BIT;
            upload.oldLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;upload.newLayout=VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
            p.vkCmdPipelineBarrier(p.command,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,0,nullptr,0,nullptr,1,&upload);
        }
        VkImageMemoryBarrier barrier{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        // OpenXR guarantees COLOR_ATTACHMENT_OPTIMAL and queue ownership after
        // successful wait; restore that exact layout before releasing the image.
        barrier.srcAccessMask=VK_ACCESS_COLOR_ATTACHMENT_READ_BIT|VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        barrier.dstAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;barrier.oldLayout=VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;barrier.newLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        barrier.srcQueueFamilyIndex=barrier.dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;
        barrier.image=p.images[e][p.image_index[e]].image;barrier.subresourceRange={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
        p.vkCmdPipelineBarrier(p.command,VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,0,nullptr,0,nullptr,1,&barrier);
        VkImageCopy region{};region.srcSubresource=region.dstSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};region.extent=eyes[e].extent;
        if(flat_base){
            if(!p.vkCmdClearColorImage)return fail("Flat projection clear function unavailable");
            VkClearColorValue black{};black.float32[3]=1.f;
            p.vkCmdClearColorImage(p.command,barrier.image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,&black,1,&barrier.subresourceRange);
        }else p.vkCmdCopyImage(p.command,eyes[e].image,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,barrier.image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&region);
        barrier.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;barrier.dstAccessMask=VK_ACCESS_COLOR_ATTACHMENT_READ_BIT|VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        barrier.oldLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;barrier.newLayout=VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        p.vkCmdPipelineBarrier(p.command,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,0,0,nullptr,0,nullptr,1,&barrier);
    }
    if(p.hud_frame){
        VkImageMemoryBarrier upload{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        upload.srcAccessMask=p.hud_image_ready?VK_ACCESS_TRANSFER_READ_BIT:0;
        upload.dstAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;
        upload.oldLayout=p.hud_image_ready?VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:VK_IMAGE_LAYOUT_UNDEFINED;
        upload.newLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        upload.srcQueueFamilyIndex=upload.dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;
        upload.image=p.hud_image;upload.subresourceRange={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
        p.vkCmdPipelineBarrier(p.command,p.hud_image_ready?VK_PIPELINE_STAGE_TRANSFER_BIT:VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
            VK_PIPELINE_STAGE_TRANSFER_BIT,0,0,nullptr,0,nullptr,1,&upload);
        VkBufferImageCopy pixels{};pixels.imageSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};
        pixels.imageExtent={p.hud_width,p.hud_height+MenuBackdropRows,1};
        if(p.hud_black_opacity>=0){
            if(!p.vkCmdClearColorImage)return fail("GPU fade clear function unavailable");
            VkClearColorValue color{};color.float32[3]=p.hud_black_opacity;
            p.vkCmdClearColorImage(p.command,p.hud_image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,&color,1,&upload.subresourceRange);
        }else p.vkCmdCopyBufferToImage(p.command,p.hud_staging,p.hud_image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&pixels);
        upload.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;upload.dstAccessMask=VK_ACCESS_TRANSFER_READ_BIT;
        upload.oldLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;upload.newLayout=VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
        p.vkCmdPipelineBarrier(p.command,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,0,nullptr,0,nullptr,1,&upload);
        VkImageMemoryBarrier target{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        target.srcAccessMask=VK_ACCESS_COLOR_ATTACHMENT_READ_BIT|VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        target.dstAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;
        target.oldLayout=VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;target.newLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        target.srcQueueFamilyIndex=target.dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;
        target.image=p.hud_images[p.hud_index].image;target.subresourceRange={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
        p.vkCmdPipelineBarrier(p.command,VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,0,nullptr,0,nullptr,1,&target);
        VkImageCopy copy{};copy.srcSubresource=copy.dstSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};
        copy.extent={p.hud_width,p.hud_height+MenuBackdropRows,1};
        p.vkCmdCopyImage(p.command,p.hud_image,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,target.image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&copy);
        target.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;target.dstAccessMask=VK_ACCESS_COLOR_ATTACHMENT_READ_BIT|VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        target.oldLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;target.newLayout=VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        p.vkCmdPipelineBarrier(p.command,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,0,0,nullptr,0,nullptr,1,&target);
    }
    if(!p.vkcheck(p.vkEndCommandBuffer(p.command),"vkEndCommandBuffer",error))return fail(error);
    if(!p.vkcheck(p.vkResetFences(p.context.device,1,&p.fence),"vkResetFences",error))return fail(error);
    VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};submit.commandBufferCount=1;submit.pCommandBuffers=&p.command;
    if(!p.vkcheck(p.vkQueueSubmit(p.context.queue,1,&submit,p.fence),"vkQueueSubmit",error))return fail(error);
    p.gpu_pending=true;if(!p.panel_only)p.owned_images_ready=p.owned;p.upload_pending=false;
    if(p.hud_frame)p.hud_image_ready=true;
    if(!p.complete_gpu(100'000'000,&error))return fail(error);
    if(p.device_lost)return fail("Vulkan device was lost during stereo image upload/copy.");
    for(size_t e=0;e<(submit_eyes?2u:0u);++e){
        XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
        if(!p.check(p.xrReleaseSwapchainImage(p.chains[e],&release),"xrReleaseSwapchainImage",error))return fail(error);
        p.acquired[e]=p.waited[e]=false;
    }
    if(p.hud_frame){
        XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
        if(!p.check(p.xrReleaseSwapchainImage(p.hud_chain,&release),"xrReleaseSwapchainImage(HUD)",error))return fail(error);
        p.hud_acquired=p.hud_waited=false;
    }
    std::array<XrCompositionLayerProjectionView,2> projections{XrCompositionLayerProjectionView{XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW},XrCompositionLayerProjectionView{XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW}};
    for(size_t e=0;e<(submit_eyes?2u:0u);++e){auto& view=projections[e];view.pose=p.views[e].pose;view.fov=p.views[e].fov;
        view.subImage.swapchain=p.chains[e];view.subImage.imageRect.extent={static_cast<int32_t>(eyes[e].extent.width),static_cast<int32_t>(eyes[e].extent.height)};}
    const bool cached=p.panel_only&&p.reuse_previous_world&&p.previous_world_valid;
    if(cached)projections=p.previous_projection;
    XrCompositionLayerProjection layer{XR_TYPE_COMPOSITION_LAYER_PROJECTION};layer.space=p.local;layer.viewCount=2;layer.views=projections.data();
    XrCompositionLayerQuad hud_layer{XR_TYPE_COMPOSITION_LAYER_QUAD};
    hud_layer.layerFlags=XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT;
    hud_layer.space=p.hud_view;hud_layer.eyeVisibility=XR_EYE_VISIBILITY_BOTH;
    hud_layer.subImage.swapchain=p.hud_chain;
    hud_layer.subImage.imageRect.extent={static_cast<int32_t>(p.hud_width),static_cast<int32_t>(p.hud_height)};
    hud_layer.pose.orientation.w=1.f;hud_layer.pose.position={0.f,p.hud_offset_y,-p.hud_distance};
    hud_layer.size={p.hud_width_m,p.hud_width_m*(p.hud_width?float(p.hud_height)/float(p.hud_width):1.f)};
    if(p.hud_black_opacity>=0){
        // Generous FOV coverage including eye offsets, with a zero RGB / alpha mask.
        float tx=1.f,ty=1.f;for(const auto& v:p.views){
            for(float a:{v.fov.angleLeft,v.fov.angleRight})if(std::isfinite(a)&&std::abs(a)<1.5f)tx=std::max(tx,std::abs(std::tan(a)));
            for(float a:{v.fov.angleDown,v.fov.angleUp})if(std::isfinite(a)&&std::abs(a)<1.5f)ty=std::max(ty,std::abs(std::tan(a)));
        }
        hud_layer.pose.position={0,0,-1.f};hud_layer.size={2.5f*tx+.2f,2.5f*ty+.2f};
    }
    // VIEW keeps the quad fixed relative to the viewer, independently of the
    // scene's LOCAL-space stereo views. Pixels already have premultiplied alpha.
    XrCompositionLayerQuad backdrop=hud_layer;
    std::array<const XrCompositionLayerBaseHeader*,4> layers{};uint32_t layerCount=0;
    if(submit_eyes||cached)layers[layerCount++]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&layer);
    if(p.panel_only&&p.hud_frame&&p.hud_backdrop&&(p.max_layers>=uint32_t((submit_eyes||cached?1:0)+2+(p.content_cover?1:0)))){
        backdrop.layerFlags=0;backdrop.pose.position={0.f,0.f,-(p.hud_distance+0.5f)};
        float tx=1.f,ty=1.f;
        for(const auto& v:p.views){
            for(float a:{v.fov.angleLeft,v.fov.angleRight})if(std::isfinite(a)&&std::abs(a)<1.5f)tx=std::max(tx,std::abs(std::tan(a)));
            for(float a:{v.fov.angleDown,v.fov.angleUp})if(std::isfinite(a)&&std::abs(a)<1.5f)ty=std::max(ty,std::abs(std::tan(a)));
        }
        float d=-backdrop.pose.position.z;
        backdrop.size={2.f*d*tx*1.25f+0.2f,2.f*d*ty*1.25f+0.2f};
        backdrop.subImage.imageRect.offset={2,int32_t(p.hud_height+MenuBackdropGap+2)};
        backdrop.subImage.imageRect.extent={MenuBackdropSize,MenuBackdropSize};
        layers[layerCount++]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&backdrop);
    }
    if(p.hud_frame)layers[layerCount++]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&hud_layer);
    XrCompositionLayerQuad menu_cover=hud_layer;
    if(p.panel_only&&p.hud_frame&&p.content_cover&&p.hud_black_opacity<0){
        menu_cover.subImage.imageRect.offset={int32_t(p.hud_width-3),int32_t(p.hud_height+1)};
        menu_cover.subImage.imageRect.extent={2,2};menu_cover.pose.position={0,0,-1.f};
        float tx=1.f,ty=1.f;for(const auto& v:p.views){
            for(float a:{v.fov.angleLeft,v.fov.angleRight})if(std::isfinite(a)&&std::abs(a)<1.5f)tx=std::max(tx,std::abs(std::tan(a)));
            for(float a:{v.fov.angleDown,v.fov.angleUp})if(std::isfinite(a)&&std::abs(a)<1.5f)ty=std::max(ty,std::abs(std::tan(a)));
        }
        menu_cover.size={2.5f*tx+.2f,2.5f*ty+.2f};
        layers[layerCount++]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&menu_cover);
    }
    XrFrameEndInfo end{XR_TYPE_FRAME_END_INFO};end.displayTime=p.display_time;end.environmentBlendMode=XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
    end.layerCount=layerCount;end.layers=layers.data();
    XrResult result=p.end_frame(end);p.pending=p.begun=p.renderable=p.hud_frame=false;
    if(!p.check(result,"xrEndFrame(Vulkan stereo)",error)){p.faulted=true;p.previous_world_valid=false;return false;}
    p.diag.last_layer_count=layerCount;p.diag.last_flat_projection_background=flat_base;
    if(!p.panel_only){p.previous_projection=projections;p.previous_world_valid=true;}
    else if(!p.reuse_previous_world)p.previous_world_valid=false;
    return true;
}

bool XrVulkanBackend::submit_rgba(const void* left,const void* right,size_t bytes,std::string& error,const XrVulkanHudFrame* hud){
    auto& p=*impl_;error.clear();
    p.hud_backdrop=false;p.hud_frame=false;p.reuse_previous_world=false; // Null or invalid HUD input must never resubmit old pixels.
    if(!p.owned||!p.staging_map){error="Vulkan CPU-upload path is not initialized.";return false;}
    if(!p.pending){error="No OpenXR frame is pending for CPU pixels.";return false;}
    if(!p.renderable)return p.finish_empty(&error);
    if(!left||!right||left==right||bytes!=p.eye_bytes){error="CPU upload requires separate left/right RGBA8 buffers of exactly width*height*4 bytes each.";return false;}
    if(p.faulted||p.gpu_pending){error="Vulkan staging memory cannot be overwritten while a previous copy is pending or faulted.";return false;}
    if(hud){
        if(hud->backdrop_rgba){error="Decorative backdrop requires menu-only submission";return false;}
        if(!validate_vulkan_hud_frame(*hud,error))return false;
        if(!p.ensure_hud(*hud,error)){p.faulted=true;return false;}
        p.stage_hud(*hud);
        if(p.hud_black_opacity<0&&!p.hud_coherent){VkMappedMemoryRange range{VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE};
            range.memory=p.hud_staging_memory;range.size=VK_WHOLE_SIZE;
            if(!p.vkcheck(p.vkFlushMappedMemoryRanges(p.context.device,1,&range),"vkFlushMappedMemoryRanges(HUD)",error)){p.faulted=true;return false;}}
        p.hud_distance=hud->distance_m;p.hud_width_m=hud->width_m;p.hud_offset_y=hud->offset_y_m;
        p.hud_frame=true;
    }
    std::memcpy(p.staging_map,left,bytes);std::memcpy(static_cast<unsigned char*>(p.staging_map)+bytes,right,bytes);
    if(!p.staging_coherent){VkMappedMemoryRange range{VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE};range.memory=p.staging_memory;range.size=VK_WHOLE_SIZE;
        if(!p.vkcheck(p.vkFlushMappedMemoryRanges(p.context.device,1,&range),"vkFlushMappedMemoryRanges",error)){p.faulted=true;return false;}}
    p.upload_pending=true;return submit(p.sources.data(),error);
}
bool XrVulkanBackend::submit_panel(const XrVulkanHudFrame& panel,std::string& error){
    auto& p=*impl_;p.hud_frame=false;p.hud_backdrop=false;
    if(!p.owned||!p.pending||p.faulted||p.gpu_pending){error="Menu-only frame requires an idle owned Vulkan backend and pending XR frame";return false;}
    if(!p.renderable)return p.finish_empty(&error);
    if(!validate_vulkan_hud_frame(panel,error)||!p.ensure_hud(panel,error))return false;
    p.stage_hud(panel);
    if(p.hud_black_opacity<0&&!p.hud_coherent){VkMappedMemoryRange r{VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE};r.memory=p.hud_staging_memory;r.size=VK_WHOLE_SIZE;
        if(!p.vkcheck(p.vkFlushMappedMemoryRanges(p.context.device,1,&r),"Flush menu panel",error))return false;}
    p.hud_distance=panel.distance_m;p.hud_width_m=panel.width_m;p.hud_offset_y=panel.offset_y_m;p.hud_frame=true;
    p.reuse_previous_world=panel.keep_previous_world;p.flat_projection_background=panel.projection_background;p.panel_only=true;
    bool result=submit(p.sources.data(),error);p.panel_only=false;p.reuse_previous_world=false;p.flat_projection_background=false;return result;
}
bool XrVulkanBackend::has_previous_world()const{return impl_->previous_world_valid&&!impl_->faulted;}
void XrVulkanBackend::cancel_frame(){auto& p=*impl_;if(p.complete_gpu(100'000'000)){p.return_images();p.finish_empty();}}
void XrVulkanBackend::request_recenter(){impl_->recenter=true;}
bool XrVulkanBackend::running()const{return impl_->active&&!impl_->faulted;}
bool XrVulkanBackend::focused()const{return running()&&impl_->state==XR_SESSION_STATE_FOCUSED;}
bool XrVulkanBackend::frame_pending()const{return impl_->pending;}
std::string XrVulkanBackend::runtime_name()const{return impl_->name;}
std::string XrVulkanBackend::graphics_name()const{return impl_->gpu_name;}
uint32_t XrVulkanBackend::graphics_api_version()const{return impl_->context.api_version;}
XrVulkanDiagnostics XrVulkanBackend::diagnostics()const{return impl_->diag;}
bool XrVulkanBackend::shutdown(){return !impl_||impl_->close();}

#undef XR_VK_FUNCTIONS
#undef VK_DEVICE_FUNCTIONS
} // namespace vrvd
