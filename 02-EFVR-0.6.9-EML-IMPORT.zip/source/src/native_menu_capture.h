#pragma once
#include "managed_read.h"
#include <atomic>
#include <algorithm>
#include <chrono>
#include <cmath>
namespace vrvd {
// Only the game's own RT extraction completion authorizes reading a handle.
// No Canvas/camera/layout mutation. All managed operations run on the game thread.
class NativeMenuCapture: private ManagedRead {
 BE_ResolvedMethodV1 capture{},getRt{},release{},texW{},texH{},rtCtor{},rtCreate{},rtRelease{},texCtor{},destroy{},blit{},getActive{},setActive{},readPixels{},raw{},length{},copy{};
 BE_ResolvedClassV1 rtClass{},texClass{};
 Root handle,rt,cpu,activeBackup;
 bool active_dirty=false;
 uint32_t width=0,height=0;
 uint64_t request_generation=0;
 std::chrono::steady_clock::time_point requested_at{};
 bool ready=false,poisoned=false;
 inline static std::atomic<void*> expected{nullptr},completed{nullptr};
 inline static std::atomic<bool> requesting{false};
 using Done=void(*)(void*,void*,void*);
 inline static Done nextDone=nullptr;
 static void done(void* camera,void* target,void* method){
  if(nextDone)nextDone(camera,target,method);
  if(target&&(target==expected.load()||requesting.load()))completed.store(target);
 }
 bool init_images(uint32_t w,uint32_t h,std::string& e){
  if(rt.p&&cpu.p&&w==width&&h==height)return true;
  if(rt.p||cpu.p){e="Menu readback size changed; restart VR";return false;}
  width=w;height=h;int iw=w,ih=h,depth=0,fmt=0,linear=1;uint8_t yes=1,no=0,created=0;
  if(!rt.set(host,host->object_new(host->context,rtClass.class_info))||!rt.p)return false;
  void* a[]{&iw,&ih,&depth,&fmt,&linear};
  if(!call(rtCtor,rt.p,a,e)||!value(rtCreate,rt.p,created,e)||!created)return false;
  if(!cpu.set(host,host->object_new(host->context,texClass.class_info))||!cpu.p)return false;
  fmt=4;void* b[]{&iw,&ih,&fmt,&no,&yes};return call(texCtor,cpu.p,b,e);
 }
 bool free_handle(std::string& e){
  if(!handle.p)return true;
  if(completed.load()!=handle.p){e="Native menu extraction pending; target retained";return false;}
  if(!call(release,handle.p,nullptr,e))return false;
  expected.store(nullptr);completed.store(nullptr);handle.clear();return true;
 }
 bool restore_active(std::string& e){
  if(!active_dirty)return true;void* a[]{activeBackup.p};
  if(!call(setActive,nullptr,a,e))return false;
  active_dirty=false;activeBackup.clear();return true;
 }
public:
 // cleanup() is the only managed cleanup entry; destruction may be under loader lock.
 ~NativeMenuCapture(){handle.abandon();rt.abandon();cpu.abandon();activeBackup.abandon();}
 std::string status="not_resolved";
 uint64_t completed_generation=0;
 uint64_t requests=0,completions=0;
 uint32_t source_width=0,source_height=0;
 bool resolve(const BE_HostApiV1* api,std::string& e){
  if(ready)return true;host=api;
  auto b=[&](BE_ResolvedMethodV1& m,const char* a,const char* n,const char* c,const char* f,const char* args,const char* ret,unsigned count){return bind(m,a,n,c,f,args,ret,count,e);};
  const char* core="UnityEngine.CoreModule.dll";const char* rendering="Unity.RenderPipelines.Core.Runtime.dll";
  BE_ResolvedMethodV1 end{};
  bool ok=b(capture,"Assembly-CSharp.dll","Beyond.UI","ScreenCaptureUtils","GetScreenCapture",nullptr,"UnityEngine.Rendering.RTHandle",0)&&
   b(end,"HG.RenderPipelines.Runtime.dll","HG.Rendering.Runtime","HGCamera","RTExtractionDone","HG.Rendering.Runtime.HGCamera|UnityEngine.Rendering.RTHandle","System.Void",2)&&
   b(getRt,rendering,"UnityEngine.Rendering","RTHandle","get_rt",nullptr,"UnityEngine.RenderTexture",0)&&
   b(release,rendering,"UnityEngine.Rendering","RTHandle","Release",nullptr,"System.Void",0)&&
   b(texW,core,"UnityEngine","Texture","get_width",nullptr,"System.Int32",0)&&b(texH,core,"UnityEngine","Texture","get_height",nullptr,"System.Int32",0)&&
   b(rtCtor,core,"UnityEngine","RenderTexture",".ctor","System.Int32|System.Int32|System.Int32|UnityEngine.RenderTextureFormat|UnityEngine.RenderTextureReadWrite","System.Void",5)&&
   b(rtCreate,core,"UnityEngine","RenderTexture","Create",nullptr,"System.Boolean",0)&&b(rtRelease,core,"UnityEngine","RenderTexture","Release",nullptr,"System.Void",0)&&
   b(texCtor,core,"UnityEngine","Texture2D",".ctor","System.Int32|System.Int32|UnityEngine.TextureFormat|System.Boolean|System.Boolean","System.Void",5)&&
   b(destroy,core,"UnityEngine","Object","Destroy","UnityEngine.Object","System.Void",1)&&
   b(blit,core,"UnityEngine","Graphics","Blit","UnityEngine.Texture|UnityEngine.RenderTexture","System.Void",2)&&
   b(getActive,core,"UnityEngine","RenderTexture","get_active",nullptr,"UnityEngine.RenderTexture",0)&&b(setActive,core,"UnityEngine","RenderTexture","set_active","UnityEngine.RenderTexture","System.Void",1)&&
   b(readPixels,core,"UnityEngine","Texture2D","ReadPixels","UnityEngine.Rect|System.Int32|System.Int32|System.Boolean","System.Void",4)&&
   b(raw,core,"UnityEngine","Texture2D","GetRawTextureData",nullptr,"System.Byte[]",0)&&b(length,"mscorlib.dll","System","Array","get_Length",nullptr,"System.Int32",0)&&
   b(copy,"mscorlib.dll","System.Runtime.InteropServices","Marshal","Copy","System.Byte[]|System.Int32|System.IntPtr|System.Int32","System.Void",4)&&
   api->resolve_class(api->context,core,"UnityEngine","RenderTexture",&rtClass)==BE_Result_Ok&&
   api->resolve_class(api->context,core,"UnityEngine","Texture2D",&texClass)==BE_Result_Ok;
  if(!ok)return false;
  if(api->create_hook(api->context,"quest3.vrvd",end.method_pointer,reinterpret_cast<void*>(done),reinterpret_cast<void**>(&nextDone))!=BE_Result_Ok){e="Native menu completion hook unavailable";return false;}
  ready=true;status="ready";return true;
 }
 bool request(uint64_t generation,std::string& e){
  if(poisoned){e="Native extraction root allocation failed; restart game before retry";return false;}
  if(handle.p)return true;void* h=nullptr;completed.store(nullptr);requesting.store(true);
  bool ok=invoke(capture,nullptr,nullptr,h,e);requesting.store(false);
  if(!ok||!h){status="request_failed";return false;}
  if(!handle.set(host,h)){poisoned=true;status="root_retention_failed_restart_required";e="Cannot retain native menu RTHandle; further requests blocked";return false;}
  expected.store(h);request_generation=generation;requested_at=std::chrono::steady_clock::now();++requests;status="waiting_extraction";return true;
 }
 bool poll(uint64_t generation,uint32_t w,uint32_t h,std::vector<uint8_t>& output,bool& fresh,std::string& e){
  fresh=false;if(!restore_active(e))return false;
  if(!handle.p)return true;
  if(completed.load()!=handle.p){
   if(std::chrono::steady_clock::now()-requested_at>std::chrono::seconds(3)){status="extraction_timeout_retained";e="HG has not completed this menu extraction; no unverified pixels submitted";}
   return true;
  }
  if(request_generation!=generation){status="discarded_old_generation";return free_handle(e);}
  if(!init_images(w,h,e))return false;
  void* source=nullptr;int sw=0,sh=0;
  if(!invoke(getRt,handle.p,nullptr,source,e)||!source||!value(texW,source,sw,e)||!value(texH,source,sh,e)||sw<=0||sh<=0||sw>16384||sh>16384){status="invalid_source";return false;}
  void* old=nullptr;
  if(!invoke(getActive,nullptr,nullptr,old,e)||!activeBackup.set(host,old))return false;
  active_dirty=true;
  void* a[]{source,rt.p};void* target[]{rt.p};
  bool ok=call(blit,nullptr,a,e)&&call(setActive,nullptr,target,e);
  struct Rect {float x,y,w,h;} rect{0,0,float(w),float(h)};int zero=0;uint8_t no=0;void* read[]{&rect,&zero,&zero,&no};
  void* bytes=nullptr;Root held;int count=0;std::vector<uint8_t> image(size_t(w)*h*4);
  ok=ok&&call(readPixels,cpu.p,read,e)&&invoke(raw,cpu.p,nullptr,bytes,e)&&bytes&&held.set(host,bytes)&&value(length,bytes,count,e)&&count==int(image.size());
  if(ok){intptr_t p=reinterpret_cast<intptr_t>(image.data());void* cp[]{bytes,&zero,&p,&count};ok=call(copy,nullptr,cp,e);}
  std::string restoreError;
  if(!restore_active(restoreError)){e="Menu readback could not restore active RT: "+restoreError;return false;}
  if(!ok){if(e.empty())e="Native menu RGBA readback mismatch";return false;}
  // Preserve original window aspect inside a fixed-size XR texture. Unity rows are bottom-up.
  output.assign(image.size(),0);for(size_t i=3;i<output.size();i+=4)output[i]=255;
  int fitW=w,fitH=std::max(1,int(double(w)*sh/sw));if(fitH>int(h)){fitH=h;fitW=std::max(1,int(double(h)*sw/sh));}
  int ox=(int(w)-fitW)/2,oy=(int(h)-fitH)/2;
  for(int y=0;y<fitH;++y)for(int x=0;x<fitW;++x){size_t src=(size_t(h-1-uint32_t(y)*h/fitH)*w+uint32_t(x)*w/fitW)*4;size_t dst=(size_t(oy+y)*w+ox+x)*4;std::memcpy(output.data()+dst,image.data()+src,3);}
  if(!free_handle(e))return false;
  source_width=sw;source_height=sh;
  fresh=true;completed_generation=generation;++completions;status="captured_pending_visual_check";return true;
 }
 bool cleanup(std::string& e){
  if(poisoned){e="Unretained extraction target; restart game for cleanup";return false;}
  if(!restore_active(e))return false;
  bool ok=free_handle(e);
  if(!ok)return false;
  if(rt.p){void* a[]{rt.p};if(!call(rtRelease,rt.p,nullptr,e)||!call(destroy,nullptr,a,e))return false;rt.clear();}
  if(cpu.p){void* a[]{cpu.p};if(!call(destroy,nullptr,a,e))return false;cpu.clear();}
  width=height=0;return true;
 }
 bool pending()const{return handle.p!=nullptr;}
 bool resources_alive()const{return poisoned||handle.p||rt.p||cpu.p||active_dirty;}
 void hooks_released(){ready=false;}
};
}
