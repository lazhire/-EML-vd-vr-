#include "hg_ui_camera.h"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <utility>

namespace vrvd {
namespace {
constexpr const char* HgAssembly="HG.RenderPipelines.Runtime.dll";
constexpr const char* HgNamespace="HG.Rendering.Runtime";
constexpr const char* Core="UnityEngine.CoreModule.dll";
constexpr int Boolean=2,Int32=8,Value=17;
constexpr uint32_t Static=0x10,ReadOnly=0x20,Literal=0x40;
void* production_export(const char* name) {
    const auto module=GetModuleHandleW(L"GameAssembly.dll");
    return module?reinterpret_cast<void*>(GetProcAddress(module,name)):nullptr;
}
}
struct HgUiCamera::Impl {
    const BE_HostApiV1* host=nullptr;
    BE_ResolvedClassV1 additional{},boolean{},color{},camera{};
    BE_ResolvedMethodV1 get_component{},add_component{},get_go{},equals{};
    bool present=false,ready=false;
    void* component=nullptr;
    uint32_t root=0;
    bool existing_dirty=false;
    int32_t saved_clear=0;
    uint8_t saved_alpha=0,saved_passthrough=0;
    std::array<float,4> saved_color{};
    struct Field {const void* info=nullptr;const void* klass=nullptr;};
    Field path_field,clear_field,aa_field,color_field,alpha_field,depth_field,dynamic_field,history_field,passthrough_field;
    int32_t ui_value=0,clear_value=0,aa_value=0;
    const void* (*class_field)(const void*,const char*)=nullptr;
    const void* (*field_type)(const void*)=nullptr;
    const void* (*field_parent)(const void*)=nullptr;
    uint32_t (*field_flags)(const void*)=nullptr;
    int (*type_kind)(const void*)=nullptr;
    bool (*by_ref)(const void*)=nullptr;
    const void* (*class_from_type)(const void*)=nullptr;
    bool (*is_enum)(const void*)=nullptr;
    const void* (*enum_base)(const void*)=nullptr;
    const char* (*class_name)(const void*)=nullptr;
    const void* (*object_class)(void*)=nullptr;
    void (*field_set)(void*,const void*,void*)=nullptr;

    template<class T> bool load(T& fn,HudNativeResolver resolver,const char* name,std::string& e) {
        fn=reinterpret_cast<T>(resolver(name));if(fn)return true;e="HG HUD missing IL2CPP export: "+std::string(name);return false;
    }
    bool exports(HudNativeResolver r,std::string& e) {
        return load(class_field,r,"il2cpp_class_get_field_from_name",e)&&load(field_type,r,"il2cpp_field_get_type",e)&&
            load(field_parent,r,"il2cpp_field_get_parent",e)&&load(field_flags,r,"il2cpp_field_get_flags",e)&&
            load(type_kind,r,"il2cpp_type_get_type",e)&&load(by_ref,r,"il2cpp_type_is_byref",e)&&
            load(class_from_type,r,"il2cpp_class_from_type",e)&&load(is_enum,r,"il2cpp_class_is_enum",e)&&
            load(enum_base,r,"il2cpp_class_enum_basetype",e)&&load(class_name,r,"il2cpp_class_get_name",e)&&
            load(object_class,r,"il2cpp_object_get_class",e)&&load(field_set,r,"il2cpp_field_set_value",e);
    }
    bool field(const char* name,Field& f,int kind,const void* expected,std::string& e) {
        f.info=class_field(additional.class_info,name);const void* type=f.info?field_type(f.info):nullptr;
        if(!f.info||field_parent(f.info)!=additional.class_info||!type||by_ref(type)||type_kind(type)!=kind||
           (field_flags(f.info)&(Static|ReadOnly|Literal))) {e="HG HUD field contract mismatch: "+std::string(name);return false;}
        f.klass=class_from_type(type);
        if(!f.klass||(expected&&f.klass!=expected)){e="HG HUD field class mismatch: "+std::string(name);return false;}return true;
    }
    bool read(void* obj,const Field& f,void* value,size_t size,std::string& e) {
        void* boxed=host->field_get_value_object(host->context,f.info,obj);
        void* data=boxed?host->object_unbox(host->context,boxed):nullptr;
        if(!data||object_class(boxed)!=f.klass){e="HG HUD field readback type mismatch";return false;}
        std::memcpy(value,data,size);return true;
    }
    bool named_enum(const char* name,Field& f,const char* enum_name,const char* constant,int32_t& value,std::string& e) {
        if(!field(name,f,Value,nullptr,e))return false;
        const auto base=enum_base(f.klass);const auto actual_name=class_name(f.klass);
        if(!is_enum(f.klass)||!actual_name||std::strcmp(actual_name,enum_name)||!base||by_ref(base)||type_kind(base)!=Int32) {
            e="HG HUD enum contract mismatch: "+std::string(name);return false;
        }
        Field literal{class_field(f.klass,constant),f.klass};const auto type=literal.info?field_type(literal.info):nullptr;
        if(!literal.info||field_parent(literal.info)!=f.klass||(field_flags(literal.info)&(Static|Literal))!=(Static|Literal)||
           !type||by_ref(type)||type_kind(type)!=Value||class_from_type(type)!=f.klass) {
            e="HG HUD enum constant unavailable: "+std::string(enum_name)+"."+constant;return false;
        }
        return read(nullptr,literal,&value,sizeof value,e);
    }
    template<class T> bool write(const Field& f,T value,const char* name,std::string& e) {
        field_set(component,f.info,&value);T actual{};
        if(!read(component,f,&actual,sizeof actual,e))return false;
        if(std::memcmp(&value,&actual,sizeof value)){e="HG HUD field write/readback failed: "+std::string(name);return false;}return true;
    }
    bool invoke(const BE_ResolvedMethodV1& method,void* object,void** args,void*& out,std::string& e) {
        void* exception=nullptr;out=host->runtime_invoke(host->context,method.method_info,object,args,&exception);
        if(exception){e="HG HUD managed camera binding exception";return false;}return true;
    }
    bool same(void* a,void* b,std::string& e) {
        void* args[]{a,b};void* out=nullptr;if(!invoke(equals,nullptr,args,out,e))return false;
        auto data=out?static_cast<const uint8_t*>(host->object_unbox(host->context,out)):nullptr;
        if(!data||*data!=1){e="HG HUD component ownership mismatch";return false;}return true;
    }
};
HgUiCamera::HgUiCamera():impl_(new Impl){}
HgUiCamera::~HgUiCamera()=default;
bool HgUiCamera::resolve(const BE_HostApiV1* host,HudNativeResolver resolver,std::string& e) {
    auto& s=*impl_;e.clear();if(s.root){e="HG HUD resources must be released before rebinding";return false;}
    s.host=host;s.ready=false;s.present=false;
    if(!host||!host->resolve_class||!host->resolve_method||!host->runtime_invoke||!host->object_unbox||
       !host->gchandle_new||!host->gchandle_free){e="Incomplete EML API for HG HUD";return false;}
    const auto found=host->resolve_class(host->context,HgAssembly,HgNamespace,"HGAdditionalCameraData",&s.additional);
    if(found==BE_Result_NotFound){s.ready=true;return true;}
    if(found!=BE_Result_Ok||!s.additional.class_info||!s.additional.type_object||!host->field_get_value_object) {
        e="HG HUD additional camera class unavailable";return false;
    }
    s.present=true;if(!s.exports(resolver?resolver:production_export,e))return false;
    auto klass=[&](const char* assembly,const char* ns,const char* name,BE_ResolvedClassV1& result) {
        if(host->resolve_class(host->context,assembly,ns,name,&result)!=BE_Result_Ok||!result.class_info){e="HG HUD class unavailable: "+std::string(name);return false;}return true;
    };
    if(!klass("mscorlib.dll","System","Boolean",s.boolean)||!klass(Core,"UnityEngine","Color",s.color)||
       !klass(Core,"UnityEngine","Camera",s.camera))return false;
    auto method=[&](const char* type,const char* name,const char* params,const char* result,uint32_t count,BE_ResolvedMethodV1& out) {
        BE_MethodDescriptorV1 d{Core,"UnityEngine",type,name,params,result,count};
        if(host->resolve_method(host->context,&d,&out)!=BE_Result_Ok||!out.method_info){e="HG HUD method unavailable: "+std::string(name);return false;}return true;
    };
    if(!method("Component","GetComponent","System.Type","UnityEngine.Component",1,s.get_component)||
       !method("GameObject","AddComponent","System.Type","UnityEngine.Component",1,s.add_component)||
       !method("Component","get_gameObject",nullptr,"UnityEngine.GameObject",0,s.get_go)||
       !method("Object","op_Equality","UnityEngine.Object|UnityEngine.Object","System.Boolean",2,s.equals))return false;
    if(!s.named_enum("hgRenderPath",s.path_field,"HGRenderPath","UI",s.ui_value,e)||
       !s.named_enum("clearColorMode",s.clear_field,"ClearColorMode","Color",s.clear_value,e)||
       !s.named_enum("antialiasing",s.aa_field,"AntialiasingMode","None",s.aa_value,e)||
       !s.field("backgroundColorHDR",s.color_field,Value,s.color.class_info,e))return false;
    for(auto pair:{std::pair<const char*,Impl::Field*>{"enableAlpha",&s.alpha_field},{"clearDepth",&s.depth_field},
            {"allowDynamicResolution",&s.dynamic_field},{"hasPersistentHistory",&s.history_field},{"fullscreenPassthrough",&s.passthrough_field}})
        if(!s.field(pair.first,*pair.second,Boolean,s.boolean.class_info,e))return false;
    s.ready=true;return true;
}
bool HgUiCamera::bind(void* camera,void* go,std::string& e) {
    auto& s=*impl_;if(!s.ready){e="HG HUD helper is unresolved";return false;}if(!s.present)return true;
    if(!camera||!go||s.object_class(camera)!=s.camera.class_info){e="HG HUD requires its own camera and GameObject";return false;}
    void* owner=nullptr;if(!s.invoke(s.get_go,camera,nullptr,owner,e)||!s.same(owner,go,e))return false;
    void* args[]{s.additional.type_object};void* component=nullptr;
    if(!s.invoke(s.get_component,camera,args,component,e))return false;
    if(!component&&!s.invoke(s.add_component,go,args,component,e))return false;
    if(!component||s.object_class(component)!=s.additional.class_info){e="HG HUD component type mismatch";return false;}
    if(!s.invoke(s.get_go,component,nullptr,owner,e)||!s.same(owner,go,e))return false;
    if(s.component&&s.component!=component){e="HG HUD component replaced while resources are owned";return false;}
    if(!s.root){s.root=s.host->gchandle_new(s.host->context,component,0);if(!s.root){e="HG HUD could not retain additional component";return false;}s.component=component;}
    return s.write(s.path_field,s.ui_value,"hgRenderPath.UI",e)&&s.write(s.clear_field,s.clear_value,"clearColorMode.Color",e)&&
        s.write(s.aa_field,s.aa_value,"antialiasing.None",e)&&s.write(s.alpha_field,uint8_t(1),"enableAlpha",e)&&
        s.write(s.depth_field,uint8_t(1),"clearDepth",e)&&s.write(s.dynamic_field,uint8_t(0),"allowDynamicResolution",e)&&
        s.write(s.history_field,uint8_t(0),"hasPersistentHistory",e)&&s.write(s.passthrough_field,uint8_t(0),"fullscreenPassthrough",e);
}
bool HgUiCamera::set_background(const float rgba[4],std::string& e) {
    auto& s=*impl_;if(!s.ready){e="HG HUD helper is unresolved";return false;}if(!s.present)return true;
    if(!s.root||!s.component||!rgba){e="HG HUD has no bound private component";return false;}
    std::array<float,4> wanted{};for(size_t i=0;i<4;++i){if(!std::isfinite(rgba[i])){e="HG HUD clear color must be finite";return false;}wanted[i]=rgba[i];}
    return s.write(s.color_field,wanted,"backgroundColorHDR",e);
}
bool HgUiCamera::begin_existing(void* camera,std::string& e){
    auto& s=*impl_;
    if(!s.ready||!s.present||s.root||!camera){e="Original HG UI camera not ready or restoration pending";return false;}
    void* args[]{s.additional.type_object};void* component=nullptr;
    if(!s.invoke(s.get_component,camera,args,component,e)||!component||s.object_class(component)!=s.additional.class_info){e="Original UI camera has no HG additional data";return false;}
    s.component=component;int32_t path=-1;
    if(!s.read(component,s.path_field,&path,sizeof path,e)||path!=s.ui_value){s.component=nullptr;e="Original camera is not HG UI path; overlay skipped";return false;}
    if(!s.read(component,s.clear_field,&s.saved_clear,sizeof s.saved_clear,e)||
       !s.read(component,s.color_field,&s.saved_color,sizeof s.saved_color,e)||
       !s.read(component,s.alpha_field,&s.saved_alpha,sizeof s.saved_alpha,e)||
       !s.read(component,s.passthrough_field,&s.saved_passthrough,sizeof s.saved_passthrough,e)){s.component=nullptr;return false;}
    s.root=s.host->gchandle_new(s.host->context,component,0);
    if(!s.root){s.component=nullptr;e="Cannot retain original HG UI component";return false;}
    s.existing_dirty=true; // before ANY setter; failed writes must be restored too.
    return s.write(s.clear_field,s.clear_value,"overlay clear",e)&&
           s.write(s.color_field,std::array<float,4>{0,0,0,0},"overlay background",e)&&
           s.write(s.alpha_field,uint8_t(1),"overlay alpha",e)&&
           s.write(s.passthrough_field,uint8_t(0),"overlay passthrough",e);
}
bool HgUiCamera::restore_existing(std::string& e){
    auto& s=*impl_;if(!s.existing_dirty)return true;
    // Attempt all restores even if one verification fails; retry on the next game tick.
    bool ok=true;
    ok=s.write(s.passthrough_field,s.saved_passthrough,"restore passthrough",e)&&ok;
    ok=s.write(s.alpha_field,s.saved_alpha,"restore alpha",e)&&ok;
    ok=s.write(s.color_field,s.saved_color,"restore color",e)&&ok;
    ok=s.write(s.clear_field,s.saved_clear,"restore clear",e)&&ok;
    if(ok){s.existing_dirty=false;release();}return ok;
}
bool HgUiCamera::restore_pending()const{return impl_->existing_dirty;}
void HgUiCamera::release(){auto& s=*impl_;if(s.existing_dirty)return;if(s.root&&s.host)s.host->gchandle_free(s.host->context,s.root);s.root=0;s.component=nullptr;}
bool HgUiCamera::resources_alive()const{return impl_->root!=0;}
std::string HgUiCamera::path()const{return !impl_->ready?"unresolved":impl_->present?"hg_ui_camera":"standard_canvas_camera";}
}
