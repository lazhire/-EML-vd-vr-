#include "desktop_render_filter.h"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <cstring>
#include <mutex>
#include <stdexcept>
#include <vector>

namespace vrvd {
namespace {
constexpr const char* Owner="endfield.vr.desktop";
constexpr const char* Core="UnityEngine.CoreModule.dll";
constexpr const char* Hg="HG.RenderPipelines.Runtime.dll";
constexpr int Void=1,Int32=8,Value=17,Class=18,Generic=21;
void* production_export(const char* name){const auto m=GetModuleHandleW(L"GameAssembly.dll");return m?reinterpret_cast<void*>(GetProcAddress(m,name)):nullptr;}
}
static_assert(sizeof(DesktopRenderContext)==8&&sizeof(void*)==8,"Desktop filter requires Windows x64 ABI");
struct DesktopRenderFilter::Impl {
    struct State {
        const BE_HostApiV1* host=nullptr;
        BE_ResolvedClassV1 camera{},context{},pipeline{};
        BE_ResolvedMethodV1 render{},frame{},equals{};
        const void* list=nullptr;
        const void *ctor=nullptr,*count=nullptr,*item=nullptr,*add=nullptr;
        const void*(*class_methods)(const void*,void**)=nullptr;
        const char*(*method_name)(const void*)=nullptr;
        uint32_t(*param_count)(const void*)=nullptr;
        const void*(*param_type)(const void*,uint32_t)=nullptr;
        const void*(*return_type)(const void*)=nullptr;
        int(*type_kind)(const void*)=nullptr;
        bool(*byref)(const void*)=nullptr;
        const void*(*class_from_type)(const void*)=nullptr;
        const char*(*class_name)(const void*)=nullptr;
        const char*(*class_namespace)(const void*)=nullptr;
        int32_t(*value_size)(const void*,uint32_t*)=nullptr;
        const void*(*object_class)(void*)=nullptr;
        char*(*type_name)(const void*)=nullptr;
        void(*free_string)(void*)=nullptr;
        uint32_t source_root=0;void* source=nullptr;DWORD thread=0;
        uint64_t generation=0;
        unsigned active_filters=0;
        DesktopFilterSnapshot stats;
        template<class T>bool load(T& fn,DesktopNativeResolver r,const char* name,std::string& e){fn=reinterpret_cast<T>(r(name));if(fn)return true;e="Desktop filter missing IL2CPP export: "+std::string(name);return false;}
        bool exports(DesktopNativeResolver r,std::string& e){
            return load(class_methods,r,"il2cpp_class_get_methods",e)&&load(method_name,r,"il2cpp_method_get_name",e)&&
                load(param_count,r,"il2cpp_method_get_param_count",e)&&load(param_type,r,"il2cpp_method_get_param",e)&&
                load(return_type,r,"il2cpp_method_get_return_type",e)&&load(type_kind,r,"il2cpp_type_get_type",e)&&
                load(byref,r,"il2cpp_type_is_byref",e)&&load(class_from_type,r,"il2cpp_class_from_type",e)&&
                load(class_name,r,"il2cpp_class_get_name",e)&&load(class_namespace,r,"il2cpp_class_get_namespace",e)&&
                load(value_size,r,"il2cpp_class_value_size",e)&&load(object_class,r,"il2cpp_object_get_class",e)&&
                load(type_name,r,"il2cpp_type_get_name",e)&&load(free_string,r,"il2cpp_free",e);
        }
        bool kind(const void* t,int k) const{return t&&!byref(t)&&type_kind(t)==k;}
        bool named_class(const void* c,const char* ns,const char* name) const {
            const char* n=c?class_name(c):nullptr;const char* space=c?class_namespace(c):nullptr;
            return n&&space&&!std::strcmp(n,name)&&!std::strcmp(space,ns);
        }
        bool camera_type(const void* t)const{return kind(t,Class)&&class_from_type(t)==camera.class_info;}
        bool invoke(const void* method,void* object,void** args,void*& out,std::string& e)const{
            void* exception=nullptr;out=host->runtime_invoke(host->context,method,object,args,&exception);
            if(exception){e="Desktop filter managed invocation failed; original list retained";return false;}return true;
        }
        bool integer(const void* method,void* object,int32_t& out,std::string& e)const{
            void* boxed=nullptr;if(!invoke(method,object,nullptr,boxed,e))return false;
            const auto data=boxed?host->object_unbox(host->context,boxed):nullptr;
            if(!data){e="Desktop filter integer result missing";return false;}std::memcpy(&out,data,sizeof out);return true;
        }
        bool live_source(void* accepted,std::string& e)const{
            void* args[]{accepted,nullptr};void* boxed=nullptr;if(!invoke(equals.method_info,nullptr,args,boxed,e))return false;
            const auto data=boxed?static_cast<const uint8_t*>(host->object_unbox(host->context,boxed)):nullptr;
            if(!data||*data>1){e="Desktop filter source equality invalid";return false;}
            if(*data){e="Desktop filter source Camera was destroyed";return false;}return true;
        }
        bool list_methods(std::string& e){
            void* iterator=nullptr;const void* method=nullptr;
            for(unsigned seen=0;(method=class_methods(list,&iterator));++seen){
                if(seen>1024){e="Desktop filter List method enumeration overflow";return false;}
                const auto name=method_name(method);if(!name)continue;
                const auto arity=param_count(method);const auto result=return_type(method);const void** slot=nullptr;
                if(!std::strcmp(name,".ctor")&&arity==0&&kind(result,Void))slot=&ctor;
                if(!std::strcmp(name,"get_Count")&&arity==0&&kind(result,Int32))slot=&count;
                if(!std::strcmp(name,"get_Item")&&arity==1&&kind(param_type(method,0),Int32)&&camera_type(result))slot=&item;
                if(!std::strcmp(name,"Add")&&arity==1&&camera_type(param_type(method,0))&&kind(result,Void))slot=&add;
                if(slot){if(*slot){e="Desktop filter ambiguous List method";return false;}*slot=method;}
            }
            if(!ctor||!count||!item||!add){e="Desktop filter cannot resolve closed List<Camera> operations";return false;}return true;
        }
        bool resolve(std::string& e,DesktopNativeResolver resolver){
            if(!exports(resolver?resolver:production_export,e))return false;
            const auto cls=[&](const char* a,const char* ns,const char* n,BE_ResolvedClassV1& out){
                if(host->resolve_class(host->context,a,ns,n,&out)!=BE_Result_Ok||!out.class_info){e="Desktop filter class missing: "+std::string(n);return false;}return true;};
            if(!cls(Core,"UnityEngine","Camera",camera)||!cls(Core,"UnityEngine.Rendering","ScriptableRenderContext",context)||
               !cls(Hg,"HG.Rendering.Runtime","HGRenderPipeline",pipeline))return false;
            uint32_t alignment=0;
            if(value_size(context.class_info,&alignment)!=8||!alignment||alignment>8){e="Desktop filter requires verified 8-byte ScriptableRenderContext ABI";return false;}
            const void* selected=nullptr;const void* context_type=nullptr;const void* list_type=nullptr;
            void* iterator=nullptr;const void* method=nullptr;
            for(unsigned seen=0;(method=class_methods(pipeline.class_info,&iterator));++seen){
                if(seen>2048){e="Desktop filter HG method enumeration overflow";return false;}
                const auto name=method_name(method);if(!name||std::strcmp(name,"Render")||param_count(method)!=2||!kind(return_type(method),Void))continue;
                const auto first=param_type(method,0),second=param_type(method,1);
                if(!kind(first,Value)||class_from_type(first)!=context.class_info||!kind(second,Generic))continue;
                const auto candidate=class_from_type(second);
                if(!named_class(candidate,"System.Collections.Generic","List`1"))continue;
                if(selected){e="Desktop filter ambiguous HG Render(List) overload";return false;}
                selected=method;list=candidate;context_type=first;list_type=second;
            }
            if(!selected){e="Desktop filter HG Render(List<Camera>) is unavailable";return false;}
            if(!list_methods(e))return false; // Closed item/Add signatures prove Camera, not another List<T>.
            char* first=type_name(context_type);char* second=type_name(list_type);
            std::string params;if(first&&second)params=std::string(first)+"|"+second;
            if(first)free_string(first);if(second)free_string(second);
            if(params.empty()){e="Desktop filter managed parameter names unavailable";return false;}
            BE_MethodDescriptorV1 descriptor{Hg,"HG.Rendering.Runtime","HGRenderPipeline","Render",params.c_str(),"System.Void",2};
            if(host->resolve_method(host->context,&descriptor,&render)!=BE_Result_Ok||render.method_info!=selected||!render.method_pointer){e="Desktop filter HG native Render identity could not be verified";return false;}
            BE_MethodDescriptorV1 frame_desc{Core,"UnityEngine","Time","get_frameCount",nullptr,"System.Int32",0};
            BE_MethodDescriptorV1 equals_desc{Core,"UnityEngine","Object","op_Equality","UnityEngine.Object|UnityEngine.Object","System.Boolean",2};
            if(host->resolve_method(host->context,&frame_desc,&frame)!=BE_Result_Ok||!frame.method_info||
               host->resolve_method(host->context,&equals_desc,&equals)!=BE_Result_Ok||!equals.method_info){e="Desktop filter frame/source validation methods missing";return false;}
            return true;
        }
    };
    struct Root {
        const BE_HostApiV1* host=nullptr;void* object=nullptr;uint32_t handle=0;
        ~Root(){if(handle)host->gchandle_free(host->context,handle);}
    };
    std::shared_ptr<State> state=std::make_shared<State>();
    inline static std::mutex mutex;
    inline static std::shared_ptr<State> owner;
    // The chain's trampoline slot must outlive every callback and reinstall.
    inline static void* next_render=nullptr;
    static bool current(const std::shared_ptr<State>& s,uint64_t generation){return owner==s&&s->stats.installed&&s->stats.armed&&s->generation==generation&&s->thread==GetCurrentThreadId();}
    static bool clone_without_source(State& s,void* source,void* input,Root& clone,uint32_t& removed,int32_t& remaining,std::string& e){
        removed=0;if(!input||s.object_class(input)!=s.list){e="Desktop filter received an unexpected camera collection";return false;}
        int32_t count=0;if(!s.integer(s.count,input,count,e))return false;
        if(count<0||count>256){e="Desktop filter camera count exceeds bounded copy limit";return false;}
        std::vector<void*> cameras; cameras.reserve(size_t(count));
        for(int32_t i=0;i<count;++i){void* args[]{&i};void* camera=nullptr;if(!s.invoke(s.item,input,args,camera,e))return false;cameras.push_back(camera);if(camera==source)++removed;}
        if(!removed)return true;
        clone.host=s.host;clone.object=s.host->object_new(s.host->context,s.list);
        if(!clone.object||(clone.handle=s.host->gchandle_new(s.host->context,clone.object,0))==0){e="Desktop filter could not retain a cloned camera list";return false;}
        void* ignored=nullptr;if(!s.invoke(s.ctor,clone.object,nullptr,ignored,e))return false;
        for(void* camera:cameras)if(camera!=source){void* args[]{camera};if(!s.invoke(s.add,clone.object,args,ignored,e))return false;}
        int32_t copied=0,after=0;
        if(!s.integer(s.count,clone.object,copied,e)||copied!=count-int32_t(removed)||!s.integer(s.count,input,after,e)||after!=count){e="Desktop filter list changed during cloning";return false;}
        for(int32_t i=0;i<count;++i){void* args[]{&i};void* actual=nullptr;if(!s.invoke(s.item,input,args,actual,e)||actual!=cameras[size_t(i)]){e="Desktop filter original camera list changed during cloning";return false;}}
        remaining=copied;return true;
    }
    static void render(void* pipeline,DesktopRenderContext context,void* cameras,const void* method){
        DesktopRenderNative next=nullptr;std::shared_ptr<State> s;uint64_t generation=0;void* source=nullptr;int32_t submitted=-1;
        {std::lock_guard<std::mutex> lock(mutex);next=reinterpret_cast<DesktopRenderNative>(next_render);
            if(owner&&owner->stats.installed){++owner->stats.calls;
                if(owner->stats.armed&&owner->thread==GetCurrentThreadId()){s=owner;generation=s->generation;source=s->source;submitted=s->stats.submitted_frame;++s->active_filters;}
                else ++owner->stats.pass_through_calls;}}
        if(!next)throw std::runtime_error("Desktop render filter lacks its original trampoline");
        // Prevent a reentrant stop from freeing the source root while managed
        // List calls are in flight. clear() will be retried on the game thread.
        struct Active {std::shared_ptr<State> s;~Active(){if(s){std::lock_guard<std::mutex> lock(mutex);--s->active_filters;}}} active{s};
        Root clone;uint32_t removed=0;int32_t remaining=0;bool filtered=false;std::string error;
        if(s){
            try{
                int32_t frame=0;
                if(!s->integer(s->frame.method_info,nullptr,frame,error)){}
                else if(frame!=submitted){error="";}
                else if(!s->live_source(source,error)){}
                else if(clone_without_source(*s,source,cameras,clone,removed,remaining,error)&&removed){
                    std::lock_guard<std::mutex> lock(mutex);
                    filtered=current(s,generation);
                    if(filtered){++s->stats.filtered_calls;s->stats.filtered_cameras+=removed;
                        if(!remaining)++s->stats.empty_lists;
                        s->stats.status="filtering_submitted_frame";s->stats.error.clear();}
                }
            }catch(const std::exception& ex){error=ex.what();}catch(...){error="Desktop filter clone exception; using original cameras";}
            {std::lock_guard<std::mutex> lock(mutex);if(!filtered){++s->stats.pass_through_calls;if(!error.empty()){
                ++s->stats.contract_failures;s->stats.error=error;s->stats.status="pass_through_after_failure";
                s->stats.armed=false;++s->generation; // A fresh successful submission must explicitly re-arm.
            }}}
        }
        // Forward the context bits, this, MethodInfo and every other camera.
        // Empty cloned lists are intentionally forwarded: the audited HG code
        // performs its own early-return/cleanup path. Native audit (current
        // client): regular List._size == 0 branch at RVA 0x5513510 -> 0x5517977
        // -> Render epilogue; SimpleUI's empty enumeration does the same.
        // Never synthesize Prepare
        // false, skip the whole pipeline call, or mutate the input list.
        next(pipeline,context,filtered?clone.object:cameras,method);
    }
};
DesktopRenderFilter::DesktopRenderFilter():impl_(new Impl){}
DesktopRenderFilter::~DesktopRenderFilter(){disable();}
bool DesktopRenderFilter::install(const BE_HostApiV1* host,std::string& error,DesktopNativeResolver resolver){
    error.clear();auto s=impl_->state;
    {std::lock_guard<std::mutex> lock(Impl::mutex);if(s->stats.installed||s->source_root||s->active_filters){error="Desktop filter must shut down before reinstall";return false;}
        if(Impl::owner){error="Another desktop filter owns the route";return false;}
        s=std::make_shared<Impl::State>();impl_->state=s;}
    if(!host||!host->resolve_class||!host->resolve_method||!host->runtime_invoke||!host->object_unbox||!host->object_new||
       !host->gchandle_new||!host->gchandle_free||!host->create_hook||!host->release_module_hooks){error="Desktop filter requires a complete host API";return false;}
    s->host=host;if(!s->resolve(error,resolver)){std::lock_guard<std::mutex> lock(Impl::mutex);s->stats.status="unavailable";s->stats.error=error;return false;}
    {std::lock_guard<std::mutex> lock(Impl::mutex);if(Impl::owner&&Impl::owner!=s){error="Another desktop filter owns the route";return false;}Impl::owner=s;}
    const auto result=host->create_hook(host->context,Owner,s->render.method_pointer,reinterpret_cast<void*>(Impl::render),&Impl::next_render);
    if(result!=BE_Result_Ok||!Impl::next_render){
        if(result==BE_Result_Ok)host->release_module_hooks(host->context,Owner);
        std::lock_guard<std::mutex> lock(Impl::mutex);s->stats.status="unavailable";s->stats.error=error="Desktop filter hook could not be installed";if(Impl::owner==s)Impl::owner.reset();return false;}
    {std::lock_guard<std::mutex> lock(Impl::mutex);
        s->stats.installed=true;s->stats.status="ready_pass_through";}
    return true;
}
bool DesktopRenderFilter::mark_submitted(void* source,int32_t frame,std::string& error){
    error.clear();auto s=impl_->state;uint64_t generation=0;bool changed=false;
    {std::lock_guard<std::mutex> lock(Impl::mutex);if(!s->stats.installed||Impl::owner!=s){error="Desktop filter is not installed";return false;}
        s->stats.armed=false;generation=++s->generation;s->stats.status="ready_pass_through";
        if(s->active_filters||(s->thread&&s->thread!=GetCurrentThreadId())){error="Desktop filter source is busy or belongs to another game thread";return false;}
        changed=s->source!=source;}
    if(!source||s->object_class(source)!=s->camera.class_info){error="Desktop filter requires the accepted source Camera";return false;}
    int32_t actual=0;if(!s->integer(s->frame.method_info,nullptr,actual,error)||actual!=frame){if(error.empty())error="Desktop filter submission frame is stale";return false;}
    uint32_t fresh=0;
    if(changed&&(fresh=s->host->gchandle_new(s->host->context,source,0))==0){error="Desktop filter source GC root failed";return false;}
    uint32_t previous=0;bool accepted=false;
    {std::lock_guard<std::mutex> lock(Impl::mutex);
        accepted=Impl::owner==s&&s->stats.installed&&s->generation==generation&&!s->active_filters;
        if(accepted){if(changed){previous=s->source_root;s->source_root=fresh;s->source=source;}
            s->thread=GetCurrentThreadId();s->stats.submitted_frame=frame;s->stats.armed=true;++s->generation;s->stats.status="armed_for_submitted_frame";s->stats.error.clear();}}
    if(!accepted){if(fresh)s->host->gchandle_free(s->host->context,fresh);error="Desktop filter submission was cancelled during validation";return false;}
    if(previous)s->host->gchandle_free(s->host->context,previous);return true;
}
void DesktopRenderFilter::disable(){std::lock_guard<std::mutex> lock(Impl::mutex);auto& s=*impl_->state;s.stats.armed=false;++s.generation;if(s.stats.installed)s.stats.status="ready_pass_through";}
bool DesktopRenderFilter::clear(){
    disable();auto s=impl_->state;uint32_t root=0;
    {std::lock_guard<std::mutex> lock(Impl::mutex);if(s->active_filters||(s->source_root&&s->thread!=GetCurrentThreadId()))return false;
        root=s->source_root;s->source_root=0;s->source=nullptr;s->thread=0;s->stats.submitted_frame=-1;}
    if(root)s->host->gchandle_free(s->host->context,root);return true;
}
bool DesktopRenderFilter::shutdown(){
    if(!clear())return false;auto s=impl_->state;
    bool installed=false;{std::lock_guard<std::mutex> lock(Impl::mutex);installed=s->stats.installed;}
    if(installed&&s->host->release_module_hooks(s->host->context,Owner)!=BE_Result_Ok)return false;
    {std::lock_guard<std::mutex> lock(Impl::mutex);s->stats.installed=false;s->stats.status="disabled";if(Impl::owner==s)Impl::owner.reset();}return true;
}
bool DesktopRenderFilter::resources_alive()const{std::lock_guard<std::mutex> lock(Impl::mutex);return impl_->state->source_root!=0;}
DesktopFilterSnapshot DesktopRenderFilter::snapshot()const{std::lock_guard<std::mutex> lock(Impl::mutex);return impl_->state->stats;}
}
