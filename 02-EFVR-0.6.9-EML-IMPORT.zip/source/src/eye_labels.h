#pragma once
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace vrvd {
namespace eye_labels_detail {
struct Rgb {uint8_t r,g,b;};
inline const char* glyph(char c){
    switch(c){
        case 'L':return "10000100001000010000100001000011111";
        case 'R':return "11110100011000111110101001001010001";
        case 'N':return "10001110011010110101100111000110001";
        case 'O':return "01110100011000110001100011000101110";
        case 'M':return "10001110111010110101100011000110001";
        case 'A':return "01110100011000111111100011000110001";
        case 'S':return "01111100001000001110000010000111110";
        case 'W':return "10001100011000110101101011101110001";
        case 'P':return "11110100011000111110100001000010000";
        case 'E':return "11111100001000011110100001000011111";
        case 'D':return "11110100011000110001100011000111110";
        default:return "00000000000000000000000000000000000";
    }
}
inline void pixel(uint8_t* rgba,uint32_t width,uint32_t height,int x,int y,Rgb color){
    if(x<0||y<0||x>=int(width)||y>=int(height))return;
    const size_t at=(size_t(y)*width+uint32_t(x))*4;
    rgba[at]=color.r;rgba[at+1]=color.g;rgba[at+2]=color.b;rgba[at+3]=255;
}
inline void label(uint8_t* rgba,uint32_t width,uint32_t height,const char* text,int y,int scale,Rgb color){
    int x=(int(width)-(int(std::strlen(text))*6-1)*scale)/2;
    for(const char* p=text;*p;++p,x+=6*scale){const char* bits=glyph(*p);
        for(int row=0;row<7;++row)for(int col=0;col<5;++col)if(bits[row*5+col]=='1')
            for(int dy=0;dy<scale;++dy)for(int dx=0;dx<scale;++dx)
                pixel(rgba,width,height,x+col*scale+dx,y+row*scale+dy,color);
    }
}
} // namespace eye_labels_detail

// Diagnostic overlay only. Caller supplies width*height*4 accessible bytes,
// tightly packed linear RGBA8 with TOP-LEFT row origin. No allocation, graphics
// APIs, eye remapping or pose changes are performed. source_eye is 0=L, 1=R.
// Call AFTER readback and BEFORE optional image routing: L/R identifies the
// SOURCE image, so the letter travels with its pixels if those pixels are swapped.
// The SWAPPED/NORMAL word is only a routing-state hint, not a correction.
inline void annotate_eye_rgba(uint8_t* rgba,uint32_t width,uint32_t height,unsigned source_eye,bool swapped){
    if(!rgba||!width||!height||width>16384||height>16384||source_eye>1)return;
    using namespace eye_labels_detail;
    const int dimension=int(std::min(width,height));
    const int letter_scale=std::max(2,dimension/96),mode_scale=std::max(1,dimension/256);
    const int y=int(height)/10,panel_height=7*letter_scale+3+7*mode_scale;
    const int panel_width=std::max(7*6*mode_scale,7*letter_scale);
    for(int row=y-3;row<y+panel_height+3;++row)
        for(int col=(int(width)-panel_width)/2-3;col<(int(width)+panel_width)/2+3;++col)
            pixel(rgba,width,height,col,row,{8,8,8});
    label(rgba,width,height,source_eye?"R":"L",y,letter_scale,source_eye?Rgb{255,51,255}:Rgb{26,255,255});
    label(rgba,width,height,swapped?"SWAPPED":"NORMAL",y+7*letter_scale+3,mode_scale,swapped?Rgb{255,38,8}:Rgb{255,255,255});
}
} // namespace vrvd
