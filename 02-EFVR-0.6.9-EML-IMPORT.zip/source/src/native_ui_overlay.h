#pragma once
#include "managed_read.h"
#include "hg_ui_camera.h"
#include "menu_overlay_pixels.h"
namespace vrvd {
// Renders the original UI camera into an owned target. Does not reparent Canvas,
// change any UI transform/layer, synthesize input, or copy the desktop/final frame.
// Camera.Render and HG UI replay support remain an in-game acceptance requirement.
class NativeUiOverlay:private ManagedRead {
 BE_ResolvedMethodV1 uiCamera{},component{},target{},setTarget{},active{},setActive{},pixelW{},pixelH{},
  clearFlags{},setClearFlags{},background{},setBackground{},render{},rtCtor{},rtCreate{},rtRelease{},
  texCtor{},destroy{},blit{},readPixels{},raw{},length{},copy{},preclear{};
 BE_ResolvedClassV1 rtClass{},texClass{};
 Root camera,oldTarget,oldActive,sceneRT,smallRT,cpu;
 HgUiCamera hg;
 struct Color{float r,g,b,a;};
 Color savedColor{};int savedFlags=0;
 bool ready=false,dirty=false,activeDirty=false,imagesReady=false;
 unsigned sourceW=0,sourceH=0,outW=0,outH=0;
 bool create_images(unsigned sw,unsigned sh,unsigned w,unsigned h,std::string& e){
  if(imagesReady&&sw==sourceW&&sh==sourceH&&w==outW&&h==outH)return true;
  if(!free_images(e))return false;
  sourceW=sw;sourceH=sh;outW=w;outH=h;
  auto makeRT=[&](Root& r,unsigned width,unsigned height,int depth){
   int iw=width,ih=height,fmt=0,linear=1;uint8_t yes=0;
   if(!r.set(host,host->object_new(host->context,rtClass.class_info))||!r.p){e="Cannot allocate UI render target";return false;}
   void* args[]{&iw,&ih,&depth,&fmt,&linear};
   return call(rtCtor,r.p,args,e)&&value(rtCreate,r.p,yes,e)&&yes==1;
  };
  if(!makeRT(sceneRT,sw,sh,24)||!makeRT(smallRT,w,h,0))return false;
  if(!cpu.set(host,host->object_new(host->context,texClass.class_info))||!cpu.p)return false;
  int iw=w,ih=h,fmt=4;uint8_t no=0,yes=1;void* a[]{&iw,&ih,&fmt,&no,&yes};
  imagesReady=call(texCtor,cpu.p,a,e);return imagesReady;
 }
 bool free_images(std::string& e){
  if(restore_pending()){e="UI restoration pending; textures retained";return false;}
  for(auto* r:{&sceneRT,&smallRT})if(r->p){void* a[]{r->p};if(!call(rtRelease,r->p,nullptr,e)||!call(destroy,nullptr,a,e))return false;r->clear();}
  if(cpu.p){void* a[]{cpu.p};if(!call(destroy,nullptr,a,e))return false;cpu.clear();}
  imagesReady=false;sourceW=sourceH=outW=outH=0;return true;
 }
 bool set_ref(const BE_ResolvedMethodV1& m,void* obj,void* v,std::string& e){void* a[]{v};return call(m,obj,a,e);}
 template<class T>bool set_value(const BE_ResolvedMethodV1& m,void* obj,T& v,std::string& e){void* a[]{&v};return call(m,obj,a,e);}
 bool verify_capture_target(std::string& e){
  void* actual=nullptr;int flags=0;Color color{};
  if(!invoke(target,camera.p,nullptr,actual,e)||actual!=sceneRT.p||
     !value(clearFlags,camera.p,flags,e)||flags!=2||
     !value(background,camera.p,color,e)||color.r!=0||color.g!=0||color.b!=0||color.a!=0){
   e="Original UI target/clear readback mismatch; camera render refused";return false;
  }return true;
 }
 bool read_image(std::vector<uint8_t>& bytes,std::string& e){
  void* a[]{sceneRT.p,smallRT.p};
  if(!call(blit,nullptr,a,e)||!set_ref(setActive,nullptr,smallRT.p,e))return false;
  struct Rect{float x,y,w,h;} r{0,0,float(outW),float(outH)};int zero=0;uint8_t no=0;
  void* rd[]{&r,&zero,&zero,&no};void* array=nullptr;Root hold;int count=0;
  if(!call(readPixels,cpu.p,rd,e)||!invoke(raw,cpu.p,nullptr,array,e)||!array||!hold.set(host,array)||!value(length,array,count,e)||count!=int(size_t(outW)*outH*4)){e="Native UI readback size mismatch";return false;}
  bytes.resize(count);intptr_t p=reinterpret_cast<intptr_t>(bytes.data());void* cp[]{array,&zero,&p,&count};return call(copy,nullptr,cp,e);
 }
public:
 std::string status="not_resolved";
 uint64_t attempts=0,frames=0;
 ~NativeUiOverlay(){camera.abandon();oldTarget.abandon();oldActive.abandon();sceneRT.abandon();smallRT.abandon();cpu.abandon();}
 bool resolve(const BE_HostApiV1* api,std::string& e){
  if(ready)return true;host=api;
  const char* core="UnityEngine.CoreModule.dll";
  auto b=[&](BE_ResolvedMethodV1& m,const char* cls,const char* name,const char* args,const char* ret,unsigned n){return bind(m,core,"UnityEngine",cls,name,args,ret,n,e);};
  ready=bind(uiCamera,"Gameplay.Beyond.dll","Beyond.Gameplay.View","CameraManager","get_uiCamera",nullptr,"UnityEngine.Camera",0,e)&&
   b(target,"Camera","get_targetTexture",nullptr,"UnityEngine.RenderTexture",0)&&b(setTarget,"Camera","set_targetTexture","UnityEngine.RenderTexture","System.Void",1)&&
   b(active,"RenderTexture","get_active",nullptr,"UnityEngine.RenderTexture",0)&&b(setActive,"RenderTexture","set_active","UnityEngine.RenderTexture","System.Void",1)&&
   b(pixelW,"Camera","get_pixelWidth",nullptr,"System.Int32",0)&&b(pixelH,"Camera","get_pixelHeight",nullptr,"System.Int32",0)&&
   b(clearFlags,"Camera","get_clearFlags",nullptr,"UnityEngine.CameraClearFlags",0)&&b(setClearFlags,"Camera","set_clearFlags","UnityEngine.CameraClearFlags","System.Void",1)&&
   b(background,"Camera","get_backgroundColor",nullptr,"UnityEngine.Color",0)&&b(setBackground,"Camera","set_backgroundColor","UnityEngine.Color","System.Void",1)&&
   b(render,"Camera","Render",nullptr,"System.Void",0)&&
   b(rtCtor,"RenderTexture",".ctor","System.Int32|System.Int32|System.Int32|UnityEngine.RenderTextureFormat|UnityEngine.RenderTextureReadWrite","System.Void",5)&&
   b(rtCreate,"RenderTexture","Create",nullptr,"System.Boolean",0)&&b(rtRelease,"RenderTexture","Release",nullptr,"System.Void",0)&&
   b(texCtor,"Texture2D",".ctor","System.Int32|System.Int32|UnityEngine.TextureFormat|System.Boolean|System.Boolean","System.Void",5)&&
   b(destroy,"Object","Destroy","UnityEngine.Object","System.Void",1)&&b(blit,"Graphics","Blit","UnityEngine.Texture|UnityEngine.RenderTexture","System.Void",2)&&
   b(readPixels,"Texture2D","ReadPixels","UnityEngine.Rect|System.Int32|System.Int32|System.Boolean","System.Void",4)&&b(raw,"Texture2D","GetRawTextureData",nullptr,"System.Byte[]",0)&&
   b(preclear,"GL","Clear","System.Boolean|System.Boolean|UnityEngine.Color","System.Void",3)&&
   bind(length,"mscorlib.dll","System","Array","get_Length",nullptr,"System.Int32",0,e)&&bind(copy,"mscorlib.dll","System.Runtime.InteropServices","Marshal","Copy","System.Byte[]|System.Int32|System.IntPtr|System.Int32","System.Void",4,e)&&
   api->resolve_class(api->context,core,"UnityEngine","RenderTexture",&rtClass)==BE_Result_Ok&&api->resolve_class(api->context,core,"UnityEngine","Texture2D",&texClass)==BE_Result_Ok&&hg.resolve(api,nullptr,e);
  if(!ready){status="binding_unavailable";if(e.empty())e="Native UI overlay binding failed";}return ready;
 }
 bool restore(std::string& e){
  bool ok=hg.restore_existing(e);
  if(dirty){
   bool restored=true;
   restored=set_ref(setTarget,camera.p,oldTarget.p,e)&&restored;
   restored=set_value(setBackground,camera.p,savedColor,e)&&restored;
   restored=set_value(setClearFlags,camera.p,savedFlags,e)&&restored;
   // Verify original target was restored, including the null/backbuffer case.
   void* actual=nullptr;restored=invoke(target,camera.p,nullptr,actual,e)&&actual==oldTarget.p&&restored;
   Color color{};int flags=0;
   restored=value(background,camera.p,color,e)&&std::memcmp(&color,&savedColor,sizeof color)==0&&restored;
   restored=value(clearFlags,camera.p,flags,e)&&flags==savedFlags&&restored;
   if(restored){dirty=false;camera.clear();oldTarget.clear();}else ok=false;
  }
  if(activeDirty){void* actual=nullptr;if(set_ref(setActive,nullptr,oldActive.p,e)&&invoke(active,nullptr,nullptr,actual,e)&&actual==oldActive.p){activeDirty=false;oldActive.clear();}else ok=false;}
  return ok;
 }
 bool capture(void* manager,unsigned w,unsigned h,std::vector<uint8_t>& result,std::string& e){
  result.clear();++attempts;
  if(!ready||!manager){e="Waiting for original UI camera";status="waiting_ui_camera";return false;}
  if(!restore(e))return false;
  void* c=nullptr;void* old=nullptr;int sw=0,sh=0;
  bool ok=invoke(uiCamera,manager,nullptr,c,e)&&c&&camera.set(host,c)&&
   value(pixelW,c,sw,e)&&value(pixelH,c,sh,e)&&sw>0&&sh>0&&sw<=8192&&sh<=8192&&
   invoke(target,c,nullptr,old,e)&&oldTarget.set(host,old)&&value(clearFlags,c,savedFlags,e)&&value(background,c,savedColor,e);
  if(ok)ok=create_images(sw,sh,w,h,e);
  if(ok)ok=invoke(active,nullptr,nullptr,old,e)&&oldActive.set(host,old);
  std::vector<uint8_t> pixels;
  if(ok){
   activeDirty=true;dirty=true;
   // RAII guarantees restoration even if C++ allocation or vector operations throw.
   struct RestoreScope{NativeUiOverlay& owner;~RestoreScope(){std::string ignored;owner.restore(ignored);}} scope{*this};
   Color clear{0,0,0,0};int flags=2;uint8_t yes=1;void* clearArgs[]{&yes,&yes,&clear};
   ok=hg.begin_existing(c,e)&&set_ref(setTarget,c,sceneRT.p,e)&&set_value(setClearFlags,c,flags,e)&&set_value(setBackground,c,clear,e)&&
      verify_capture_target(e)&&set_ref(setActive,nullptr,sceneRT.p,e)&&call(preclear,nullptr,clearArgs,e)&&call(render,c,nullptr,e)&&read_image(pixels,e);
  }
  std::string re;bool restored=restore(re);
  if(!restored){e="Original UI camera restoration pending: "+re;status="restoration_pending";return false;}
  camera.clear();oldTarget.clear();oldActive.clear();
  if(!ok){status="capture_unavailable";if(e.empty())e="Original UI camera unavailable";return false;}
  if(!prepare_menu_overlay(pixels,w,h,sw,sh,result,e)){status="invalid_rgba_hidden";return false;}
  ++frames;status="rgba_captured_needs_visual_check";return true;
 }
 bool cleanup(std::string& e){return restore(e)&&free_images(e);}
 bool restore_pending()const{return dirty||activeDirty||hg.restore_pending();}
 bool resources_alive()const{return restore_pending()||sceneRT.p||smallRT.p||cpu.p;}
 unsigned source_width()const{return sourceW;}
 unsigned source_height()const{return sourceH;}
 void reset_bindings(){if(!resources_alive())ready=false;}
};
}
