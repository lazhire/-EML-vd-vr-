#pragma once
#include <cstdint>
namespace vrvd {
// Separate from camera callbacks; never guess a Unity thread from a Time getter.
inline bool may_pump_menu(uint32_t known_main,uint32_t current,bool live,bool inside_clock,bool inside_camera){
 return live&&known_main!=0&&known_main==current&&!inside_clock&&!inside_camera;
}
// Static UI may produce no new WGC frame. Neither image age nor child-panel changes invalidate a completed window image.
inline bool may_present_menu(bool has_pixels,bool source_available){
 return has_pixels&&source_available;
}
}
