#include "unity_hud.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <exception>
#include <unordered_set>
#include <utility>

namespace vrvd {
namespace {
constexpr const char* Core="UnityEngine.CoreModule.dll";
constexpr const char* Ui="UnityEngine.UIModule.dll";
constexpr const char* Owner="quest3.vrvd";
struct V2 {float x,y;}; struct V3 {float x,y,z;};
struct Q4 {float x,y,z,w;}; struct Rect {float x,y,w,h;};
struct Color {float r,g,b,a;};
struct Binding {const char* klass;const char* name;const char* params;const char* result;uint32_t count;const char* assembly=Core;const char* ns="UnityEngine";};
}

struct UnityHud::Impl {
    enum M {
        Find,FindAll,ArrayLength,ArrayGet,Equals,Destroy,Hide,GoCtor,AddComponent,ComponentGo,ComponentTransform,
        Layer,SetLayer,Active,Enabled,SetEnabled,ChildCount,Child,GetComponent,
        CanvasRoot,CanvasMode,SetCanvasMode,CanvasCamera,SetCanvasCamera,CanvasDistance,SetCanvasDistance,ForceCanvas,
        LocalPosition,SetLocalPosition,LocalRotation,SetLocalRotation,LocalScale,SetLocalScale,
        AnchorMin,SetAnchorMin,AnchorMax,SetAnchorMax,Anchored,SetAnchored,Size,SetSize,Pivot,SetPivot,
        ClearFlags,Background,Culling,Orthographic,OrthoSize,Aspect,Near,Far,Hdr,Msaa,Occlusion,Target,Render,
        RtCtor,RtCreate,RtRelease,RtAA,RtMip,RtAutoMip,RtFormat,SetRtFormat,RtSrgb,GetActive,SetActive,
        TexCtor,ReadPixels,Raw,TexFormat,TexMips,TexSrgb,TexGraphicsFormat,Copy,Preclear,Count
    };
    inline static const Binding bindings[Count]{
        {"Object","FindObjectsOfType","System.Type","UnityEngine.Object[]",1},
        {"Resources","FindObjectsOfTypeAll","System.Type","UnityEngine.Object[]",1},
        {"Array","get_Length",nullptr,"System.Int32",0,"mscorlib.dll","System"},
        {"Array","GetValue","System.Int32","System.Object",1,"mscorlib.dll","System"},
        {"Object","op_Equality","UnityEngine.Object|UnityEngine.Object","System.Boolean",2},
        {"Object","Destroy","UnityEngine.Object","System.Void",1},
        {"Object","set_hideFlags","UnityEngine.HideFlags","System.Void",1},
        {"GameObject",".ctor","System.String","System.Void",1},
        {"GameObject","AddComponent","System.Type","UnityEngine.Component",1},
        {"Component","get_gameObject",nullptr,"UnityEngine.GameObject",0},
        {"Component","get_transform",nullptr,"UnityEngine.Transform",0},
        {"GameObject","get_layer",nullptr,"System.Int32",0},
        {"GameObject","set_layer","System.Int32","System.Void",1},
        {"GameObject","get_activeInHierarchy",nullptr,"System.Boolean",0},
        {"Behaviour","get_isActiveAndEnabled",nullptr,"System.Boolean",0},
        {"Behaviour","set_enabled","System.Boolean","System.Void",1},
        {"Transform","get_childCount",nullptr,"System.Int32",0},
        {"Transform","GetChild","System.Int32","UnityEngine.Transform",1},
        {"Component","GetComponent","System.Type","UnityEngine.Component",1},
        {"Canvas","get_isRootCanvas",nullptr,"System.Boolean",0,Ui},
        {"Canvas","get_renderMode",nullptr,"UnityEngine.RenderMode",0,Ui},
        {"Canvas","set_renderMode","UnityEngine.RenderMode","System.Void",1,Ui},
        {"Canvas","get_worldCamera",nullptr,"UnityEngine.Camera",0,Ui},
        {"Canvas","set_worldCamera","UnityEngine.Camera","System.Void",1,Ui},
        {"Canvas","get_planeDistance",nullptr,"System.Single",0,Ui},
        {"Canvas","set_planeDistance","System.Single","System.Void",1,Ui},
        {"Canvas","ForceUpdateCanvases",nullptr,"System.Void",0,Ui},
        {"Transform","get_localPosition",nullptr,"UnityEngine.Vector3",0},
        {"Transform","set_localPosition","UnityEngine.Vector3","System.Void",1},
        {"Transform","get_localRotation",nullptr,"UnityEngine.Quaternion",0},
        {"Transform","set_localRotation","UnityEngine.Quaternion","System.Void",1},
        {"Transform","get_localScale",nullptr,"UnityEngine.Vector3",0},
        {"Transform","set_localScale","UnityEngine.Vector3","System.Void",1},
        {"RectTransform","get_anchorMin",nullptr,"UnityEngine.Vector2",0},
        {"RectTransform","set_anchorMin","UnityEngine.Vector2","System.Void",1},
        {"RectTransform","get_anchorMax",nullptr,"UnityEngine.Vector2",0},
        {"RectTransform","set_anchorMax","UnityEngine.Vector2","System.Void",1},
        {"RectTransform","get_anchoredPosition",nullptr,"UnityEngine.Vector2",0},
        {"RectTransform","set_anchoredPosition","UnityEngine.Vector2","System.Void",1},
        {"RectTransform","get_sizeDelta",nullptr,"UnityEngine.Vector2",0},
        {"RectTransform","set_sizeDelta","UnityEngine.Vector2","System.Void",1},
        {"RectTransform","get_pivot",nullptr,"UnityEngine.Vector2",0},
        {"RectTransform","set_pivot","UnityEngine.Vector2","System.Void",1},
        {"Camera","set_clearFlags","UnityEngine.CameraClearFlags","System.Void",1},
        {"Camera","set_backgroundColor","UnityEngine.Color","System.Void",1},
        {"Camera","set_cullingMask","System.Int32","System.Void",1},
        {"Camera","set_orthographic","System.Boolean","System.Void",1},
        {"Camera","set_orthographicSize","System.Single","System.Void",1},
        {"Camera","set_aspect","System.Single","System.Void",1},
        {"Camera","set_nearClipPlane","System.Single","System.Void",1},
        {"Camera","set_farClipPlane","System.Single","System.Void",1},
        {"Camera","set_allowHDR","System.Boolean","System.Void",1},
        {"Camera","set_allowMSAA","System.Boolean","System.Void",1},
        {"Camera","set_useOcclusionCulling","System.Boolean","System.Void",1},
        {"Camera","set_targetTexture","UnityEngine.RenderTexture","System.Void",1},
        {"Camera","Render",nullptr,"System.Void",0},
        {"RenderTexture",".ctor","System.Int32|System.Int32|System.Int32|UnityEngine.RenderTextureFormat|UnityEngine.RenderTextureReadWrite","System.Void",5},
        {"RenderTexture","Create",nullptr,"System.Boolean",0},
        {"RenderTexture","Release",nullptr,"System.Void",0},
        {"RenderTexture","set_antiAliasing","System.Int32","System.Void",1},
        {"RenderTexture","set_useMipMap","System.Boolean","System.Void",1},
        {"RenderTexture","set_autoGenerateMips","System.Boolean","System.Void",1},
        {"RenderTexture","get_graphicsFormat",nullptr,"UnityEngine.Experimental.Rendering.GraphicsFormat",0},
        {"RenderTexture","set_graphicsFormat","UnityEngine.Experimental.Rendering.GraphicsFormat","System.Void",1},
        {"RenderTexture","get_sRGB",nullptr,"System.Boolean",0},
        {"RenderTexture","get_active",nullptr,"UnityEngine.RenderTexture",0},
        {"RenderTexture","set_active","UnityEngine.RenderTexture","System.Void",1},
        {"Texture2D",".ctor","System.Int32|System.Int32|UnityEngine.TextureFormat|System.Boolean|System.Boolean","System.Void",5},
        {"Texture2D","ReadPixels","UnityEngine.Rect|System.Int32|System.Int32|System.Boolean","System.Void",4},
        {"Texture2D","GetRawTextureData",nullptr,"System.Byte[]",0},
        {"Texture2D","get_format",nullptr,"UnityEngine.TextureFormat",0},
        {"Texture","get_mipmapCount",nullptr,"System.Int32",0},
        {"Texture","get_isDataSRGB",nullptr,"System.Boolean",0},
        {"Texture","get_graphicsFormat",nullptr,"UnityEngine.Experimental.Rendering.GraphicsFormat",0},
        {"Marshal","Copy","System.Byte[]|System.Int32|System.IntPtr|System.Int32","System.Void",4,"mscorlib.dll","System.Runtime.InteropServices"},
        {"GL","Clear","System.Boolean|System.Boolean|UnityEngine.Color","System.Void",3}
    };
    const BE_HostApiV1* host=nullptr;
    std::array<BE_ResolvedMethodV1,Count> methods{};
    BE_ResolvedClassV1 canvasClass{},goClass{},cameraClass{},rtClass{},texClass{},rectClass{},rendererClass{};
    struct Ref {void* p=nullptr;uint32_t h=0;};
    struct CanvasState {Ref canvas,camera,transform;int32_t mode=0;float distance=0;bool changed=false;};
    struct NodeState {
        Ref go,transform;int32_t layer=0;bool rect=false,changed=false,capture=true;
        V3 position{},scale{};Q4 rotation{};V2 min{},max{},anchored{},size{},pivot{};
    };
    std::vector<CanvasState> canvases;
    std::vector<NodeState> nodes;
    Ref go,camera,rt,tex,savedActive;
    bool activePending=false,ready=false,dirty=false;
    uint32_t width=0,height=0,captured=0,skipped=0;
    HgUiCamera hg;
    std::string captureWarning;
    bool opaqueOutput=false;
    void warn(const std::string& text){if(!captureWarning.empty())captureWarning+="; ";captureWarning+=text;}

    void log(const std::string& e){if(host&&host->log)host->log(host->context,Owner,e.c_str());}
    bool invoke(M m,void* obj,void** args,void*& result,std::string& error) {
        if(!host||!methods[m].method_info){error="HUD binding unavailable: "+std::string(bindings[m].name);return false;}
        void* exception=nullptr;result=host->runtime_invoke(host->context,methods[m].method_info,obj,args,&exception);
        if(exception){error="HUD managed exception: "+std::string(bindings[m].klass)+"."+bindings[m].name;return false;}return true;
    }
    bool call(M m,void* obj,void** args,std::string& e){void* ignored=nullptr;return invoke(m,obj,args,ignored,e);}
    template<class T> bool value(M m,void* obj,T& out,std::string& e,void** args=nullptr){
        void* boxed=nullptr;if(!invoke(m,obj,args,boxed,e))return false;
        void* data=boxed?host->object_unbox(host->context,boxed):nullptr;
        if(!data){e="HUD missing boxed result: "+std::string(bindings[m].name);return false;}
        std::memcpy(&out,data,sizeof(T));return true;
    }
    template<class T> bool set(M m,void* obj,T& v,std::string& e){void* a[]{&v};return call(m,obj,a,e);}
    bool setref(M m,void* obj,void* v,std::string& e){void* a[]{v};return call(m,obj,a,e);}
    bool retain(Ref& r,void* p,std::string& e){
        r.p=p;if(!p)return true;r.h=host->gchandle_new(host->context,p,0);
        if(!r.h){r.p=nullptr;e="HUD could not retain managed object";return false;}return true;
    }
    void release(Ref& r){if(r.h)host->gchandle_free(host->context,r.h);r={};}
    struct LocalRef {
        Impl& owner;Ref ref;
        explicit LocalRef(Impl& value):owner(value){}
        ~LocalRef(){owner.release(ref);}
    };
    bool alive(void* p,bool& result,std::string& e){
        if(!p){result=false;return true;}uint8_t equal=0;void* a[]{p,nullptr};
        if(!value(Equals,nullptr,equal,e,a)||equal>1)return false;result=!equal;return true;
    }
    bool getref(M m,void* obj,Ref& out,std::string& e,void** args=nullptr){void* p=nullptr;return invoke(m,obj,args,p,e)&&retain(out,p,e);}
    bool array(const BE_ResolvedClassV1& cls,Ref& result,int32_t& length,std::string& e,bool all=false){
        void* a[]{cls.type_object};if(!getref(all?FindAll:Find,nullptr,result,e,a)||!result.p){if(e.empty())e="HUD object enumeration returned null";return false;}
        if(!value(ArrayLength,result.p,length,e))return false;
        if(length<0||length>1000000){e="HUD object enumeration length is invalid";return false;}return true;
    }
    bool item(Ref& array,int32_t index,void*& out,std::string& e){void* a[]{&index};return invoke(ArrayGet,array.p,a,out,e);}
    bool equal(void* a,void* b,std::string& e){uint8_t eq=0;void* args[]{a,b};if(!value(Equals,nullptr,eq,e,args))return false;if(eq!=1){e="HUD object restoration did not take effect";return false;}return true;}
    bool restoreActive(std::string& e){
        if(!activePending)return true;
        if(!setref(SetActive,nullptr,savedActive.p,e))return false;
        void* actual=nullptr;if(!invoke(GetActive,nullptr,nullptr,actual,e)||!equal(actual,savedActive.p,e))return false;
        // Keep this root until the entire hierarchy has been restored. A later
        // cleanup retry can execute Canvas callbacks that change active again.
        return true;
    }
    void releaseSnapshots(){
        for(auto& c:canvases){release(c.canvas);release(c.camera);release(c.transform);}canvases.clear();
        for(auto& n:nodes){release(n.go);release(n.transform);}nodes.clear();dirty=false;
    }
    bool restore(std::string& error){
        bool ok=true;std::string e;
        auto track=[&](bool result){if(!result){ok=false;if(error.empty())error=e;}e.clear();};
        // Restore all objects even if one setter fails; retain every snapshot on
        // failure because retry must restore a coherent hierarchy, not a subset.
        for(auto& c:canvases)if(c.changed){
            bool living=false;if(!alive(c.canvas.p,living,e)){track(false);continue;}if(!living)continue;
            track(setref(SetCanvasCamera,c.canvas.p,c.camera.p,e));
            track(set(SetCanvasMode,c.canvas.p,c.mode,e));
            track(set(SetCanvasDistance,c.canvas.p,c.distance,e));
            int32_t actual=-1;track(value(CanvasMode,c.canvas.p,actual,e));
            if(actual!=c.mode){e="HUD Canvas mode restoration did not take effect";track(false);}
            void* actualCamera=nullptr;
            if(invoke(CanvasCamera,c.canvas.p,nullptr,actualCamera,e))track(equal(actualCamera,c.camera.p,e));else track(false);
        }
        if(dirty)track(call(ForceCanvas,nullptr,nullptr,e));
        for(auto& n:nodes)if(n.changed){
            bool living=false;if(!alive(n.go.p,living,e)){track(false);continue;}if(!living)continue;
            track(set(SetLayer,n.go.p,n.layer,e));
            int32_t actual=-1;track(value(Layer,n.go.p,actual,e));
            if(actual!=n.layer){e="HUD layer restoration did not take effect";track(false);}
            if(n.rect){
                track(set(SetAnchorMin,n.transform.p,n.min,e));track(set(SetAnchorMax,n.transform.p,n.max,e));
                track(set(SetPivot,n.transform.p,n.pivot,e));track(set(SetSize,n.transform.p,n.size,e));
                track(set(SetAnchored,n.transform.p,n.anchored,e));
            }
            track(set(SetLocalScale,n.transform.p,n.scale,e));track(set(SetLocalRotation,n.transform.p,n.rotation,e));
            track(set(SetLocalPosition,n.transform.p,n.position,e));
        }
        // Canvas/Rect setters and ForceUpdateCanvases can execute game callbacks.
        // Restore global active state last, after every such callback, even if
        // an earlier property restoration failed and must be retried later.
        track(restoreActive(e));
        if(ok){activePending=false;release(savedActive);releaseSnapshots();}return ok;
    }
    bool destroy(Ref& object,bool isRt,std::string& e){
        if(!object.p){release(object);return true;}bool living=false;if(!alive(object.p,living,e))return false;
        if(living){if(isRt&&!call(RtRelease,object.p,nullptr,e))return false;if(!setref(Destroy,nullptr,object.p,e))return false;}
        release(object);return true;
    }
    bool clean(){
        std::string e;if(!restore(e)){log(e);return false;}bool ok=true;
        if(destroy(go,false,e))release(camera);else {ok=false;log(e);}
        // Keep targets while a private camera could still reference them.
        if(go.p)return false;
        hg.release();
        e.clear();if(!destroy(rt,true,e)){ok=false;log(e);}e.clear();if(!destroy(tex,false,e)){ok=false;log(e);}
        if(ok)width=height=0;captured=0;return ok;
    }
    bool make(const BE_ResolvedClassV1& cls,Ref& object,std::string& e){return retain(object,host->object_new(host->context,cls.class_info),e)&&object.p;}
    bool ensure(uint32_t w,uint32_t h,std::string& e){
        if(w==width&&h==height&&go.p&&camera.p&&rt.p&&tex.p){
            bool living=true;
            for(const Ref* r:{&go,&camera,&rt,&tex}){bool current=false;if(!alive(r->p,current,e))return false;living&=current;}
            if(living)return hg.bind(camera.p,go.p,e);
        }
        if(!clean()){e="HUD previous resources or restoration are pending";return false;}
        int32_t iw=int32_t(w),ih=int32_t(h),depth=24,format=0,linear=1,aa=1,gfx=8;
        uint8_t no=0,yes=1;int32_t hide=61,solidColor=2;float aspect=float(w)/float(h),ortho=1,nearZ=.1f,farZ=10;
        if(!make(rtClass,rt,e))return false;
        void* rtArgs[]{&iw,&ih,&depth,&format,&linear};uint8_t created=0,srgb=1;
        if(!call(RtCtor,rt.p,rtArgs,e)||!set(SetRtFormat,rt.p,gfx,e)||!set(RtAA,rt.p,aa,e)||
           !set(RtMip,rt.p,no,e)||!set(RtAutoMip,rt.p,no,e)||!value(RtCreate,rt.p,created,e)||created!=1||
           !value(RtSrgb,rt.p,srgb,e)||srgb!=0){if(e.empty())e="HUD linear RenderTexture creation failed";return false;}
        int32_t actual=0;if(!value(RtFormat,rt.p,actual,e)||actual!=8){e="HUD requires RGBA8 UNORM RenderTexture";return false;}
        if(!make(texClass,tex,e))return false;format=4;
        void* texArgs[]{&iw,&ih,&format,&no,&yes};
        if(!call(TexCtor,tex.p,texArgs,e)||!value(TexFormat,tex.p,actual,e)||actual!=4||
           !value(TexMips,tex.p,actual,e)||actual!=1||!value(TexSrgb,tex.p,srgb,e)||srgb!=0||
           !value(TexGraphicsFormat,tex.p,actual,e)||actual!=8){if(e.empty())e="HUD CPU texture format mismatch";return false;}
        if(!make(goClass,go,e))return false;
        LocalRef name(*this);if(!retain(name.ref,host->string_new(host->context,"VRVD isolated HUD camera"),e))return false;
        if(!setref(GoCtor,go.p,name.ref.p,e))return false;
        void* cameraType[]{cameraClass.type_object};
        if(!getref(AddComponent,go.p,camera,e,cameraType)||!camera.p){if(e.empty())e="HUD camera creation failed";return false;}
        if(!set(SetEnabled,camera.p,no,e)||!set(Hide,go.p,hide,e)||!set(Hide,rt.p,hide,e)||!set(Hide,tex.p,hide,e)||
           !set(ClearFlags,camera.p,solidColor,e)||!set(Orthographic,camera.p,yes,e)||!set(OrthoSize,camera.p,ortho,e)||
           !set(Aspect,camera.p,aspect,e)||!set(Near,camera.p,nearZ,e)||!set(Far,camera.p,farZ,e)||
           !set(Hdr,camera.p,no,e)||!set(Msaa,camera.p,no,e)||!set(Occlusion,camera.p,no,e)||!setref(Target,camera.p,rt.p,e))return false;
        if(!hg.bind(camera.p,go.p,e))return false;
        width=w;height=h;return true;
    }
    bool snapshotNode(void* transform,std::unordered_set<void*>& seen,std::string& e,bool& unsupported,unsigned depth=0,bool excluded=false){
        if(depth>256){e="HUD Canvas hierarchy exceeds depth limit";return false;}
        if(!seen.insert(transform).second){e="HUD Canvas hierarchy is overlapping or cyclic";return false;}
        if(nodes.size()>=16384){e="HUD Canvas hierarchy exceeds capture limit";return false;}
        nodes.emplace_back();auto& n=nodes.back();
        if(!retain(n.transform,transform,e)||!getref(ComponentGo,transform,n.go,e)||!n.go.p||!value(Layer,n.go.p,n.layer,e)||
           !value(LocalPosition,transform,n.position,e)||!value(LocalRotation,transform,n.rotation,e)||!value(LocalScale,transform,n.scale,e))return false;
        void* rectType[]{rectClass.type_object};void* rect=nullptr;
        if(!invoke(GetComponent,transform,rectType,rect,e))return false;n.rect=rect!=nullptr;
        if(n.rect&&(!value(AnchorMin,transform,n.min,e)||!value(AnchorMax,transform,n.max,e)||!value(Anchored,transform,n.anchored,e)||
           !value(Size,transform,n.size,e)||!value(Pivot,transform,n.pivot,e)))return false;
        // CanvasRenderer is not UnityEngine.Renderer. Reject embedded scene
        // meshes/particles instead of passing them off as a captured HUD.
        void* canvasType[]{canvasClass.type_object};void* canvas=nullptr;
        if(!invoke(GetComponent,transform,canvasType,canvas,e))return false;
        if(canvas){int32_t mode=-1;if(!value(CanvasMode,canvas,mode,e))return false;if(mode==2){excluded=true;if(depth==0){unsupported=true;e="world-space root Canvas";return false;}warn("Excluded world-space Canvas subtree; retained screen UI siblings");}}
        void* rendererType[]{rendererClass.type_object};void* renderer=nullptr;
        if(!invoke(GetComponent,transform,rendererType,renderer,e))return false;
        if(renderer&&!excluded){unsupported=true;e="screen Canvas contains an embedded scene Renderer";return false;}
        n.capture=!excluded;
        int32_t children=0;if(!value(ChildCount,transform,children,e)||children<0||children>16384){if(e.empty())e="Invalid HUD child count";return false;}
        for(int32_t i=0;i<children;++i){void* args[]{&i};void* child=nullptr;if(!invoke(Child,transform,args,child,e)||!child||!snapshotNode(child,seen,e,unsupported,depth+1,excluded))return false;}
        return true;
    }
    bool snapshot(int32_t& spareLayer,std::string& e){
        LocalRef scopedAll(*this);Ref& all=scopedAll.ref;int32_t length=0;
        if(!array(canvasClass,all,length,e)){release(all);return false;}
        bool ok=true;
        for(int32_t i=0;i<length&&ok;++i){
            void* c=nullptr;uint8_t root=0,enabled=0;int32_t mode=-1;
            if(!item(all,i,c,e)||!c||!value(CanvasRoot,c,root,e)||!value(Enabled,c,enabled,e)||!value(CanvasMode,c,mode,e)){ok=false;break;}
            if(root!=1||enabled!=1||mode==2)continue;
            if(mode<0||mode>1){e="HUD Canvas has unknown render mode";ok=false;break;}
            canvases.emplace_back();auto& state=canvases.back();state.mode=mode;
            ok=retain(state.canvas,c,e)&&getref(CanvasCamera,c,state.camera,e)&&getref(ComponentTransform,c,state.transform,e)&&
               state.transform.p&&value(CanvasDistance,c,state.distance,e)&&std::isfinite(state.distance);
        }
        release(all);if(!ok){if(e.empty())e="HUD Canvas snapshot failed";return false;}
        if(canvases.empty()){e="No active screen-space root Canvas found; custom HG UI is not captured";return false;}
        std::unordered_set<void*> seen;
        for(size_t index=0;index<canvases.size();){
            auto& c=canvases[index];const size_t before=nodes.size();bool unsupported=false;
            if(snapshotNode(c.transform.p,seen,e,unsupported)){++index;continue;}
            if(!unsupported)return false;
            // No objects are changed during snapshot. Discard this root's
            // partial snapshots while keeping independent compatible roots.
            for(size_t i=before;i<nodes.size();++i){seen.erase(nodes[i].transform.p);release(nodes[i].go);release(nodes[i].transform);}
            nodes.resize(before);release(c.canvas);release(c.camera);release(c.transform);
            canvases.erase(canvases.begin()+index);++skipped;
            if(skipped==1)warn("Skipped incompatible screen Canvas: "+e);
            e.clear();
        }
        if(canvases.empty()){e="All screen Canvas roots were skipped ("+std::to_string(skipped)+"): "+captureWarning;return false;}
        // An unused live layer, proved immediately before mutation, prevents a
        // camera culling mask from capturing unrelated world geometry. A stale
        // cached layer is not a valid proof after a scene/object change.
        // Resources includes HideFlags.DontSave objects that FindObjectsOfType
        // omits. Loaded assets can over-reserve layers; that is a safe failure.
        if(!array(goClass,all,length,e,true)){release(all);return false;}
        uint32_t used=0;
        for(int32_t i=0;i<length;++i){void* object=nullptr;int32_t layer=-1;uint8_t active=0;
            if(!item(all,i,object,e)||!object||!value(Active,object,active,e)||!value(Layer,object,layer,e)||layer<0||layer>31){ok=false;break;}
            if(active)used|=uint32_t(1)<<layer;
        }
        release(all);if(!ok){if(e.empty())e="HUD layer isolation scan failed";return false;}
        spareLayer=-1;for(int i=31;i>=8;--i)if(!(used&(uint32_t(1)<<i))){spareLayer=i;break;}
        if(spareLayer<0){e="HUD capture cannot find a provably unused user layer";return false;}return true;
    }
    bool isolated(int32_t layer,std::string& e){
        LocalRef list(*this);int32_t length=0;if(!array(goClass,list.ref,length,e,true))return false;
        std::unordered_set<void*> allowed;for(const auto& n:nodes)if(n.capture)allowed.insert(n.go.p);
        for(int32_t i=0;i<length;++i){void* object=nullptr;uint8_t active=0;int32_t actual=-1;
            if(!item(list.ref,i,object,e)||!object||!value(Active,object,active,e)||!value(Layer,object,actual,e))return false;
            if(active&&actual==layer&&!allowed.count(object)){e="HUD isolation changed during Canvas/render callbacks";return false;}
        }
        // A callback can also attach a Renderer to an existing UI GameObject.
        for(const auto& n:nodes){if(!n.capture)continue;void* args[]{rendererClass.type_object};void* renderer=nullptr;
            if(!invoke(GetComponent,n.transform.p,args,renderer,e))return false;
            if(renderer){e="HUD callback attached scene geometry to the captured Canvas";return false;}
        }
        return true;
    }
    bool bind(int32_t layer,std::string& e){
        int32_t mask=static_cast<int32_t>(uint32_t(1)<<layer),mode=1;float plane=1;
        if(!set(Culling,camera.p,mask,e))return false;
        for(auto& n:nodes){n.changed=true;dirty=true;if(n.capture&&!set(SetLayer,n.go.p,layer,e))return false;}
        for(auto& c:canvases){c.changed=true;dirty=true;
            if(!setref(SetCanvasCamera,c.canvas.p,camera.p,e)||!set(SetCanvasMode,c.canvas.p,mode,e)||!set(SetCanvasDistance,c.canvas.p,plane,e))return false;
        }
        return call(ForceCanvas,nullptr,nullptr,e)&&isolated(layer,e);
    }
    bool read(std::vector<uint8_t>& bytes,std::string& e){
        if(!activePending){e="HUD active RenderTexture was not saved before rendering";return false;}
        if(!setref(SetActive,nullptr,rt.p,e))return false;
        void* actual=nullptr;if(!invoke(GetActive,nullptr,nullptr,actual,e)||!equal(actual,rt.p,e))return false;
        Rect rect{0,0,float(width),float(height)};int32_t zero=0;uint8_t no=0;void* args[]{&rect,&zero,&zero,&no};
        if(!call(ReadPixels,tex.p,args,e))return false;
        LocalRef scopedRaw(*this);Ref& raw=scopedRaw.ref;
        if(!getref(Raw,tex.p,raw,e)||!raw.p){if(e.empty())e="HUD readback returned no byte array";return false;}
        int32_t size=0;bool ok=value(ArrayLength,raw.p,size,e);
        const size_t expected=size_t(width)*height*4;
        if(ok&&(size<0||size_t(size)!=expected)){e="HUD readback length mismatch";ok=false;}
        if(ok){bytes.resize(expected);intptr_t destination=reinterpret_cast<intptr_t>(bytes.data());void* a[]{raw.p,&zero,&destination,&size};ok=call(Copy,nullptr,a,e);}
        return ok;
    }
    void opaque_image(const std::vector<uint8_t>& black,std::vector<uint8_t>& output){
        output.resize(black.size());
        for(uint32_t y=0;y<height;++y)for(uint32_t x=0;x<width;++x){
            const size_t src=(size_t(y)*width+x)*4,dst=(size_t(height-1-y)*width+x)*4;
            for(size_t c=0;c<3;++c)output[dst+c]=black[src+c];output[dst+3]=255;
        }
        opaqueOutput=true;
    }
    bool preclear(Color& background,std::string& e){
        if(!activePending){e="HUD preclear requires saved render state";return false;}
        if(!setref(SetActive,nullptr,rt.p,e))return false;
        void* actual=nullptr;if(!invoke(GetActive,nullptr,nullptr,actual,e)||!equal(actual,rt.p,e))return false;
        uint8_t yes=1;void* args[]{&yes,&yes,&background};return call(Preclear,nullptr,args,e);
    }
    bool native_alpha_image(const std::vector<uint8_t>& black,const std::vector<uint8_t>& white,std::vector<uint8_t>& output){
        bool transparent=false,visible=false;
        if(black.size()!=white.size()||black.empty())return false;
        for(size_t i=0;i<black.size();i+=4){
            const int a=black[i+3];transparent|=a<5;visible|=a>5&&(black[i]>3||black[i+1]>3||black[i+2]>3);
            for(size_t c=0;c<4;++c)if(std::abs(int(black[i+c])-int(white[i+c]))>3)return false;
            for(size_t c=0;c<3;++c)if(int(black[i+c])>a+3)return false;
        }
        if(!transparent||!visible)return false;
        output.resize(black.size());
        for(uint32_t y=0;y<height;++y)for(uint32_t x=0;x<width;++x){
            const size_t src=(size_t(y)*width+x)*4,dst=(size_t(height-1-y)*width+x)*4;
            for(size_t c=0;c<3;++c)output[dst+c]=std::min(black[src+c],black[src+3]);
            output[dst+3]=black[src+3];
        }
        warn("Using validated native alpha; HG UI ignored black/white backgrounds");return true;
    }
    bool opaque_menu(const std::vector<uint8_t>& black,const std::vector<uint8_t>& white,std::vector<uint8_t>& output){
        int low[3]{255,255,255},high[3]{};
        if(black.empty()||black.size()!=white.size())return false;
        for(size_t i=0;i<black.size();i+=4){
            if(black[i+3]<250||white[i+3]<250)return false;
            for(size_t c=0;c<4;++c)if(std::abs(int(black[i+c])-int(white[i+c]))>3)return false;
            for(size_t c=0;c<3;++c){low[c]=std::min(low[c],int(black[i+c]));high[c]=std::max(high[c],int(black[i+c]));}
        }
        if(std::max({high[0]-low[0],high[1]-low[1],high[2]-low[2]})<4)return false;
        opaque_image(black,output);warn("Validated opaque native game UI; input remains with the game");return true;
    }
    bool image(int32_t layer,std::vector<uint8_t>& output,HudComposition mode,std::string& e){
        std::vector<uint8_t> black,white;
        Color background{0,0,0,0};
        const float clearBlack[]{0,0,0,0},clearWhite[]{1,1,1,1};
        if(!set(Background,camera.p,background,e)||!hg.set_background(clearBlack,e)||!preclear(background,e)||!call(Render,camera.p,nullptr,e)||!isolated(layer,e)||!read(black,e))return false;
        if(mode==HudComposition::Opaque){
            int low[3]{255,255,255},high[3]{};
            for(size_t i=0;i<black.size();i+=4)for(int c=0;c<3;++c){low[c]=std::min(low[c],int(black[i+c]));high[c]=std::max(high[c],int(black[i+c]));}
            if(std::max({high[0]-low[0],high[1]-low[1],high[2]-low[2]})<4){e="HUD has no visible detail; uniform panel hidden";return false;}
            opaque_image(black,output);warn("Explicit opaque UI panel selected");return true;
        }
        background={1,1,1,1};
        if(!set(Background,camera.p,background,e)||!hg.set_background(clearWhite,e)||!preclear(background,e)||!call(Render,camera.p,nullptr,e)||!isolated(layer,e)||!read(white,e))return false;
        const auto incompatible=[&](const char* reason){
            e=std::string(reason)+"; invalid HUD hidden (automatic opaque fallback disabled)";return false;
        };
        output.resize(black.size());bool visible=false,transparentBackground=false;
        for(uint32_t y=0;y<height;++y)for(uint32_t x=0;x<width;++x){
            const size_t src=(size_t(y)*width+x)*4,dst=(size_t(height-1-y)*width+x)*4;
            int delta[3]{int(white[src])-int(black[src]),int(white[src+1])-int(black[src+1]),int(white[src+2])-int(black[src+2])};
            std::sort(delta,delta+3);
            if(delta[0]<-3||delta[2]>255||delta[2]-delta[0]>5)return incompatible("HUD shader is background-dependent; transparent composition cannot be reconstructed");
            const int alpha=255-std::clamp(delta[1],0,255);visible|=alpha>0;transparentBackground|=alpha<250;
            for(size_t c=0;c<3;++c){
                if(int(black[src+c])>alpha+5)return incompatible("HUD uses additive/non-premultiplied content");
                output[dst+c]=uint8_t(std::min(int(black[src+c]),alpha));
            }
            output[dst+3]=uint8_t(alpha);
        }
        if(!visible){e="HUD Canvas render is empty; the game's custom UI pipeline may not support Camera.Render";return false;}
        if(!transparentBackground){if(native_alpha_image(black,white,output))return true;if(mode==HudComposition::GameUi&&opaque_menu(black,white,output))return true;e="HUD black/white passes have no transparent background; opaque or unrendered layer hidden";return false;}
        return true;
    }
    bool fields(const char* klass,const char* const* names,size_t size,std::string& e){
        int32_t first=-1;
        for(size_t i=0;i<size;++i){BE_FieldDescriptorV1 desc{Core,"UnityEngine",klass,names[i],"System.Single"};BE_ResolvedFieldV1 f{};
            if(host->resolve_field(host->context,&desc,&f)!=BE_Result_Ok||!f.field_info){e="HUD unknown value layout: "+std::string(klass);return false;}
            if(i==0)first=f.offset;if(first<0||first>64||f.offset!=first+int32_t(i*4)){e="HUD unsupported value layout: "+std::string(klass);return false;}
        }return true;
    }
};

UnityHud::UnityHud():impl_(std::make_unique<Impl>()){}
UnityHud::~UnityHud()=default;
bool UnityHud::resolve(const BE_HostApiV1* host,std::string& error,HudNativeResolver resolver){
    error.clear();auto& s=*impl_;if(resources_alive()){error="Clean up HUD resources before rebinding";return false;}s.ready=false;
    if(!host||!host->resolve_method||!host->resolve_class||!host->resolve_field||!host->runtime_invoke||!host->object_unbox||
       !host->object_new||!host->string_new||!host->gchandle_new||!host->gchandle_free){error="Incomplete EML API for HUD capture";return false;}
    s.host=host;
    for(size_t i=0;i<Impl::Count;++i){const auto& b=Impl::bindings[i];BE_MethodDescriptorV1 d{b.assembly,b.ns,b.klass,b.name,b.params,b.result,b.count};
        if(host->resolve_method(host->context,&d,&s.methods[i])!=BE_Result_Ok||!s.methods[i].method_info){error="HUD API unavailable: "+std::string(b.klass)+"."+b.name;return false;}}
    auto cls=[&](const char* assembly,const char* name,BE_ResolvedClassV1& out){
        if(host->resolve_class(host->context,assembly,"UnityEngine",name,&out)!=BE_Result_Ok||!out.class_info||!out.type_object){error="HUD class unavailable: "+std::string(name);return false;}return true;};
    if(!cls(Ui,"Canvas",s.canvasClass)||!cls(Core,"GameObject",s.goClass)||!cls(Core,"Camera",s.cameraClass)||
       !cls(Core,"RenderTexture",s.rtClass)||!cls(Core,"Texture2D",s.texClass)||!cls(Core,"RectTransform",s.rectClass)||
       !cls(Core,"Renderer",s.rendererClass))return false;
    const char* v2[]{"x","y"};const char* v3[]{"x","y","z"};const char* q4[]{"x","y","z","w"};
    const char* rect[]{"m_XMin","m_YMin","m_Width","m_Height"};const char* color[]{"r","g","b","a"};
    if(!s.fields("Vector2",v2,2,error)||!s.fields("Vector3",v3,3,error)||!s.fields("Quaternion",q4,4,error)||
       !s.fields("Rect",rect,4,error)||!s.fields("Color",color,4,error))return false;
    if(!s.hg.resolve(host,resolver,error))return false;
    s.ready=true;return true;
}
bool UnityHud::capture(uint32_t width,uint32_t height,std::vector<uint8_t>& rgba,std::string& error,HudComposition mode){
    error.clear();auto& s=*impl_;s.captured=0;s.skipped=0;s.captureWarning.clear();s.opaqueOutput=false;
    if(mode!=HudComposition::Auto&&mode!=HudComposition::Transparent&&mode!=HudComposition::Opaque&&mode!=HudComposition::GameUi){error="Invalid HUD composition mode";return false;}
    if(!s.ready){error="HUD capture is not resolved";return false;}
    if(width==0||height==0||width>2048||height>2048){error="HUD capture dimensions must be in 1..2048";return false;}
    if(restore_pending()){error="HUD restoration is pending; retry cleanup on the game thread";return false;}
    bool ok=false;std::vector<uint8_t> result;uint32_t count=0;
    try{int32_t layer=-1;
        ok=s.ensure(width,height,error);
        // Camera.Render itself can change active state or throw. Save before
        // any Canvas callbacks/rendering, never after the first successful eye.
        if(ok){ok=s.getref(Impl::GetActive,nullptr,s.savedActive,error);if(ok)s.activePending=true;}
        ok=ok&&s.snapshot(layer,error)&&s.bind(layer,error)&&s.image(layer,result,mode,error);
        if(ok)count=uint32_t(s.canvases.size());
    }catch(const std::exception& ex){error="HUD capture failed: "+std::string(ex.what());ok=false;}
    catch(...){error="HUD capture failed with an unknown native exception";ok=false;}
    std::string restoreError;if(!s.restore(restoreError)){if(!error.empty())error+="; ";error+="HUD restoration pending: "+restoreError;ok=false;}
    if(ok){rgba.swap(result);s.captured=count;}else {s.opaqueOutput=false;if(error.empty())error="HUD capture failed";}
    return ok;
}
uint32_t UnityHud::count()const{return impl_->captured;}
uint32_t UnityHud::skipped_count()const{return impl_->skipped;}
std::string UnityHud::capture_path()const{return impl_->hg.path();}
std::string UnityHud::warning()const{return impl_->captureWarning;}
bool UnityHud::opaque()const{return impl_->opaqueOutput;}
bool UnityHud::restore_pending()const{return impl_->activePending||impl_->dirty;}
bool UnityHud::resources_alive()const{const auto& s=*impl_;return s.go.p||s.camera.p||s.rt.p||s.tex.p||s.savedActive.p||!s.canvases.empty()||!s.nodes.empty()||s.activePending||s.dirty||s.hg.resources_alive();}
void UnityHud::cleanup(){if(impl_->host)impl_->clean();}
}
