#pragma once
#include <vector>
#include <cstdint>
#include <algorithm>
namespace vrvd {
// Bounded information screen: retains full native layout and its background.
inline bool make_info_hud(const std::vector<uint8_t>& source,unsigned w,unsigned h,std::vector<uint8_t>& out){
 if(!w||!h||source.size()!=size_t(w)*h*4)return false;
 out=source;for(size_t i=3;i<out.size();i+=4)out[i]=255;return true;
}
// Reuse original screen layout at the perimeter. These are opaque game-window
// crops, not a claimed extraction of transparent native UI. Center is zero RGBA.
inline bool make_edge_hud(const std::vector<uint8_t>& source,unsigned w,unsigned h,std::vector<uint8_t>& out){
 if(!w||!h||source.size()!=size_t(w)*h*4)return false;
 out.assign(source.size(),0);
 for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x){
  const float nx=(x+.5f)/w,ny=(y+.5f)/h;
  // Minimap/task area, top-right buttons, lower gamepad/action/health areas.
  bool region=(nx<.24f&&ny<.57f)||(nx>.76f&&ny<.27f)||ny>.78f;
  if(!region)continue;size_t i=(size_t(y)*w+x)*4;
  std::copy_n(source.data()+i,4,out.data()+i);out[i+3]=255;
 }
 return true;
}
}
