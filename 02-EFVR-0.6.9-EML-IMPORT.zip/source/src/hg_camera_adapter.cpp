#include "hg_camera_adapter.h"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <array>
#include <cstdint>
#include <cstring>

namespace vrvd {
namespace {
constexpr const char* HgAssembly = "HG.RenderPipelines.Runtime.dll";
constexpr const char* HgNamespace = "HG.Rendering.Runtime";
constexpr const char* Core = "UnityEngine.CoreModule.dll";
constexpr int TypeBoolean = 2, TypeInt32 = 8, TypeValue = 17, TypeClass = 18, TypeGeneric = 21;
constexpr uint32_t Static = 0x10, ReadOnly = 0x20, Literal = 0x40;
void* productionExport(const char* name) {
    const HMODULE module = GetModuleHandleW(L"GameAssembly.dll");
    return module ? reinterpret_cast<void*>(GetProcAddress(module, name)) : nullptr;
}
struct Binding { const char* assembly; const char* ns; const char* klass; const char* name; const char* args; const char* result; uint32_t count; };
}

struct HgCameraAdapter::Impl {
    enum M { Equals, GetGo, GetComponent, AddComponent, CopyTo, GetOrCreate, Reset, Count };
    inline static const Binding bindings[Count]{
        {Core,"UnityEngine","Object","op_Equality","UnityEngine.Object|UnityEngine.Object","System.Boolean",2},
        {Core,"UnityEngine","Component","get_gameObject",nullptr,"UnityEngine.GameObject",0},
        {Core,"UnityEngine","Component","GetComponent","System.Type","UnityEngine.Component",1},
        {Core,"UnityEngine","GameObject","AddComponent","System.Type","UnityEngine.Component",1},
        {HgAssembly,HgNamespace,"HGAdditionalCameraData","CopyTo","HG.Rendering.Runtime.HGAdditionalCameraData","System.Void",1},
        {HgAssembly,HgNamespace,"HGCamera","GetOrCreate","UnityEngine.Camera|System.Int32","HG.Rendering.Runtime.HGCamera",2},
        {HgAssembly,HgNamespace,"HGCamera","Reset",nullptr,"System.Void",0}
    };
    struct Ref { void* p=nullptr; uint32_t root=0; };
    struct Eye { Ref camera,go,additional,hg,drawHg; bool initialized=false,prepared=false; };
    const BE_HostApiV1* host=nullptr;
    std::array<BE_ResolvedMethodV1,Count> methods{};
    BE_ResolvedClassV1 additionalClass{},hgClass{},cameraClass{},booleanClass{},delegateClass{};
    std::array<Eye,2> eyes{};
    HgProjectionHook projectionHook;
    bool resolved=false,present=false;
    std::string state="HG camera adapter unresolved";
    int32_t noneValue=0; // Set only from the verified named enum constant at runtime.
    int sourceFullscreenPassthrough=-1;
    const void *aaField=nullptr,*dynamicField=nullptr,*historyField=nullptr,*passthroughField=nullptr,*customField=nullptr,*projectionField=nullptr,*hgCameraField=nullptr,*hgPersistentField=nullptr;
    const void* enumClass=nullptr;

    const void* (*classField)(const void*,const char*)=nullptr;
    const void* (*fieldType)(const void*)=nullptr;
    const void* (*fieldParent)(const void*)=nullptr;
    uint32_t (*fieldFlags)(const void*)=nullptr;
    int (*typeKind)(const void*)=nullptr;
    bool (*isByRef)(const void*)=nullptr;
    const void* (*classFromType)(const void*)=nullptr;
    bool (*classIsEnum)(const void*)=nullptr;
    const void* (*enumBaseType)(const void*)=nullptr;
    const void* (*declaringClass)(const void*)=nullptr;
    const char* (*className)(const void*)=nullptr;
    bool (*classSubclass)(const void*,const void*,bool)=nullptr;
    const void* (*objectClass)(void*)=nullptr;
    void (*fieldSet)(void*,const void*,void*)=nullptr;
    void (*fieldSetObject)(void*,const void*,void*)=nullptr;

    template<class T> bool load(T& fn,HgNativeResolver resolver,const char* name,std::string& e) {
        fn=reinterpret_cast<T>(resolver(name));
        if(!fn){e="HG adapter missing IL2CPP export: "+std::string(name);return false;}return true;
    }
    bool exports(HgNativeResolver r,std::string& e) {
        return load(classField,r,"il2cpp_class_get_field_from_name",e)&&load(fieldType,r,"il2cpp_field_get_type",e)&&
            load(fieldParent,r,"il2cpp_field_get_parent",e)&&load(fieldFlags,r,"il2cpp_field_get_flags",e)&&
            load(typeKind,r,"il2cpp_type_get_type",e)&&load(isByRef,r,"il2cpp_type_is_byref",e)&&
            load(classFromType,r,"il2cpp_class_from_type",e)&&load(classIsEnum,r,"il2cpp_class_is_enum",e)&&
            load(enumBaseType,r,"il2cpp_class_enum_basetype",e)&&load(declaringClass,r,"il2cpp_class_get_declaring_type",e)&&
            load(className,r,"il2cpp_class_get_name",e)&&load(classSubclass,r,"il2cpp_class_is_subclass_of",e)&&
            load(objectClass,r,"il2cpp_object_get_class",e)&&load(fieldSet,r,"il2cpp_field_set_value",e)&&
            load(fieldSetObject,r,"il2cpp_field_set_value_object",e);
    }
    bool invoke(M m,void* instance,void** args,void*& result,std::string& e) {
        void* exception=nullptr;
        result=host->runtime_invoke(host->context,methods[m].method_info,instance,args,&exception);
        if(exception){e="HG adapter managed exception: "+std::string(bindings[m].klass)+"."+bindings[m].name;return false;}return true;
    }
    bool call(M m,void* instance,void** args,std::string& e){void* result=nullptr;return invoke(m,instance,args,result,e);}
    bool equal(void* a,void* b,bool& result,std::string& e) {
        void* args[]{a,b};void* boxed=nullptr;
        if(!invoke(Equals,nullptr,args,boxed,e))return false;
        const void* data=boxed?host->object_unbox(host->context,boxed):nullptr;
        if(!data){e="HG adapter missing equality result";return false;}uint8_t value=0;std::memcpy(&value,data,1);
        if(value>1){e="HG adapter invalid equality result";return false;}result=value!=0;return true;
    }
    bool living(void* p,std::string& e) {
        bool dead=true;if(!equal(p,nullptr,dead,e))return false;
        if(dead){e="HG adapter received a destroyed Unity object";return false;}return true;
    }
    bool retain(Ref& ref,void* p,std::string& e) {
        if(ref.p){if(ref.p==p)return true;e="HG adapter root cannot be rebound before cleanup";return false;}
        if(!p){e="HG adapter cannot retain null object";return false;}
        const uint32_t root=host->gchandle_new(host->context,p,0);
        if(!root){e="HG adapter could not retain managed object";return false;}ref={p,root};return true;
    }
    void release(Ref& ref){if(ref.root)host->gchandle_free(host->context,ref.root);ref={};}
    struct LocalRef {Impl& s;Ref ref;explicit LocalRef(Impl& owner):s(owner){}~LocalRef(){s.release(ref);}};
    bool klass(const char* assembly,const char* ns,const char* name,BE_ResolvedClassV1& out,std::string& e) {
        if(host->resolve_class(host->context,assembly,ns,name,&out)!=BE_Result_Ok||!out.class_info||!out.type_object){e="HG adapter class unavailable: "+std::string(name);return false;}return true;
    }
    bool field(const void* klass,const char* name,const void*& out,int kind,bool writable,std::string& e) {
        out=classField(klass,name);const void* type=out?fieldType(out):nullptr;
        if(!out||fieldParent(out)!=klass||!type||isByRef(type)||(kind>=0&&typeKind(type)!=kind)||
           (fieldFlags(out)&Static)||(writable&&(fieldFlags(out)&(ReadOnly|Literal)))) {
            e="HG adapter field contract mismatch: "+std::string(name);return false;
        }return true;
    }
    bool delegateField(const char* name,const void*& out,std::string& e) {
        if(!field(additionalClass.class_info,name,out,-1,true,e))return false;
        const void* type=fieldType(out);const int kind=typeKind(type);const void* klass=classFromType(type);
        if((kind!=TypeClass&&kind!=TypeGeneric)||!klass||!classSubclass(klass,delegateClass.class_info,false)) {
            e="HG adapter field is not a managed delegate: "+std::string(name);return false;
        }return true;
    }
    bool unboxField(void* object,const void* field,const void* expectedClass,void* out,size_t bytes,std::string& e) {
        void* boxed=host->field_get_value_object(host->context,field,object);
        const void* data=boxed?host->object_unbox(host->context,boxed):nullptr;
        if(!boxed||objectClass(boxed)!=expectedClass||!data){e="HG adapter boxed field type mismatch";return false;}
        std::memcpy(out,data,bytes);return true;
    }
    bool fields(std::string& e) {
        if(!field(additionalClass.class_info,"antialiasing",aaField,TypeValue,true,e)||
           !field(additionalClass.class_info,"allowDynamicResolution",dynamicField,TypeBoolean,true,e)||
           !field(additionalClass.class_info,"hasPersistentHistory",historyField,TypeBoolean,true,e)||
           !field(additionalClass.class_info,"fullscreenPassthrough",passthroughField,TypeBoolean,true,e)||
           !delegateField("customRender",customField,e)||!delegateField("nonObliqueProjectionGetter",projectionField,e)||
           !field(hgClass.class_info,"camera",hgCameraField,TypeClass,false,e)||
           !field(hgClass.class_info,"isPersistent",hgPersistentField,TypeBoolean,true,e))return false;
        if(classFromType(fieldType(dynamicField))!=booleanClass.class_info||classFromType(fieldType(historyField))!=booleanClass.class_info||
           classFromType(fieldType(passthroughField))!=booleanClass.class_info||classFromType(fieldType(hgPersistentField))!=booleanClass.class_info||
           classFromType(fieldType(hgCameraField))!=cameraClass.class_info){e="HG adapter boolean/camera field class mismatch";return false;}
        enumClass=classFromType(fieldType(aaField));
        const void* base=enumClass?enumBaseType(enumClass):nullptr;
        const char* name=enumClass?className(enumClass):nullptr;
        if(!enumClass||!classIsEnum(enumClass)||declaringClass(enumClass)!=additionalClass.class_info||!name||
           std::strcmp(name,"AntialiasingMode")!=0||!base||isByRef(base)||typeKind(base)!=TypeInt32) {
            e="HG adapter requires HGAdditionalCameraData.AntialiasingMode backed by Int32";return false;
        }
        const void* none=classField(enumClass,"None");
        const void* type=none?fieldType(none):nullptr;
        if(!none||fieldParent(none)!=enumClass||(fieldFlags(none)&(Static|Literal))!=(Static|Literal)||
           !type||isByRef(type)||typeKind(type)!=TypeValue||classFromType(type)!=enumClass) {
            e="HG adapter cannot verify named AntialiasingMode.None constant";return false;
        }
        return unboxField(nullptr,none,enumClass,&noneValue,sizeof(noneValue),e);
    }
    bool configure(void* target,const char* phase,std::string& e) {
        // The only native writes are symbolic, typed IL2CPP FieldInfo API calls,
        // and target is always the explicitly retained private eye component.
        uint8_t no=0;
        fieldSet(target,aaField,&noneValue);fieldSet(target,dynamicField,&no);fieldSet(target,historyField,&no);
        // CopyTo inherits this flag. HG TryCalculateFrameParameters returns
        // false before GetOrCreate/Build when it is set. Private eyes need a
        // scene render; never change the source camera's passthrough mode.
        fieldSet(target,passthroughField,&no);
        // Reference fields take the managed object itself, not an address of a
        // pointer variable. Passing &nullDelegate stores a dangling stack address.
        // Keep reference and scalar entry points separate to prevent that mistake.
        fieldSetObject(target,customField,nullptr);
        // GetNonObliqueProjection unconditionally invokes this delegate outside
        // our routed Render scope. Preserve the valid camera-supplied getter.
        const std::string prefix="HG eye field write/readback verification failed ("+std::string(phase)+"): ";
        const auto mismatch=[&](const char* name,const std::string& expected,const std::string& actual) {
            e=prefix+name+" expected="+expected+" actual="+actual;return false;
        };
        const auto read=[&](const char* name,const void* field,const void* klass,void* out,size_t bytes) {
            if(unboxField(target,field,klass,out,bytes,e))return true;
            e=prefix+name+": "+e;return false;
        };
        int32_t aa=0;uint8_t dynamic=0xff,history=0xff,passthrough=0xff;
        if(!read("antialiasing",aaField,enumClass,&aa,sizeof(aa)))return false;
        if(aa!=noneValue)return mismatch("antialiasing",std::to_string(noneValue),std::to_string(aa));
        if(!read("allowDynamicResolution",dynamicField,booleanClass.class_info,&dynamic,sizeof(dynamic)))return false;
        if(dynamic!=0)return mismatch("allowDynamicResolution","0",std::to_string(dynamic));
        if(!read("hasPersistentHistory",historyField,booleanClass.class_info,&history,sizeof(history)))return false;
        if(history!=0)return mismatch("hasPersistentHistory","0",std::to_string(history));
        if(!read("fullscreenPassthrough",passthroughField,booleanClass.class_info,&passthrough,sizeof(passthrough)))return false;
        if(passthrough!=0)return mismatch("fullscreenPassthrough","0",std::to_string(passthrough));
        if(host->field_get_value_object(host->context,customField,target))return mismatch("customRender","null","non-null");
        if(!host->field_get_value_object(host->context,projectionField,target))return mismatch("nonObliqueProjectionGetter","non-null","null");
        return true;
    }
    bool keepPrivateHistory(unsigned index,void* hg,const char* phase,std::string& error) {
        if(index>1||!hg||objectClass(hg)!=hgClass.class_info||
           !eyes[index].camera.root||!eyes[index].go.root||
           host->field_get_value_object(host->context,hgCameraField,hg)!=eyes[index].camera.p||
           hg==eyes[index^1].hg.p||hg==eyes[index^1].drawHg.p) {
            error="HG cache retention refused a non-private history object";return false;
        }
        // Unlike AdditionalCameraData.hasPersistentHistory, this flag prevents
        // CleanUnused from disposing a disabled manual-render camera between
        // its preparation and Camera.Render. Only owned private HG objects are
        // changed. Destroyed/null cameras remain eligible for engine cleanup,
        // regardless of this flag, so teardown destroys the eye GO first.
        uint8_t yes=1,actual=0xff;fieldSet(hg,hgPersistentField,&yes);
        const std::string prefix="HG private cache write/readback verification failed ("+std::string(phase)+"): isPersistent ";
        if(!unboxField(hg,hgPersistentField,booleanClass.class_info,&actual,sizeof(actual),error)) {
            error=prefix+error;return false;
        }
        if(actual!=1){error=prefix+"expected=1 actual="+std::to_string(actual);return false;}
        return true;
    }
    static bool validateDrawBinding(void* context,unsigned index,void* hg,void* camera,void* additional,std::string& error) {
        auto& s=*static_cast<Impl*>(context);error.clear();
        if(index>1){error="HG draw eye index is invalid";return false;}
        auto& eye=s.eyes[index];const auto& other=s.eyes[index^1];
        // Called only inside this eye's live HG frame preparation, without the
        // helper routing mutex. Do not invoke Reset or recreate engine history.
        if(!eye.prepared||camera!=eye.camera.p||additional!=eye.additional.p||
           !eye.camera.root||!eye.additional.root||!eye.go.root) {
            error="HG draw binding does not own the prepared eye objects";return false;
        }
        if(!hg||s.objectClass(hg)!=s.hgClass.class_info) {
            error="HG draw binding returned an incompatible object class";return false;
        }
        if(s.host->field_get_value_object(s.host->context,s.hgCameraField,hg)!=camera) {
            error="HG draw binding belongs to another Camera";return false;
        }
        if(hg==other.hg.p||hg==other.drawHg.p) {
            error="HG draw binding is shared with the other eye";return false;
        }
        if(eye.drawHg.p&&eye.drawHg.p!=hg) {
            error="HG draw binding changed within the same eye render";return false;
        }
        // The native return is a managed reference, so retain that exact object
        // before the render pipeline resumes. The separate typed persistent
        // flag prevents CleanUnused; a GC root alone would not prevent Dispose.
        return s.retain(eye.drawHg,hg,error)&&s.keepPrivateHistory(index,hg,"draw GetOrCreate",error);
    }
};

HgCameraAdapter::HgCameraAdapter():impl_(std::make_unique<Impl>()){}
HgCameraAdapter::~HgCameraAdapter()=default;
bool HgCameraAdapter::resolve(const BE_HostApiV1* host,std::string& error,HgNativeResolver resolver) {
    error.clear();auto& s=*impl_;
    if(resources_alive()){error="Clean up HG adapter roots before rebinding";return false;}
    s.resolved=false;s.present=false;s.state="HG camera adapter unresolved";
    s.sourceFullscreenPassthrough=-1;
    if(!host||host->abi_version!=BETTER_ENDFIELD_MODULE_ABI_V1||!host->resolve_class||!host->resolve_method||
       !host->runtime_invoke||!host->object_unbox||!host->gchandle_new||!host->gchandle_free) {
        error="Incomplete EML host API for HG camera adapter";return false;
    }
    s.host=host;s.additionalClass={};s.methods={};
    const BE_Result found=host->resolve_class(host->context,HgAssembly,HgNamespace,"HGAdditionalCameraData",&s.additionalClass);
    if(found==BE_Result_NotFound){s.resolved=true;s.state="HG pipeline types absent; no camera fields changed";return true;}
    if(found!=BE_Result_Ok||!s.additionalClass.class_info||!s.additionalClass.type_object){error="HGAdditionalCameraData class contract unavailable";return false;}
    if(!host->field_get_value_object){error="HG adapter requires the EML boxed field read API";return false;}
    if(!s.klass(HgAssembly,HgNamespace,"HGCamera",s.hgClass,error)||
       !s.klass(Core,"UnityEngine","Camera",s.cameraClass,error)||
       !s.klass("mscorlib.dll","System","Boolean",s.booleanClass,error)||
       !s.klass("mscorlib.dll","System","MulticastDelegate",s.delegateClass,error))return false;
    for(size_t i=0;i<Impl::Count;++i){const auto& b=Impl::bindings[i];
        BE_MethodDescriptorV1 d{b.assembly,b.ns,b.klass,b.name,b.args,b.result,b.count};
        if(host->resolve_method(host->context,&d,&s.methods[i])!=BE_Result_Ok||!s.methods[i].method_info){error="HG adapter method unavailable: "+std::string(b.klass)+"."+b.name;return false;}
    }
    if(!s.exports(resolver?resolver:productionExport,error)||!s.fields(error))return false;
    if(!s.projectionHook.install(host,error,Impl::validateDrawBinding,&s))return false;
    s.present=true;s.resolved=true;s.state="HG adapter ready; private eyes not prepared";return true;
}

bool HgCameraAdapter::prepare(void* mainCamera,void* eyeCamera,void* eyeGO,unsigned index,std::string& error) {
    error.clear();auto& s=*impl_;
    if(!s.resolved){error="HG camera adapter is unresolved";return false;}
    if(index>1){error="HG adapter eye index must be 0 or 1";return false;}
    if(!s.present)return true;
    if(s.projectionHook.snapshot().scope_active){error="HG eye preparation cannot run inside an active render scope";return false;}
    auto& eye=s.eyes[index];eye.prepared=false;
    const auto fail=[&](){error="Eye "+std::to_string(index)+": "+error;s.state="HG camera preparation failed: "+error;return false;};
    bool same=false;
    if(!s.living(mainCamera,error)||!s.living(eyeCamera,error)||!s.living(eyeGO,error)||!s.equal(mainCamera,eyeCamera,same,error))return fail();
    if(same){error="HG adapter refuses to modify the original camera";return fail();}
    void* actualGo=nullptr;
    if(!s.invoke(Impl::GetGo,eyeCamera,nullptr,actualGo,error)||!s.equal(actualGo,eyeGO,same,error))return fail();
    if(!same){error="HG adapter eye camera does not belong to its private GameObject";return fail();}
    void* mainGo=nullptr;
    if(!s.invoke(Impl::GetGo,mainCamera,nullptr,mainGo,error)||!s.equal(mainGo,eyeGO,same,error))return fail();
    if(same){error="HG adapter refuses to add/modify components on the original GameObject";return fail();}
    if(s.eyes[index^1].camera.p){
        if(!s.equal(eyeCamera,s.eyes[index^1].camera.p,same,error))return fail();
        if(same){error="HG adapter requires distinct eye cameras";return fail();}
        if(!s.equal(eyeGO,s.eyes[index^1].go.p,same,error))return fail();
        if(same){error="HG adapter requires distinct eye GameObjects";return fail();}
    }
    if(!s.retain(eye.camera,eyeCamera,error)||!s.retain(eye.go,eyeGO,error))return fail();
    void* typeArgs[]{s.additionalClass.type_object};void* source=nullptr;
    if(!s.invoke(Impl::GetComponent,mainCamera,typeArgs,source,error)||!s.living(source,error))return fail();
    Impl::LocalRef sourceRoot(s);if(!s.retain(sourceRoot.ref,source,error))return fail();
    if(s.objectClass(source)!=s.additionalClass.class_info){error="HG source camera component has an unexpected class";return fail();}
    uint8_t sourcePassthrough=0xff;
    if(!s.unboxField(source,s.passthroughField,s.booleanClass.class_info,&sourcePassthrough,sizeof(sourcePassthrough),error))return fail();
    if(sourcePassthrough>1){error="HG source fullscreenPassthrough is not a valid Boolean";return fail();}
    s.sourceFullscreenPassthrough=sourcePassthrough;
    if(s.host->field_get_value_object(s.host->context,s.customField,source)) {
        error="HG source camera has customRender callbacks; private eye copy is not supported";return fail();
    }
    if(!eye.additional.p) {
        void* target=nullptr;
        if(!s.invoke(Impl::GetComponent,eyeCamera,typeArgs,target,error))return fail();
        bool empty=false;if(!s.equal(target,nullptr,empty,error))return fail();
        if(empty&&!s.invoke(Impl::AddComponent,eyeGO,typeArgs,target,error))return fail();
        if(!s.living(target,error)||s.objectClass(target)!=s.additionalClass.class_info){error="HG private eye component creation failed";return fail();}
        if(!s.retain(eye.additional,target,error))return fail();
    }
    if(!s.living(eye.additional.p,error))return fail();
    if(!s.equal(source,eye.additional.p,same,error))return fail();
    if(same){error="HG adapter refuses to write the source camera component";return fail();}
    void* componentGo=nullptr;
    if(!s.invoke(Impl::GetGo,eye.additional.p,nullptr,componentGo,error)||!s.equal(componentGo,eyeGO,same,error))return fail();
    if(!same){error="HG additional camera data belongs to another GameObject";return fail();}
    void* copyArgs[]{eye.additional.p};
    if(!s.call(Impl::CopyTo,source,copyArgs,error)||!s.configure(eye.additional.p,"after CopyTo",error))return fail();
    {
        // Two independent Camera objects already separate the cache keys.
        // Standard Camera.Render uses multipass 0; inventing id=1 for the right
        // camera could configure a different HGCamera than the pipeline uses.
        int32_t multipass=0;void* args[]{eyeCamera,&multipass};void* hg=nullptr;
        if(!s.invoke(Impl::GetOrCreate,nullptr,args,hg,error)||!hg||s.objectClass(hg)!=s.hgClass.class_info){if(error.empty())error="HGCamera.GetOrCreate returned an incompatible object";return fail();}
        if(s.eyes[index^1].hg.p==hg){error="HGCamera history object was shared between private eyes";return fail();}
        Impl::LocalRef currentHg(s);if(!s.retain(currentHg.ref,hg,error))return fail();
        void* wrapperCamera=s.host->field_get_value_object(s.host->context,s.hgCameraField,hg);
        if(!s.equal(wrapperCamera,eyeCamera,same,error))return fail();
        if(!same){error="HGCamera cache returned another camera's history object";return fail();}
        const bool changed=eye.hg.p!=hg;
        if(changed||!eye.initialized) {
            if(!s.call(Impl::Reset,hg,nullptr,error))return fail();
            // Reset is an HG-managed call: reapply and verify private settings.
            if(!s.configure(eye.additional.p,"after HGCamera.Reset",error))return fail();
        }
        if(!s.keepPrivateHistory(index,hg,"after private HG preparation",error))return fail();
        if(changed){s.release(eye.hg);eye.hg=currentHg.ref;currentHg.ref={};}
        eye.initialized=true;
    }
    eye.prepared=true;
    s.state=active()?"HG private eyes prepared; internal projection routing waits for eye Render":"HG private eye prepared; waiting for other eye";
    return true;
}
bool HgCameraAdapter::begin_projection(unsigned index,const float matrix[16],std::string& error) {
    error.clear();auto& s=*impl_;
    if(!s.resolved){error="HG adapter is unresolved";return false;}
    if(!s.present)return true;
    if(index>1||!s.eyes[index].prepared){error="HG eye is not prepared for projection routing";return false;}
    if(s.projectionHook.snapshot().scope_active){error="HG eye render scopes cannot overlap";return false;}
    s.projectionHook.clear_eye(index);
    auto& eye=s.eyes[index];s.release(eye.drawHg);
    return s.projectionHook.set_eye(index,eye.hg.p,eye.camera.p,eye.additional.p,matrix,error)&&s.projectionHook.begin_eye(index,error);
}
bool HgCameraAdapter::end_projection(unsigned index,std::string& error) {
    auto& s=*impl_;error.clear();if(!s.present)return true;
    if(!s.projectionHook.end_eye(index,error)){s.state=error;return false;}
    s.state="HG internal projection routed for private eye "+std::to_string(index);return true;
}
void HgCameraAdapter::clear_projection(){impl_->projectionHook.clear();}
HgProjectionSnapshot HgCameraAdapter::projection_diagnostics()const{return impl_->projectionHook.snapshot();}
void HgCameraAdapter::cleanup(){auto& s=*impl_;s.projectionHook.clear();if(!s.host)return;for(auto& e:s.eyes){s.release(e.drawHg);s.release(e.hg);s.release(e.additional);s.release(e.camera);s.release(e.go);e={};}s.state=s.present?"HG adapter ready; private eye roots released":"HG pipeline types absent";}
bool HgCameraAdapter::available()const{return impl_->resolved&&impl_->present;}
bool HgCameraAdapter::active()const{return available()&&impl_->eyes[0].prepared&&impl_->eyes[1].prepared;}
bool HgCameraAdapter::resources_alive()const{for(const auto& e:impl_->eyes)if(e.camera.p||e.go.p||e.additional.p||e.hg.p||e.drawHg.p)return true;return false;}
std::string HgCameraAdapter::status()const{return impl_->state;}
int HgCameraAdapter::source_fullscreen_passthrough()const{return impl_->sourceFullscreenPassthrough;}
}
