#pragma once
#include <BetterEndfield/ThirdPartyModule.h>
#include <array>
#include <cstdint>
#include <memory>
#include <string>

namespace vrvd {
struct HgProjectionMatrix { float values[16]; };
// Verified Windows x64 native ABI for both HG instance methods returning a
// 64-byte Matrix4x4: explicit hidden result buffer precedes this/camera/method.
using HgProjectionNative = HgProjectionMatrix* (*)(HgProjectionMatrix*,void*,void*,const void*);
// Diagnostic-only observer, verified from the current managed/native method.
// Unlike the matrix methods, Boolean is returned in AL and has no sret buffer.
using HgFrameParametersNative = uint8_t (*)(void*,void*,void**,void**,void*,const void*);
using HgGetOrCreateNative = void* (*)(void*,int32_t,const void*);
// Runs on the eye render thread, outside the routing lock. Success means the
// adapter verified the returned HG object and retained it through end_eye.
using HgDrawBindingValidator = bool (*)(void* context,unsigned eye,void* hg,void* camera,void* additional,std::string& error);
struct HgProjectionCallCounters {
    // All counters observe only the currently installed owner. Lifetime totals
    // reset on install; clear/clear_eye retain them for failure diagnosis.
    uint64_t entries=0;
    // Attribute every entry during an eye scope to that active eye, including
    // calls for unrelated cameras. Identity mismatches compare to that eye.
    std::array<uint64_t,2> scope_entries{},same_camera_wrong_instance{},same_instance_wrong_camera{};
    // Exact registered private pair observed outside its own scope (including
    // while the other eye is active). Such calls always pass through unchanged.
    std::array<uint64_t,2> outside_scope_private{};
    // Only the selected eye's frame counters reset at its next begin_eye.
    std::array<uint64_t,2> frame_scope_entries{},frame_same_camera_wrong_instance{},frame_same_instance_wrong_camera{};
};
struct HgProjectionSnapshot {
    bool installed=false, scope_active=false;
    int active_eye=-1;
    uint64_t build_hits=0, non_oblique_hits=0;
    std::array<uint64_t,2> frame_build_hits{},frame_non_oblique_hits{};
    HgProjectionCallCounters build_calls,non_oblique_calls;
    bool frame_parameters_observer=false;
    std::string frame_parameters_status="not_installed";
    uint64_t prepare_entries=0;
    std::array<uint64_t,2> prepare_calls{},frame_prepare_calls{},frame_prepare_successes{},
        frame_prepare_hg_mismatch{},frame_prepare_additional_mismatch{};
    bool draw_binding_required=false,get_or_create_hook=false;
    std::array<uint64_t,2> frame_draw_bindings{},frame_draw_binding_failures{},frame_draw_binding_changed{},frame_prepare_validation_failures{};
    std::array<int32_t,2> frame_draw_multipass{};
    std::array<std::string,2> draw_binding_error{};
};
class HgProjectionHook {
public:
    HgProjectionHook();
    ~HgProjectionHook(); // Clears identity registry only; never calls Unity/host.
    HgProjectionHook(const HgProjectionHook&)=delete;
    HgProjectionHook& operator=(const HgProjectionHook&)=delete;
    // One module-owned installation. On a subsequent module resolve, the host
    // must already have released the preceding module hooks. This function does
    // not release any hooks, including partially installed ones, or use offsets.
    bool install(const BE_HostApiV1*,std::string& error,HgDrawBindingValidator validator=nullptr,void* validatorContext=nullptr);
    bool set_eye(unsigned,void* hg,void* camera,void* additional,const float matrix[16],std::string& error);
    bool begin_eye(unsigned,std::string& error);
    bool end_eye(unsigned,std::string& error);
    void clear_eye(unsigned);
    void clear();
    HgProjectionSnapshot snapshot() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
}
