#pragma once
#include <BetterEndfield/ThirdPartyModule.h>
#include <memory>
#include <string>

namespace vrvd {
using HudNativeResolver = void*(*)(const char*);
// Configures only the caller-owned HUD camera. No pipeline asset, game camera,
// HG scene-eye hook, or ScriptableRenderContext is modified or synthesized.
class HgUiCamera {
public:
    HgUiCamera();
    ~HgUiCamera();
    bool resolve(const BE_HostApiV1*, HudNativeResolver, std::string& error);
    bool bind(void* private_camera,void* private_game_object,std::string& error);
    bool set_background(const float rgba[4],std::string& error);
    // Scoped rendering of the ORIGINAL UI camera: preserve its path/layout.
    bool begin_existing(void* camera, std::string& error);
    bool restore_existing(std::string& error);
    bool restore_pending() const;
    // Call after the owner has destroyed its private camera GameObject.
    void release();
    bool resources_alive() const;
    std::string path() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
}
