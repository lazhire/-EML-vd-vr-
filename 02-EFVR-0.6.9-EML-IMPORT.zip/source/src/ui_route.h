#pragma once
#include <string>
#include <vector>
#include <set>
#include <cstdint>
namespace vrvd {
struct PanelInfo { int id=0,level=0; std::string name; bool world=false; int instance=0; };
struct UiSignals {
 bool valid=false,loading=false,system_scene=false;
 std::string controller,error;
 std::vector<PanelInfo> panels;
};
inline std::string route_ui(const UiSignals& s,const std::set<std::string>& overlays,bool force_menu=false) {
 if(s.loading)return "loading";
 if(!s.valid)return "unknown";
 if(force_menu)return "menu";
 if(s.system_scene)return "menu";
 // Exact panel names observed in this client's host logs. A camera class alone
 // cannot identify UI ownership: QuickMenu/Watch retain LevelCameraController.
 // Named native menus may themselves report IsWorldUI=true. That flag describes
 // their implementation, not whether their pixels belong in the VR edge crop.
 // Only exact known interactive panels bypass the world-UI exclusion.
 auto has=[&](const char* name){for(const auto& p:s.panels)if(p.name==name)return true;return false;};
 for(const auto* name:{"CharInfo","CharInfoEmpty","Watch","WatchController","Mission","AdventureBook","AdventureDaily","Inventory",
     "ActivityCenter","ActivityCharSignCommon","ActivityPushPopup","ActivityCenterEmptyBottom",
     "Map","MapInfoPopup","CashShop","ShopRecommend","ShopChoicenessBattlePass","DomainMain","GameSetting","GameSettingWarningPopUp","GachaPool","FriendList","FriendTab","BattlePass","BattlePassPlan","EquipTech","RewardsPopUpForSystem","DungeonCustomReward","StaminaPopUp","DungeonCommonEntry","CharFormation","Snapshot"})
  if(has(name))return "menu";
 // Loading panel may outlive the loader flag. Exact name, never a substring.
 if(has("Loading"))return "loading";
 if(has("QuickMenu"))return "radial";
 // Keep the entire dialogue, including choices and subtitles, until panels close.
 if(has("Dialog")||has("DialogMask")||has("HeadLabelInDialog"))return "dialogue";
 if(has("CommonPopUp"))return "menu";
 if(has("BlockGlitchTransition")||has("CommonBlockMask")||has("WatchBlur"))return "transition";
 // System-scene menus legitimately have no active gameplay controller.
 // valid + empty means the getter succeeded and returned null, not a failed
 // string copy (the observer marks that invalid). Leave gameplay camera alone.
 if(s.controller.empty())return "menu";
 if(s.controller=="Beyond.Gameplay.View.FacTopViewCameraController")return "building";
 if(s.controller=="Beyond.Gameplay.View.SnapshotCameraController")return "photo";
 if(s.controller=="Beyond.Gameplay.View.InteractNpcCameraController")return "dialogue";
 if(s.controller=="Beyond.Gameplay.View.AnimatedCameraController" ||
    s.controller=="Beyond.Gameplay.View.TrackCameraController")return "cinematic";
 if(s.controller!="Beyond.Gameplay.View.LevelCameraController" &&
    s.controller!="Beyond.Gameplay.View.LevelFreeLookCameraController")return "special_camera";
 // Unknown screen panels are not proof of an interactive menu. Passive game
 // HUDs vary by location and combat state; never suspend first-person based on
 // absence from a HUD allowlist. Known menus/camera/loading rules above own it.
 (void)overlays;
 return "gameplay";
}
inline std::string ui_signature(const UiSignals& s,const std::string& mode) {
 std::string v=mode+"|"+s.controller+"|"+(s.system_scene?"1":"0");
 for(const auto& p:s.panels)v+="|"+std::to_string(p.id)+":"+std::to_string(p.instance)+":"+std::to_string(p.level)+":"+p.name+":"+(p.world?"1":"0");
 return v;
}
// Initial unknown does not claim first-person. Once a real menu was observed,
// transient unknown must retain suspension until confirmed gameplay resumes.
inline unsigned first_person_ui_gate(bool vr_requested,bool observer_ready,const std::string& mode,bool menu_latched=false){
 if(!vr_requested||!observer_ready)return 0;
 if(mode=="unknown"||mode.empty())return menu_latched?2:0;
 if(mode=="gameplay"||mode=="radial")return 1;
 if(mode=="menu"||mode=="loading"||mode=="photo"||mode=="building"||mode=="dialogue"||mode=="transition"||mode=="cinematic"||mode=="special_camera")return 2;
 return 0;
}
} // namespace vrvd
