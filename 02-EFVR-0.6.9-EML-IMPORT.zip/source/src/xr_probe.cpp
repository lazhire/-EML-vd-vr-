#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include "xr_backend.h"
#include <chrono>
#include <cmath>
#include <cstring>
#include <iostream>
#include <stdexcept>

// Standalone diagnostic scene: never loads EML or accesses Endfield.
namespace {
template<class T> struct Com {
    T* p = nullptr;
    ~Com(){if(p)p->Release();}
    T** out(){return &p;}
    T* operator->()const{return p;}
};
void check(HRESULT result,const char* label){if(FAILED(result))throw std::runtime_error(label);}
const char* shader = R"HLSL(
cbuffer EyeBuffer : register(b0) {float4 eyePos;float4 eyeRot;float4 tangent;};
struct Vertex {float4 pos:SV_POSITION;float2 uv:TEXCOORD0;};
Vertex vs(uint id:SV_VertexID){Vertex o;o.uv=float2((id<<1)&2,id&2);o.pos=float4(o.uv*float2(2,-2)+float2(-1,1),0,1);return o;}
float3 rotate(float4 q,float3 p){return p+2*cross(q.xyz,cross(q.xyz,p)+q.w*p);}
float sphere(float3 o,float3 d,float3 c,float r){float3 a=o-c;float b=dot(a,d),h=b*b-dot(a,a)+r*r;return h<0?-1:-b-sqrt(h);}
float4 ps(Vertex i):SV_TARGET {
 float3 o=eyePos.xyz+float3(0,1.6,0);
 float3 d=rotate(eyeRot,normalize(float3(lerp(tangent.x,tangent.y,i.uv.x),lerp(tangent.z,tangent.w,i.uv.y),-1)));
 float3 color=lerp(float3(.10,.15,.24),float3(.35,.50,.68),saturate(d.y*.5+.5));float nearest=10000;
 if(d.y<-.0001){float t=-o.y/d.y;if(t>0){float3 p=o+t*d;float grid=step(.94,frac(p.x))+step(.94,frac(p.z));color=lerp(float3(.16,.20,.23),float3(.5,.55,.58),saturate(grid));nearest=t;}}
 float3 c0=float3(-.55,1.35,-2),c1=float3(.6,1.1,-3.5);
 float t0=sphere(o,d,c0,.3),t1=sphere(o,d,c1,.5);
 if(t0>0&&t0<nearest){float3 n=normalize(o+t0*d-c0);color=float3(1,.4,.08)*(.25+.75*saturate(dot(n,normalize(float3(-1,2,1)))));nearest=t0;}
 if(t1>0&&t1<nearest){float3 n=normalize(o+t1*d-c1);color=float3(.08,.55,1)*(.25+.75*saturate(dot(n,normalize(float3(-1,2,1)))));}
 return float4(color,1);
})HLSL";
}
int main(int argc,char** argv) {
    if(argc==1 || std::strcmp(argv[1],"--help")==0){
        std::cout << "VRVD standalone stereo diagnostic. No game or EML is loaded.\n"
          "Usage: vrvd-xr-probe.exe --run [seconds=30] [absolute-openxr_loader.dll-path]\n"
          "Connect Quest 3 using VD first. R recentres; Escape exits.\n"
          "Expected: orange near sphere, blue farther sphere, ground grid; correct stereo and head motion.\n";
        return 0;
    }
    if(std::strcmp(argv[1],"--run")!=0)return 1;
    try {
        int seconds=argc>2?std::stoi(argv[2]):30;
        if(seconds<1 || seconds>300)throw std::runtime_error("Duration must be 1..300 seconds");
        std::wstring loader=L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\SteamVR\\bin\\win64\\openxr_loader.dll";
        if(argc>3){int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,argv[3],-1,nullptr,0);if(!n)throw std::runtime_error("Invalid loader path");loader.resize(n);MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,argv[3],-1,loader.data(),n);}
        Com<ID3D11Device> device;Com<ID3D11DeviceContext> context;
        D3D_FEATURE_LEVEL level;
        check(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,nullptr,0,D3D11_SDK_VERSION,device.out(),&level,context.out()),"D3D11 device creation failed");
        constexpr UINT size=1024;
        Com<ID3D11Texture2D> textures[2];Com<ID3D11RenderTargetView> rtvs[2];
        D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=size;desc.MipLevels=desc.ArraySize=1;desc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;desc.SampleDesc.Count=1;desc.Usage=D3D11_USAGE_DEFAULT;desc.BindFlags=D3D11_BIND_RENDER_TARGET;
        for(int eye=0;eye<2;++eye){check(device->CreateTexture2D(&desc,nullptr,textures[eye].out()),"Eye texture failed");check(device->CreateRenderTargetView(textures[eye].p,nullptr,rtvs[eye].out()),"Eye RTV failed");}
        Com<ID3DBlob> vs,ps,errors;
        check(D3DCompile(shader,std::strlen(shader),"probe",nullptr,nullptr,"vs","vs_5_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,vs.out(),errors.out()),"Vertex shader compile failed");
        if(errors.p){errors.p->Release();errors.p=nullptr;}
        check(D3DCompile(shader,std::strlen(shader),"probe",nullptr,nullptr,"ps","ps_5_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,ps.out(),errors.out()),"Pixel shader compile failed");
        Com<ID3D11VertexShader> vertex;Com<ID3D11PixelShader> pixel;
        check(device->CreateVertexShader(vs->GetBufferPointer(),vs->GetBufferSize(),nullptr,vertex.out()),"Vertex shader create failed");
        check(device->CreatePixelShader(ps->GetBufferPointer(),ps->GetBufferSize(),nullptr,pixel.out()),"Pixel shader create failed");
        Com<ID3D11Buffer> constants;D3D11_BUFFER_DESC bd{};bd.ByteWidth=48;bd.Usage=D3D11_USAGE_DEFAULT;bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;
        check(device->CreateBuffer(&bd,nullptr,constants.out()),"Constant buffer failed");
        vrvd::XrBackend xr;std::string error;
        if(!xr.initialize(textures[0].p,textures[1].p,loader.c_str(),error))throw std::runtime_error(error);
        std::cout << "Runtime: " << xr.runtime_name() << "\nPut on the headset. R recentres, Escape exits.\n";
        auto start=std::chrono::steady_clock::now();unsigned frames=0;
        while(std::chrono::steady_clock::now()-start<std::chrono::seconds(seconds)) {
            if(GetAsyncKeyState(VK_ESCAPE)&0x8000)break;
            if(GetAsyncKeyState('R')&1)xr.request_recenter();
            vrvd::Eye eyes[2]{};bool render=false;
            if(!xr.begin_frame(eyes,render,error))throw std::runtime_error(error);
            if(!render){Sleep(10);continue;}
            context->IASetInputLayout(nullptr);context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
            context->VSSetShader(vertex.p,nullptr,0);context->PSSetShader(pixel.p,nullptr,0);
            context->PSSetConstantBuffers(0,1,&constants.p);
            D3D11_VIEWPORT viewport{0,0,(float)size,(float)size,0,1};context->RSSetViewports(1,&viewport);
            for(unsigned eye=0;eye<2;++eye){
                const auto& e=eyes[eye];float data[12]{e.position[0],e.position[1],e.position[2],0,e.orientation[0],e.orientation[1],e.orientation[2],e.orientation[3],std::tan(e.angleLeft),std::tan(e.angleRight),std::tan(e.angleUp),std::tan(e.angleDown)};
                context->UpdateSubresource(constants.p,0,nullptr,data,0,0);context->OMSetRenderTargets(1,&rtvs[eye].p,nullptr);context->Draw(3,0);
            }
            context->OMSetRenderTargets(0,nullptr,nullptr);
            if(!xr.submit(textures[0].p,textures[1].p,error))throw std::runtime_error(error);
            ++frames;
        }
        xr.shutdown();std::cout << "Submitted stereo frames: "<<frames<<"\nVisual correctness must be confirmed in the headset.\n";
        return frames?0:2;
    } catch(const std::exception& e){std::cerr<<"Diagnostic failed: "<<e.what()<<"\n";return 1;}
}
