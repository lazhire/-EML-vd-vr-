"""Validate a compiled EML release without starting EML, game or VR."""
import argparse, datetime, hashlib, json, shutil, subprocess, sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--zig',type=Path,required=True)
parser.add_argument('--scratch',type=Path,required=True)
parser.add_argument('--node',default=shutil.which('node'))
args=parser.parse_args()
if not args.node:raise SystemExit('Node.js is required for EML settings-page checks')
manifest=json.loads((root/'module.json').read_text(encoding='utf-8'))
library=root/manifest['libraries']['windows-x64']
if not library.is_file():raise SystemExit('Run tools/build.py first')
report_path=root/'BUILD_CHECKS.json'
report_path.unlink(missing_ok=True)
compiled_args=['--zig',str(args.zig.resolve()),'--scratch',str(args.scratch.resolve())]
commands=[('DLL EML ABI',[sys.executable,'tools/smoke_test.py']),
    ('module lifecycle',[sys.executable,'tools/test_module_lifecycle.py',*compiled_args]),
    ('HUD capture',[sys.executable,'tools/test_unity_hud.py',*compiled_args]),
    ('OpenXR native HUD layer',[sys.executable,'tools/test_vulkan_hud.py',*compiled_args]),
    ('desktop filter',[sys.executable,'tools/test_desktop_render_filter.py',*compiled_args]),
    ('EML settings page',[args.node,'tools/test_ui_eml.js']),
    ('JS syntax',[args.node,'--check','ui/app.js'])]
records=[]
for name,command in commands:
    print('Checking '+name,flush=True)
    result=subprocess.run(command,cwd=root,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=600)
    output=(result.stdout+result.stderr).strip()
    print(output,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
    records.append({'name':name,'command':command,'result':'PASS','output':output})
report={'result':'PASS','version':manifest['version'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'library_sha256':hashlib.sha256(library.read_bytes()).hexdigest(),'checks':records,
    'eml_launched':False,'game_launched':False,'vr_session_opened':False}
report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PASS: EML release validation recorded; no game or VR session')
