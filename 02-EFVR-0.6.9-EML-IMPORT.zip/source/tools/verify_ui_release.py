"""Build and verify 0.6.9 with fake managed/XR calls. Never runs Endfield."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,sys,shutil
p=argparse.ArgumentParser();p.add_argument('--zig',type=Path,required=True);p.add_argument('--scratch',type=Path,required=True);p.add_argument('--build',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parents[1];args=['--zig',str(a.zig.resolve()),'--scratch',str(a.scratch.resolve())]
commands=[]
if a.build:
 commands += [('VR build',[sys.executable,'tools/build.py',*args]),('First-person build',[sys.executable,'tools/build_pair.py',*args])]
commands += [('production independent menu pump',[sys.executable,'tools/test_menu_pump.py',*args]),('native UI contracts',[sys.executable,'tools/test_ui_transition.py',*args]),
 ('native overlay rendering and restore',[sys.executable,'tools/test_menu_overlay.py',*args]),
 ('menu focus pixels',[sys.executable,'tools/test_menu_focus.py',*args]),
 ('OpenXR menu-only and HUD submission',[sys.executable,'tools/test_vulkan_hud.py',*args]),
 ('stereo projection regression',[sys.executable,'tools/test_stereo_projection.py',*args]),
 ('release ABI',[sys.executable,'tools/test_release_056.py']),
 ('EML UI',[shutil.which('node'),'tools/test_ui_056.js']),('JS syntax',[shutil.which('node'),'--check','ui/app.js']),
 ('First-person JS syntax',[shutil.which('node'),'--check',str(root.parent/'first-person-ui-guard-056/ui/app.js')])]
report=root/'BUILD_CHECKS.json';report.unlink(missing_ok=True);records=[]
for label,cmd in commands:
 print('Checking '+label,flush=True)
 r=subprocess.run(cmd,cwd=root,capture_output=True,text=True,encoding='utf8',errors='replace',timeout=600)
 out=(r.stdout+r.stderr).strip();print(out,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 records.append(dict(name=label,result='PASS',command=cmd,output=out))
manifest=json.loads((root/'module.json').read_text(encoding='utf8'));lib=root/manifest['libraries']['windows-x64']
fp=root.parent/'first-person-ui-guard-056/native/windows-x64/example.first-person.dll'
data=dict(result='PASS',version=manifest['version'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 library_sha256=hashlib.sha256(lib.read_bytes()).hexdigest(),first_person_sha256=hashlib.sha256(fp.read_bytes()).hexdigest(),
 checks=records,game_launched=False,eml_launched=False,vr_session_opened=False,game_visual_validation='NOT_RUN')
data['source_sha256']={}
for directory in [root/'src',root/'ui',root.parent/'first-person-ui-guard-056/native',root.parent/'first-person-ui-guard-056/ui']:
 for file in directory.rglob('*'):
  if file.is_file() and file.suffix in {'.cpp','.inc','.h','.js','.html'}:
   data['source_sha256'][file.relative_to(root.parent).as_posix()]=hashlib.sha256(file.read_bytes()).hexdigest()
report.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8');print('PASS: offline release verification complete',flush=True)
