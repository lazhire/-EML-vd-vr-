"""Build and run stereo completion interval tests without a game or runtime."""
import argparse
import os
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--zig',type=Path,required=True);p.add_argument('--scratch',type=Path,required=True)
a=p.parse_args();scratch=a.scratch.resolve();scratch.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
for key,folder in [('TEMP','tmp'),('TMP','tmp'),('ZIG_GLOBAL_CACHE_DIR','zig-global'),('ZIG_LOCAL_CACHE_DIR','zig-local')]:
    path=scratch/folder;path.mkdir(parents=True,exist_ok=True);env[key]=str(path)
exe=scratch/'frame-metrics-test.exe'
subprocess.run([str(a.zig.resolve()),'c++','-target','x86_64-windows-gnu','-std=c++17','-O2',str(root/'tests/frame_metrics_test.cpp'),'-o',str(exe)],env=env,cwd=scratch,check=True)
subprocess.run([str(exe)],cwd=scratch,check=True,timeout=30)
