"""Compile and run game-free Unity readback tests using a fake EML host."""
import argparse
import os
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--zig',type=Path,required=True)
parser.add_argument('--scratch',type=Path,required=True)
args=parser.parse_args()
scratch=args.scratch.resolve();scratch.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
for key,folder in [('TEMP','tmp'),('TMP','tmp'),('ZIG_GLOBAL_CACHE_DIR','zig-global'),('ZIG_LOCAL_CACHE_DIR','zig-local')]:
    p=scratch/folder;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
exe=scratch/'unity-readback-test.exe'
subprocess.run([str(args.zig.resolve()),'c++','-target','x86_64-windows-gnu','-std=c++17','-O2',
    '-I'+str(root/'vendor/eml'),str(root/'tests/unity_readback_test.cpp'),str(root/'src/unity_bridge.cpp'),str(root/'src/hg_camera_adapter.cpp'),str(root/'src/hg_projection_hook.cpp'),'-luuid',
    '-o',str(exe)],env=env,cwd=scratch,check=True)
subprocess.run([str(exe)],cwd=scratch,check=True,timeout=30)
