"""Build the Windows x64 EML module with a portable Zig C++ toolchain."""
import argparse
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zig', type=Path, required=True)
    parser.add_argument('--scratch', type=Path, required=True)
    args = parser.parse_args()
    zig = args.zig.resolve()
    scratch = args.scratch.resolve()
    scratch.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    for key, folder in [('TEMP','tmp'),('TMP','tmp'),('ZIG_GLOBAL_CACHE_DIR','zig-global'),('ZIG_LOCAL_CACHE_DIR','zig-local')]:
        path = scratch / folder
        path.mkdir(parents=True, exist_ok=True)
        env[key] = str(path)
    dest = ROOT / 'native/windows-x64'
    dest.mkdir(parents=True, exist_ok=True)
    command = [str(zig),'c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-shared',
        '-I'+str(ROOT/'vendor/eml'),'-I'+str(ROOT/'vendor'),'-I'+str(ROOT/'vendor/openxr/include'),'-I'+str(ROOT/'vendor/vulkan/include'),
        str(ROOT/'src/module.cpp'),str(ROOT/'src/window_menu_capture.cpp'),str(ROOT/'src/unity_bridge.cpp'),str(ROOT/'src/hg_camera_adapter.cpp'),str(ROOT/'src/hg_projection_hook.cpp'),str(ROOT/'src/unity_hud.cpp'),str(ROOT/'src/hg_ui_camera.cpp'),str(ROOT/'src/unity_gpu_probe.cpp'),str(ROOT/'src/xr_backend.cpp'),str(ROOT/'src/xr_vulkan.cpp'),str(ROOT/'src/openvr_backend.cpp'),str(ROOT/'src/desktop_render_filter.cpp'),
        '-o',str(dest/'quest3.vrvd.dll'),'-ld3d11','-ldxgi','-lole32','-luuid','-luser32','-ladvapi32','-lgdi32','-lapi-ms-win-core-winrt-l1-1-0','-lapi-ms-win-core-winrt-string-l1-1-0','-ldwmapi']
    subprocess.run(command, env=env, cwd=scratch, check=True)
    print('Built:', dest/'quest3.vrvd.dll')
    probe = [str(zig),'c++','-target','x86_64-windows-gnu','-std=c++17','-O2',
        '-I'+str(ROOT/'vendor/eml'),'-I'+str(ROOT/'vendor/openxr/include'),
        str(ROOT/'src/xr_probe.cpp'),str(ROOT/'src/xr_backend.cpp'),
        '-o',str(dest/'vrvd-xr-probe.exe'),'-ld3d11','-ldxgi','-ld3dcompiler_47','-lole32','-luuid','-luser32']
    subprocess.run(probe, env=env, cwd=scratch, check=True)
    print('Built:', dest/'vrvd-xr-probe.exe')
    vk_probe = [str(zig),'c++','-target','x86_64-windows-gnu','-std=c++17','-O2',
        '-I'+str(ROOT/'vendor/eml'),'-I'+str(ROOT/'vendor/openxr/include'),'-I'+str(ROOT/'vendor/vulkan/include'),
        str(ROOT/'src/xr_vulkan_probe.cpp'),str(ROOT/'src/xr_vulkan.cpp'),
        '-o',str(dest/'vrvd-vulkan-probe.exe'),'-luser32']
    subprocess.run(vk_probe, env=env, cwd=scratch, check=True)
    print('Built:', dest/'vrvd-vulkan-probe.exe')

if __name__ == '__main__':
    main()
