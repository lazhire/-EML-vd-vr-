"""Build/run actual module lifecycle branches without a game or XR session."""
import argparse
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--zig', type=Path, required=True)
parser.add_argument('--scratch', type=Path, required=True)
args = parser.parse_args()
scratch = args.scratch.resolve()
scratch.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
for key, folder in [('TEMP', 'tmp'), ('TMP', 'tmp'), ('ZIG_GLOBAL_CACHE_DIR', 'zig-global'), ('ZIG_LOCAL_CACHE_DIR', 'zig-local')]:
    directory = scratch / folder
    directory.mkdir(parents=True, exist_ok=True)
    env[key] = str(directory)
exe = scratch / 'menu-pump-integration-test.exe'
sources = ['window_menu_capture.cpp', 'unity_bridge.cpp', 'hg_camera_adapter.cpp', 'hg_projection_hook.cpp', 'unity_hud.cpp', 'hg_ui_camera.cpp', 'unity_gpu_probe.cpp', 'xr_backend.cpp', 'xr_vulkan.cpp', 'openvr_backend.cpp', 'desktop_render_filter.cpp']
command = [str(args.zig.resolve()), 'c++', '-target', 'x86_64-windows-gnu', '-std=c++17', '-O2',
    '-I' + str(root / 'vendor/eml'), '-I' + str(root / 'vendor'),
    '-I' + str(root / 'vendor/openxr/include'), '-I' + str(root / 'vendor/vulkan/include'),
    str(root / 'tests/menu_pump_integration_test.cpp'), *[str(root / 'src' / name) for name in sources],
    '-o', str(exe), '-ld3d11', '-ldxgi', '-lole32', '-luuid', '-luser32', '-ladvapi32','-lgdi32','-lapi-ms-win-core-winrt-l1-1-0','-lapi-ms-win-core-winrt-string-l1-1-0','-ldwmapi']
subprocess.run(command, env=env, cwd=scratch, check=True)
subprocess.run([str(exe)], env=env, cwd=scratch, check=True, timeout=45)
