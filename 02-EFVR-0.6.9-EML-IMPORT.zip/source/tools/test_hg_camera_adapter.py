"""Build and run the private HG-camera adapter's fake-host contract tests."""
import argparse
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--zig', type=Path, required=True)
parser.add_argument('--scratch', type=Path, required=True)
args = parser.parse_args()
scratch = args.scratch.resolve()
scratch.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
for key, name in [('TEMP', 'tmp'), ('TMP', 'tmp'), ('ZIG_GLOBAL_CACHE_DIR', 'zig-global'), ('ZIG_LOCAL_CACHE_DIR', 'zig-local')]:
    path = scratch / name
    path.mkdir(parents=True, exist_ok=True)
    env[key] = str(path)
exe = scratch / 'hg-camera-adapter-test.exe'
subprocess.run([str(args.zig.resolve()), 'c++', '-target', 'x86_64-windows-gnu', '-std=c++17', '-O2',
                '-I' + str(root / 'vendor/eml'), str(root / 'tests/hg_camera_adapter_test.cpp'),
                str(root / 'src/hg_camera_adapter.cpp'), str(root / 'src/hg_projection_hook.cpp'), '-o', str(exe)], env=env, cwd=scratch, check=True)
subprocess.run([str(exe)], cwd=scratch, check=True, timeout=30)
