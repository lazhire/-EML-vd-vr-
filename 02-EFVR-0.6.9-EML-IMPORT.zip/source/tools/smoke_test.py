"""Exercise the release DLL through the EML ABI, without a game or VR runtime."""
import ctypes as c
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[1]
LOG = c.CFUNCTYPE(None,c.c_void_p,c.c_char_p)
REPLY = c.CFUNCTYPE(c.c_int32,c.c_void_p,c.c_char_p,c.c_int32,c.c_char_p)
EMIT = c.CFUNCTYPE(c.c_int32,c.c_void_p,c.c_char_p)
GET_RUNTIME = c.CFUNCTYPE(c.c_void_p,c.c_void_p)
class Host(c.Structure):
    _fields_=[('struct_size',c.c_uint32),('version',c.c_uint32),('context',c.c_void_p),
        ('module_id',c.c_char_p),('platform',c.c_char_p),('package_root',c.c_char_p),
        ('runtime',c.c_void_p),('hooks',c.c_void_p),('log',LOG),('reply',REPLY),
        ('emit',EMIT),('get_runtime',GET_RUNTIME)]
INIT=c.CFUNCTYPE(c.c_int32,c.POINTER(Host),c.c_char_p)
CONFIG=c.CFUNCTYPE(c.c_int32,c.c_char_p)
MESSAGE=c.CFUNCTYPE(c.c_int32,c.c_char_p,c.c_char_p)
SHUTDOWN=c.CFUNCTYPE(None)
class Module(c.Structure):
    _fields_=[('struct_size',c.c_uint32),('version',c.c_uint32),('id',c.c_char_p),
        ('initialize',INIT),('configuration_changed',CONFIG),('on_message',MESSAGE),('shutdown',SHUTDOWN)]

def encode(value): return json.dumps(value).encode('utf-8')

def main():
    manifest=json.loads((ROOT/'module.json').read_text(encoding='utf-8'))
    assert manifest['dependencies']==['example.first-person']
    assert manifest['version']=='0.5.5-game-ui-experimental'
    defaults=manifest['default_configuration']
    expected={'runtime_backend':'openxr','quality_preset':'custom',
        'eye_width':1440,'eye_height':1440,'vulkan_eye_width':1024,'vulkan_eye_height':1024,
        'hud_mode':'head_locked','hud_composition':'game_ui','hud_capture_width':1280,
        'hud_capture_height':720,'hud_refresh_hz':10,'desktop_render_mode':'normal',
        'hud_distance_m':1.5,'hud_width_m':1.8,'hud_offset_y_m':0}
    assert all(defaults.get(key)==value for key,value in expected.items())
    kernel=c.WinDLL('kernel32',use_last_error=True)
    kernel.GetModuleHandleW.argtypes=[c.c_wchar_p];kernel.GetModuleHandleW.restype=c.c_void_p
    assert not kernel.GetModuleHandleW('GameAssembly.dll')
    library=c.CDLL(str(ROOT/manifest['libraries']['windows-x64']))
    entry=library.BetterEndfield_GetThirdPartyModuleV1
    entry.argtypes=[];entry.restype=c.POINTER(Module)
    module=entry().contents
    assert module.struct_size==c.sizeof(Module) and module.version==1
    assert module.id.decode()==manifest['id']=='quest3.vrvd'
    # An EML addon must not accidentally package the standalone integrated host.
    for exported in ['EndfieldVR_GetBuildInfo','EndfieldVR_GetFirstPersonModuleV1']:
        assert not hasattr(library,exported), exported
    replies=[]
    def capture(ctx,req,result,body):
        replies.append((result,json.loads(body)))
        return result
    log=LOG(lambda *_:None);reply=REPLY(capture);emit=EMIT(lambda *_:0)
    runtime=GET_RUNTIME(lambda _:None)
    host=Host(c.sizeof(Host),1,None,b'quest3.vrvd',b'windows-x64',str(ROOT).encode(),None,None,log,reply,emit,runtime)
    def status():
        assert module.on_message(b'status',b'{"action":"status"}')==0
        return replies[-1][1]
    def configure(config): return module.configuration_changed(encode(config))
    def assert_defaults(snapshot):
        for field,key in [('configured_eye_width','eye_width'),('configured_eye_height','eye_height'),
                          ('configured_vulkan_eye_width','vulkan_eye_width'),('configured_vulkan_eye_height','vulkan_eye_height')]:
            assert snapshot[field]==expected[key],(field,snapshot[field])
        for key in ['quality_preset','runtime_backend','hud_mode','hud_capture_width','hud_capture_height','hud_refresh_hz','desktop_render_mode']:
            assert snapshot[key]==expected[key],(key,snapshot[key])
        assert snapshot['hud_composition_requested']=='game_ui'
        for key in ['hud_distance_m','hud_width_m','hud_offset_y_m']:
            assert abs(snapshot[key]-expected[key])<0.00001, (key,snapshot[key])
        assert snapshot['module_version']==manifest['version']
        assert not snapshot['desktop_filter']['installed']
        assert snapshot['submitted_frames']==0 and not snapshot['hooks_ready']
    assert module.initialize(None,b'{}')==4
    host.version=2;assert module.initialize(c.byref(host),b'{}')==4;host.version=1
    assert module.initialize(c.byref(host),b'{bad json')==1
    invalid_configs=[{'eye_width':0},{'eye_height':9000},{'vulkan_eye_width':3073},{'vulkan_eye_height':0},
        {'swap_eyes':'yes'},{'eye_labels':7},{'hud_mode':'wrist'},{'hud_distance_m':0.1},
        {'hud_width_m':3},{'hud_offset_y_m':-2},{'runtime_backend':'vrchat'},{'runtime_backend':True},
        {'openvr_loader_path':42},{'quality_preset':'low'},{'quality_preset':True},
        {'hud_capture_width':255},{'hud_capture_height':2049},{'hud_capture_width':'wide'},
        {'hud_refresh_hz':4},{'hud_refresh_hz':31},{'hud_refresh_hz':'fast'},
        {'hud_composition':'keyed'},{'hud_composition':False},{'desktop_render_mode':'disable_all'}]
    for config in invalid_configs: assert module.initialize(c.byref(host),encode(config))==1, config
    shutdown_seconds=[]
    for cycle in range(3):
        # Both manifest initialization and an empty saved config must be usable.
        assert module.initialize(c.byref(host),encode(defaults if cycle==0 else {}))==0
        try:
            assert_defaults(status())
            assert module.initialize(c.byref(host),b'{}')==5
            # Preserved older dimensions do not get silently promoted to maximum.
            assert configure({'runtime_backend':'openxr','vulkan_eye_width':768,'vulkan_eye_height':768})==0
            s=status();assert s['quality_preset']=='custom' and s['configured_vulkan_eye_width']==768
            assert s['runtime_backend']=='openxr'
            # Previously saved explicit maximum can be intentionally downgraded.
            assert configure({'quality_preset':'maximum','vulkan_eye_width':768,'vulkan_eye_height':768})==0
            s=status();assert s['configured_vulkan_eye_width']==3072 and s['configured_eye_width']==2560
            assert configure(defaults)==0;assert_defaults(status())
            assert configure(dict(defaults,hud_mode='off'))==0
            s=status();assert s['hud_mode']=='off' and s['hud_status']=='off'
            assert configure(defaults)==0;assert_defaults(status())
            custom=dict(defaults,vulkan_eye_width=2064,vulkan_eye_height=2208,swap_eyes=True,
                        hud_mode='head_locked',hud_composition='opaque',hud_capture_width=1024,hud_capture_height=576,hud_refresh_hz=15,
                        desktop_render_mode='headset_only')
            assert configure(custom)==0
            s=status();assert s['configured_vulkan_eye_width']==2064 and s['configured_vulkan_eye_height']==2208
            assert s['swap_eyes'] and s['hud_mode']=='head_locked' and s['desktop_render_mode']=='headset_only'
            for invalid in invalid_configs:
                assert configure(dict(custom,**invalid))==1
                s=status();assert s['configured_vulkan_eye_width']==2064 and s['swap_eyes']
                assert s['hud_capture_width']==1024 and s['hud_refresh_hz']==15
                assert s['hud_composition_requested']=='opaque' and s['desktop_render_mode']=='headset_only'
            for mode in ['game_ui','auto','transparent','opaque']:
                assert configure(dict(custom,hud_composition=mode))==0
                assert status()['hud_composition_requested']==mode
            assert configure({'runtime_backend':'steamvr_openvr'})==0
            assert status()['runtime_backend']=='steamvr_openvr'
            assert configure(defaults)==0;assert_defaults(status())
            # Normal EML operation uses the manual confirmation argument. A fake
            # host has no camera adapter, so confirmed start returns NotReady.
            assert module.on_message(b'missing-confirmation',b'{"action":"start"}')==1
            assert module.on_message(b'confirmed',b'{"action":"start","first_person_confirmed":true}')==2
            assert module.on_message(b'stop',b'{"action":"stop"}')==0
            start=time.monotonic()
        finally: module.shutdown()
        shutdown_seconds.append(time.monotonic()-start)
        assert module.on_message(b'after',b'{"action":"status"}')==2
    for name in ['GameAssembly.dll','EModLoader.Host.dll','openvr_api.dll']:
        assert not kernel.GetModuleHandleW(name),name
    print(json.dumps({'result':'PASS','version':manifest['version'],'cycles':3,
        'checks':['EML module ABI and first-person dependency','standalone host/first-person exports absent',
                  'manifest and empty-config defaults agree','legacy dimensions preserved without migration',
                  'explicit maximum can downgrade to custom 1024','invalid configuration is atomic',
                  'optional desktop filter configuration','native HUD centered pose and explicit off','HUD selections and dimensions','OpenXR/OpenVR settings only',
                  'manual first-person confirmation and no-game rejection','correct BE_Result reply/emit ABI'],
        'shutdown_seconds':shutdown_seconds,'game_loaded':False,'xr_session_created':False,'openvr_session_created':False},indent=2))

if __name__=='__main__': main()
