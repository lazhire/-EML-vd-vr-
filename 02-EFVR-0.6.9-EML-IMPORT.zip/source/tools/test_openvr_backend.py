"""Build/run OpenVR math and input-contract tests without initializing VR or GPU."""
import argparse
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--zig', type=Path, required=True)
parser.add_argument('--scratch', type=Path, required=True)
args = parser.parse_args()
scratch = args.scratch.resolve()
scratch.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
for key, folder in [('TEMP', 'tmp'), ('TMP', 'tmp'), ('ZIG_GLOBAL_CACHE_DIR', 'zig-global'), ('ZIG_LOCAL_CACHE_DIR', 'zig-local')]:
    path = scratch / folder
    path.mkdir(parents=True, exist_ok=True)
    env[key] = str(path)
exe = scratch / 'openvr-backend-test.exe'
command = [str(args.zig.resolve()), 'c++', '-target', 'x86_64-windows-gnu', '-std=c++17', '-O2',
           '-I' + str(root / 'vendor/eml'), '-I' + str(root / 'vendor/vulkan/include'),
           str(root / 'tests/openvr_backend_test.cpp'), str(root / 'src/openvr_backend.cpp'),
           '-ld3d11', '-ldxgi', '-lole32', '-luuid', '-luser32', '-o', str(exe)]
subprocess.run(command, env=env, cwd=scratch, check=True)
subprocess.run([str(exe)], cwd=scratch, check=True, timeout=30)
