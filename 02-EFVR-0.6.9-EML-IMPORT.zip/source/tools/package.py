"""Package native module, local settings page, and corresponding source."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'module.json').read_text(encoding='utf-8'))
checks=json.loads((ROOT/'BUILD_CHECKS.json').read_text(encoding='utf-8'))
assert checks['result']=='PASS' and checks['version']==manifest['version']
for item in manifest['libraries'].values():
    if not (ROOT/item).is_file():
        raise SystemExit('Missing compiled library: '+item)
    assert hashlib.sha256((ROOT/item).read_bytes()).hexdigest()==checks['library_sha256'], 'Library changed after validation'
dest=ROOT.parent/('quest3.vrvd-'+manifest['version']+'.zip')
entries={}
for name in ['module.json','README.md','LICENSE','THIRD_PARTY_NOTICES.md','VALIDATION.md','BUILD_CHECKS.json']:
    entries[name]=ROOT/name
for directory in ['ui']:
    for path in (ROOT/directory).rglob('*'):
        if path.is_file() and path.suffix not in {'.lib','.pdb','.a'}:
            entries[path.relative_to(ROOT).as_posix()]=path
for library in manifest['libraries'].values():
    entries[library]=ROOT/library
for directory in ['src','vendor','tools','ui','tests']:
    for path in (ROOT/directory).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            entries['source/'+path.relative_to(ROOT).as_posix()]=path
for name in ['CMakeLists.txt','module.json','LICENSE','THIRD_PARTY_NOTICES.md','README.md','VALIDATION.md']:
    entries['source/'+name]=ROOT/name
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as archive:
    hashes={}
    for name,path in sorted(entries.items()):
        payload=path.read_bytes();hashes[name]=hashlib.sha256(payload).hexdigest()
        archive.writestr(name,payload)
    archive.writestr('SHA256SUMS.json',json.dumps(hashes,indent=2))
with zipfile.ZipFile(dest) as archive:
    assert archive.testzip() is None
    assert json.loads(archive.read('module.json'))['dependencies']==['example.first-person']
    for name,expected in json.loads(archive.read('SHA256SUMS.json')).items():
        assert hashlib.sha256(archive.read(name)).hexdigest()==expected
    assert not any(name.lower().endswith('.exe') for name in archive.namelist())
digest=hashlib.sha256(dest.read_bytes()).hexdigest()
dest.with_suffix('.zip.sha256').write_text(digest+'  '+dest.name+'\n',encoding='ascii')
print(json.dumps({'file':str(dest),'bytes':dest.stat().st_size,'sha256':digest,'entries':len(entries)},indent=2))
