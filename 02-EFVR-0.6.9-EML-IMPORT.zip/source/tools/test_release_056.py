"""Exercise release ABI with no game, injection, graphics device or XR runtime."""
import ctypes as c,json
from pathlib import Path
from smoke_test import Host,Module,LOG,REPLY,EMIT,GET_RUNTIME,encode
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'module.json').read_text(encoding='utf8'))
lib=c.CDLL(str(root/manifest['libraries']['windows-x64']));entry=lib.BetterEndfield_GetThirdPartyModuleV1;entry.restype=c.POINTER(Module);m=entry().contents
assert m.id==b'quest3.vrvd'
replies=[]
log=LOG(lambda *_:None);reply=REPLY(lambda ctx,req,result,body: replies.append((result,json.loads(body))) or result);emit=EMIT(lambda *_:0);get=GET_RUNTIME(lambda _:None)
host=Host(c.sizeof(Host),1,None,b'quest3.vrvd',b'windows-x64',str(root).encode(),None,None,log,reply,emit,get)
def send(action,**kw):return m.on_message(b'test',encode(dict(action=action,**kw)))
for cycle in range(3):
 assert m.initialize(c.byref(host),encode(manifest['default_configuration']))==0
 try:
  assert send('status')==0;s=replies[-1][1]
  assert s['module_version']==manifest['version'] and s['hud_mode']=='off' and s['hud_refresh_hz']==20
  assert not s['performance']['application_metrics_fresh']
  for name in ['eye_render_cpu_ms','eye_readback_cpu_ms','upload_submit_cpu_ms']:
   assert s['performance'][name] is None
  assert 'CPU wall time' in s['performance']['timing_scope']
  assert not s['ui_transition']['menu_focus_enabled'] and s['ui_transition']['menu_blur_radius']==9
  assert s['ui_transition']['capture_policy']=='engine_final_result_cpu_readback' and s['ui_transition']['window_capture_used'] is False
  assert s['ui_transition']['engine_camera_source']=='auto'
  assert s['hud_capture_path']=='hg_final_result_information_panel'
  assert m.configuration_changed(encode(dict(engine_camera_source='invalid',vulkan_eye_width=2048)))!=0
  send('status');assert replies[-1][1]['configured_vulkan_eye_width']==2560
  assert not s['ui_transition']['transparent_hud_ready'] and not s['ui_transition']['paired_first_person']
  assert m.configuration_changed(encode(dict(transition_fade_ms=500)))==0
  send('status');assert replies[-1][1]['ui_transition']['transition_fade_ms']==300
  assert lib.EFVR_QueryFirstPersonGate()==0
  assert s['ui_transition']['gameplay_hud_hidden'] and s['ui_transition']['transition_fade_ms']==300
  assert m.configuration_changed(encode(dict(native_menu_overlay=True,transition_revision=2,transition_total_ms=250,transition_fade_ms=250)))==0
  send('status');assert replies[-1][1]['hud_mode']=='off' and replies[-1][1]['ui_transition']['transition_fade_ms']==250
  assert m.configuration_changed(encode(dict(transition_fade_ms=601)))!=0
  send('status');assert replies[-1][1]['ui_transition']['transition_fade_ms']==250
  # Deliberately invalid overlay config must not change any earlier parsed setting.
  assert m.configuration_changed(encode(dict(vulkan_eye_width=2048,ui_overlay_panels=[3])))!=0
  send('status');assert replies[-1][1]['configured_vulkan_eye_width']==2560
  assert m.configuration_changed(encode(dict(hud_mode='head_locked',desktop_render_mode='headset_only')))==0
  send('status');assert replies[-1][1]['hud_mode']=='off' and replies[-1][1]['desktop_render_mode']=='normal'
  assert m.configuration_changed(encode(dict(native_menu_overlay=False)))==0
  send('status');assert replies[-1][1]['hud_mode']=='off'
  assert m.configuration_changed(encode(dict(native_menu_overlay='invalid')))!=0
  send('status');assert replies[-1][1]['hud_mode']=='off'
  assert m.configuration_changed(encode(dict(menu_focus_enabled=False,menu_blur_radius=12,menu_background_brightness=.3,menu_feather_px=10)))==0
  send('status');assert not replies[-1][1]['ui_transition']['menu_focus_enabled']
  assert m.configuration_changed(encode(dict(menu_focus_enabled=True,menu_blur_radius=17)))!=0
  send('status');assert not replies[-1][1]['ui_transition']['menu_focus_enabled'] and replies[-1][1]['ui_transition']['menu_blur_radius']==12
  assert m.configuration_changed(encode(dict(vulkan_eye_width=1024,vulkan_eye_height=1024,hud_capture_width=1280,hud_capture_height=720)))==0
  send('status');q=replies[-1][1];assert q['configured_vulkan_eye_width']==2560 and q['hud_capture_width']==2560 and q['ui_transition']['quality_migrated']
  assert m.configuration_changed(encode(dict(ui_quality_revision=1,vulkan_eye_width=1024,vulkan_eye_height=1024,hud_capture_width=1280,hud_capture_height=720,hud_layout='edges')))==0
  send('status');q=replies[-1][1];assert q['configured_vulkan_eye_width']==1024 and q['hud_capture_width']==1280 and not q['ui_transition']['quality_migrated'] and q['hud_capture_path']=='hg_final_result_edge_crops'
  assert m.configuration_changed(encode(dict(ui_quality_revision=1,vulkan_eye_width=3072,vulkan_eye_height=3072,hud_capture_width=3840,hud_capture_height=2160)))==0
  send('status');q=replies[-1][1];assert q['configured_vulkan_eye_width']==3072 and q['hud_capture_width']==3840 and q['hud_capture_height']==2160
  assert m.configuration_changed(encode(dict(hud_capture_width=4097)))!=0
  send('status');assert replies[-1][1]['hud_capture_width']==3840
  assert send('start',first_person_confirmed=True)!=0
  for action in ['learn_gameplay_ui','menu_mode','auto_mode','stop']:assert send(action)==0
 finally:m.shutdown()
fp=root.parent/'first-person-ui-guard-056/native/windows-x64/example.first-person.dll';guard=c.CDLL(str(fp));assert guard.EFVR_FirstPersonGuardVersion()==1
kernel=c.WinDLL('kernel32');kernel.GetModuleHandleW.argtypes=[c.c_wchar_p];kernel.GetModuleHandleW.restype=c.c_void_p
for name in ['GameAssembly.dll','openvr_api.dll','openxr_loader.dll']:assert not kernel.GetModuleHandleW(name)
print('PASS: release ABI x3, paired guard export, overlay config migration and disable, invalid config atomicity, no-game rejection, no runtime loaded')
