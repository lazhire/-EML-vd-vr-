"""Build the paired first-person guard only; never launches the game."""
from pathlib import Path
import argparse,os,subprocess
p=argparse.ArgumentParser();p.add_argument('--zig',type=Path,required=True);p.add_argument('--scratch',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1];fp=root.parent/'first-person-ui-guard-056';scratch=a.scratch.resolve();scratch.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
for k,n in [('TEMP','tmp'),('TMP','tmp'),('ZIG_GLOBAL_CACHE_DIR','zig-global'),('ZIG_LOCAL_CACHE_DIR','zig-local')]:
 d=scratch/n;d.mkdir(exist_ok=True);env[k]=str(d)
dest=fp/'native/windows-x64';dest.mkdir(exist_ok=True)
subprocess.run([str(a.zig.resolve()),'c++','-target','x86_64-windows-gnu','-std=c++20','-fms-extensions','-O2','-shared',
 '-I'+str(root/'vendor/eml'),'-I'+str(root/'vendor'),str(fp/'native/module.cpp'),'-o',str(dest/'example.first-person.dll'),'-luser32'],env=env,cwd=scratch,check=True)
print('Built paired first-person guard:',dest/'example.first-person.dll')
