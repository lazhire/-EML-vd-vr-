"""Create verified EML imports and a Q3 debug kit. Never install or launch."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[1];fp=root.parent/'first-person-ui-guard-056'
checks=json.loads((root/'BUILD_CHECKS.json').read_text(encoding='utf8'))
assert checks['result']=='PASS' and checks['version']=='0.6.9-smooth-popup'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(root/'native/windows-x64/quest3.vrvd.dll')==checks['library_sha256']
assert digest(fp/'native/windows-x64/example.first-person.dll')==checks['first_person_sha256']
for name,expected in checks['source_sha256'].items():assert digest(root.parent/name)==expected,'Source changed after verification: '+name
def write_zip(dest,entries,importable=False):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
  hashes={}
  for name,p in sorted(entries.items()):
   data=p.read_bytes();z.writestr(name,data);hashes[name]=hashlib.sha256(data).hexdigest()
  z.writestr('SHA256SUMS.json',json.dumps(hashes,indent=2))
 with zipfile.ZipFile(dest) as z:
  assert z.testzip() is None
  if importable:
   m=json.loads(z.read('module.json'));assert m['ui'] in z.namelist()
   for lib in m['libraries'].values():assert lib in z.namelist()
  for name,h in json.loads(z.read('SHA256SUMS.json')).items():assert hashlib.sha256(z.read(name)).hexdigest()==h
 dest.with_suffix('.zip.sha256').write_text(digest(dest)+'  '+dest.name+'\n',encoding='ascii')
def sources(folder):
 for sub in ['src','native','tools','tests','vendor']:
  for p in (folder/sub).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts and 'windows-x64' not in p.parts and p.suffix not in {'.exe','.dll','.o','.obj','.pyc','.pdb','.a','.lib'}:
    yield 'source/'+p.relative_to(folder).as_posix(),p
imports=[]
for folder,name in [(fp,'FirstPerson-056-EML-IMPORT.zip'),(root,'EFVR-0.6.9-EML-IMPORT.zip')]:
 m=json.loads((folder/'module.json').read_text(encoding='utf8'));dest=root.parent/name
 entries={n:folder/n for n in ['module.json','README.md','LICENSE','THIRD_PARTY_NOTICES.md']}
 for name in m['libraries'].values():entries[name]=folder/name
 for p in (folder/'ui').rglob('*'):
  if p.is_file():entries[p.relative_to(folder).as_posix()]=p
 entries.update(dict(sources(folder)))
 if folder==root:
  for name in ['BUILD_CHECKS.json','VALIDATION.md','开始这里.txt','Collect-Diagnostics.ps1','Collect-Diagnostics.cmd','UI-ROUTING-EVIDENCE.json','TRANSITION-DESIGN.txt','FIRST-PERSON-REGRESSION.json','ACTIVITY-ROUTING-067.json','PERFORMANCE-NOTES.txt']:entries[name]=root/name
 write_zip(dest,entries,True);imports.append(dest)
outer=root.parent/'EFVR-0.6.9-Q3-DEBUG-KIT.zip'
entries={'01-FirstPerson-056-EML-IMPORT.zip':imports[0],'02-EFVR-0.6.9-EML-IMPORT.zip':imports[1]}
for name in ['开始这里.txt','Collect-Diagnostics.ps1','Collect-Diagnostics.cmd','BUILD_CHECKS.json','VALIDATION.md','UI-ROUTING-EVIDENCE.json','TRANSITION-DESIGN.txt','FIRST-PERSON-REGRESSION.json','ACTIVITY-ROUTING-067.json','PERFORMANCE-NOTES.txt']:entries[name]=root/name
audit=root.parent/'render-feasibility-20261112'
for name in ['审查结论.txt','extraction-enums.json']:entries['audit/'+name]=audit/name
entries['Flat-Compare.cmd']=root/'Flat-Compare.cmd'
entries['tools/vrvd-vulkan-probe.exe']=root/'native/windows-x64/vrvd-vulkan-probe.exe'
write_zip(outer,entries)
print(json.dumps(dict(bundle=str(outer),bytes=outer.stat().st_size,sha256=digest(outer),imports=[str(p) for p in imports]),indent=2))
