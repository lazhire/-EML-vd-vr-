"use strict";
// Fake DOM + EML bridge checks. No browser, loader, game or VR session is opened.
const fs = require("node:fs"), path = require("node:path"), vm = require("node:vm");
const root = path.resolve(__dirname,"..");
const html = fs.readFileSync(path.join(root,"ui/index.html"),"utf8");
const script = fs.readFileSync(path.join(root,"ui/app.js"),"utf8");
let checks = 0;
function check(value, message) { ++checks; if (!value) throw new Error(message); }
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
check(new Set(ids).size === ids.length,"HTML IDs must be unique");
for (const m of script.matchAll(/el\("([^"]+)"\)/g)) check(ids.includes(m[1]),"Missing element: "+m[1]);
async function setup(configuration = {}, connection = {connected:true,mode:"game"}) {
  const nodes = new Map(ids.map(id=>[id,{checked:false,disabled:true,hidden:false,textContent:"",_value:"",
    get value(){return this._value;},set value(v){this._value=String(v);}}]));
  let receiver, failSave = false, delaySave = null;
  const saved = [], sent = [];
  const bridge = {
    readConfig:async()=>structuredClone(configuration), status:async()=>connection,
    onmessage:fn=>{receiver=fn;return ()=>{};},
    send:async v=>sent.push(v),
    saveConfig:async v=>{if(failSave)throw new Error("controlled save failure");if(delaySave)await delaySave;saved.push(structuredClone(v));}
  };
  const context = vm.createContext({console,document:{getElementById:id=>{if(!nodes.has(id))throw new Error("Unknown DOM ID "+id);return nodes.get(id);}},
    window:{betterEndfield:bridge,addEventListener:()=>{}},navigator:{clipboard:{writeText:async()=>{}}},
    setTimeout:()=>1,clearTimeout:()=>{},Date});
  vm.runInContext(script,context,{filename:"ui/app.js"});
  await new Promise(resolve=>setImmediate(resolve));
  const state = extra => receiver({kind:"reply",body:{state:"ready_disabled",hooks_ready:true,requested:false,
    render_event_pending:false,teardown_pending:false,recovery_pending:false,restart_required:false,...extra}});
  return {nodes,saved,sent,state,setFailure:v=>{failSave=v;},setDelay:v=>{delaySave=v;}};
}
(async()=>{
  const fresh = await setup(); const e=id=>fresh.nodes.get(id);
  check(e("quality-preset").value==="custom"&&e("vulkan-width").value==="1024"&&e("vulkan-height").value==="1024","Fresh profile must be custom/1024");
  check(e("width").value==="1440"&&e("height").value==="1440","D3D profile must remain 1440");
  check(e("hud-enabled").checked&&e("hud-composition").value==="game_ui"&&e("hud-refresh").value==="10","HUD defaults must be on/transparent/10Hz");
  check(e("hud-distance").value==="1.5"&&e("hud-width").value==="1.8"&&e("hud-offset").value==="0","Fresh HUD default is centered in front");
  check(e("hud-capture-width").value==="1280"&&e("hud-capture-height").value==="720","HUD default capture size");
  check(e("desktop-render-mode").value==="normal"&&e("runtime-backend").value==="openxr","Default EML OpenXR/desktop mode");
  check(fresh.sent.length===1&&fresh.sent[0].action==="status","Page must not auto-start VR");
  check(e("apply-performance").disabled&&e("map-native-hud").disabled,"Before game status, full config presets must be disabled");
  for(const flag of ["requested","render_event_pending","teardown_pending","recovery_pending","restart_required"]){
    fresh.state({[flag]:true});
    check(e("apply-performance").disabled&&e("map-native-hud").disabled&&e("save").disabled,"Presets/save must wait for "+flag);
    await e("apply-performance").onclick();
    await e("map-native-hud").onclick();
    check(fresh.saved.length===0,"Programmatic presets must also reject "+flag);
  }
  fresh.state({}); check(!e("apply-performance").disabled,"Stopped/clean state allows reset");
  await e("preset-1024").onclick();check(fresh.saved.length===0,"Size shortcut fills form only");
  const old={quality_preset:"maximum",vulkan_eye_width:3072,vulkan_eye_height:3072,runtime_backend:"steamvr_openvr",
    openxr_loader_path:"C:\\custom\\openxr_loader.dll",openvr_loader_path:"D:\\VR\\openvr_api.dll",swap_eyes:true,
    hud_mode:"head_locked",hud_composition:"opaque",hud_distance_m:2.5,hud_width_m:0.8,hud_offset_y_m:-0.5,
    desktop_render_mode:"headset_only",user_extra:"keep"};
  const upgraded=await setup(old), u=id=>upgraded.nodes.get(id);
  check(u("quality-preset").value==="maximum"&&u("vulkan-width").value==="3072","Existing saved high profile is displayed, not silently changed");
  upgraded.state({});
  let release;upgraded.setDelay(new Promise(resolve=>{release=resolve;}));
  const saving=u("apply-performance").onclick();
  upgraded.state({});
  check(u("apply-performance").disabled&&u("map-native-hud").disabled&&u("save").disabled&&u("apply-view").disabled,"Status poll must not enable overlapping saves");
  release();await saving;upgraded.setDelay(null);
  const result=upgraded.saved[0];
  check(result.quality_preset==="custom"&&result.vulkan_eye_width===1024&&result.vulkan_eye_height===1024,"Reset saves low eye profile");
  check(result.hud_mode==="head_locked"&&result.hud_composition==="opaque"&&result.hud_capture_width===1280&&result.hud_capture_height===720&&result.hud_refresh_hz===10,"Performance preset retains HUD mode/composition while reducing capture load");
  check(result.hud_distance_m===2.5&&result.hud_width_m===0.8&&result.hud_offset_y_m===-0.5,"Performance preset retains HUD pose");
  check(result.desktop_render_mode==="normal","Reset disables experimental desktop filter");
  check(result.runtime_backend===old.runtime_backend&&result.openxr_loader_path===old.openxr_loader_path&&result.openvr_loader_path===old.openvr_loader_path,"Reset preserves runtime and loader configuration");
  check(result.swap_eyes===true&&result.hud_distance_m===2.5&&result.user_extra==="keep","Reset preserves unrelated configuration");
  check(u("hud-enabled").checked&&u("hud-composition").value==="opaque"&&u("vulkan-width").value==="1024"&&u("desktop-render-mode").value==="normal","Performance preset reflects preserved HUD in form");
  u("desktop-render-mode").value="headset_only";await u("save").onclick();
  check(upgraded.saved.at(-1).desktop_render_mode==="headset_only","Stopped configuration save includes selected desktop mode");
  const savedCount=upgraded.saved.length;u("desktop-render-mode").value="disable_all_cameras";await u("save").onclick();
  check(upgraded.saved.length===savedCount,"Reject invalid desktop mode");
  upgraded.state({requested:true,desktop_render_mode:"headset_only",desktop_filter:{installed:true,filtered_calls:10,status:"armed"}});
  check(u("desktop-filter-effect").textContent.includes("未观察"),"Nonzero accumulated count alone is not proof of current optimization");
  upgraded.state({requested:true,desktop_render_mode:"headset_only",desktop_filter:{installed:true,filtered_calls:11,status:"armed"}});
  check(u("desktop-filter-effect").textContent.includes("最近已观察"),"Increasing count provides evidence");
  const diagnostic=JSON.parse(u("diagnostic-record").textContent);
  check(diagnostic.desktop_render_mode==="headset_only"&&diagnostic.desktop_filter.filtered_calls===11,"Diagnostics include actual filter state");
  upgraded.state({requested:false,desktop_render_mode:"normal",desktop_filter:{installed:false,filtered_calls:11,error:"metadata unavailable"}});
  check(u("desktop-filter-effect").textContent.includes("未观察")&&u("desktop-filter-error").textContent==="metadata unavailable","Stopped/fallback state must not claim current filtering");
  const failed=await setup(old), f=id=>failed.nodes.get(id);failed.state({});failed.setFailure(true);
  await f("apply-performance").onclick();
  check(failed.saved.length===0&&f("vulkan-width").value==="3072"&&f("performance-saved").textContent.includes("预设未保存"),"Failed reset does not report success or overwrite form");
  check(!f("apply-performance").disabled,"Failed reset releases save guard");
  const oldOff={...old,hud_mode:"off",eye_width:1600,eye_height:1440,eye_labels:true,custom_nested:{keep:"me"}};
  const mapping=await setup(oldOff), m=id=>mapping.nodes.get(id);
  check(!m("hud-enabled").checked&&mapping.saved.length===0,"Old HUD-off config is never silently enabled");
  mapping.state({hud_status:"off",hud_canvas_count:0});
  const statusBeforeMap=m("hud-status").textContent;
  const missingLayout=JSON.parse(m("diagnostic-record").textContent);
  check(!("hud_distance_m" in missingLayout)&&!("hud_width_m" in missingLayout)&&!("hud_offset_y_m" in missingLayout),"Missing runtime layout must not be guessed from saved config or defaults");
  let mappingRelease; mapping.setDelay(new Promise(resolve=>{mappingRelease=resolve;}));
  const mappingSave=m("map-native-hud").onclick();
  mapping.state({hud_status:"off",hud_canvas_count:0});
  check(m("map-native-hud").disabled&&m("apply-performance").disabled&&m("apply-view").disabled&&m("save").disabled,"Native HUD save blocks all competing config writes");
  await m("apply-performance").onclick();await m("map-native-hud").onclick();
  mappingRelease();await mappingSave;mapping.setDelay(null);
  check(mapping.saved.length===1,"Concurrent preset invocations do not queue extra writes");
  const mapped=mapping.saved[0];
  const hudChanges={hud_mode:"head_locked",hud_composition:"game_ui",hud_distance_m:1.5,hud_width_m:1.8,hud_offset_y_m:0,
    hud_capture_width:1280,hud_capture_height:720,hud_refresh_hz:10};
  for(const [key,value] of Object.entries(hudChanges))check(mapped[key]===value,"Native HUD mapping saves "+key);
  for(const [key,value] of Object.entries(oldOff))if(!(key in hudChanges))check(JSON.stringify(mapped[key])===JSON.stringify(value),"Native HUD mapping preserves "+key);
  check(m("hud-enabled").checked&&m("hud-width").value==="1.8"&&m("hud-offset").value==="0","Successful mapping refreshes HUD form");
  check(m("native-hud-saved").textContent.includes("配置已保存")&&m("native-hud-saved").textContent.includes("尚未证明"),"Saved mapping does not assert capture success");
  check(m("hud-status").textContent===statusBeforeMap,"Saving config must not rewrite runtime capture status");
  mapping.state({requested:true,hud_status:"captured_pending_visual_check",hud_canvas_count:4,hud_distance_m:1.75,hud_width_m:1.35,hud_offset_y_m:-0.25});
  check(m("hud-status").textContent.includes("仍需确认")&&m("hud-canvas-count").textContent==="4 个","Runtime capture report retains headset verification caveat and native Canvas count");
  const actualLayout=JSON.parse(m("diagnostic-record").textContent);
  check(actualLayout.hud_distance_m===1.75&&actualLayout.hud_width_m===1.35&&actualLayout.hud_offset_y_m===-0.25,"Copied diagnostics retain actual runtime HUD layout, not local form values");
  mapping.state({hud_distance_m:1.5,hud_width_m:1.8,hud_offset_y_m:0});
  check(JSON.parse(m("diagnostic-record").textContent).hud_offset_y_m===0,"Centered runtime offset zero must not be omitted");
  mapping.state({requested:true,hud_status:"unavailable",hud_canvas_count:0,hud_error:"controlled capture error"});
  check(m("hud-error").textContent==="controlled capture error"&&m("hud-status").textContent.includes("不可用"),"Native HUD capture errors stay visible");
  m("hud-enabled").checked=false;await m("apply-view").onclick();
  check(mapping.saved.at(-1).hud_mode==="off","Manual HUD control can still disable mapping");
  const stillOff=await setup(oldOff);stillOff.state({});await stillOff.nodes.get("apply-performance").onclick();
  check(stillOff.saved[0].hud_mode==="off"&&stillOff.saved[0].hud_width_m===oldOff.hud_width_m,"Performance preset also preserves explicitly disabled HUD");
  const mappingFailure=await setup(oldOff), mf=id=>mappingFailure.nodes.get(id);mappingFailure.state({});mappingFailure.setFailure(true);
  await mf("map-native-hud").onclick();
  check(mappingFailure.saved.length===0&&!mf("hud-enabled").checked&&mf("hud-width").value==="0.8"&&mf("native-hud-saved").textContent.includes("未保存"),"Mapping save failure does not enable HUD or change form");
  check(!mf("map-native-hud").disabled,"Mapping failure releases save guard");
  const offline=await setup({}, {connected:true,mode:"offline"});
  check(!offline.nodes.get("apply-performance").disabled&&!offline.nodes.get("map-native-hud").disabled&&offline.sent.length===0,"Explicit EML offline configuration mode permits presets without game messages");
  await offline.nodes.get("map-native-hud").onclick();
  check(offline.saved.length===1&&offline.saved[0].hud_mode==="head_locked"&&offline.sent.length===0,"Offline native HUD mapping saves configuration only");
  const disconnected=await setup({}, {connected:false});
  check(disconnected.nodes.get("apply-performance").disabled&&disconnected.nodes.get("map-native-hud").disabled,"Unknown disconnected host cannot prove resources are idle");
  await disconnected.nodes.get("apply-performance").onclick();
  await disconnected.nodes.get("map-native-hud").onclick();
  check(disconnected.saved.length===0,"Disconnected reset guard prevents writes");
  console.log("PASS: EML UI "+checks+" assertions; fake DOM/bridge only, no game/VR");
})().catch(error=>{console.error(error);process.exitCode=1;});
