"""Compile and run pure routing and fake-managed extraction tests; no game/VR."""
from pathlib import Path
import argparse,os,subprocess
p=argparse.ArgumentParser();p.add_argument('--zig',type=Path,required=True);p.add_argument('--scratch',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1];scratch=a.scratch.resolve();scratch.mkdir(parents=True,exist_ok=True);env=os.environ.copy()
for k,n in [('TEMP','tmp'),('TMP','tmp'),('ZIG_GLOBAL_CACHE_DIR','zig-global'),('ZIG_LOCAL_CACHE_DIR','zig-local')]:
 d=scratch/n;d.mkdir(exist_ok=True);env[k]=str(d)
for name in ['first_person_regression_066_test','flat_transition_test','engine_final_capture_test','ui_observer_contract_test','ui_route_test','native_menu_capture_test','first_person_pause_test','edge_hud_test']:
 exe=scratch/(name+'.exe')
 subprocess.run([str(a.zig.resolve()),'c++','-target','x86_64-windows-gnu','-std=c++17','-O2',
  '-I'+str(root/'vendor/eml'),str(root/'tests'/(name+'.cpp')),'-o',str(exe)],env=env,cwd=scratch,check=True)
 subprocess.run([str(exe)],env=env,cwd=scratch,check=True,timeout=30)
