"""Test the actual Gaussian/feather transform with synthetic pixels, no game."""
from pathlib import Path
import argparse,os,subprocess
p=argparse.ArgumentParser();p.add_argument('--zig',type=Path,required=True);p.add_argument('--scratch',type=Path,required=True);a=p.parse_args()
r=Path(__file__).resolve().parents[1];scratch=a.scratch.resolve();env=os.environ.copy()
for k,n in [('TEMP','tmp'),('TMP','tmp'),('ZIG_GLOBAL_CACHE_DIR','zig-global'),('ZIG_LOCAL_CACHE_DIR','zig-local')]:
 d=scratch/n;d.mkdir(parents=True,exist_ok=True);env[k]=str(d)
exe=scratch/'menu-focus-test-058.exe'
subprocess.run([str(a.zig.resolve()),'c++','-target','x86_64-windows-gnu','-std=c++17','-O2',str(r/'tests/menu_focus_test.cpp'),'-o',str(exe)],env=env,cwd=scratch,check=True)
subprocess.run([str(exe),str(scratch/'menu-focus-synthetic')],env=env,cwd=scratch,check=True,timeout=30)
