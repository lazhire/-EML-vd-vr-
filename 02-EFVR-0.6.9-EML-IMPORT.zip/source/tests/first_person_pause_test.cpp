#include "../../first-person-ui-guard-056/native/vr_ui_pause.h"
#include <cassert>
#include <iostream>
int main(){
 VrUiPause p;p.suspended(true,true,false,false);assert(p.resume);
 p.suspended(false,true,false,false);assert(p.resume);
 assert(p.released(false,true,false,false));assert(!p.released(false,true,false,false));
 p.suspended(true,true,false,false);p.suspended(false,true,true,false);assert(!p.released(false,true,false,false));
 p.suspended(true,true,false,false);p.suspended(false,true,false,true);assert(!p.resume);
 p.suspended(false,true,false,true);assert(p.resume);assert(!p.released(false,false,false,false));
 p.suspended(true,true,false,false);assert(!p.released(true,true,false,false));
 p.suspended(true,true,false,false);assert(!p.released(false,true,false,true));
 std::cout<<"PASS: first-person intent survives menus, explicit exit/disable wins, toggle is consumed once, resume is not duplicated\n";
}
