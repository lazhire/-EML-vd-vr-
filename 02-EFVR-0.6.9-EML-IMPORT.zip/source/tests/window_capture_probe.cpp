#include "../src/window_menu_capture.h"
#include <windows.h>
#include <fstream>
#include <iostream>
#include <thread>
#include <chrono>
int main(int argc,char** argv){
 if(argc!=3){std::cerr<<"Usage: probe PID OUTPUT.bmp (captures only that process's Unity window)\n";return 2;}
 auto dpi=reinterpret_cast<BOOL(WINAPI*)(HANDLE)>(GetProcAddress(GetModuleHandleW(L"user32.dll"),"SetProcessDpiAwarenessContext"));if(dpi)dpi(reinterpret_cast<HANDLE>(-4));
 vrvd::WindowMenuCapture c;c.probe_process(std::stoul(argv[1]));std::string e;std::vector<uint8_t> p;bool fresh=false;
 for(unsigned session=0;session<2;++session){
  for(uint64_t gen=1;gen<=2;++gen){
   fresh=false;
   for(int i=0;i<300&&!fresh;++i){if(!c.poll(gen+session*2,1280,720,p,fresh,e)){std::cerr<<e<<"\n";c.cleanup();return 1;}if(i==0&&fresh){std::cerr<<"Reused prior generation frame\n";c.cleanup();return 1;}std::this_thread::sleep_for(std::chrono::milliseconds(20));}
   if(!fresh){std::cerr<<"No completed frame: "<<c.status<<"\n";c.cleanup();return 1;}
  }
  c.cleanup();if(c.resources_alive()){std::cerr<<"Capture resources not released\n";return 1;}
 }
 BITMAPFILEHEADER f{};BITMAPINFOHEADER b{};f.bfType=0x4d42;f.bfOffBits=sizeof(f)+sizeof(b);f.bfSize=f.bfOffBits+DWORD(p.size());b.biSize=sizeof(b);b.biWidth=1280;b.biHeight=-720;b.biPlanes=1;b.biBitCount=32;b.biCompression=BI_RGB;
 for(size_t i=0;i<p.size();i+=4)std::swap(p[i],p[i+2]);std::ofstream o(argv[2],std::ios::binary);o.write(reinterpret_cast<char*>(&f),sizeof f);o.write(reinterpret_cast<char*>(&b),sizeof b);o.write(reinterpret_cast<char*>(p.data()),p.size());
 std::cout<<"Captured window client "<<c.source_width<<"x"<<c.source_height<<" -> 1280x720; 2 sessions / 4 fresh generations / cleanup verified. No injection, no game input.\n";c.cleanup();return 0;
}
