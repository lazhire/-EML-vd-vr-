#include "../src/native_ui_overlay.h"
#include <map>
#include <stdexcept>
#include <iostream>
// HG field contracts/restoration are exercised separately against the real helper.
namespace vrvd {
struct HgUiCamera::Impl{bool dirty=false;};
HgUiCamera::HgUiCamera():impl_(new Impl){} HgUiCamera::~HgUiCamera()=default;
bool HgUiCamera::resolve(const BE_HostApiV1*,HudNativeResolver,std::string&){return true;}
bool HgUiCamera::begin_existing(void*,std::string&){impl_->dirty=true;return true;}
bool HgUiCamera::restore_existing(std::string&){impl_->dirty=false;return true;}
bool HgUiCamera::restore_pending()const{return impl_->dirty;}
}
using namespace vrvd;
namespace {
void require(bool b,const char* e){if(!b)throw std::runtime_error(e);}
void* ptr(uintptr_t p){return reinterpret_cast<void*>(p);}
struct Color{float r,g,b,a;};Color bg{.2f,.3f,.4f,1.f};
void* oldTarget=ptr(12);void* currentTarget=oldTarget;void* oldActive=ptr(13);void* active=oldActive;
int flags=3,boxed=0,w=8,h=8,rendered=0;uintptr_t nextObj=100;
std::vector<std::string> methods(1);std::map<uint32_t,void*> roots;uint32_t nextRoot=1;
bool renderFail=false,restoreFail=false,opaque=false,throwRead=false,ctorFail=false,silentTarget=false;
BE_Result BE_CALL resolve(void*,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* r){
 require(std::string(d->class_name)!="Canvas","must not bind Canvas mutators");
 methods.push_back(d->method_name);r->method_info=ptr(methods.size()-1);return BE_Result_Ok;
}
BE_Result BE_CALL cls(void*,const char*,const char*,const char*,BE_ResolvedClassV1* r){r->class_info=ptr(99);r->type_object=ptr(99);return BE_Result_Ok;}
void* BE_CALL invoke(void*,const void* method,void* obj,void** args,void** ex){
 *ex=nullptr;auto n=methods.at(reinterpret_cast<uintptr_t>(method));
 if(n=="get_uiCamera")return ptr(10);
 if(n=="get_targetTexture")return currentTarget;
 if(n=="set_targetTexture"){if(restoreFail&&args[0]==oldTarget){*ex=ptr(1);return nullptr;}if(silentTarget&&args[0]!=oldTarget)return nullptr;currentTarget=args[0];return nullptr;}
 if(n=="get_active")return active;
 if(n=="set_active"){active=args[0];return nullptr;}
 if(n=="get_clearFlags"){boxed=flags;return &boxed;}
 if(n=="set_clearFlags"){flags=*static_cast<int*>(args[0]);return nullptr;}
 if(n=="get_backgroundColor")return &bg;
 if(n=="set_backgroundColor"){bg=*static_cast<Color*>(args[0]);return nullptr;}
 if(n=="get_pixelWidth"||n=="get_pixelHeight"){boxed=8;return &boxed;}
 if(n==".ctor"){w=*static_cast<int*>(args[0]);h=*static_cast<int*>(args[1]);if(ctorFail)*ex=ptr(1);return nullptr;}
 if(n=="Create"){boxed=1;return &boxed;}
 if(n=="Render"){
  require(obj==ptr(10)&&currentTarget!=oldTarget&&flags==2&&bg.a==0,"must render original UI camera with owned transparent target");
  ++rendered;if(renderFail)*ex=ptr(1);return nullptr;
 }
 if(n=="ReadPixels"&&throwRead)throw std::runtime_error("fake C++ allocation exception");
 if(n=="GetRawTextureData")return ptr(15);
 if(n=="get_Length"){boxed=w*h*4;return &boxed;}
 if(n=="Copy"){
  auto dst=reinterpret_cast<uint8_t*>(*static_cast<intptr_t*>(args[2]));
  for(int y=0;y<h;++y)for(int x=0;x<w;++x){size_t i=(y*w+x)*4;bool ink=x==2&&y==1;dst[i]=ink?70:0;dst[i+1]=ink?35:0;dst[i+2]=0;dst[i+3]=opaque?255:ink?128:0;}
 }
 return nullptr;
}
void restored(){require(currentTarget==oldTarget&&active==oldActive&&flags==3&&bg.r==.2f&&bg.a==1,"original camera/active RT must be restored");}
}
int main(){
 BE_HostApiV1 api{};api.resolve_method=resolve;api.resolve_class=cls;api.runtime_invoke=invoke;
 api.object_unbox=+[](void*,void* p)->void*{return p;};api.object_new=+[](void*,const void*)->void*{return ptr(++nextObj);};
 api.gchandle_new=+[](void*,void* p,int)->uint32_t{auto id=nextRoot++;roots[id]=p;return id;};api.gchandle_free=+[](void*,uint32_t id){roots.erase(id);};
 NativeUiOverlay c;std::string e;std::vector<uint8_t> pixels;
 require(c.resolve(&api,e),"resolve");
 require(c.capture(ptr(9),8,8,pixels,e),"capture transparent UI");restored();
 require(pixels[((8-1-1)*8+2)*4]==70&&pixels[((8-1-1)*8+2)*4+3]==128,"flip once, preserve premultiplied native color and alpha");
 silentTarget=true;int before=rendered;require(!c.capture(ptr(9),8,8,pixels,e)&&rendered==before,"ignored target write must not render into original game output");silentTarget=false;restored();
 opaque=true;require(!c.capture(ptr(9),8,8,pixels,e)&&pixels.empty(),"opaque frame must never cover VR");opaque=false;restored();
 renderFail=true;require(!c.capture(ptr(9),8,8,pixels,e)&&pixels.empty(),"managed render failure hidden");renderFail=false;restored();
 throwRead=true;bool threw=false;try{c.capture(ptr(9),8,8,pixels,e);}catch(const std::runtime_error&){threw=true;}throwRead=false;require(threw,"C++ exception must propagate after restoration");restored();
 restoreFail=true;require(!c.capture(ptr(9),8,8,pixels,e)&&c.restore_pending()&&pixels.empty(),"failed restore retains original refs, refuses frame");
 require(!c.cleanup(e)&&c.resources_alive(),"pending restoration must prevent texture destruction");restoreFail=false;
 require(c.cleanup(e)&&!c.resources_alive(),"restore retry and cleanup");restored();require(roots.empty(),"roots released");
 ctorFail=true;require(!c.capture(ptr(9),8,8,pixels,e),"partial allocation failed");ctorFail=false;
 require(c.capture(ptr(9),8,8,pixels,e),"retry reconstructs incompletely initialized images");require(c.cleanup(e)&&roots.empty(),"final cleanup");
 // Pixel conversion must not invent transparency or paint black edges.
 std::vector<uint8_t> rgba(8*8*4,0),out;rgba[4]=50;rgba[7]=128;
 require(prepare_menu_overlay(rgba,8,8,16,9,out,e)&&out[3]==0,"transparent aspect-fit bars");
 rgba[4]=255;require(!prepare_menu_overlay(rgba,8,8,16,9,out,e)&&out.empty(),"reject incompatible alpha semantics");
 std::cout<<"PASS: original UI camera only, transparency/orientation/aspect, no Canvas bindings, managed/C++ failures, restore retry, allocation retry; fake host only\n";
}
