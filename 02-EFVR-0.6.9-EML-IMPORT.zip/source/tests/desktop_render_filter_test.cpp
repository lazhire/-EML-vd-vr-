// Fake IL2CPP metadata + EML host. No game, XR runtime, GPU or installation.
#include "../src/desktop_render_filter.h"
#include <cstring>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <map>
#include <stdexcept>
#include <thread>
#include <vector>

namespace {
void require(bool condition,const char* message){if(!condition)throw std::runtime_error(message);}
struct Class;
struct Type {int kind;Class* klass;const char* name;bool ref=false;};
struct Method {const char* name;Type* result;std::vector<Type*> args;};
struct Class {const char* name;const char* ns;std::vector<Method*> methods;int size=8;};
struct Object {Class* klass;std::vector<void*> cameras;bool alive=true;};
struct Fake {
    inline static Fake* current=nullptr;
    Class camera{"Camera","UnityEngine",{}},context{"ScriptableRenderContext","UnityEngine.Rendering",{}},
        pipeline{"HGRenderPipeline","HG.Rendering.Runtime",{}},list{"List`1","System.Collections.Generic",{}},other{"Other","Test",{}};
    Type tVoid{1,nullptr,"System.Void"},tInt{8,nullptr,"System.Int32"},tBool{2,nullptr,"System.Boolean"},
        tCamera{18,&camera,"UnityEngine.Camera"},tContext{17,&context,"UnityEngine.Rendering.ScriptableRenderContext"},
        tList{21,&list,"System.Collections.Generic.List<UnityEngine.Camera>"},tArray{29,nullptr,"UnityEngine.Camera[]"};
    Method ctor{".ctor",&tVoid,{}},count{"get_Count",&tInt,{}},item{"get_Item",&tCamera,{&tInt}},add{"Add",&tVoid,{&tCamera}},
        renderList{"Render",&tVoid,{&tContext,&tList}},renderArray{"Render",&tVoid,{&tContext,&tArray}},
        frame{"get_frameCount",&tInt,{}},equals{"op_Equality",&tBool,{&tCamera,&tCamera}};
    Object source{&camera,{}},nextSource{&camera,{}},eye{&camera,{}},hud{&camera,{}},reflection{&camera,{}};
    BE_HostApiV1 api{};
    vrvd::DesktopRenderFilter* filter=nullptr;
    vrvd::DesktopRenderNative detour=nullptr,oldDetour=nullptr;
    int32_t unityFrame=42,box=0;
    uint32_t nextRoot=1;
    std::map<uint32_t,void*> roots;
    std::vector<std::unique_ptr<Object>> allocated;
    unsigned creates=0,releases=0,calls=0,rootsCreated=0,rootsFreed=0,oldProbes=0;
    bool failRoot=false,throwOriginal=false,failCreate=false,nullOriginal=false,badResolvedIdentity=false,probeOld=false;
    const Method* failMethod=nullptr;
    std::function<void(const Method*)> onInvoke;
    void* seenThis=nullptr;void* seenList=nullptr;const void* seenMethod=nullptr;uintptr_t seenContext=0;
    std::vector<void*> seenCameras;
    static void original(void* pipeline,vrvd::DesktopRenderContext ctx,void* input,const void* method){
        auto& f=*current;++f.calls;f.seenThis=pipeline;f.seenContext=ctx.value;f.seenList=input;f.seenMethod=method;
        f.seenCameras=static_cast<Object*>(input)->cameras;
        if(f.filter)f.filter->snapshot(); // No route mutex may be held around native code.
        if(f.throwOriginal)throw std::runtime_error("original failure");
    }
    Fake(){
        current=this;list.methods={&add,&item,&ctor,&count};pipeline.methods={&renderArray,&renderList};
        api.abi_version=1;api.context=this;
        api.resolve_class=[](void* p,const char*,const char*,const char* name,BE_ResolvedClassV1* out){
            auto& f=*static_cast<Fake*>(p);Class* c=std::strcmp(name,"Camera")==0?&f.camera:std::strcmp(name,"ScriptableRenderContext")==0?&f.context:std::strcmp(name,"HGRenderPipeline")==0?&f.pipeline:nullptr;
            if(!c)return BE_Result_NotFound;*out={c,nullptr,nullptr};return BE_Result_Ok;};
        api.resolve_method=[](void* p,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* out){
            auto& f=*static_cast<Fake*>(p);
            if(std::strcmp(d->method_name,"Render")==0){
                require(std::string(d->assembly_name)=="HG.RenderPipelines.Runtime.dll"&&std::string(d->namespace_name)=="HG.Rendering.Runtime"&&std::string(d->class_name)=="HGRenderPipeline","Render identity changed");
                require(d->parameter_count==2&&std::string(d->parameter_types)=="UnityEngine.Rendering.ScriptableRenderContext|System.Collections.Generic.List<UnityEngine.Camera>"&&std::string(d->return_type)=="System.Void","Render overload was not exact");
                *out={f.badResolvedIdentity?&f.renderArray:&f.renderList,reinterpret_cast<void*>(original)};return BE_Result_Ok;
            }
            if(std::strcmp(d->method_name,"get_frameCount")==0){*out={&f.frame,nullptr};return BE_Result_Ok;}
            if(std::strcmp(d->method_name,"op_Equality")==0){*out={&f.equals,nullptr};return BE_Result_Ok;}
            return BE_Result_NotFound;
        };
        api.create_hook=[](void* p,const char* owner,void* target,void* replacement,void** next){
            auto& f=*static_cast<Fake*>(p);++f.creates;
            require(std::string(owner)=="endfield.vr.desktop","Desktop hook owner collided with eye hook");
            require(target==reinterpret_cast<void*>(original),"Unexpected native target");
            if(f.probeOld){Object input{&f.list,{&f.eye}};f.oldDetour(&f.pipeline,{0x1234},&input,&f.renderList);++f.oldProbes;require(f.seenList==&input,"Old callback lost passthrough before republishing trampoline");}
            if(f.failCreate)return BE_Result_Failed;
            f.detour=reinterpret_cast<vrvd::DesktopRenderNative>(replacement);*next=f.nullOriginal?nullptr:target;return BE_Result_Ok;
        };
        api.release_module_hooks=[](void* p,const char* owner){auto& f=*static_cast<Fake*>(p);require(std::string(owner)=="endfield.vr.desktop","Released another module's hooks");++f.releases;return BE_Result_Ok;};
        api.object_new=[](void* p,const void* c)->void*{auto& f=*static_cast<Fake*>(p);f.allocated.push_back(std::make_unique<Object>(Object{const_cast<Class*>(static_cast<const Class*>(c)),{}}));return f.allocated.back().get();};
        api.object_unbox=[](void*,void* p){return p;};
        api.gchandle_new=[](void* p,void* object,int pinned)->uint32_t{auto& f=*static_cast<Fake*>(p);require(pinned==0,"Unexpected pinned root");if(f.failRoot)return 0;const auto handle=f.nextRoot++;f.roots[handle]=object;++f.rootsCreated;return handle;};
        api.gchandle_free=[](void* p,uint32_t handle){auto& f=*static_cast<Fake*>(p);require(f.roots.erase(handle)==1,"GC root double free");++f.rootsFreed;};
        api.runtime_invoke=[](void* p,const void* method,void* object,void** args,void** exception)->void*{
            auto& f=*static_cast<Fake*>(p);const auto m=static_cast<const Method*>(method);*exception=nullptr;
            const auto action=f.onInvoke;if(action)action(m);
            if(m==f.failMethod){*exception=&f;return nullptr;}
            if(m==&f.frame){f.box=f.unityFrame;return &f.box;}
            if(m==&f.equals){const auto obj=static_cast<Object*>(args[0]);f.box=(!obj||!obj->alive)?1:0;return &f.box;}
            auto& target=*static_cast<Object*>(object);
            if(m==&f.ctor){target.cameras.clear();return nullptr;}
            if(m==&f.count){f.box=int32_t(target.cameras.size());return &f.box;}
            if(m==&f.item){const auto index=*static_cast<int32_t*>(args[0]);return target.cameras.at(size_t(index));}
            if(m==&f.add){target.cameras.push_back(args[0]);return nullptr;}
            throw std::runtime_error("Unexpected managed method");
        };
    }
    static const void* methods(const void* c,void** iterator){const auto& methods=static_cast<const Class*>(c)->methods;const auto index=reinterpret_cast<uintptr_t>(*iterator);if(index>=methods.size())return nullptr;*iterator=reinterpret_cast<void*>(index+1);return methods[index];}
    static const char* methodName(const void* m){return static_cast<const Method*>(m)->name;}
    static uint32_t paramCount(const void* m){return uint32_t(static_cast<const Method*>(m)->args.size());}
    static const void* paramType(const void* m,uint32_t i){return static_cast<const Method*>(m)->args.at(i);}
    static const void* resultType(const void* m){return static_cast<const Method*>(m)->result;}
    static int kind(const void* t){return static_cast<const Type*>(t)->kind;}
    static bool byref(const void* t){return static_cast<const Type*>(t)->ref;}
    static const void* fromType(const void* t){return static_cast<const Type*>(t)->klass;}
    static const char* className(const void* c){return static_cast<const Class*>(c)->name;}
    static const char* classNamespace(const void* c){return static_cast<const Class*>(c)->ns;}
    static int32_t valueSize(const void* c,uint32_t* alignment){*alignment=8;return static_cast<const Class*>(c)->size;}
    static const void* objectClass(void* o){return static_cast<Object*>(o)->klass;}
    static char* typeName(const void* t){const auto name=static_cast<const Type*>(t)->name;auto* copy=static_cast<char*>(std::malloc(std::strlen(name)+1));std::strcpy(copy,name);return copy;}
    static void freeString(void* p){std::free(p);}
    static void* resolver(const char* name){
#define EXPORT(n,f) if(std::strcmp(name,n)==0)return reinterpret_cast<void*>(f)
        EXPORT("il2cpp_class_get_methods",methods);EXPORT("il2cpp_method_get_name",methodName);EXPORT("il2cpp_method_get_param_count",paramCount);
        EXPORT("il2cpp_method_get_param",paramType);EXPORT("il2cpp_method_get_return_type",resultType);EXPORT("il2cpp_type_get_type",kind);
        EXPORT("il2cpp_type_is_byref",byref);EXPORT("il2cpp_class_from_type",fromType);EXPORT("il2cpp_class_get_name",className);
        EXPORT("il2cpp_class_get_namespace",classNamespace);EXPORT("il2cpp_class_value_size",valueSize);EXPORT("il2cpp_object_get_class",objectClass);
        EXPORT("il2cpp_type_get_name",typeName);EXPORT("il2cpp_free",freeString);
#undef EXPORT
        return nullptr;
    }
    void install(vrvd::DesktopRenderFilter& h){filter=&h;std::string error;require(h.install(&api,error,resolver),error.c_str());}
    bool mark(vrvd::DesktopRenderFilter& h,void* source=nullptr){std::string error;return h.mark_submitted(source?source:&this->source,unityFrame,error);}
    void run(Object& input){detour(&pipeline,{0xFEDCBA9876543210ull},&input,&renderList);require(seenThis==&pipeline&&seenContext==0xFEDCBA9876543210ull&&seenMethod==&renderList,"Native forwarding ABI changed");}
    void finish(vrvd::DesktopRenderFilter& h){require(h.shutdown(),"Shutdown failed");require(roots.empty()&&rootsCreated==rootsFreed,"Managed roots leaked");filter=nullptr;}
};

void basic_filter_and_reinstall(){
    Fake f;vrvd::DesktopRenderFilter h;f.install(h);Object input{&f.list,{&f.source,&f.hud,&f.reflection}};
    f.run(input);require(f.seenList==&input,"Unsubmitted desktop was filtered");
    require(f.mark(h),"Submission failed");require(f.roots.size()==1,"Source is not rooted");
    f.run(input);require(f.seenList!=&input&&f.seenCameras==std::vector<void*>({&f.hud,&f.reflection}),"Filter removed other cameras or reordered list");
    require(input.cameras==std::vector<void*>({&f.source,&f.hud,&f.reflection})&&f.roots.size()==1,"Original list changed or clone root leaked");
    Object eyes{&f.list,{&f.eye,&f.hud}};f.run(eyes);require(f.seenList==&eyes,"Private eye/HUD list was cloned");
    Object onlySource{&f.list,{&f.source}};const auto before=f.calls;f.run(onlySource);
    require(f.seenList!=&onlySource&&f.seenCameras.empty()&&f.calls==before+1&&h.snapshot().empty_lists==1,"Empty list did not reach original exactly once");
    ++f.unityFrame;f.run(input);require(f.seenList==&input,"Previous-frame submission suppressed desktop");
    require(f.mark(h),"New frame failed");h.disable();f.run(input);require(f.seenList==&input,"Disable did not restore desktop immediately");
    require(f.mark(h,&f.nextSource)&&f.roots.size()==1,"Source replacement leaked root");
    require(h.clear()&&f.roots.empty(),"Game-thread clear failed");
    f.oldDetour=f.detour;f.finish(h);f.probeOld=true;f.install(h);require(f.oldProbes==1,"Reinstall did not exercise old callback");
    require(f.mark(h),"Reinstalled filter did not arm");f.run(input);require(f.seenList!=&input,"Reinstalled filter stopped filtering");f.finish(h);
}
void metadata_rejections(){
    for(int mode=0;mode<5;++mode){Fake f;vrvd::DesktopRenderFilter h;std::string error;
        if(mode==0)f.context.size=16;
        if(mode==1)f.list.methods.erase(f.list.methods.begin()); // no Add(Camera)
        if(mode==2)f.badResolvedIdentity=true;
        if(mode==3)f.tContext.ref=true;
        if(mode==4)f.item.result=&f.tInt;
        require(!h.install(&f.api,error,Fake::resolver)&&!error.empty()&&f.creates==0,"Unverified metadata installed a hook");
        require(h.snapshot().status=="unavailable","Unavailable status missing");f.finish(h);
    }
    Fake f;vrvd::DesktopRenderFilter h;std::string error;f.nullOriginal=true;
    require(!h.install(&f.api,error,Fake::resolver)&&f.releases==1,"Null trampoline install did not release its hook");f.finish(h);
}
void fail_open(){
    Fake f;vrvd::DesktopRenderFilter h;f.install(h);Object input{&f.list,{&f.source,&f.hud}};
    f.failRoot=true;require(!f.mark(h)&&!h.snapshot().armed,"Root failure armed filtering");f.failRoot=false;require(f.mark(h),"Mark failed");
    for(const auto method:{&f.ctor,&f.count,&f.item,&f.add}){
        require(f.mark(h),"Re-arm before clone failure failed");f.failMethod=method;f.run(input);require(f.seenList==&input&&f.roots.size()==1&&!h.snapshot().armed,"Managed clone failure did not fail open, disarm or leaked roots");f.failMethod=nullptr;
    }
    require(f.mark(h),"Re-arm failed");f.failRoot=true;f.run(input);require(f.seenList==&input&&f.roots.size()==1,"Clone root failure did not fail open");f.failRoot=false;
    require(f.mark(h),"Re-arm failed");f.source.alive=false;f.run(input);require(f.seenList==&input,"Destroyed source suppressed desktop");f.source.alive=true;
    require(f.mark(h),"Re-arm failed");Object invalid{&f.other,{&f.source}};f.run(invalid);require(f.seenList==&invalid,"Unknown collection did not pass through");
    require(f.mark(h),"Re-arm failed");Object huge{&f.list,std::vector<void*>(257,&f.source)};f.run(huge);require(f.seenList==&huge,"Unbounded collection was copied");
    require(f.mark(h),"Re-arm failed");
    bool changed=false;f.onInvoke=[&](const Method* method){if(method==&f.add&&!changed){input.cameras[1]=&f.eye;changed=true;}};
    f.run(input);require(f.seenList==&input&&f.roots.size()==1,"Reentrant source-list mutation was not detected");f.onInvoke=nullptr;
    require(h.snapshot().contract_failures>=9,"Failure diagnostics not counted");f.finish(h);
}
void gates_and_reentrancy(){
    Fake f;vrvd::DesktopRenderFilter h;f.install(h);Object input{&f.list,{&f.source,&f.hud}};require(f.mark(h),"Mark failed");
    std::thread worker([&]{f.run(input);require(f.seenList==&input,"Foreign thread suppressed desktop");require(!h.clear(),"Foreign thread freed game source root");});worker.join();
    require(!h.snapshot().armed&&f.roots.size()==1,"Cross-thread clear failed to disarm or retain root");require(f.mark(h),"Re-arm failed");
    bool triedClear=false;f.onInvoke=[&](const Method* method){if(method==&f.add){triedClear=true;require(!h.clear(),"Reentrant clear freed active source");}};
    f.run(input);require(triedClear&&f.seenList==&input&&f.roots.size()==1,"Reentrant stop did not fail open");f.onInvoke=nullptr;
    f.onInvoke=[&](const Method* method){if(method==&f.frame)h.disable();};
    require(!f.mark(h)&&!h.snapshot().armed,"Reentrant stop during mark rearmed filter");f.onInvoke=nullptr;
    require(f.mark(h),"Mark failed after cancelled validation");std::string error;
    require(!h.mark_submitted(&f.source,f.unityFrame-1,error)&&!h.snapshot().armed,"Stale mark retained old arm");
    require(f.mark(h),"Mark failed before native exception");f.throwOriginal=true;const auto before=f.calls;bool caught=false;
    try{f.run(input);}catch(const std::runtime_error& e){caught=std::string(e.what())=="original failure";}
    require(caught&&f.calls==before+1&&f.roots.size()==1,"Original exception was retried, swallowed or leaked a clone root");f.throwOriginal=false;f.finish(h);
}
}
int main(){try{metadata_rejections();basic_filter_and_reinstall();fail_open();gates_and_reentrancy();std::cout<<"desktop_render_filter: all fake-host checks passed\n";return 0;}catch(const std::exception& e){std::cerr<<"desktop_render_filter: "<<e.what()<<"\n";return 1;}}
