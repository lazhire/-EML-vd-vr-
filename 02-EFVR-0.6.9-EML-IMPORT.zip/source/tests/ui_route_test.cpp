#include "../src/ui_route.h"
#include <stdexcept>
#include <iostream>
using namespace vrvd;
void require(bool b){if(!b)throw std::runtime_error("UI transition invariant failed");}
int main(){
 UiSignals s;std::set<std::string> overlays{"GameplayHud"};
 require(route_ui(s,overlays)=="unknown");s.valid=true;s.controller="Beyond.Gameplay.View.LevelCameraController";
 s.panels.push_back({1,0,"GameplayHud",false});require(route_ui(s,overlays)=="gameplay");
 auto key=ui_signature(s,"gameplay");
 s.panels.push_back({2,1,"CharacterDetail",false});require(route_ui(s,overlays)=="gameplay");require(key!=ui_signature(s,"menu"));
 s.panels.back().name="UnregisteredActivity";require(route_ui(s,overlays)=="gameplay");
 s.panels.back().world=true;require(route_ui(s,overlays)=="gameplay");
 s.loading=true;require(route_ui(s,overlays,true)=="loading");s.valid=false;require(route_ui(s,overlays)=="loading");s.valid=true;s.loading=false;
 s.system_scene=true;s.controller.clear();require(route_ui(s,overlays)=="menu");s.system_scene=false;
 require(route_ui(s,overlays)=="menu");
 require(first_person_ui_gate(true,true,"unknown",true)==2);
 require(first_person_ui_gate(true,true,"unknown",false)==0);
 s.controller="Beyond.Gameplay.View.FacTopViewCameraController";require(route_ui(s,overlays)=="building");
 s.controller="Beyond.Gameplay.View.SnapshotCameraController";require(route_ui(s,overlays)=="photo");
 s.controller="Beyond.Gameplay.View.InteractNpcCameraController";require(route_ui(s,overlays)=="dialogue");
 s.controller="FutureCamera";require(route_ui(s,overlays)=="special_camera");
 s.controller="Beyond.Gameplay.View.LevelCameraController";require(route_ui(s,overlays)=="gameplay");
 require(route_ui(s,overlays,true)=="menu");s.valid=false;require(route_ui(s,overlays)=="unknown");
 s.valid=true;s.panels.push_back({0,0,"$CSPopupPanel",false,99});overlays.insert("$CSPopupPanel");require(route_ui(s,overlays)=="gameplay");
 key=ui_signature(s,"menu");s.panels.back().instance=100;require(key!=ui_signature(s,"menu"));
 s.panels.clear();
 for(const auto* n:{"Watch","CharInfo","CharInfoEmpty","CommonPopUp","Mission","AdventureBook","AdventureDaily","Inventory","GameSetting","GameSettingWarningPopUp","GachaPool","FriendList","FriendTab","BattlePass","BattlePassPlan","EquipTech","RewardsPopUpForSystem","DungeonCustomReward","StaminaPopUp","DungeonCommonEntry","CharFormation","Snapshot"}){
  s.panels={{1,0,n,false,9}};require(route_ui(s,overlays)=="menu");
 }
 for(bool world:{false,true}){
  for(const auto* n:{"Mission","AdventureBook","AdventureDaily","Inventory","Watch"}){s.panels={{1,0,n,world,9}};require(route_ui(s,overlays)=="menu");}
  s.panels={{1,0,"QuickMenu",world,9}};require(route_ui(s,overlays)=="radial");require(first_person_ui_gate(true,true,"radial")==1);
  s.panels.push_back({2,0,"Mission",world,10});require(route_ui(s,overlays)=="menu");
 }
 s.panels={{1,0,"MissionHud",true,9},{2,0,"MiniMap",true,10},{3,0,"ControllerHint",false,11}};require(route_ui(s,overlays)=="gameplay");
 for(const auto* n:{"Dialog","DialogMask","HeadLabelInDialog"}){
  s.panels={{1,0,n,false,9}};require(route_ui(s,overlays)=="dialogue");
  require(first_person_ui_gate(true,true,route_ui(s,overlays))==2);
 }
 s.panels={{1,0,"BlockGlitchTransition",false,9}};require(route_ui(s,overlays)=="transition");
 s.panels.clear();require(route_ui(s,overlays)=="gameplay");
 std::cout<<"PASS: gameplay/menu/nested/unknown/world UI/loading/special camera routing and generation identity\n";
}
