#include "../src/menu_focus.h"
#include <chrono>
#include <fstream>
#include <iostream>
#include <stdexcept>
using namespace vrvd;
void require(bool b,const char* why){if(!b)throw std::runtime_error(why);}
int main(int argc,char** argv){
 std::string e;MenuFocusPixels out;std::vector<uint8_t> p(128*128*4,200);
 for(size_t i=3;i<p.size();i+=4)p[i]=255;
 require(make_menu_focus(p,128,128,128,128,9,.5f,6,out,e),"uniform image");
 require(out.panel[(64*128+64)*4]==200&&out.panel[(64*128+64)*4+3]==255,"menu interior remains sharp and unchanged");
 require(out.panel[3]==0&&out.panel[(3*128+64)*4+3]>0&&out.panel[(3*128+64)*4+3]<255,"feathered alpha edge");
 for(size_t i=0;i<out.panel.size();i+=4)require(out.panel[i]<=out.panel[i+3],"premultiplied panel");
 for(size_t i=0;i<out.backdrop.size();i+=4)require(out.backdrop[i]==100&&out.backdrop[i+3]==255,"normalized Gaussian preserves constant color and requested brightness");
 std::fill(p.begin(),p.end(),0);for(size_t i=3;i<p.size();i+=4)p[i]=255;
 p[(64*128+64)*4]=255;
 require(make_menu_focus(p,128,128,128,128,6,1.f,0,out,e),"impulse");
 auto at=[&](int x,int y){return out.backdrop[(y*128+x)*4];};
 require(at(64,64)>at(65,64)&&at(65,64)>0&&at(65,64)==at(64,65)&&at(63,64)==at(65,64),"two-axis symmetric Gaussian, not flat dimming");
 require(out.panel==p,"zero feather leaves full menu unchanged");
 std::fill(p.begin(),p.end(),0);for(unsigned y=28;y<100;++y)for(unsigned x=0;x<128;++x){auto i=(y*128+x)*4;p[i]=80;p[i+1]=120;p[i+2]=160;p[i+3]=255;}
 require(make_menu_focus(p,128,128,1920,1080,9,1.f,4,out,e),"aspect-fit input");
 require(out.panel[3]==0&&out.panel[(64*128+64)*4]==80,"letterbox is transparent while content retained");
 for(size_t i=0;i<out.backdrop.size();i+=4)require(out.backdrop[i]==80&&out.backdrop[i+1]==120,"opaque black letterbox excluded from blur");
 require(!make_menu_focus(p,128,128,0,1080,9,.5f,4,out,e)&&out.panel.empty()&&out.backdrop.empty(),"invalid source clears stale images");
 require(!make_menu_focus(p,128,128,1920,1080,17,.5f,4,out,e),"bounded blur radius");
 require(!make_menu_focus(p,128,128,1920,1080,9,NAN,4,out,e),"finite brightness");
 // Synthetic reference image, not a game screenshot. Used for offline visual inspection.
 unsigned w=640,h=360;p.assign(w*h*4,255);
 for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x){auto i=(y*w+x)*4;
  bool grid=((x/24+y/24)%2)==0;
  p[i]=uint8_t(30+x*90/w);p[i+1]=uint8_t(50+y*90/h);p[i+2]=uint8_t(grid?100:170);
  if(x<130||x>w-130){p[i]=190;p[i+1]=150;p[i+2]=35;}
  if(y<30){p[i]=30;p[i+1]=35;p[i+2]=45;}
 }
 auto start=std::chrono::steady_clock::now();
 for(int i=0;i<10;++i)require(make_menu_focus(p,w,h,w,h,9,.45f,6,out,e),"preview conversion");
 auto ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()/10;
 if(argc>1){
  std::ofstream panel(std::string(argv[1])+"-panel.rgba",std::ios::binary);
  std::ofstream blur(std::string(argv[1])+"-bg.rgba",std::ios::binary);
  std::ofstream src(std::string(argv[1])+"-source.rgba",std::ios::binary);
  panel.write(reinterpret_cast<const char*>(out.panel.data()),out.panel.size());
  blur.write(reinterpret_cast<const char*>(out.backdrop.data()),out.backdrop.size());src.write(reinterpret_cast<const char*>(p.data()),p.size());
 }
 std::cout<<"PASS: clear interior, feathered premultiplied edges, separable Gaussian symmetry, brightness, letterbox exclusion, invalidation; synthetic 640x360 mean "<<ms<<" ms (not game performance)\n";
}
