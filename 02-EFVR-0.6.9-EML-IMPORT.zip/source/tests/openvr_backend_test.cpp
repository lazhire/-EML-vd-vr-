#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../src/openvr_backend.h"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <limits>
#include <string>

using namespace vrvd;
namespace {
int checks=0;
void require(bool ok,const char* name){++checks;if(!ok){std::fprintf(stderr,"FAIL: %s\n",name);std::exit(1);}}
bool approx_equal(float a,float b,float tolerance=0.00002f){return std::fabs(a-b)<=tolerance;}
void identity(float m[3][4]){std::memset(m,0,sizeof(float)*12);m[0][0]=m[1][1]=m[2][2]=1;}
void axis_rotation(float m[3][4],int axis,float radians) {
    identity(m);const int j=(axis+1)%3,k=(axis+2)%3;
    m[j][j]=m[k][k]=std::cos(radians);m[j][k]=-std::sin(radians);m[k][j]=std::sin(radians);
}
struct Fixture {
    float head[3][4]{};
    float eye[2][3][4]{};
    // Deliberately asymmetric left/right and upper/lower angles. This catches
    // sign inversions which a symmetric test would conceal.
    float fov[2][4]={{-1.2f,.8f,-1.1f,.9f},{-.8f,1.2f,-.95f,1.05f}};
    Eye out[2]{};
    openvr_detail::RecenterState center;
    std::string error;
    Fixture(){identity(head);for(auto& m:eye)identity(m);eye[0][0][3]=-.032f;eye[1][0][3]=.032f;}
    bool convert(bool reset=false){return openvr_detail::convert_eyes(head,eye,fov,reset,center,out,error);}
};
void check_geometry() {
    Fixture f;f.head[0][3]=10;f.head[1][3]=1.6f;f.head[2][3]=-3;
    require(f.convert(),"translated HMD accepted");
    require(approx_equal(f.out[0].position[0],-.032f)&&approx_equal(f.out[1].position[0],.032f),"standard eye order and full IPD");
    require(approx_equal(f.out[0].position[1],0)&&approx_equal(f.out[0].position[2],0),"recenter removes height and center translation");
    require(approx_equal(f.out[0].orientation[3],1),"identity quaternion");
    require(approx_equal(std::tan(f.out[0].angleLeft),-1.2f)&&approx_equal(std::tan(f.out[0].angleRight),.8f),"asymmetric horizontal FOV");
    require(approx_equal(std::tan(f.out[0].angleUp),.9f)&&approx_equal(std::tan(f.out[0].angleDown),-1.1f),"OpenVR named bottom is geometric up; named top is geometric down");
    require(approx_equal(std::tan(f.out[1].angleLeft),-.8f)&&approx_equal(std::tan(f.out[1].angleRight),1.2f),"right eye keeps its own FOV");
    for(int eye=0;eye<2;++eye) {
        // Independent matrix oracle from Valve unity-xr-plugin Display.cpp,
        // a30a0100... lines 1079-1093. Project the adapter's FOV boundary rays
        // through that matrix: each must land on its correct NDC edge.
        const float left=f.fov[eye][0],right=f.fov[eye][1];
        const float top=f.fov[eye][3],bottom=f.fov[eye][2];
        const float p00=2.f/(right-left),p02=(right+left)/(right-left);
        const float p11=2.f/(top-bottom),p12=(top+bottom)/(top-bottom);
        require(approx_equal(p00*std::tan(f.out[eye].angleLeft)-p02,-1)&&
                approx_equal(p00*std::tan(f.out[eye].angleRight)-p02,1),"Valve projection maps left/right boundary rays to NDC edges");
        require(approx_equal(p11*std::tan(f.out[eye].angleUp)-p12,1)&&
                approx_equal(p11*std::tan(f.out[eye].angleDown)-p12,-1),"Valve asymmetric projection maps upper/lower boundary rays to NDC edges");
    }
    f.head[0][3]+=.1f;f.head[1][3]+=.2f;f.head[2][3]-=.3f;
    require(f.convert(),"tracked translation accepted");
    require(approx_equal(f.out[0].position[0],.1f-.032f)&&approx_equal(f.out[0].position[1],.2f)&&approx_equal(f.out[0].position[2],-.3f),"6DOF translation retained after initial recenter");
    require(f.convert(true)&&approx_equal(f.out[0].position[1],0),"explicit recenter updates origin");

    Fixture yaw;axis_rotation(yaw.head,1,1.57079632679f);yaw.head[1][3]=1.7f;
    require(yaw.convert(),"ninety degree yaw accepted");
    require(approx_equal(yaw.out[0].position[0],-.032f)&&approx_equal(yaw.out[1].position[0],.032f)&&approx_equal(yaw.out[0].position[2],0),"head rotation precedes eye offset, inverse yaw recenters IPD");
    require(approx_equal(yaw.out[0].orientation[1],0)&&approx_equal(std::fabs(yaw.out[0].orientation[3]),1),"recenter removes yaw once");
    yaw.head[2][3]=-.5f;
    require(yaw.convert()&&approx_equal(yaw.out[0].position[0],.5f-.032f),"world movement is rotated into recentered head axes");

    for(int axis=0;axis<3;++axis)for(float angle:{0.37f,3.14159265359f,-2.9f}) {
        Fixture r;axis_rotation(r.head,axis,angle);r.center.valid=true;
        require(r.convert(),"all matrix-to-quaternion branches accept rigid rotation");
        const float expected=std::sin(angle*.5f),w=std::cos(angle*.5f);
        const float dot=r.out[0].orientation[axis]*expected+r.out[0].orientation[3]*w;
        require(approx_equal(std::fabs(dot),1),"matrix-to-quaternion rotation preserves axis and sign equivalence");
    }
    Fixture canted;axis_rotation(canted.eye[0],1,-.05f);axis_rotation(canted.eye[1],1,.05f);
    canted.eye[0][0][3]=-.032f;canted.eye[1][0][3]=.032f;
    require(canted.convert(),"canted eye metadata accepted");
    require(canted.out[0].orientation[1]<0&&canted.out[1].orientation[1]>0,"per-eye rotations retained, no parallel-eye coercion");
}
void check_rejections() {
    const float nan=std::numeric_limits<float>::quiet_NaN();
    Fixture f;f.head[0][0]=nan;
    require(!f.convert()&&!f.center.valid,"nonfinite tracking rejected without modifying recenter");
    Fixture scale;scale.head[0][0]=2;
    require(!scale.convert(),"scaled tracking transform rejected");
    Fixture reflection;reflection.head[2][2]=-1;
    require(!reflection.convert(),"left-handed reflected transform rejected");
    Fixture shear;shear.eye[0][0][1]=.02f;
    require(!shear.convert(),"sheared eye metadata rejected");
    Fixture swapped;swapped.eye[0][0][3]=.032f;swapped.eye[1][0][3]=-.032f;
    require(!swapped.convert(),"crossed eye transforms rejected");
    Fixture mono;mono.eye[0][0][3]=mono.eye[1][0][3]=0;
    require(!mono.convert(),"zero IPD cannot masquerade as stereo");
    Fixture extreme;extreme.eye[1][0][3]=1;
    require(!extreme.convert(),"implausible IPD rejected");
    Fixture bad_fov;bad_fov.fov[0][2]=.7f;
    require(!bad_fov.convert(),"wrong vertical tangent convention rejected");
    Fixture bad_nan;bad_nan.fov[1][0]=nan;
    require(!bad_nan.convert(),"nonfinite FOV rejected");
    Fixture bad_center;bad_center.center.valid=true;bad_center.center.yaw=nan;
    require(!bad_center.convert(),"nonfinite stored recenter rejected");
    Fixture atomic;atomic.out[0].position[0]=123;atomic.fov[1][1]=-1;
    require(!atomic.convert()&&atomic.out[0].position[0]==123&&!atomic.center.valid,"bad second eye publishes neither pose nor recenter");
}
void check_buffers() {
    unsigned char l[16]{},r[16]{};std::string error;
    require(openvr_detail::validate_rgba(l,r,2,2,16,error),"matching independent RGBA images accepted");
    require(!openvr_detail::validate_rgba(l,l,2,2,16,error),"same eye buffer rejected");
    require(!openvr_detail::validate_rgba(nullptr,r,2,2,16,error),"null image rejected");
    require(!openvr_detail::validate_rgba(l,r,2,2,15,error),"short image rejected");
    require(!openvr_detail::validate_rgba(l,r,2,2,17,error),"oversized/strided image rejected");
    require(!openvr_detail::validate_rgba(l,r,0,2,0,error),"zero dimensions rejected");
    require(!openvr_detail::validate_rgba(l,r,UINT32_MAX,UINT32_MAX,SIZE_MAX,error),"overflow dimensions rejected");
    XrVulkanHudFrame hud;hud.rgba=l;hud.width=hud.height=2;hud.bytes=16;
    require(openvr_detail::validate_hud(hud,error),"premultiplied HUD metadata accepted");
    hud.distance_m=0;require(!openvr_detail::validate_hud(hud,error),"zero HUD distance rejected");
    hud.distance_m=1;hud.offset_y_m=std::numeric_limits<float>::infinity();
    require(!openvr_detail::validate_hud(hud,error),"infinite HUD transform rejected");
    hud.offset_y_m=0;hud.bytes=15;require(!openvr_detail::validate_hud(hud,error),"HUD bytes validated before upload");
}
void check_inactive_api() {
    // These deliberately fail BEFORE loading a runtime. Never supply an existing
    // openvr_api.dll and never invoke VR_Init in this executable.
    OpenVrBackend backend;std::string error;Eye eyes[2]{};bool draw=true;
    require(!backend.running()&&!backend.frame_pending(),"new backend inactive");
    require(!backend.begin_frame(eyes,draw,error)&&!draw,"begin on inactive backend rejected");
    unsigned char l[4]{},r[4]{};
    require(!backend.submit_rgba(l,r,4,error),"submit without begin rejected");
    require(!backend.initialize_owned(L"openvr_api.dll",1,1,error),"relative runtime DLL rejected before LoadLibrary");
    require(!backend.initialize_owned(L"C:\\SteamVR\\openvr_api.dll",0,1,error),"zero target rejected before LoadLibrary");
    require(!backend.initialize_owned(L"C:\\SteamVR\\openvr_api.dll",8192,1,error),"oversized target rejected before LoadLibrary");
    require(!backend.initialize_owned(L"C:\\SteamVR\\other.dll",1,1,error),"wrong runtime DLL name rejected before LoadLibrary");
    require(!backend.running()&&!backend.frame_pending(),"invalid init leaves no partial session");
    backend.request_recenter();backend.cancel_frame();
    require(backend.diagnostics().submitted_frames==0,"rejected submissions do not count as successful stereo");
    require(backend.shutdown()&&backend.shutdown(),"inactive shutdown idempotent");
}
}
int main() {
    check_geometry();check_rejections();check_buffers();check_inactive_api();
    std::printf("OpenVR offline checks passed: %d (geometry, FOV, buffers, inactive lifecycle; no runtime/GPU calls).\n",checks);
}
