// Exercises the real UnityGpuProbe through a fake EML host. No game/XR/GPU.
#include "../src/unity_gpu_probe.h"
#include <array>
#include <cstring>
#include <deque>
#include <iostream>
#include <map>
#include <memory>
#include <stdexcept>
#include <vector>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
struct Object {
    int slot = -1;
    bool alive = true, constructed = false, created = false;
    int width = 0, height = 0, graphicsFormat = 8, aa = 1, mips = 1;
    uintptr_t handle = 0;
};
struct Method { std::string klass, name; };
struct FakeHost {
    BE_HostApiV1 api{};
    std::deque<Method> methods;
    std::vector<std::unique_ptr<Object>> objects;
    std::map<uint32_t, Object*> roots;
    std::vector<std::pair<int, int>> copies;
    std::vector<int> blits;
    Object* original = nullptr;
    Object* black = nullptr;
    Object* active = nullptr;
    int graphics = 21, rtCount = 0, invokeCount = 0, destroyCount = 0;
    int failCreateSlot = -1, badFormatSlot = -1, zeroHandleSlot = -1;
    int failBlitSlot = -1, failCopySlot = -1, failRootCall = -1, rootCalls = 0;
    int failDestroyCount = 0, failReleaseCount = 0, failRestoreCount = 0;
    bool duplicateHandles = false, badRestoreNoException = false, noBlack = false;
    std::string missingMethod;
    uint32_t nextRoot = 1;
    alignas(16) std::array<uint8_t, 32> boxed{};

    Object* make() {
        auto object = std::make_unique<Object>();
        auto* result = object.get();
        objects.push_back(std::move(object));
        return result;
    }
    Object* slot(int value) {
        for (auto& object : objects) if (object->slot == value) return object.get();
        return nullptr;
    }
    template<class T> void* box(const T& value) {
        static_assert(sizeof(T) <= 32);
        std::memcpy(boxed.data(), &value, sizeof(T));
        return boxed.data();
    }
    static FakeHost& from(void* context) { return *static_cast<FakeHost*>(context); }
    static bool same(Object* a, Object* b) {
        if (a && !a->alive) a = nullptr;
        if (b && !b->alive) b = nullptr;
        return a == b;
    }
    FakeHost() {
        original = make(); black = make(); active = original;
        api.abi_version = BETTER_ENDFIELD_MODULE_ABI_V1;
        api.context = this;
        api.log = [](void*, const char*, const char*) {};
        api.resolve_method = [](void* context, const BE_MethodDescriptorV1* d, BE_ResolvedMethodV1* out) {
            auto& s = from(context);
            const std::string name = d->method_name, klass = d->class_name;
            require(std::string(d->assembly_name) == "UnityEngine.CoreModule.dll", "Wrong assembly");
            require(std::string(d->namespace_name) == "UnityEngine", "Wrong namespace");
            require(klass != "Camera" && name != "ReadPixels" && klass != "Marshal" && klass != "GL", "Probe touched camera/readback/callback APIs");
            if (name == "Blit") {
                require(klass == "Graphics" && d->parameter_count == 2 && std::string(d->parameter_types) == "UnityEngine.Texture|UnityEngine.RenderTexture", "Wrong Blit overload");
                require(std::string(d->return_type) == "System.Void", "Wrong Blit result");
            }
            if (name == "CopyTexture") {
                require(klass == "Graphics" && d->parameter_count == 2 && std::string(d->parameter_types) == "UnityEngine.Texture|UnityEngine.Texture", "Wrong CopyTexture overload");
                require(std::string(d->return_type) == "System.Void", "Wrong CopyTexture result");
            }
            if (name == "GetNativeTexturePtr") require(klass == "Texture" && d->parameter_count == 0 && std::string(d->return_type) == "System.IntPtr", "Wrong native pointer API");
            if (name == "get_blackTexture") require(klass == "Texture2D" && d->parameter_count == 0 && std::string(d->return_type) == "UnityEngine.Texture2D", "Wrong black texture API");
            if (name == ".ctor") require(d->parameter_count == 5 && std::string(d->parameter_types) == "System.Int32|System.Int32|System.Int32|UnityEngine.RenderTextureFormat|UnityEngine.RenderTextureReadWrite", "Wrong RT constructor overload");
            if (name == s.missingMethod) return BE_Result_NotFound;
            s.methods.push_back({klass, name}); out->method_info = &s.methods.back();
            return BE_Result_Ok;
        };
        api.resolve_class = [](void*, const char* assembly, const char* ns, const char* name, BE_ResolvedClassV1* out) {
            require(std::string(assembly) == "UnityEngine.CoreModule.dll" && std::string(ns) == "UnityEngine" && std::string(name) == "RenderTexture", "Probe allocated a non-RT class");
            out->class_info = reinterpret_cast<void*>(uintptr_t(1)); return BE_Result_Ok;
        };
        api.object_new = [](void* context, const void*) -> void* {
            auto& s = from(context); auto* object = s.make(); object->slot = s.rtCount++;
            // Deliberately invalid as addresses. Production must only copy these bits.
            object->handle = uintptr_t(0xDEAD00000000ULL) + uintptr_t(object->slot + 1) * 4096u + 3u;
            return object;
        };
        api.object_unbox = [](void*, void* object) -> void* { return object; };
        api.gchandle_new = [](void* context, void* object, int pinned) -> uint32_t {
            auto& s = from(context); require(pinned == 0, "Unexpected pinned root");
            if (++s.rootCalls == s.failRootCall) return 0;
            auto root = s.nextRoot++; s.roots[root] = static_cast<Object*>(object); return root;
        };
        api.gchandle_free = [](void* context, uint32_t root) {
            require(from(context).roots.erase(root) == 1, "Missing or double-freed root");
        };
        api.runtime_invoke = [](void* context, const void* method, void* object, void** args, void** exception) -> void* {
            return from(context).invoke(*static_cast<const Method*>(method), static_cast<Object*>(object), args, exception);
        };
    }
    void* invoke(const Method& m, Object* object, void** args, void** exception) {
        ++invokeCount; *exception = nullptr; const auto& name = m.name;
        if (name == "get_graphicsDeviceType") return box<int32_t>(graphics);
        if (name == "op_Equality") return box<uint8_t>(same(static_cast<Object*>(args[0]), static_cast<Object*>(args[1])) ? 1 : 0);
        if (name == ".ctor") {
            object->constructed = true; object->width = *static_cast<int32_t*>(args[0]); object->height = *static_cast<int32_t*>(args[1]);
            require(object->width == 64 && object->height == 64, "Unexpected probe dimensions");
            require(*static_cast<int32_t*>(args[2]) == 0 && *static_cast<int32_t*>(args[3]) == 0 && *static_cast<int32_t*>(args[4]) == 1, "Probe must have no depth and use ARGB32 Linear constructor");
            return nullptr;
        }
        if (name == "set_hideFlags") return nullptr;
        if (name == "set_graphicsFormat") { object->graphicsFormat = *static_cast<int32_t*>(args[0]); return nullptr; }
        if (name == "set_antiAliasing") { object->aa = *static_cast<int32_t*>(args[0]); return nullptr; }
        if (name == "set_useMipMap" || name == "set_autoGenerateMips") { require(*static_cast<uint8_t*>(args[0]) == 0, "Probe mipmaps enabled"); return nullptr; }
        if (name == "Create") { object->created = object->slot != failCreateSlot; return box<uint8_t>(object->created ? 1 : 0); }
        if (name == "IsCreated") return box<uint8_t>(object->created ? 1 : 0);
        if (name == "get_sRGB") return box<uint8_t>(0);
        if (name == "get_width") return box<int32_t>(object->width);
        if (name == "get_height") return box<int32_t>(object->height);
        if (name == "get_graphicsFormat") return box<int32_t>(object->slot == badFormatSlot ? 9 : object->graphicsFormat);
        if (name == "get_antiAliasing") return box<int32_t>(object->aa);
        if (name == "get_mipmapCount") return box<int32_t>(object->mips);
        if (name == "GetNativeTexturePtr") return box<uintptr_t>(object->slot == zeroHandleSlot ? 0 : duplicateHandles ? uintptr_t(7) : object->handle);
        if (name == "get_blackTexture") return noBlack ? nullptr : black;
        if (name == "get_active") return active;
        if (name == "set_active") {
            if (failRestoreCount > 0) { --failRestoreCount; *exception = this; return nullptr; }
            if (!badRestoreNoException) active = static_cast<Object*>(args[0]);
            return nullptr;
        }
        if (name == "Blit") {
            require(args[0] == black, "Blit source is not built-in black texture");
            auto* target = static_cast<Object*>(args[1]);
            require(target && target->slot >= 0 && target->slot % 4 < 2, "Blit did not target a source RT");
            active = target; blits.push_back(target->slot);
            if (target->slot == failBlitSlot) *exception = this;
            return nullptr;
        }
        if (name == "CopyTexture") {
            auto* src = static_cast<Object*>(args[0]); auto* dst = static_cast<Object*>(args[1]);
            require(src && dst && dst->slot == src->slot + 2, "Wrong stereo source/marker pairing");
            require(src->created && dst->created && src != dst, "Copy uses invalid resources");
            copies.emplace_back(src->slot, dst->slot);
            if (src->slot == failCopySlot) *exception = this;
            return nullptr;
        }
        if (name == "Release") {
            require(object != active, "Released the active RenderTexture");
            if (failReleaseCount > 0) { --failReleaseCount; *exception = this; return nullptr; }
            object->created = false; return nullptr;
        }
        if (name == "Destroy") {
            auto* target = static_cast<Object*>(args[0]);
            require(target != active && target != original && target != black, "Destroyed active or borrowed texture");
            if (failDestroyCount > 0) { --failDestroyCount; *exception = this; return nullptr; }
            target->alive = false; ++destroyCount; return nullptr;
        }
        throw std::runtime_error("Unexpected probe API: " + m.klass + "." + name);
    }
    void finish(vrvd::UnityGpuProbe& probe) {
        probe.cleanup(); require(!probe.resources_alive(), "Cleanup left resources");
        require(roots.empty(), "Cleanup leaked managed roots");
        require(probe.source_handle(0) == 0 && probe.marker_handle(1) == 0, "Cleanup retained native handles");
    }
};

void happyPath() {
    FakeHost s; vrvd::UnityGpuProbe probe; std::string error;
    require(!probe.ensure(error), "Unresolved probe accepted ensure");
    require(probe.resolve(&s.api, error), error.c_str());
    require(s.invokeCount == 0 && s.rtCount == 0, "Resolve invoked/allocated managed resources");
    require(probe.ensure(error), error.c_str());
    require(s.rtCount == 4 && s.roots.size() == 4, "Expected four rooted private RTs");
    for (unsigned eye = 0; eye < 2; ++eye) {
        require(probe.source_handle(eye) == s.slot(int(eye))->handle, "Source handle bits changed");
        require(probe.marker_handle(eye) == s.slot(int(eye + 2))->handle, "Marker handle bits changed");
    }
    require(probe.source_handle(2) == 0 && probe.marker_handle(~0u) == 0, "Invalid eye was accepted");
    require(!probe.resolve(&s.api, error), "Rebinding live resources was accepted");
    require(probe.issue_copy(error), error.c_str());
    require(s.blits == std::vector<int>({0, 1}) && s.copies == std::vector<std::pair<int,int>>({{0,2},{1,3}}), "Expected two distinct ordered GPU copies");
    require(s.active == s.original && s.roots.size() == 4, "Copy did not restore active RT/release temporary roots");
    require(probe.issue_copy(error) && s.rtCount == 4, "Second issue reallocated RTs");
    s.finish(probe); require(s.destroyCount == 4, "Expected four destroyed RTs");
}
void bindingAndDeviceFailures() {
    FakeHost s; vrvd::UnityGpuProbe probe; std::string error;
    s.missingMethod = "CopyTexture";
    require(!probe.resolve(&s.api, error) && error.find("CopyTexture") != std::string::npos, "Missing overload did not fail closed");
    require(!probe.ensure(error) && s.rtCount == 0, "Partial resolve allocated resources");
    s.missingMethod.clear(); require(probe.resolve(&s.api, error), error.c_str());
    s.graphics = 2; require(!probe.ensure(error) && s.rtCount == 0, "Non-Vulkan probe allocated RTs");
    s.finish(probe);
}
void allocationFailures() {
    for (int mode = 0; mode < 6; ++mode) {
        FakeHost s; vrvd::UnityGpuProbe probe; std::string error;
        require(probe.resolve(&s.api, error), error.c_str());
        if (mode == 0) s.failCreateSlot = 2;
        if (mode == 1) s.badFormatSlot = 1;
        if (mode == 2) s.zeroHandleSlot = 3;
        if (mode == 3) s.duplicateHandles = true;
        if (mode == 4) s.failRootCall = 2;
        if (mode == 5) s.failCreateSlot = 0;
        require(!probe.ensure(error) && !error.empty(), "Bad allocation was accepted");
        require(s.active == s.original, "Allocation changed global active RT");
        s.finish(probe);
        for (const auto& object : s.objects) require(!object->constructed || !object->alive, "Partial allocation leaked native RT");
    }
}
void copyFailuresRestore() {
    for (int mode = 0; mode < 5; ++mode) {
        FakeHost s; vrvd::UnityGpuProbe probe; std::string error;
        require(probe.resolve(&s.api, error) && probe.ensure(error), error.c_str());
        if (mode == 0) s.failBlitSlot = 0;
        if (mode == 1) s.failBlitSlot = 1;
        if (mode == 2) s.failCopySlot = 0;
        if (mode == 3) s.failCopySlot = 1;
        if (mode == 4) s.noBlack = true;
        require(!probe.issue_copy(error), "Copy failure was accepted");
        require(s.active == s.original && s.roots.size() == 4, "Copy failure left active RT or temporary root");
        s.finish(probe);
    }
}
void restorationRetry() {
    for (bool noException : {false, true}) {
        FakeHost s; vrvd::UnityGpuProbe probe; std::string error;
        require(probe.resolve(&s.api, error) && probe.ensure(error), error.c_str());
        s.failRestoreCount = noException ? 0 : 2;
        s.badRestoreNoException = noException;
        require(!probe.issue_copy(error), "Restore failure was accepted");
        require(s.roots.size() == 5 && s.active != s.original, "Restore failure did not retain original RT root");
        require(!probe.issue_copy(error), "Copy allowed while restoration pending");
        probe.cleanup();
        require(probe.resources_alive() && s.destroyCount == 0, "Cleanup destroyed RT before restoration");
        s.badRestoreNoException = false; s.failRestoreCount = 0;
        s.finish(probe); require(s.active == s.original, "Cleanup retry did not restore original RT");
    }
}
void cleanupRetry() {
    for (bool release : {false, true}) {
        FakeHost s; vrvd::UnityGpuProbe probe; std::string error;
        require(probe.resolve(&s.api, error) && probe.issue_copy(error), error.c_str());
        if (release) s.failReleaseCount = 1; else s.failDestroyCount = 1;
        probe.cleanup(); require(probe.resources_alive() && s.roots.size() == 1, "Failed destruction did not retain resource root");
        require(!probe.resolve(&s.api, error), "Rebind accepted incomplete cleanup");
        s.finish(probe); require(s.destroyCount == 4, "Retry missed/double-destroyed a texture");
    }
}
void liveness() {
    FakeHost s; vrvd::UnityGpuProbe probe; std::string error;
    require(probe.resolve(&s.api, error) && probe.ensure(error), error.c_str());
    s.slot(1)->alive = false;
    require(!probe.issue_copy(error) && s.copies.empty(), "Dead RT was used by copy");
    require(!probe.resources_alive() && s.roots.empty(), "Dead RT cleanup leaked roots");
    require(probe.ensure(error) && s.rtCount == 8, "Explicit retry could not allocate fresh RTs");
    s.finish(probe);
}
void missingRootAndNullActive() {
    FakeHost s; vrvd::UnityGpuProbe probe; std::string error;
    require(probe.resolve(&s.api, error) && probe.ensure(error), error.c_str());
    s.failRootCall = 6; // Four RT roots, then borrowed black; original-active root fails.
    require(!probe.issue_copy(error) && s.blits.empty() && s.active == s.original, "Unretained active RT allowed Blit");
    require(s.roots.size() == 4, "Failed active root leaked temporary black root");
    s.failRootCall = -1; s.active = nullptr;
    require(probe.issue_copy(error) && s.active == nullptr, "Null active RT was not restored");
    s.finish(probe);
}
}

int main() {
    try {
        happyPath(); bindingAndDeviceFailures(); allocationFailures(); copyFailuresRestore();
        restorationRetry(); cleanupRetry(); liveness(); missingRootAndNullActive();
        std::cout << "PASS UnityGpuProbe: stereo GPU copy API, opaque handles, format/liveness, partial allocation, active restoration and cleanup retries (no game/GPU)\n";
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << "FAIL UnityGpuProbe: " << ex.what() << '\n';
        return 1;
    }
}
