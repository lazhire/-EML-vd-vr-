#include "../src/xr_vulkan.h"
#include <iostream>
#include <stdexcept>

int main(){
    int checks=0;
    auto check=[&](bool condition,const char* label){if(!condition)throw std::runtime_error(label);++checks;};
    // Construction, cached observation, invalid-path rejection and empty
    // shutdown never load a runtime or create an XR/Vulkan instance/session.
    vrvd::XrVulkanBackend backend;
    auto initial=backend.diagnostics();
    check(!initial.session_created&&!initial.view_caps_known,"initial session/view state must be unknown");
    for(const auto& v:initial.views){
        check(v.recommended_width==0&&v.recommended_height==0&&v.max_width==0&&v.max_height==0&&
              v.recommended_samples==0&&v.max_samples==0&&v.actual_width==0&&v.actual_height==0,"initial eye dimensions");
    }
    check(!initial.refresh_extension_available&&!initial.refresh_extension_enabled&&!initial.refresh_functions_available,"no assumed refresh support");
    check(!initial.refresh_rates_known&&initial.session_refresh_rates.empty(),"no fabricated refresh list");
    check(!initial.current_display_hz_known&&initial.current_display_hz==0,"no default hardware refresh claim");
    check(!initial.predicted_period_known&&initial.predicted_period_ns==0,"no prediction before WaitFrame");
    check(initial.submitted_frames==0&&initial.cancelled_frames==0,"no phantom submissions");
    check(initial.swapchain_timeout_count==0&&initial.fence_timeout_count==0,"no phantom timeouts");
    check(!initial.wait_frame_cpu_known&&!initial.swapchain_wait_cpu_known&&!initial.gpu_fence_wait_cpu_known&&!initial.end_frame_cpu_known,"no measured timing without API calls");
    check(initial.wait_frame_cpu_ms==0&&initial.swapchain_wait_cpu_ms==0&&initial.gpu_fence_wait_cpu_ms==0&&initial.end_frame_cpu_ms==0,"initial timing zeros");
    initial.session_refresh_rates.push_back(120);initial.current_display_hz=120;
    initial.views[0].recommended_width=2064;
    const auto unchanged=backend.diagnostics();
    check(unchanged.session_refresh_rates.empty()&&unchanged.current_display_hz==0&&unchanged.views[0].recommended_width==0,"snapshot must not mutate backend");
    backend.cancel_frame();
    check(backend.diagnostics().cancelled_frames==0,"cancel without a pending frame must not count");
    std::string error;
    check(!backend.prepare(nullptr,error)&&!error.empty(),"null loader rejected before loading any library");
    const auto rejected=backend.diagnostics();
    check(!rejected.session_created&&!rejected.refresh_extension_available&&!rejected.predicted_period_known,"failed preflight must not fabricate diagnostics");
    check(backend.shutdown()&&backend.shutdown(),"empty shutdown remains idempotent");
    check(backend.diagnostics().submitted_frames==0&&!backend.diagnostics().end_frame_cpu_known,"empty shutdown remains unmeasured");
    std::cout<<"PASS "<<checks<<" Vulkan diagnostics checks; no runtime, GPU, XR session, or game calls.\n";
}
