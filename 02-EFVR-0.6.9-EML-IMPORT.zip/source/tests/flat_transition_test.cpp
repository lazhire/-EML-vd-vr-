#include "../src/flat_transition.h"
#include <cassert>
#include <cmath>
#include <string>
#include <iostream>
bool near(float a,float b){return std::abs(a-b)<.002f;}
int main(){
 vrvd::FlatTransition t;assert(t.duration_ms==300);
 t.target(true,1,true);assert(t.fading_out()&&t.outgoing(1)==0);
 assert(near(t.outgoing(1.075),.5f));t.target(true,1.08,true);
 assert(t.outgoing(1.151)==1);t.submitted_black(.9f);assert(t.fading_out());
 t.submitted_black(1);assert(std::string(t.name())=="revealing_flat");
 assert(t.menu_opacity(2)==1);assert(near(t.menu_opacity(2.075),.5f));
 t.target(true,2.08,false);assert(t.menu_opacity(2.151)==0);t.submitted_menu(0);
 assert(std::string(t.name())=="flat"&&t.menu_opacity(3)==0);
 t.target(false,4,false);assert(t.fading_flat_out()&&t.menu_opacity(4)==0);
 assert(near(t.menu_opacity(4.075),.5f));t.target(false,4.08,false);
 t.submitted_menu(.9f);assert(t.fading_flat_out());
 assert(t.menu_opacity(4.151)==1);t.submitted_menu(1);assert(!t.fading_flat_out());
 assert(t.menu_opacity(8)==1&&t.world_opacity(8)==1);
 assert(near(t.world_opacity(8.075),.5f));assert(t.world_opacity(8.151)==0);
 t.reset();t.target(true,10,true);float a=t.outgoing(10.075);t.target(false,10.075,true);
 assert(near(t.world_opacity(10.075),a));assert(t.world_opacity(10.226)==0);
 t.reset();t.target(true,20,false);assert(t.menu_opacity(20)==1);
 t.submitted_menu(t.menu_opacity(20.151));t.target(false,21,false);
 float b=t.menu_opacity(21.075);t.target(true,21.075,false);
 assert(near(t.menu_opacity(21.075),b));assert(t.menu_opacity(21.226)==0);
 t.submitted_menu(0);assert(std::string(t.name())=="flat");
 t.reset();t.duration_ms=0;t.target(true,30,true);assert(t.outgoing(30)==1);
 t.submitted_black(1);assert(t.menu_opacity(30)==0);t.submitted_menu(0);
 t.target(false,31,false);assert(t.menu_opacity(31)==1);t.submitted_menu(1);
 assert(t.world_opacity(31)==0);
 std::cout<<"PASS: 300 ms two-sided smooth transition, submitted black barriers, delayed content, nested menus, continuous reversal, zero duration\n";
}
