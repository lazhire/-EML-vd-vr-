// Exercise the production Time hook and process_frame entry without game/XR.
#include "../src/module.cpp"
#include <cassert>
#include <iostream>
int original_calls=0;
float original_time(void*){++original_calls;return 0.f;} // paused game
int recursion=0;
float recursive_time(void*){if(recursion++==0){ui_clock(nullptr);}--recursion;return .125f;}
int main(){
 live=true;hooks_ready=false;requested=false;api=nullptr;next_ui_clock=original_time;
 unity_thread=0;clock_ticks=0;camera_ticks=0;tail_ticks=0;ui_clock(nullptr);
 assert(clock_ticks==0&&original_calls==1); // never infer Unity thread from Time
 unity_thread=GetCurrentThreadId();
 for(int i=0;i<4;++i)assert(ui_clock(nullptr)==0.f);
 assert(clock_ticks==4&&camera_ticks==0&&tail_ticks==0&&last_camera_tick!=Clock::time_point{});
 inside_camera=true;ui_clock(nullptr);inside_camera=false;assert(clock_ticks==4);
 std::thread other([]{ui_clock(nullptr);});other.join();assert(clock_ticks==4);
 next_ui_clock=recursive_time;assert(ui_clock(nullptr)==.125f&&clock_ticks==5&&!inside_clock);
 live=false;ui_clock(nullptr);assert(clock_ticks==5);
 // Exercise production transition invalidation with completed menu/HUD images.
 menu_pixels={1,2,3,255};hud_pixels={4,5,6,255};window_pixels={7,8,9,255};
 menu_last_capture=Clock::now();window_last_capture=menu_last_capture;
 last_menu_frame=9;menu_focus_dirty=false;menu_handoff_pending=true;
 const auto captured_at=menu_last_capture;ui_capture_due=false;
 for(uint64_t generation=100;generation<150;++generation)observe_ui_generation(generation);
 assert(menu_pixels==std::vector<uint8_t>({1,2,3,255}));
 assert(hud_pixels.size()==4&&window_pixels.size()==4);
 assert(menu_last_capture==captured_at&&window_last_capture==captured_at&&ui_capture_due);
 assert(last_menu_frame==9&&!menu_focus_dirty&&menu_handoff_pending);
 assert(vrvd::may_present_menu(true,true)); // static final frames do not expire
 assert(!vrvd::may_present_menu(true,false));
 assert(!vrvd::may_present_menu(false,true));
 std::vector<uint8_t> p;
 assert(vrvd::make_menu_wait_panel(640,360,p)&&p.size()==640*360*4);
 size_t changed=0;for(size_t i=0;i<p.size();i+=4){assert(p[i+3]==255);if(p[i]!=p[0])++changed;}
 assert(changed>100);assert(!vrvd::make_menu_wait_panel(0,360,p));
 hud_capture_width=640;hud_capture_height=360;
 assert(vrvd::make_menu_wait_panel(640,360,menu_pixels));
 engine_capture.source_width=640;engine_capture.source_height=360;
 ui_observer.mode="menu";menu_focus_enabled=true;menu_focus_dirty=true;
 vrvd::XrVulkanHudFrame raw{menu_pixels.data(),menu_pixels.size(),640,360,1.5f,1.8f,0.f};
 auto decorated=raw;assert(decorate_menu_frame(decorated));
 assert(decorated.rgba!=raw.rgba&&decorated.bytes==raw.bytes&&decorated.backdrop_bytes==128*128*4);
 engine_capture.source_width=0;menu_focus_dirty=true;decorated=raw;
 assert(!decorate_menu_frame(decorated)&&decorated.rgba==raw.rgba&&!decorated.backdrop_rgba);
 assert(!menu_error.empty()); // visible raw menu survives optional effect failure
 assert(!GetModuleHandleW(L"GameAssembly.dll")&&!GetModuleHandleW(L"openxr_loader.dll"));
 std::cout<<"PASS: production clock pumps without camera/tail, paused time untouched, owner thread, reentry/unload gates; 50 page/panel changes retain completed images and readback scheduling; source invalidation; actual readable GDI wait panel; no game/XR\n";
}
