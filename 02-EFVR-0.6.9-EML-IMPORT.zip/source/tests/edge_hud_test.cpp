#include "../src/edge_hud.h"
#include <cassert>
#include <iostream>
int main(){
 std::vector<uint8_t> input(100*100*4,90),output;
 assert(vrvd::make_edge_hud(input,100,100,output));
 auto alpha=[&](int x,int y){return output[(y*100+x)*4+3];};
 assert(alpha(10,10)==255&&alpha(90,10)==255&&alpha(50,90)==255);
 for(int y=30;y<75;++y)for(int x=25;x<75;++x){size_t i=(y*100+x)*4;assert(output[i]==0&&output[i+1]==0&&output[i+2]==0&&output[i+3]==0);}
 assert(!vrvd::make_edge_hud({},100,100,output));
 assert(vrvd::make_info_hud(input,100,100,output));
 for(size_t i=0;i<input.size();i+=4){assert(output[i]==input[i]&&output[i+1]==input[i+1]&&output[i+2]==input[i+2]&&output[i+3]==255);}
 assert(!vrvd::make_info_hud({},100,100,output));
 std::cout<<"PASS: opaque HUD edge crops retain source RGB; center has zero premultiplied RGBA; invalid buffer rejected\n";
}
