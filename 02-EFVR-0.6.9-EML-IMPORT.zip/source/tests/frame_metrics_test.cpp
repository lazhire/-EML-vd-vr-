#include "../src/frame_metrics.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
void check(bool x){if(!x)throw std::runtime_error("Frame metrics regression");}
int main(){
    vrvd::FrameMetrics metrics;check(metrics.snapshot().samples==0);
    double t=100;metrics.submitted(t);check(metrics.snapshot().samples==0);
    for(int i=0;i<95;++i){t+=10;metrics.submitted(t);}
    for(int i=0;i<5;++i){t+=50;metrics.submitted(t);}
    auto s=metrics.snapshot();check(s.samples==100&&std::abs(s.stereo_pairs_hz-100000.0/1200)<1e-6);
    check(s.p95_interval_ms==10&&s.p99_interval_ms==50);
    metrics.submitted(t);metrics.submitted(t-1);metrics.submitted(NAN);check(metrics.snapshot().samples==100);
    for(int i=0;i<250;++i){t+=8;metrics.submitted(t);}
    s=metrics.snapshot();check(s.samples==240&&s.stereo_pairs_hz==125&&s.p99_interval_ms==8);
    metrics.reset();check(metrics.snapshot().samples==0);std::cout<<"PASS: stereo-pair intervals, percentiles, stalls, bounded window, reset\n";
}
