// Geometric public-API integration test against the real UnityBridge.
// Fake EML invocation captures matrices and poses; no game, XR runtime or GPU.
// Build with src/unity_bridge.cpp and -Ivendor/eml (C++17).
#include "../src/unity_bridge.h"
#include <algorithm>
#include <array>
#include <cstring>
#include <cmath>
#include <deque>
#include <iostream>
#include <map>
#include <memory>
#include <stdexcept>

namespace {
void require(bool condition,const char* message) {
    if(!condition) throw std::runtime_error(message);
}
struct Object {
    std::string kind;
    bool alive=true,created=true;
    int eye=-1,width=0,height=0,format=4,graphicsFormat=8;
    Object* transform=nullptr;
    Object* target=nullptr;
    std::vector<uint8_t> pixels;
    std::array<float,3> position{};
    std::array<float,4> rotation{0,0,0,1};
    std::array<float,16> projection{},view{},nonJittered{},culling{};
    float fov=75,aspect=1;
    bool positionSet=false,rotationSet=false,projectionSet=false;
};
struct Method {std::string klass,name;};
struct FakeHost {
    struct Capture {int eye;std::array<float,3> position;std::array<float,4> rotation;std::array<float,16> projection,view,nonJittered,culling;float fov,aspect;};
    std::vector<Capture> captures;
    std::array<float,3> basePosition{0,1,0};
    std::array<float,4> baseRotation{0,0,0,1};
    BE_HostApiV1 api{};
    std::deque<Method> methods;
    std::deque<std::string> classes;
    std::vector<std::unique_ptr<Object>> objects;
    std::map<uint32_t,Object*> roots;
    uint32_t nextRoot=1;
    int graphics=21,rtCount=0,cpuCount=0,readCount=0,destroyCount=0;
    bool failSecondRead=false,failRestore=false,rejectCpuBindings=false;
    int overwriteMode=0;Object* firstRendered=nullptr;int frameCount=1;
    float rotationReadNoise=0;
    Object *main=nullptr,*original=nullptr,*active=nullptr;
    alignas(16) std::array<unsigned char,128> boxed{};

    Object* make(const std::string& kind) {
        auto object=std::make_unique<Object>();object->kind=kind;
        auto* pointer=object.get();objects.push_back(std::move(object));return pointer;
    }
    template<class T> void* box(const T& value) {
        static_assert(sizeof(T)<=128);std::memcpy(boxed.data(),&value,sizeof(T));return boxed.data();
    }
    static bool same(Object* a,Object* b) {
        if(a&&!a->alive)a=nullptr;if(b&&!b->alive)b=nullptr;return a==b;
    }
    static FakeHost& from(void* context){return *static_cast<FakeHost*>(context);}
    FakeHost() {
        main=make("Camera");main->transform=make("Transform");
        original=make("OriginalActiveRenderTexture");active=original;
        api.abi_version=1;api.context=this;
        api.log=[](void*,const char*,const char*){};
        api.resolve_method=[](void* context,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* out) {
            auto& s=from(context);
            if(s.rejectCpuBindings&&(std::string(d->method_name)=="ReadPixels"||std::string(d->class_name)=="Marshal"))return BE_Result_NotFound;
            s.methods.push_back({d->class_name,d->method_name});out->method_info=&s.methods.back();return BE_Result_Ok;
        };
        api.resolve_field=[](void*,const BE_FieldDescriptorV1* d,BE_ResolvedFieldV1* out) {
            const std::string c=d->class_name,n=d->field_name;
            int index=-1;
            if(c=="Vector3"||c=="Quaternion") {
                const auto found=std::string("xyzw").find(n);if(found!=std::string::npos)index=int(found);
            } else if(c=="Matrix4x4"&&n.size()==3)index=(n[2]-'0')*4+n[1]-'0';
            else if(c=="Rect") {
                const std::array<std::string,4> names{"m_XMin","m_YMin","m_Width","m_Height"};
                const auto found=std::find(names.begin(),names.end(),n);if(found!=names.end())index=int(found-names.begin());
            }
            if(index<0)return BE_Result_NotFound;
            out->field_info=reinterpret_cast<void*>(uintptr_t(1));out->offset=16+index*4;return BE_Result_Ok;
        };
        api.resolve_class=[](void* context,const char*,const char*,const char* name,BE_ResolvedClassV1* out) {
            if(std::string(name)=="HGAdditionalCameraData")return BE_Result_NotFound;
            auto& s=from(context);s.classes.emplace_back(name);out->class_info=&s.classes.back();
            out->type_info=out->class_info;out->type_object=const_cast<void*>(out->class_info);return BE_Result_Ok;
        };
        api.object_new=[](void* context,const void* klass)->void* {
            auto& s=from(context);auto* o=s.make(*static_cast<const std::string*>(klass));
            if(o->kind=="RenderTexture")o->eye=s.rtCount++;
            if(o->kind=="Texture2D")o->eye=s.cpuCount++;
            return o;
        };
        api.string_new=[](void* context,const char*)->void* {return from(context).make("String");};
        api.object_unbox=[](void*,void* object)->void* {return object;};
        api.gchandle_new=[](void* context,void* object,int)->uint32_t {
            auto& s=from(context);if(!object)return 0;const auto handle=s.nextRoot++;
            s.roots[handle]=static_cast<Object*>(object);return handle;
        };
        api.gchandle_free=[](void* context,uint32_t handle){from(context).roots.erase(handle);};
        api.runtime_invoke=[](void* context,const void* method,void* object,void** args,void** exception)->void* {
            return from(context).invoke(*static_cast<const Method*>(method),static_cast<Object*>(object),args,exception);
        };
    }
    void* invoke(const Method& m,Object* object,void** args,void** exception) {
        *exception=nullptr;
        const auto& n=m.name;
        if(n=="get_graphicsDeviceType")return box<int32_t>(graphics);
        if(n=="op_Equality")return box<uint8_t>(same(static_cast<Object*>(args[0]),static_cast<Object*>(args[1]))?1:0);
        if(n=="get_main")return main;
        if(n=="get_transform")return object->transform;
        if(n=="get_position")return box(object==main->transform?basePosition:object->position);
        if(n=="get_rotation"){auto q=object==main->transform?baseRotation:object->rotation;
            if(object!=main->transform)q[0]+=rotationReadNoise;return box(q);}
        if(n=="get_nearClipPlane")return box<float>(0.05f);
        if(n=="get_farClipPlane")return box<float>(100.0f);
        if(n==".ctor") {
            if(object->kind=="RenderTexture"||object->kind=="Texture2D") {
                object->width=*static_cast<int32_t*>(args[0]);object->height=*static_cast<int32_t*>(args[1]);
                if(object->kind=="Texture2D") {
                    object->format=*static_cast<int32_t*>(args[2]);
                    require(*static_cast<uint8_t*>(args[3])==0,"CPU texture unexpectedly has mipmaps");
                    require(*static_cast<uint8_t*>(args[4])==1,"CPU texture is not linear");
                }
            }
            return nullptr;
        }
        if(n=="Create")return box<uint8_t>(1);
        if(n=="get_sRGB"||n=="get_isDataSRGB")return box<uint8_t>(0);
        if(n=="get_format")return box<int32_t>(object->format);
        if(n=="get_mipmapCount")return box<int32_t>(1);
        if(n=="get_graphicsFormat")return box<int32_t>(object->graphicsFormat);
        if(n=="set_graphicsFormat"){object->graphicsFormat=*static_cast<int32_t*>(args[0]);return nullptr;}
        if(n=="GetNativeTexturePtr")return box<intptr_t>(reinterpret_cast<intptr_t>(object));
        if(n=="AddComponent") {
            auto* camera=make("Camera");camera->transform=make("Transform");return camera;
        }
        if(n=="set_targetTexture"){object->target=static_cast<Object*>(args[0]);return nullptr;}
        if(n=="set_position"){std::memcpy(object->position.data(),args[0],12);object->positionSet=true;return nullptr;}
        if(n=="set_rotation"){std::memcpy(object->rotation.data(),args[0],16);object->rotationSet=true;return nullptr;}
        if(n=="set_projectionMatrix"){std::memcpy(object->projection.data(),args[0],64);object->projectionSet=true;return nullptr;}
        if(n=="IsCreated")return box<uint8_t>(object->created?1:0);
        if(n=="get_width")return box<int32_t>(object->width);
        if(n=="get_height")return box<int32_t>(object->height);
        if(n=="get_frameCount")return box<int32_t>(frameCount);
        if(n=="get_OutputCamera")return main;
        if(n=="get_targetTexture")return object->target;
        if(n=="CopyFrom") {
            // Model destructive copying of source camera state, not a no-op.
            object->projection.fill(91);object->view.fill(92);
            object->nonJittered.fill(93);object->culling.fill(94);
            object->fov=75;object->aspect=1.777f;return nullptr;
        }
        if(n=="set_fieldOfView"){object->fov=*static_cast<float*>(args[0]);return nullptr;}
        if(n=="set_aspect"){object->aspect=*static_cast<float*>(args[0]);return nullptr;}
        if(n=="set_orthographic"||n=="set_usePhysicalProperties") {
            require(*static_cast<uint8_t*>(args[0])==0,"Eye must use non-physical perspective");return nullptr;
        }
        if(n=="set_position"){std::memcpy(object->position.data(),args[0],12);return nullptr;}
        if(n=="set_rotation"){std::memcpy(object->rotation.data(),args[0],16);return nullptr;}
        if(n=="set_projectionMatrix"){std::memcpy(object->projection.data(),args[0],64);return nullptr;}
        if(n=="set_worldToCameraMatrix"){std::memcpy(object->view.data(),args[0],64);return nullptr;}
        if(n=="set_nonJitteredProjectionMatrix"){std::memcpy(object->nonJittered.data(),args[0],64);return nullptr;}
        if(n=="set_cullingMatrix"){std::memcpy(object->culling.data(),args[0],64);return nullptr;}
        if(n=="get_projectionMatrix")return box(object->projection);
        if(n=="get_worldToCameraMatrix")return box(object->view);
        if(n=="get_nonJitteredProjectionMatrix")return box(object->nonJittered);
        if(n=="get_cullingMatrix")return box(object->culling);
        if(n=="Render") {
            auto* t=object->target;require(t&&t->eye>=0,"Camera did not render its own target");
            require(object->projectionSet&&object->transform->positionSet&&object->transform->rotationSet,"Render used unset eye matrices/pose");
            captures.push_back({t->eye,object->transform->position,object->transform->rotation,object->projection,
                object->view,object->nonJittered,object->culling,object->fov,object->aspect});
            if(t->eye==0)firstRendered=object;
            if(overwriteMode==1)object->projection[0]*=1.4f;
            if(overwriteMode==2)object->target=original;
            if(overwriteMode==3&&t->eye==1&&firstRendered)firstRendered->view[12]+=0.5f;
            if(overwriteMode==4)object->nonJittered[5]*=1.5f;
            if(overwriteMode==5)object->transform->position[0]+=0.5f;
            // Deliberately distinct eye/row/channel pattern, in Unity bottom-up order.
            const int b=t->eye*100;
            t->pixels={uint8_t(b+1),11,21,255,uint8_t(b+2),12,22,255,
                       uint8_t(b+3),13,23,255,uint8_t(b+4),14,24,255};
            return nullptr;
        }
        if(n=="get_active")return active;
        if(n=="set_active") {
            auto* target=static_cast<Object*>(args[0]);
            if(failRestore&&target==original){*exception=this;return nullptr;}
            active=target;return nullptr;
        }
        if(n=="ReadPixels") {
            ++readCount;
            require(active&&active->eye==object->eye,"ReadPixels read the wrong eye");
            if(failSecondRead&&object->eye==1){*exception=this;return nullptr;}
            object->pixels=active->pixels;return nullptr;
        }
        if(n=="GetRawTextureData") {auto* bytes=make("ByteArray");bytes->pixels=object->pixels;return bytes;}
        if(n=="get_Length")return box<int32_t>(int32_t(object->pixels.size()));
        if(m.klass=="Marshal"&&n=="Copy") {
            const auto* bytes=static_cast<Object*>(args[0]);const auto start=*static_cast<int32_t*>(args[1]);
            const auto destination=*static_cast<intptr_t*>(args[2]);const auto count=*static_cast<int32_t*>(args[3]);
            require(bytes->kind=="ByteArray"&&start==0&&count==int(bytes->pixels.size()),"Invalid managed byte copy arguments");
            std::memcpy(reinterpret_cast<void*>(destination),bytes->pixels.data(),size_t(count));return nullptr;
        }
        if(n=="Destroy") {
            auto* target=static_cast<Object*>(args[0]);require(target!=active,"Destroyed the still-active RenderTexture");
            target->alive=false;++destroyCount;return nullptr;
        }
        if(n=="set_enabled"||n=="set_hideFlags"||n=="set_antiAliasing"||n=="set_useMipMap"||
           n=="set_autoGenerateMips"||n=="CopyFrom"||n=="set_rect"||n=="set_position"||
           n=="set_rotation"||n=="ResetWorldToCameraMatrix"||n=="set_projectionMatrix"||
           n=="ResetCullingMatrix"||n=="Release")return nullptr;
        throw std::runtime_error("Unexpected fake-host call: "+m.klass+"."+n);
    }
};


using Vec=std::array<float,3>;
constexpr float Epsilon=0.00005f;
constexpr float RootHalf=0.7071067811865475f;
void close(float value,float expected,const char* message){require(std::abs(value-expected)<Epsilon,message);}
void vector_close(Vec value,Vec expected,const char* message){for(unsigned i=0;i<3;++i)close(value[i],expected[i],message);}

// Independent oracle: expanded quaternion rotation matrix, not the production
// reflection/composition functions. Unity camera-local +Z is forward; camera
// VIEW coordinates change that Z sign for the OpenGL-style projection.
Vec rotate(const std::array<float,4>& q,Vec v){
    const float x=q[0],y=q[1],z=q[2],w=q[3];
    return {(1-2*y*y-2*z*z)*v[0]+(2*x*y-2*z*w)*v[1]+(2*x*z+2*y*w)*v[2],
            (2*x*y+2*z*w)*v[0]+(1-2*x*x-2*z*z)*v[1]+(2*y*z-2*x*w)*v[2],
            (2*x*z-2*y*w)*v[0]+(2*y*z+2*x*w)*v[1]+(1-2*x*x-2*y*y)*v[2]};
}
std::array<float,3> project_view(const std::array<float,16>& m,Vec point){
    const float v[4]={point[0],point[1],point[2],1};float clip[4]{};
    for(unsigned row=0;row<4;++row)for(unsigned col=0;col<4;++col)clip[row]+=m[col*4+row]*v[col];
    require(clip[3]>0,"Forward point has non-positive projection W");
    return {clip[0]/clip[3],clip[1]/clip[3],clip[2]/clip[3]};
}
std::array<float,3> project_world(const FakeHost::Capture& camera,Vec world){
    Vec delta{world[0]-camera.position[0],world[1]-camera.position[1],world[2]-camera.position[2]};
    auto inverse=camera.rotation;inverse[0]*=-1;inverse[1]*=-1;inverse[2]*=-1;
    Vec local=rotate(inverse,delta);local[2]*=-1;return project_view(camera.projection,local);
}
std::array<vrvd::Eye,2> eyes(){
    std::array<vrvd::Eye,2> result{};
    for(auto& e:result){e.orientation[3]=1;e.angleLeft=e.angleDown=-0.6f;e.angleRight=e.angleUp=0.6f;}
    result[0].position[0]=-.032f;result[1].position[0]=.032f;return result;
}
struct Fixture {
    FakeHost host;vrvd::UnityBridge bridge;
    Fixture(){std::string error;require(bridge.resolve(&host.api,error),error.c_str());require(bridge.ensure_targets(2,2,error),error.c_str());}
    ~Fixture(){bridge.cleanup();}
    void render(const std::array<vrvd::Eye,2>& e){host.captures.clear();std::string error;
        require(bridge.render_eyes(e.data(),error),error.c_str());require(host.captures.size()==2,"Did not render both eyes");
        require(host.captures[0].eye==0&&host.captures[1].eye==1,"Render target identity/order swapped");}
};
void identity_and_disparity(){
    Fixture f;f.render(eyes());const auto& l=f.host.captures[0];const auto& r=f.host.captures[1];
    vector_close(l.position,{-.032f,1,0},"Left-eye baseline points right");vector_close(r.position,{.032f,1,0},"Right-eye baseline points left");
    for(const auto& c:f.host.captures){vector_close(rotate(c.rotation,{0,0,1}),{0,0,1},"Identity head does not face forward");
        vector_close(rotate(c.rotation,{1,0,0}),{1,0,0},"Camera right axis is mirrored");}
    const auto ln=project_world(l,{0,1,1}),rn=project_world(r,{0,1,1});
    const auto lf=project_world(l,{0,1,4}),rf=project_world(r,{0,1,4});
    require(ln[0]>0&&rn[0]<0,"Centered near object has reversed stereo disparity");
    require(ln[0]-rn[0]>lf[0]-rf[0]&&lf[0]>rf[0],"Near-vs-far depth disparity is reversed");
    close(ln[0]-rn[0],.064f/std::tan(.6f),"Near object disparity has wrong projection scale");
    close(ln[1],rn[1],"Identical vertical position creates vertical disparity");
}
void game_yaw_and_head_rotation(){
    Fixture f;f.host.baseRotation={0,RootHalf,0,RootHalf};auto e=eyes();f.render(e);
    vector_close(f.host.captures[0].position,{0,1,.032f},"Game yaw90 left eye is on wrong side");
    vector_close(f.host.captures[1].position,{0,1,-.032f},"Game yaw90 right eye is on wrong side");
    vector_close(rotate(f.host.captures[0].rotation,{0,0,1}),{1,0,0},"Game yaw90 forward axis wrong");
    const auto l=project_world(f.host.captures[0],{1,1,0}),r=project_world(f.host.captures[1],{1,1,0});
    require(l[0]>r[0],"Yaw90 reversed stereo depth");
    // RH XR +90 about Y turns -Z forward to -X. Compose with game's +90
    // Unity yaw: final view should return to +Z, and IPD stays camera-right.
    e[0].position[0]=e[1].position[0]=0;e[0].position[2]=.032f;e[1].position[2]=-.032f;
    for(auto& eye:e){eye.orientation[1]=RootHalf;eye.orientation[3]=RootHalf;}
    f.render(e);
    vector_close(f.host.captures[0].position,{-.032f,1,0},"Head-yaw left eye baseline flipped");
    vector_close(rotate(f.host.captures[0].rotation,{0,0,1}),{0,0,1},"Head yaw uses wrong sign or wrong multiplication order");
}
void translation_pitch_roll(){
    Fixture f;auto e=eyes();
    for(auto& eye:e){eye.position[0]+=.2f;eye.position[1]=.1f;eye.position[2]=-.3f;}
    f.render(e);vector_close(f.host.captures[0].position,{.168f,1.1f,.3f},"XR translation handedness incorrect");
    vector_close(f.host.captures[1].position,{.232f,1.1f,.3f},"Translation changed IPD order");
    // XR +30 X pitches its -Z forward UP; Unity converted camera must look UP.
    e=eyes();for(auto& eye:e){eye.orientation[0]=std::sin(.2617993878f);eye.orientation[3]=std::cos(.2617993878f);}
    f.render(e);vector_close(rotate(f.host.captures[0].rotation,{0,0,1}),{0,.5f,.8660254038f},"Pitch direction inverted");
    e=eyes();for(auto& eye:e){eye.orientation[2]=std::sin(.2617993878f);eye.orientation[3]=std::cos(.2617993878f);}
    f.render(e);vector_close(rotate(f.host.captures[0].rotation,{0,1,0}),{-.5f,.8660254038f,0},"Roll direction inverted");
}
void asymmetric_frusta(){
    Fixture f;auto e=eyes();
    e[0].angleLeft=-.9f;e[0].angleRight=.5f;e[0].angleDown=-.65f;e[0].angleUp=.8f;
    e[1].angleLeft=-.45f;e[1].angleRight=.85f;e[1].angleDown=-.7f;e[1].angleUp=.75f;f.render(e);
    for(unsigned i=0;i<2;++i){const auto& m=f.host.captures[i].projection;const auto& eye=e[i];
        const float left=std::tan(eye.angleLeft),right=std::tan(eye.angleRight),top=std::tan(eye.angleUp),bottom=std::tan(eye.angleDown);
        // Test geometric boundary rays, not copies of production coefficients.
        close(project_view(m,{left,0,-1})[0],-1,"Left FOV boundary does not map to -1 NDC");
        close(project_view(m,{right,0,-1})[0],1,"Right FOV boundary does not map to +1 NDC");
        close(project_view(m,{0,top,-1})[1],1,"Upper FOV boundary does not map to +1 NDC");
        close(project_view(m,{0,bottom,-1})[1],-1,"Lower FOV boundary does not map to -1 NDC");
        close(project_view(m,{(left+right)/2,(top+bottom)/2,-1})[0],0,"Asymmetric horizontal frustum center is wrong");
        close(project_view(m,{0,0,-.05f})[2],-1,"Near depth endpoint incorrect");
        close(project_view(m,{0,0,-100.f})[2],1,"Far depth endpoint incorrect");
    }
    require(f.host.captures[0].projection!=f.host.captures[1].projection,"Distinct per-eye FOVs shared one projection");
}
void reject_invalid_before_render(){
    Fixture f;auto e=eyes();e[1].angleRight=e[1].angleLeft;std::string error;
    require(!f.bridge.render_eyes(e.data(),error),"Invalid right-eye FOV accepted");
    require(f.host.captures.empty(),"Invalid stereo pair partially rendered a stale frame");
}
void geometry_and_culling_agree(){
    Fixture f;f.host.baseRotation={0,RootHalf,0,RootHalf};auto e=eyes();
    e[0].angleLeft=-.9f;e[0].angleRight=.5f;e[0].angleDown=-.65f;e[0].angleUp=.8f;
    e[1].angleLeft=-.45f;e[1].angleRight=.85f;e[1].angleDown=-.7f;e[1].angleUp=.75f;f.render(e);
    for(const auto& c:f.host.captures){
        require(c.projection==c.nonJittered,"Unjittered projection was inherited from main camera");
        close(std::tan(c.fov*3.14159265358979323846f/360.f)*c.projection[5],1.f,"Scalar vertical scale disagrees with projection");
        close(c.aspect,c.projection[5]/c.projection[0],"Scalar aspect disagrees with projection");
        for(const Vec world:{Vec{2,1,0},Vec{5,1.2f,.2f}}){
            const auto expected=project_world(c,world),actual=project_view(c.culling,world);
            vector_close(actual,expected,"Culling and rendered view do not agree geometrically");
        }
        const Vec p=c.position;float viewOrigin[4]{};const float v[]{p[0],p[1],p[2],1};
        for(unsigned r=0;r<4;++r)for(unsigned col=0;col<4;++col)viewOrigin[r]+=c.view[col*4+r]*v[col];
        close(viewOrigin[0],0,"View does not center the eye X");close(viewOrigin[1],0,"View does not center the eye Y");close(viewOrigin[2],0,"View does not center the eye Z");
    }
    require(f.bridge.diagnostics().geometry_checks==6,"Missing pre/post or pair validation");
}
void reject_silent_render_overwrites(){
    for(int mode=1;mode<=5;++mode){Fixture f;f.host.overwriteMode=mode;auto e=eyes();std::string error;
        require(!f.bridge.render_eyes(e.data(),error),"Silently overwritten eye data was accepted");
        require(f.bridge.diagnostics().geometry_failures>0,"Matrix failure was not reported");
        std::vector<uint8_t> result[2]{{9},{8}};
        require(!f.bridge.readback_eyes(result,error),"Rejected pair reached readback");
        require(result[0]==std::vector<uint8_t>{9}&&result[1]==std::vector<uint8_t>{8},"Rejected pair exposed partial pixels");
    }
}
void detect_lost_texture_without_destroying(){
    Fixture f;std::string error;bool valid=false;
    require(f.bridge.validate_targets(valid,error)&&valid,"Fresh targets not healthy");
    for(auto& o:f.host.objects)if(o->kind=="RenderTexture"&&o->eye==0)o->created=false;
    const auto roots=f.host.roots.size();const int destroyed=f.host.destroyCount;
    require(f.bridge.validate_targets(valid,error)&&!valid,"Alive but uncreated texture was accepted");
    require(f.host.roots.size()==roots&&f.host.destroyCount==destroyed,"Health check destructively recovered a texture");
}
void cleanup_source_before_targets_exist(){
    FakeHost host;vrvd::UnityBridge bridge;std::string error;bool accepted=false;
    require(bridge.resolve(&host.api,error),error.c_str());
    require(bridge.accept_frame(host.main,accepted,error)&&accepted,"Source camera was not accepted");
    require(bridge.resources_alive()&&host.roots.size()==1,"Accepted camera root was omitted from lifecycle accounting");
    require(!bridge.resolve(&host.api,error),"Bridge rebound with a retained source camera");
    bridge.cleanup();
    require(!bridge.resources_alive()&&host.roots.empty(),"Cleanup leaked accepted camera before target creation");
    require(host.main->alive,"Cleanup destroyed the original camera");
}
void large_world_pose_rounding(){
    Fixture f;f.host.basePosition={10000,10000,10000};f.host.rotationReadNoise=0.0000001f;
    f.render(eyes());
    require(f.bridge.diagnostics().geometry_failures==0,"Quaternion rounding amplified by large world translation");
    f.host.rotationReadNoise=0.01f;std::string error;auto e=eyes();
    require(!f.bridge.render_eyes(e.data(),error),"Material transform rotation change was accepted");
}
}
int main(){try{identity_and_disparity();game_yaw_and_head_rotation();translation_pitch_roll();asymmetric_frusta();reject_invalid_before_render();
    geometry_and_culling_agree();reject_silent_render_overwrites();detect_lost_texture_without_destroying();cleanup_source_before_targets_exist();large_world_pose_rounding();
    std::cout<<"PASS: UnityBridge geometry/culling, scalar scale, CopyFrom reset, five silent Render overwrite modes, lost texture detection; fake host, not HG draw validation\n";return 0;
}catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}}
