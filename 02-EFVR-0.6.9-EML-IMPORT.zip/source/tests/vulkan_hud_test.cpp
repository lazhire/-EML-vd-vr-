#include <array>
#include <memory>
#include <string>
#include <vector>
#include <type_traits>
#include <iostream>
#include <limits>
#include <stdexcept>
#include "../src/unity_bridge.h"
// Expose only this test's backend storage; compile the production implementation
// in this unit so callbacks observe the actual VIEW/quad submission code.
#define private public
#include "../src/xr_vulkan.h"
#undef private
#include "../src/xr_vulkan.cpp"

namespace {
template<class T>T handle(uintptr_t id){if constexpr(std::is_pointer_v<T>)return reinterpret_cast<T>(id);else return static_cast<T>(id);}
bool saw_view=false;
XrCompositionLayerQuad submitted_quad{};
uint32_t submitted_layers=0;
unsigned submissions=0,atlas_copy_height=0,atlas_upload_height=0;
float clear_alpha=-1;
unsigned eye_clears=0,scene_copies=0;
void require(bool value,const char* why){if(!value)throw std::runtime_error(why);}
int production_geometry_checks(){
    int checks=0;
    auto checked=[&](bool value,const char* why){require(value,why);++checks;};
    vrvd::XrVulkanBackend backend;
    {
        auto& p=*backend.impl_;p.owned=true;p.session=handle<XrSession>(1);
        p.max_layers=2;p.max_swap_width=p.max_swap_height=4096;
        p.xrCreateReferenceSpace=[](XrSession,const XrReferenceSpaceCreateInfo* info,XrSpace*)->XrResult {
            saw_view=info->referenceSpaceType==XR_REFERENCE_SPACE_TYPE_VIEW&&info->poseInReferenceSpace.orientation.w==1.f&&
                info->poseInReferenceSpace.position.x==0.f&&info->poseInReferenceSpace.position.y==0.f&&info->poseInReferenceSpace.position.z==0.f;
            // Deliberate boundary stop: no swapchain or device creation follows.
            return XR_ERROR_RUNTIME_FAILURE;
        };
        std::array<unsigned char,4> pixel{};vrvd::XrVulkanHudFrame frame{pixel.data(),4,1,1,1.5f,1.8f,0.f};std::string error;
        checked(!p.ensure_hud(frame,error)&&saw_view&&!error.empty(),"production HUD requests a viewer-relative reference space");
        backend.impl_.reset(new vrvd::XrVulkanBackend::Impl);
    }
    auto& p=*backend.impl_;p.session=handle<XrSession>(2);p.local=handle<XrSpace>(3);p.hud_view=handle<XrSpace>(4);
    p.hud_chain=handle<XrSwapchain>(5);p.hud_width=1280;p.hud_height=720;
    p.hud_distance=1.5f;p.hud_width_m=1.8f;p.hud_offset_y=0.f;p.command=handle<VkCommandBuffer>(6);
    p.hud_images.push_back({XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR,nullptr,handle<VkImage>(7)});
    for(unsigned eye=0;eye<2;++eye){
        p.sources[eye].image=handle<VkImage>(20+eye);p.sources[eye].format=VK_FORMAT_R8G8B8A8_UNORM;
        p.sources[eye].extent={32,32,1};p.sources[eye].layout=VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
        p.sources[eye].usage=VK_IMAGE_USAGE_TRANSFER_SRC_BIT;p.sources[eye].aspect=VK_IMAGE_ASPECT_COLOR_BIT;
        p.chains[eye]=handle<XrSwapchain>(30+eye);
        p.images[eye].push_back({XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR,nullptr,handle<VkImage>(40+eye)});
        p.views[eye].pose.orientation.w=1.f;
    }
    p.xrAcquireSwapchainImage=[](XrSwapchain,const XrSwapchainImageAcquireInfo*,uint32_t* index)->XrResult{*index=0;return XR_SUCCESS;};
    p.xrWaitSwapchainImage=[](XrSwapchain,const XrSwapchainImageWaitInfo*)->XrResult{return XR_SUCCESS;};
    p.xrReleaseSwapchainImage=[](XrSwapchain,const XrSwapchainImageReleaseInfo*)->XrResult{return XR_SUCCESS;};
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{
        submitted_layers=info->layerCount;++submissions;
        require(info->layerCount>=1&&info->layers[0]->type==XR_TYPE_COMPOSITION_LAYER_PROJECTION,"stereo projection remains first");
        if(info->layerCount==2){require(info->layers[1]->type==XR_TYPE_COMPOSITION_LAYER_QUAD,"HUD is a separate quad");
            submitted_quad=*reinterpret_cast<const XrCompositionLayerQuad*>(info->layers[1]);}
        return XR_SUCCESS;
    };
    p.vkCmdClearColorImage=[](VkCommandBuffer,VkImage image,VkImageLayout layout,const VkClearColorValue* color,uint32_t,const VkImageSubresourceRange*){require(layout==VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL&&color->float32[0]==0&&color->float32[1]==0&&color->float32[2]==0,"fade is a GPU black clear");clear_alpha=color->float32[3];if(image==handle<VkImage>(40)||image==handle<VkImage>(41)){require(clear_alpha==1,"flat base is opaque black");++eye_clears;}};
    p.vkResetCommandBuffer=[](VkCommandBuffer,VkCommandBufferResetFlags)->VkResult{return VK_SUCCESS;};
    p.vkBeginCommandBuffer=[](VkCommandBuffer,const VkCommandBufferBeginInfo*)->VkResult{return VK_SUCCESS;};
    p.vkEndCommandBuffer=[](VkCommandBuffer)->VkResult{return VK_SUCCESS;};
    p.vkResetFences=[](VkDevice,uint32_t,const VkFence*)->VkResult{return VK_SUCCESS;};
    p.vkWaitForFences=[](VkDevice,uint32_t,const VkFence*,VkBool32,uint64_t)->VkResult{return VK_SUCCESS;};
    p.vkQueueSubmit=[](VkQueue,uint32_t,const VkSubmitInfo*,VkFence)->VkResult{return VK_SUCCESS;};
    p.vkCmdPipelineBarrier=[](VkCommandBuffer,VkPipelineStageFlags,VkPipelineStageFlags,VkDependencyFlags,uint32_t,const VkMemoryBarrier*,uint32_t,const VkBufferMemoryBarrier*,uint32_t,const VkImageMemoryBarrier*){};
    p.vkCmdCopyImage=[](VkCommandBuffer,VkImage source,VkImageLayout,VkImage,VkImageLayout,uint32_t,const VkImageCopy* copy){if(!source)atlas_copy_height=copy->extent.height;else ++scene_copies;};
    p.vkCmdCopyBufferToImage=[](VkCommandBuffer,VkBuffer,VkImage image,VkImageLayout,uint32_t,const VkBufferImageCopy* copy){if(!image)atlas_upload_height=copy->imageExtent.height;};
    auto submit=[&](bool hud){p.pending=p.begun=p.renderable=true;p.hud_frame=hud;std::string error;
        require(backend.submit(p.sources.data(),error),error.c_str());};
    submit(true);
    checked(submissions==1&&submitted_layers==2,"enabled HUD submits scene and HUD together");
    checked(submitted_quad.space==p.hud_view&&submitted_quad.space!=p.local&&submitted_quad.eyeVisibility==XR_EYE_VISIBILITY_BOTH,"quad uses VIEW space for both eyes");
    checked(submitted_quad.pose.orientation.x==0.f&&submitted_quad.pose.orientation.y==0.f&&submitted_quad.pose.orientation.z==0.f&&submitted_quad.pose.orientation.w==1.f&&
        submitted_quad.pose.position.x==0.f&&submitted_quad.pose.position.y==0.f&&submitted_quad.pose.position.z==-1.5f,"native HUD is centered in front of the viewer");
    checked(std::fabs(submitted_quad.size.width-1.8f)<.00001f&&std::fabs(submitted_quad.size.height-1.0125f)<.00001f,"actual submitted quad preserves 16:9 aspect");
    checked(submitted_quad.layerFlags==XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT,"actual layer uses premultiplied source alpha");
    checked(submitted_quad.subImage.imageRect.extent.width==1280&&submitted_quad.subImage.imageRect.extent.height==720,"actual quad uses complete native HUD texture");
    p.hud_offset_y=-.25f;p.hud_width=720;p.hud_height=1280;submit(true);
    checked(submitted_quad.pose.position.y==-.25f&&std::fabs(submitted_quad.size.height-3.2f)<.00001f,"custom offset and portrait aspect reach production submission");
    submit(false);checked(submitted_layers==1,"disabled or missing HUD omits old quad on next frame");
    // Exercise the actual menu-only API, not just a manually selected layer list.
    p.hud_width=1280;p.hud_height=720;p.owned=true;p.hud_ready=true;p.max_layers=2;p.max_swap_width=p.max_swap_height=4096;
    std::vector<unsigned char> panelPixels(size_t(1280)*720*4,255),mapped(size_t(1280)*(720+vrvd::MenuBackdropRows)*4);
    p.hud_map=mapped.data();p.hud_coherent=true;
    p.xrAcquireSwapchainImage=[](XrSwapchain chain,const XrSwapchainImageAcquireInfo*,uint32_t* index)->XrResult{
        require(chain==handle<XrSwapchain>(5),"menu-only frame must not acquire either eye swapchain");*index=0;return XR_SUCCESS;};
    // During outgoing fade only, reuse released eye chains with their original
    // poses. Head motion in the new frame must not rewrite the cached view pose.
    p.views[0].pose.position.x=99.f;
    auto cpuBefore=mapped;
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{
        require(info->layerCount==2&&info->layers[0]->type==XR_TYPE_COMPOSITION_LAYER_PROJECTION,"fade reuses world below black cover");
        auto scene=reinterpret_cast<const XrCompositionLayerProjection*>(info->layers[0]);
        require(scene->views[0].pose.position.x==0,"cached world keeps original pose for runtime reprojection");
        auto mask=reinterpret_cast<const XrCompositionLayerQuad*>(info->layers[1]);
        require(mask->space==handle<XrSpace>(4)&&mask->size.width>=2.7f&&mask->size.height>=2.7f&&mask->pose.position.z==-1.f,"black mask covers entire VIEW");
        require(mask->layerFlags==XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT,"black mask blends by alpha");return XR_SUCCESS;
    };
    vrvd::XrVulkanHudFrame mask{};mask.width=1280;mask.height=720;mask.black_opacity=.4f;mask.keep_previous_world=true;
    p.pending=p.begun=p.renderable=true;std::string fadeError;
    checked(backend.submit_panel(mask,fadeError)&&backend.has_previous_world()&&clear_alpha==.4f,"GPU fade over released stereo image");
    checked(mapped==cpuBefore,"GPU fade does not fill or upload a CPU mask");
    mask.black_opacity=1;p.pending=p.begun=p.renderable=true;
    checked(backend.submit_panel(mask,fadeError)&&clear_alpha==1,"fully black outgoing boundary");
    p.xrAcquireSwapchainImage=[](XrSwapchain,const XrSwapchainImageAcquireInfo*,uint32_t* index)->XrResult{*index=0;return XR_SUCCESS;};
    const auto copies_before=scene_copies;
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{
        require(info->layerCount==2&&info->layers[0]->type==XR_TYPE_COMPOSITION_LAYER_PROJECTION&&info->layers[1]->type==XR_TYPE_COMPOSITION_LAYER_QUAD,"flat base and menu quad, never stale scene pixels");
        submitted_layers=info->layerCount;return XR_SUCCESS;};
    vrvd::XrVulkanHudFrame panel{panelPixels.data(),panelPixels.size(),1280,720,1.5f,1.8f,0};
    p.pending=p.begun=p.renderable=true;std::string panelError;
    checked(backend.submit_panel(panel,panelError)&&!backend.has_previous_world()&&p.hud_black_opacity==-1,"native menu removes cached stereo and old black cover");
    checked(std::equal(panelPixels.begin(),panelPixels.end(),mapped.begin())&&!p.panel_only&&!p.pending,"menu upload copies pixels and drains frame state");
    checked(eye_clears==2&&scene_copies==copies_before,"both menu eye images cleared on GPU, no world image copied");
    checked(backend.diagnostics().last_flat_projection_background&&backend.diagnostics().last_layer_count==2,"flat compatibility telemetry");
    std::vector<unsigned char> blur(128*128*4,91);panel.backdrop_rgba=blur.data();panel.backdrop_bytes=blur.size();
    p.max_layers=3;
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{
        require(info->layerCount==3&&info->layers[0]->type==XR_TYPE_COMPOSITION_LAYER_PROJECTION,"focus menu has black projection, backdrop then clear panel");
        auto bg=reinterpret_cast<const XrCompositionLayerQuad*>(info->layers[1]);
        auto fg=reinterpret_cast<const XrCompositionLayerQuad*>(info->layers[2]);
        require(bg->type==XR_TYPE_COMPOSITION_LAYER_QUAD&&fg->type==XR_TYPE_COMPOSITION_LAYER_QUAD,"both focus layers are quads");
        require(bg->space==fg->space&&bg->eyeVisibility==XR_EYE_VISIBILITY_BOTH&&fg->eyeVisibility==XR_EYE_VISIBILITY_BOTH,"same VIEW space and both eyes");
        require(bg->pose.position.z<fg->pose.position.z&&bg->size.width>fg->size.width&&bg->size.height>fg->size.height,"backdrop is behind panel and covers peripheral view");
        require(bg->subImage.swapchain==fg->subImage.swapchain&&bg->subImage.imageRect.offset.x==2&&bg->subImage.imageRect.offset.y==726&&bg->subImage.imageRect.extent.width==128,"disjoint atlas background rectangle");
        require(fg->subImage.imageRect.offset.y==0&&fg->subImage.imageRect.extent.height==720,"clear panel retains full resolution");
        require(bg->layerFlags==0&&fg->layerFlags==XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT,"opaque background and premultiplied feathered panel");
        submitted_layers=info->layerCount;return XR_SUCCESS;
    };
    p.pending=p.begun=p.renderable=true;
    checked(backend.submit_panel(panel,panelError)&&submitted_layers==3,"production focus composition");
    checked(atlas_copy_height==856&&atlas_upload_height==856,"GPU transfer includes full backdrop atlas rows");
    checked(mapped[(720*1280)*4]==0&&mapped[(724*1280)*4]==91&&mapped[((724+131)*1280+131)*4]==91&&mapped[(724*1280+132)*4]==0,"backdrop gutters and clear unused atlas region");
    checked(std::equal(panelPixels.begin(),panelPixels.end(),mapped.begin()),"background upload never overwrites clear menu");
    panel.backdrop_rgba=nullptr;panel.backdrop_bytes=0;
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{require(info->layerCount==2&&info->layers[0]->type==XR_TYPE_COMPOSITION_LAYER_PROJECTION,"disabling blur retains black projection and foreground only");return XR_SUCCESS;};
    p.pending=p.begun=p.renderable=true;
    checked(backend.submit_panel(panel,panelError)&&!p.hud_backdrop,"toggle off removes stale backdrop");
    checked(std::all_of(mapped.begin()+panelPixels.size(),mapped.end(),[](auto v){return v==0;}),"atlas padding cleared after backdrop disable");
    // New live stereo plus a GPU cover supports the return fade; no old world reuse.
    p.owned=false;p.hud_black_opacity=.5f;p.pending=p.begun=p.renderable=true;p.hud_frame=true;
    p.xrAcquireSwapchainImage=[](XrSwapchain,const XrSwapchainImageAcquireInfo*,uint32_t* i)->XrResult{*i=0;return XR_SUCCESS;};
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{require(info->layerCount==2,"return fade has live stereo and mask");auto scene=reinterpret_cast<const XrCompositionLayerProjection*>(info->layers[0]);require(scene->views[0].pose.position.x==99,"return fade uses fresh pose");return XR_SUCCESS;};
    checked(backend.submit(p.sources.data(),panelError)&&clear_alpha==.5f&&backend.has_previous_world(),"fresh stereo return fade");
    // Runtime with only two layers drops decoration, retaining the full menu.
    p.owned=true;p.max_layers=2;p.pending=p.begun=p.renderable=true;panel.backdrop_rgba=blur.data();panel.backdrop_bytes=blur.size();
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{require(info->layerCount==2&&info->layers[1]->type==XR_TYPE_COMPOSITION_LAYER_QUAD,"layer cap preserves foreground");return XR_SUCCESS;};
    checked(backend.submit_panel(panel,panelError),"two-layer fallback");
    panel.projection_background=false;p.pending=p.begun=p.renderable=true;
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{require(info->layerCount==2&&info->layers[0]->type==XR_TYPE_COMPOSITION_LAYER_QUAD,"legacy quad-only diagnostic path");return XR_SUCCESS;};
    checked(backend.submit_panel(panel,panelError)&&!backend.diagnostics().last_flat_projection_background,"legacy diagnostic comparison remains available");
    panel.projection_background=true;panel.content_black_opacity=.5f;
    p.max_layers=4;p.pending=p.begun=p.renderable=true;
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{
        require(info->layerCount==4,"flat fade with backdrop fits four layers");
        auto cover=reinterpret_cast<const XrCompositionLayerQuad*>(info->layers[3]);
        require(cover->subImage.imageRect.offset.x==1277&&cover->subImage.imageRect.offset.y==721&&cover->subImage.imageRect.extent.width==2,"fade samples isolated black atlas patch");
        require(cover->size.width>=2.7f&&cover->pose.position.z==-1&&cover->layerFlags==XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT,"fade covers entire VIEW with alpha");return XR_SUCCESS;
    };
    checked(backend.submit_panel(panel,panelError),"menu fade layer submission");
    checked(mapped[(size_t(721)*1280+1277)*4+3]==128&&mapped[(size_t(721)*1280+1277)*4]==0,"small black-alpha patch encoded");
    checked(std::equal(panelPixels.begin(),panelPixels.end(),mapped.begin()),"fade cover does not CPU-darken full image when layers available");
    p.max_layers=3;p.pending=p.begun=p.renderable=true;
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{require(info->layerCount==3,"drop backdrop before fade cover at three-layer cap");return XR_SUCCESS;};
    checked(backend.submit_panel(panel,panelError),"three-layer fade fallback");
    p.max_layers=2;p.pending=p.begun=p.renderable=true;
    p.xrEndFrame=[](XrSession,const XrFrameEndInfo* info)->XrResult{require(info->layerCount==2,"two-layer fallback retains menu and base");return XR_SUCCESS;};
    checked(backend.submit_panel(panel,panelError)&&mapped[0]==128&&mapped[3]==255,"two-layer CPU darkening fallback");
    panel.content_black_opacity=0;p.pending=p.begun=p.renderable=true;
    checked(backend.submit_panel(panel,panelError)&&mapped[0]==255&&mapped[(size_t(721)*1280+1277)*4+3]==0,"fade completion restores source and clears mask patch");
    // Every handle above is an inert test token; discard storage before the
    // production destructor so no runtime destruction is attempted.
    backend.impl_.reset(new vrvd::XrVulkanBackend::Impl);
    return checks;
}
}

// Compile the existing call shape too; this function is never executed.
bool legacy_call(vrvd::XrVulkanBackend& backend,const void* a,const void* b,size_t n,std::string& error) {
    return backend.submit_rgba(a,b,n,error);
}
int main() {
    std::array<unsigned char,24> pixels{};
    vrvd::XrVulkanHudFrame valid{pixels.data(),pixels.size(),2,3,1.5f,1.6f,0.f};
    std::string error;
    int checks=0;
    auto check=[&](const vrvd::XrVulkanHudFrame& item,bool expected,const char* label) {
        const bool actual=vrvd::validate_vulkan_hud_frame(item,error);
        if(actual!=expected || (actual&&!error.empty()) || (!actual&&error.empty()))throw std::runtime_error(label);
        ++checks;
    };
    check(valid,true,"valid non-square HUD");
    auto item=valid;item.rgba=nullptr;check(item,false,"null");
    item=valid;item.bytes--;check(item,false,"short byte count");
    item=valid;item.bytes++;check(item,false,"long byte count");
    item=valid;item.width=0;check(item,false,"zero width");
    item=valid;item.height=0;check(item,false,"zero height");
    item=valid;item.width=4097;check(item,false,"dimension bound");
    item=valid;item.width=UINT32_MAX;item.height=UINT32_MAX;item.bytes=4;check(item,false,"dimension multiplication overflow");
    item=valid;item.distance_m=0;check(item,false,"zero distance");
    item=valid;item.distance_m=-1;check(item,false,"behind viewer");
    item=valid;item.width_m=-1;check(item,false,"negative physical size");
    item=valid;item.width_m=std::numeric_limits<float>::infinity();check(item,false,"infinite physical width");
    item=valid;item.offset_y_m=std::numeric_limits<float>::quiet_NaN();check(item,false,"NaN offset");
    item=valid;item.distance_m=std::numeric_limits<float>::quiet_NaN();check(item,false,"NaN distance");
    item=valid;item.width_m=std::numeric_limits<float>::max();check(item,false,"derived height overflow");
    item=valid;item.offset_y_m=-0.25f;check(item,true,"negative finite offset");
    check(valid,true,"error cleared after invalid input");
    item=valid;item.backdrop_rgba=pixels.data();item.backdrop_bytes=4;check(item,false,"invalid backdrop byte count");
    item=valid;item.backdrop_bytes=128*128*4;check(item,false,"missing backdrop pointer");
    item=valid;item.backdrop_rgba=pixels.data();item.backdrop_bytes=128*128*4;check(item,false,"atlas width cannot contain backdrop");
    const int geometry=production_geometry_checks();
    vrvd::XrVulkanHudFrame mask{};mask.width=1280;mask.height=720;mask.black_opacity=.5f;mask.keep_previous_world=true;
    require(vrvd::validate_vulkan_hud_frame(mask,error),"GPU mask needs no CPU pixels");mask.black_opacity=2;require(!vrvd::validate_vulkan_hud_frame(mask,error),"invalid fade alpha");mask.black_opacity=std::numeric_limits<float>::quiet_NaN();require(!vrvd::validate_vulkan_hud_frame(mask,error),"NaN fade alpha");mask=valid;mask.keep_previous_world=true;require(!vrvd::validate_vulkan_hud_frame(mask,error),"ordinary menus cannot reuse world");
    std::cout<<"PASS "<<checks<<" HUD parameter checks and "<<geometry<<" production VIEW/quad checks; fake XR/GPU only, no runtime or game.\n";
}

