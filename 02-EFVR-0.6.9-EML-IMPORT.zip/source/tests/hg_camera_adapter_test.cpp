// Real adapter, fake managed host + named IL2CPP exports. No game or GPU.
#include "../src/hg_camera_adapter.h"
#include "../src/hg_projection_hook.h"
#include <array>
#include <cstring>
#include <deque>
#include <iostream>
#include <map>
#include <memory>
#include <stdexcept>
#include <vector>

namespace {
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
struct Class {std::string name;Class* parent=nullptr;Class* declaring=nullptr;bool enumeration=false;};
struct Type {int kind=0;Class* klass=nullptr;bool byref=false;};
struct Field {std::string name;Class* parent=nullptr;Type* type=nullptr;uint32_t flags=6;};
struct Object {
    Class* klass=nullptr;Object* go=nullptr;Object* component=nullptr;Object* camera=nullptr;
    bool alive=true,disposed=false;int32_t aa=2;uint8_t dynamic=1,persistent=1,passthrough=1,cachePersistent=0;
    Object* custom=nullptr;Object* projection=nullptr;
    alignas(16) std::array<uint8_t,16> bytes{};
};
struct Method {std::string klass,name;};
struct Fake {
    inline static Fake* current=nullptr;
    BE_HostApiV1 api{};
    std::map<std::string,Class> classes;
    std::map<std::string,Type> types;
    std::map<std::string,Field> fields;
    std::deque<Method> methods;
    std::vector<std::unique_ptr<Object>> objects;
    std::map<uint32_t,Object*> roots;
    std::map<Object*,Object*> histories;
    std::map<void*,void*> hooks;
    Object *main=nullptr,*source=nullptr,*builtinDelegate=nullptr,*mainHistory=nullptr;
    Object *drawOverride=nullptr,*drawResult=nullptr,*failRootObject=nullptr;
    bool rebuildNative=false,ignoreCacheWrite=false,wrongOutHG=false,wrongOutAdditional=false;
    uint8_t nativePrepareResult=1;
    vrvd::HgProjectionMatrix renderedScene{},renderedAux{};
    vrvd::HgCameraAdapter* repeatBeginAdapter=nullptr;
    bool repeatBeginRejected=false;
    std::array<Object*,2> cameras{},gos{};
    int32_t none=7; // Deliberately nonzero: the implementation must read "None".
    uint32_t nextRoot=1;
    int writes=0,objectWrites=0,legacyReferenceWrites=0,projectionWrites=0,copies=0,resets=0,exportCalls=0;
    bool absent=false,noNone=false,ignoreAAWrite=false,failCopy=false,failReset=false;
    bool aliasSource=false,sharedHistory=false;
    std::string missingExport,corruptFieldRead;
    bool corruptOnlyAfterReset=false;

    Class* cls(const char* name){return &classes.at(name);}
    Object* object(Class* klass){auto p=std::make_unique<Object>();p->klass=klass;auto* result=p.get();objects.push_back(std::move(p));return result;}
    template<class T> Object* box(Class* klass,T value){auto* result=object(klass);std::memcpy(result->bytes.data(),&value,sizeof(value));return result;}
    static Fake& from(void* p){return *static_cast<Fake*>(p);}
    static bool equal(Object* a,Object* b){if(a&&!a->alive)a=nullptr;if(b&&!b->alive)b=nullptr;return a==b;}
    static vrvd::HgProjectionMatrix* sceneOriginal(vrvd::HgProjectionMatrix* out,void*,void*,const void*){
        *out={};out->values[0]=11;out->values[5]=12;out->values[10]=13;out->values[15]=1;return out;
    }
    static vrvd::HgProjectionMatrix* nonObliqueOriginal(vrvd::HgProjectionMatrix* out,void*,void*,const void*){
        *out={};out->values[0]=21;out->values[5]=22;out->values[10]=23;out->values[15]=1;return out;
    }
    static void* getOriginal(void* camera,int32_t multipass,const void*) {
        auto& s=*current;require(multipass==0,"Wrong native HG multipass");
        auto* cam=static_cast<Object*>(camera);
        if(s.drawOverride)return s.drawOverride;
        if(s.rebuildNative||!s.histories.count(cam)){
            auto* hg=s.object(s.cls("HGCamera"));hg->camera=cam;s.histories[cam]=hg;
        }
        return s.histories.at(cam);
    }
    static uint8_t prepareOriginal(void*,void* camera,void** additional,void** hg,void*,const void*) {
        auto& s=*current;auto* cam=static_cast<Object*>(camera);
        auto get=reinterpret_cast<vrvd::HgGetOrCreateNative>(s.hooks.at(reinterpret_cast<void*>(getOriginal)));
        s.drawResult=static_cast<Object*>(get(camera,0,nullptr));
        if(s.repeatBeginAdapter){
            const auto rootCount=s.roots.size();std::string error;const float unusedMatrix[16]{};
            const unsigned eye=cam==s.cameras[1]?1:0;
            const bool began=s.repeatBeginAdapter->begin_projection(eye,unusedMatrix,error);
            const bool prepared=s.prepare(*s.repeatBeginAdapter,eye,error);
            s.repeatBeginRejected=!began&&!prepared&&s.roots.size()==rootCount&&s.repeatBeginAdapter->projection_diagnostics().scope_active;
        }
        *hg=s.drawResult;*additional=cam->go->component;
        auto scene=reinterpret_cast<vrvd::HgProjectionNative>(s.hooks.at(reinterpret_cast<void*>(sceneOriginal)));
        auto aux=reinterpret_cast<vrvd::HgProjectionNative>(s.hooks.at(reinterpret_cast<void*>(nonObliqueOriginal)));
        scene(&s.renderedScene,*hg,camera,nullptr);aux(&s.renderedAux,*additional,camera,nullptr);
        if(s.wrongOutHG)*hg=s.mainHistory;
        if(s.wrongOutAdditional)*additional=s.source;
        return s.nativePrepareResult;
    }
    void cleanUnused() {
        for(auto it=histories.begin();it!=histories.end();) {
            auto* cam=it->first;auto* hg=it->second;
            if(!cam->alive||(!hg->cachePersistent&&!cam->go->component->persistent)) {
                hg->disposed=true;it=histories.erase(it);
            } else ++it;
        }
    }
    bool render(unsigned index) {
        cleanUnused();void* additional=nullptr;void* hg=nullptr;
        auto fn=reinterpret_cast<vrvd::HgFrameParametersNative>(hooks.at(reinterpret_cast<void*>(prepareOriginal)));
        return fn(this,cameras[index],&additional,&hg,nullptr,nullptr)==1;
    }
    Fake(){
        current=this;
        for(const char* name: {"HGAdditionalCameraData","HGCamera","Camera","Boolean","MulticastDelegate","AntialiasingMode","ProjectionDelegate","Action","GameObject"})classes.emplace(name,Class{name});
        cls("AntialiasingMode")->enumeration=true;cls("AntialiasingMode")->declaring=cls("HGAdditionalCameraData");
        cls("ProjectionDelegate")->parent=cls("MulticastDelegate");cls("Action")->parent=cls("MulticastDelegate");
        types["aa"]={17,cls("AntialiasingMode")};types["bool"]={2,cls("Boolean")};types["i4"]={8,nullptr};
        types["custom"]={21,cls("Action")};types["projection"]={18,cls("ProjectionDelegate")};types["camera"]={18,cls("Camera")};
        for(const auto& pair:std::vector<std::pair<std::string,std::string>>{{"antialiasing","aa"},{"allowDynamicResolution","bool"},{"hasPersistentHistory","bool"},{"fullscreenPassthrough","bool"},{"customRender","custom"},{"nonObliqueProjectionGetter","projection"}})
            fields[pair.first]={pair.first,cls("HGAdditionalCameraData"),&types[pair.second],6};
        fields["None"]={"None",cls("AntialiasingMode"),&types["aa"],0x56};
        fields["camera"]={"camera",cls("HGCamera"),&types["camera"],6};
        fields["isPersistent"]={"isPersistent",cls("HGCamera"),&types["bool"],3};
        builtinDelegate=object(cls("ProjectionDelegate"));
        auto* mainGo=object(cls("GameObject"));main=object(cls("Camera"));main->go=mainGo;
        mainHistory=object(cls("HGCamera"));mainHistory->camera=main;
        source=object(cls("HGAdditionalCameraData"));source->go=mainGo;source->projection=builtinDelegate;mainGo->component=source;
        for(unsigned i=0;i<2;++i){gos[i]=object(cls("GameObject"));cameras[i]=object(cls("Camera"));cameras[i]->go=gos[i];}
        api.abi_version=1;api.context=this;
        api.resolve_class=[](void* c,const char* assembly,const char* ns,const char* name,BE_ResolvedClassV1* out){
            auto& s=from(c);if(s.absent&&std::string(name)=="HGAdditionalCameraData")return BE_Result_NotFound;
            require(s.classes.count(name)!=0,"Unexpected class lookup");
            if(std::string(name)=="HGAdditionalCameraData"||std::string(name)=="HGCamera")require(std::string(assembly)=="HG.RenderPipelines.Runtime.dll"&&std::string(ns)=="HG.Rendering.Runtime","Wrong HG assembly/namespace");
            out->class_info=s.cls(name);out->type_object=s.cls(name);return BE_Result_Ok;
        };
        api.resolve_method=[](void* c,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* out){
            auto& s=from(c);std::string n=d->method_name;
            if(n=="TryCalculateFrameParameters"){
                require(d->parameter_count==4&&std::string(d->parameter_types)=="UnityEngine.Camera|HG.Rendering.Runtime.HGAdditionalCameraData&|HG.Rendering.Runtime.HGCamera&|UnityEngine.Rendering.ScriptableCullingParameters&"&&std::string(d->return_type)=="System.Boolean","Wrong Prepare signature");
                out->method_pointer=reinterpret_cast<void*>(prepareOriginal);
            }
            if(n=="GetOrCreate")out->method_pointer=reinterpret_cast<void*>(getOriginal);
            if(n=="GetOrCreate")require(d->parameter_count==2&&std::string(d->parameter_types)=="UnityEngine.Camera|System.Int32"&&std::string(d->return_type)=="HG.Rendering.Runtime.HGCamera","GetOrCreate signature changed");
            if(n=="CopyTo")require(d->parameter_count==1&&std::string(d->parameter_types)=="HG.Rendering.Runtime.HGAdditionalCameraData","CopyTo signature changed");
            if(n=="Reset")require(d->parameter_count==0&&std::string(d->class_name)=="HGCamera","Wrong reset API");
            if(n=="BuildSceneRTAspectProjection"||n=="GetNonObliqueProjection"){
                require(std::string(d->assembly_name)=="HG.RenderPipelines.Runtime.dll"&&std::string(d->namespace_name)=="HG.Rendering.Runtime","Wrong projection hook assembly/namespace");
                require(d->parameter_count==1&&std::string(d->parameter_types)=="UnityEngine.Camera"&&std::string(d->return_type)=="UnityEngine.Matrix4x4","Wrong projection hook signature");
                require(std::string(d->class_name)==(n=="BuildSceneRTAspectProjection"?"HGCamera":"HGAdditionalCameraData"),"Wrong projection hook class");
                out->method_pointer=n=="BuildSceneRTAspectProjection"?reinterpret_cast<void*>(sceneOriginal):reinterpret_cast<void*>(nonObliqueOriginal);
            }
            s.methods.push_back({d->class_name,d->method_name});out->method_info=&s.methods.back();return BE_Result_Ok;
        };
        api.create_hook=[](void* c,const char* owner,void* target,void* detour,void** next){auto& s=from(c);
            require(std::string(owner)=="quest3.vrvd"&&target&&detour&&next,"Invalid HG projection hook registration");
            require(target==reinterpret_cast<void*>(sceneOriginal)||target==reinterpret_cast<void*>(nonObliqueOriginal)||target==reinterpret_cast<void*>(getOriginal)||target==reinterpret_cast<void*>(prepareOriginal),"Unexpected native projection target");
            s.hooks[target]=detour;*next=target;return BE_Result_Ok;
        };
        api.release_module_hooks=[](void* c,const char* owner){require(std::string(owner)=="quest3.vrvd","Wrong hook owner released");from(c).hooks.clear();return BE_Result_Ok;};
        api.runtime_invoke=[](void* c,const void* m,void* instance,void** args,void** exception)->void*{return from(c).invoke(*static_cast<const Method*>(m),static_cast<Object*>(instance),args,exception);};
        api.object_unbox=[](void*,void* p)->void*{return static_cast<Object*>(p)->bytes.data();};
        api.gchandle_new=[](void* c,void* object,int pinned)->uint32_t{auto& s=from(c);require(!pinned&&object,"Bad root");if(object==s.failRootObject)return 0;auto key=s.nextRoot++;s.roots[key]=static_cast<Object*>(object);return key;};
        api.gchandle_free=[](void* c,uint32_t key){require(from(c).roots.erase(key)==1,"Double/missing root release");};
        api.field_get_value_object=[](void* c,const void* f,void* instance)->void*{return from(c).read(*static_cast<const Field*>(f),static_cast<Object*>(instance));};
    }
    void* read(const Field& f,Object* object){
        if(f.name=="None"){require(!object,"Enum constant must be static");return box(cls("AntialiasingMode"),none);}
        require(object,"Null instance field read");
        if(object!=source&&f.name==corruptFieldRead&&(!corruptOnlyAfterReset||resets>0)) {
            if(f.name=="antialiasing")return box(cls("AntialiasingMode"),none+1);
            if(f.name=="allowDynamicResolution"||f.name=="hasPersistentHistory"||f.name=="fullscreenPassthrough")return box(cls("Boolean"),uint8_t(1));
            if(f.name=="customRender")return builtinDelegate;
            if(f.name=="nonObliqueProjectionGetter")return nullptr;
            if(f.name=="isPersistent")return box(cls("Boolean"),uint8_t(0));
        }
        if(f.name=="antialiasing")return box(cls("AntialiasingMode"),object->aa);
        if(f.name=="allowDynamicResolution")return box(cls("Boolean"),object->dynamic);
        if(f.name=="hasPersistentHistory")return box(cls("Boolean"),object->persistent);
        if(f.name=="fullscreenPassthrough")return box(cls("Boolean"),object->passthrough);
        if(f.name=="customRender")return object->custom;
        if(f.name=="nonObliqueProjectionGetter")return object->projection;
        if(f.name=="camera")return object->camera;
        if(f.name=="isPersistent")return box(cls("Boolean"),object->cachePersistent);
        throw std::runtime_error("Unexpected field read");
    }
    void* invoke(const Method& m,Object* instance,void** args,void** exception){
        *exception=nullptr;
        if(m.name=="op_Equality")return box(cls("Boolean"),uint8_t(equal(static_cast<Object*>(args[0]),static_cast<Object*>(args[1]))));
        if(m.name=="get_gameObject")return instance->go;
        if(m.name=="GetComponent")return aliasSource&&instance!=main?source:instance->go->component;
        if(m.name=="AddComponent"){require(instance!=main->go,"Added component to main camera");auto* result=object(cls("HGAdditionalCameraData"));result->go=instance;instance->component=result;return result;}
        if(m.name=="CopyTo"){
            require(instance==source,"CopyTo source must be original read-only data");auto* dst=static_cast<Object*>(args[0]);require(dst!=source,"CopyTo targeted source");++copies;
            if(failCopy){*exception=this;return nullptr;}
            dst->aa=source->aa;dst->dynamic=source->dynamic;dst->persistent=source->persistent;dst->passthrough=source->passthrough;dst->custom=source->custom;dst->projection=source->projection;return nullptr;
        }
        if(m.name=="GetOrCreate"){
            require(!instance&&*static_cast<int32_t*>(args[1])==0,"Wrong GetOrCreate instance/multipass id");auto* camera=static_cast<Object*>(args[0]);require(camera!=main,"Created main camera history");
            if(sharedHistory&&!histories.empty())return histories.begin()->second;
            if(!histories.count(camera)){auto* hg=object(cls("HGCamera"));hg->camera=camera;histories[camera]=hg;}return histories[camera];
        }
        if(m.name=="Reset"){
            require(instance&&instance->camera!=main,"Reset original camera history");++resets;
            if(failReset){*exception=this;return nullptr;}
            // A managed Reset may alter settings. The adapter must re-verify.
            instance->cachePersistent=0;
            auto* data=instance->camera->go->component;data->aa=99;data->dynamic=1;data->persistent=1;data->passthrough=1;return nullptr;
        }
        throw std::runtime_error("Unexpected managed call: "+m.name);
    }
    Object* privateFieldTarget(void* object){
        auto* o=static_cast<Object*>(object);
        require(o!=source&&o->klass==cls("HGAdditionalCameraData")&&(o->go==gos[0]||o->go==gos[1]),"A field write escaped private eye ownership");
        return o;
    }
    bool knownObject(void* value) const {
        for(const auto& object:objects)if(object.get()==value)return true;
        return false;
    }
    static void* resolveExport(const char* name){
        auto& s=*current;++s.exportCalls;if(s.missingExport==name)return nullptr;
#define EXPORT(n, expression) if(std::strcmp(name,n)==0)return reinterpret_cast<void*>(+expression)
        EXPORT("il2cpp_class_get_field_from_name",[](const void* klass,const char* name)->const void*{auto& s=*current;auto i=s.fields.find(name);if(i==s.fields.end()||i->second.parent!=klass||(s.noNone&&std::string(name)=="None"))return nullptr;return &i->second;});
        EXPORT("il2cpp_field_get_type",[](const void* field)->const void*{return static_cast<const Field*>(field)->type;});
        EXPORT("il2cpp_field_get_parent",[](const void* field)->const void*{return static_cast<const Field*>(field)->parent;});
        EXPORT("il2cpp_field_get_flags",[](const void* field)->uint32_t{return static_cast<const Field*>(field)->flags;});
        EXPORT("il2cpp_type_get_type",[](const void* type)->int{return static_cast<const Type*>(type)->kind;});
        EXPORT("il2cpp_type_is_byref",[](const void* type)->bool{return static_cast<const Type*>(type)->byref;});
        EXPORT("il2cpp_class_from_type",[](const void* type)->const void*{return static_cast<const Type*>(type)->klass;});
        EXPORT("il2cpp_class_is_enum",[](const void* klass)->bool{return static_cast<const Class*>(klass)->enumeration;});
        EXPORT("il2cpp_class_enum_basetype",[](const void*)->const void*{return &current->types.at("i4");});
        EXPORT("il2cpp_class_get_declaring_type",[](const void* klass)->const void*{return static_cast<const Class*>(klass)->declaring;});
        EXPORT("il2cpp_class_get_name",[](const void* klass)->const char*{return static_cast<const Class*>(klass)->name.c_str();});
        EXPORT("il2cpp_class_is_subclass_of",[](const void* klass,const void* parent,bool)->bool{return static_cast<const Class*>(klass)->parent==parent;});
        EXPORT("il2cpp_object_get_class",[](void* object)->const void*{return static_cast<Object*>(object)->klass;});
        EXPORT("il2cpp_field_set_value",[](void* object,const void* field,void* value){auto& s=*current;const auto& f=*static_cast<const Field*>(field);++s.writes;
            if(f.name=="isPersistent"){
                auto* hg=static_cast<Object*>(object);
                require(hg->klass==s.cls("HGCamera")&&hg->camera!=s.main&&(hg->camera==s.cameras[0]||hg->camera==s.cameras[1]),"HG retention write escaped private history ownership");
                if(!s.ignoreCacheWrite)hg->cachePersistent=*static_cast<uint8_t*>(value);return;
            }
            auto* o=s.privateFieldTarget(object);
            if(f.name=="antialiasing"){if(!s.ignoreAAWrite)o->aa=*static_cast<int32_t*>(value);}
            else if(f.name=="allowDynamicResolution")o->dynamic=*static_cast<uint8_t*>(value);
            else if(f.name=="hasPersistentHistory")o->persistent=*static_cast<uint8_t*>(value);
            else if(f.name=="fullscreenPassthrough")o->passthrough=*static_cast<uint8_t*>(value);
            // IL2CPP's generic setter dereferences scalar buffers, but stores
            // reference values directly. A pointer-to-null is NOT a null object.
            else if(f.name=="customRender"){++s.legacyReferenceWrites;o->custom=static_cast<Object*>(value);}
            else if(f.name=="nonObliqueProjectionGetter"){++s.legacyReferenceWrites;++s.projectionWrites;o->projection=static_cast<Object*>(value);}
            else throw std::runtime_error("Unexpected field write");});
        EXPORT("il2cpp_field_set_value_object",[](void* object,const void* field,void* value){auto& s=*current;auto* o=s.privateFieldTarget(object);const auto& f=*static_cast<const Field*>(field);
            // Enforce the managed-object contract independently of production:
            // a stack address containing an object/null cannot masquerade as it.
            require(!value||s.knownObject(value),"Object setter received a pointer-to-pointer instead of a managed object");
            require(f.type->kind==18||f.type->kind==21,"Object setter used for an unboxed scalar");
            ++s.writes;++s.objectWrites;
            if(f.name=="customRender")o->custom=static_cast<Object*>(value);
            else if(f.name=="nonObliqueProjectionGetter"){++s.projectionWrites;o->projection=static_cast<Object*>(value);}
            else throw std::runtime_error("Unexpected object field write");});
#undef EXPORT
        throw std::runtime_error(std::string("Unexpected export: ")+name);
    }
    bool prepare(vrvd::HgCameraAdapter& adapter,unsigned eye,std::string& error){return adapter.prepare(main,cameras[eye],gos[eye],eye,error);}
    void finish(vrvd::HgCameraAdapter& adapter){for(auto* go:gos){go->alive=false;if(go->component)go->component->alive=false;}for(auto* camera:cameras)camera->alive=false;adapter.cleanup();cleanUnused();require(histories.empty(),"Destroyed private camera cache retained despite persistent flag");require(mainHistory->cachePersistent==0,"Main HG history was changed");api.release_module_hooks(api.context,"quest3.vrvd");require(!adapter.resources_alive()&&roots.empty(),"Adapter cleanup leaked roots");require(source->aa==2&&source->dynamic==1&&source->persistent==1&&source->passthrough==1&&source->projection==builtinDelegate,"Source camera data was modified");}
};
void happy(){
    Fake s;vrvd::HgCameraAdapter adapter;std::string e;
    require(adapter.resolve(&s.api,e,Fake::resolveExport),e.c_str());require(adapter.available()&&!adapter.active(),"Wrong initial HG state");
    require(s.prepare(adapter,0,e)&&s.prepare(adapter,1,e),e.c_str());require(adapter.active()&&s.roots.size()==8&&s.resets==2,"Private histories/roots not independent");
    require(adapter.source_fullscreen_passthrough()==1&&s.source->passthrough==1,"Source passthrough must be observed and preserved");
    require(s.objectWrites==4&&s.legacyReferenceWrites==0&&s.projectionWrites==0,"Custom renderer must use object setter; original projection delegate must remain intact");
    for(auto* go:s.gos){auto* data=go->component;require(data&&data->aa==7&&!data->dynamic&&!data->persistent&&!data->passthrough&&!data->custom&&data->projection==s.builtinDelegate,"Private HG settings or preserved projection delegate not verified");}
    require(s.prepare(adapter,0,e)&&s.resets==2,"Existing private history reset every frame");
    s.histories.erase(s.cameras[0]);require(s.prepare(adapter,0,e)&&s.resets==3&&s.roots.size()==8,"Recreated HG cache not handled safely");
    require(!adapter.resolve(&s.api,e,Fake::resolveExport),"Allowed rebind with live roots");s.finish(adapter);
}
void absent(){Fake s;s.absent=true;s.api.field_get_value_object=nullptr;vrvd::HgCameraAdapter a;std::string e;require(a.resolve(&s.api,e,Fake::resolveExport)&&!a.available(),"Absent HG was not a no-op");require(a.prepare(nullptr,nullptr,nullptr,0,e)&&s.exportCalls==0&&s.writes==0,"Absent HG touched IL2CPP exports");s.finish(a);}
void contracts(){
    for(int test=0;test<12;++test){Fake s;vrvd::HgCameraAdapter a;std::string e;
        if(test==0)s.noNone=true;
        if(test==1)s.types["aa"].kind=2;
        if(test==2)s.types["bool"].byref=true;
        if(test==3)s.fields["hasPersistentHistory"].flags|=0x10;
        if(test==4)s.cls("Action")->parent=nullptr;
        if(test==5)s.types["i4"].kind=10;
        if(test==6)s.missingExport="il2cpp_field_set_value";
        if(test==7)s.missingExport="il2cpp_field_set_value_object";
        if(test==8)s.fields["fullscreenPassthrough"].type=&s.types["i4"];
        if(test==9)s.fields["isPersistent"].type=&s.types["i4"];
        if(test==10)s.fields["isPersistent"].flags|=0x20;
        if(test==11)s.fields["isPersistent"].parent=s.cls("HGAdditionalCameraData");
        require(!a.resolve(&s.api,e,Fake::resolveExport)&&!e.empty()&&s.writes==0,"Invalid field/export contract accepted");s.finish(a);
    }
}
void ownership(){
    for(int test=0;test<5;++test){Fake s;vrvd::HgCameraAdapter a;std::string e;require(a.resolve(&s.api,e,Fake::resolveExport),e.c_str());bool ok=false;
        if(test==0)ok=a.prepare(s.main,s.main,s.main->go,0,e);
        if(test==1)ok=a.prepare(s.main,s.cameras[0],s.gos[1],0,e);
        if(test==2){s.source->custom=s.builtinDelegate;ok=s.prepare(a,0,e);}
        if(test==3){s.aliasSource=true;ok=s.prepare(a,0,e);}
        if(test==4){s.main->go->component=nullptr;ok=s.prepare(a,0,e);}
        require(!ok&&!e.empty()&&s.writes==0,"Ownership/custom-render guard did not fail before field writes");s.finish(a);
    }
}
void failures(){
    for(int test=0;test<3;++test){Fake s;vrvd::HgCameraAdapter a;std::string e;require(a.resolve(&s.api,e,Fake::resolveExport),e.c_str());
        if(test==0)s.failCopy=true;if(test==1)s.ignoreAAWrite=true;if(test==2)s.failReset=true;
        require(!s.prepare(a,0,e)&&!a.active(),"Managed/write verification failure was ignored");
        s.failCopy=s.ignoreAAWrite=s.failReset=false;require(s.prepare(a,0,e),e.c_str());s.finish(a);
    }
    Fake s;vrvd::HgCameraAdapter a;std::string e;require(a.resolve(&s.api,e,Fake::resolveExport)&&s.prepare(a,0,e),e.c_str());
    s.sharedHistory=true;require(!s.prepare(a,1,e),"Shared HG history object accepted");s.finish(a);
}
void reference_setter_contract(){
    Fake s;
    using Setter=void(*)(void*,const void*,void*);
    const auto generic=reinterpret_cast<Setter>(Fake::resolveExport("il2cpp_field_set_value"));
    const auto objects=reinterpret_cast<Setter>(Fake::resolveExport("il2cpp_field_set_value_object"));
    auto* target=s.object(s.cls("HGAdditionalCameraData"));target->go=s.gos[0];
    for(const char* name:{"customRender","nonObliqueProjectionGetter"}){
        const auto& field=s.fields.at(name);void* nullObject=nullptr;
        generic(target,&field,&nullObject); // The 0.3.3 call pattern.
        require(s.read(field,target)==&nullObject,"Legacy pointer-to-null no longer reproduces the non-null readback defect");
        bool rejected=false;
        try{objects(target,&field,&nullObject);}catch(const std::runtime_error&){rejected=true;}
        require(rejected,"Object setter fixture accepted a stack address as a managed reference");
        objects(target,&field,s.builtinDelegate);
        require(s.read(field,target)==s.builtinDelegate,"Object setter did not preserve direct object identity");
        objects(target,&field,nullptr);
        require(s.read(field,target)==nullptr,"Object setter did not clear the reference with a literal null");
    }
}
void detailed_field_failures(){
    for(bool afterReset:{false,true})for(const char* field:{"antialiasing","allowDynamicResolution","hasPersistentHistory","fullscreenPassthrough","customRender","nonObliqueProjectionGetter"}){
        Fake s;vrvd::HgCameraAdapter a;std::string e;
        require(a.resolve(&s.api,e,Fake::resolveExport),e.c_str());
        s.corruptFieldRead=field;s.corruptOnlyAfterReset=afterReset;
        require(!s.prepare(a,0,e)&&!a.active(),"A field readback mismatch was ignored");
        require(e.find("Eye 0:")!=std::string::npos&&e.find(field)!=std::string::npos,"Readback failure omitted eye or field identity");
        require(e.find("expected=")!=std::string::npos&&e.find("actual=")!=std::string::npos,"Readback failure omitted expected/actual values");
        require(e.find(afterReset?"after HGCamera.Reset":"after CopyTo")!=std::string::npos,"Readback failure omitted the phase");
        require(s.resets==(afterReset?1:0),"Failure did not stop at its observed phase");
        s.corruptFieldRead.clear();require(s.prepare(a,0,e),e.c_str());s.finish(a);
    }
}
constexpr float testProjection[16]{1.2f,0,0,0,0,1.3f,0,0,0.12f,-0.08f,-1.001f,-1,0,0,-0.1f,0};
void projection_scope_integration(){
    Fake s;vrvd::HgCameraAdapter a;std::string e;
    require(a.resolve(&s.api,e,Fake::resolveExport),e.c_str());
    require(!a.begin_projection(0,testProjection,e),"Projection armed without a prepared eye");
    require(s.prepare(a,0,e)&&s.prepare(a,1,e),e.c_str());
    require(s.hooks.size()==4,"Dynamic draw binding needs all four hooks");
    auto* predicted=s.histories.at(s.cameras[0]);
    require(predicted->cachePersistent==1&&!s.gos[0]->component->persistent,"HG cache keepalive must not enable additional temporal history");
    s.rebuildNative=true;
    s.repeatBeginAdapter=&a;
    require(a.begin_projection(0,testProjection,e),e.c_str());
    const auto rootsBefore=s.roots.size();
    require(!a.begin_projection(1,testProjection,e)&&s.roots.size()==rootsBefore&&a.projection_diagnostics().scope_active,"Nested begin cleared a live render scope or roots");
    require(s.render(0)&&a.end_projection(0,e),e.c_str());
    require(s.repeatBeginRejected,"Reentrant begin/prepare released a live draw root or changed its scope");
    require(s.drawResult!=predicted&&s.drawResult->cachePersistent==1,"Replacement draw HG was not validated and kept alive");
    require(s.roots.size()==9,"Actual draw HG has no independent retained root");
    require(std::memcmp(s.renderedScene.values,testProjection,sizeof(testProjection))==0&&std::memcmp(s.renderedAux.values,testProjection,sizeof(testProjection))==0,"Actual draw did not receive the eye projection");
    const auto routing=a.projection_diagnostics();
    require(routing.frame_draw_bindings[0]>0&&routing.frame_draw_binding_changed[0]>0&&routing.frame_build_hits[0]>0,"Replacement binding was not reported");
    auto scene=reinterpret_cast<vrvd::HgProjectionNative>(s.hooks.at(reinterpret_cast<void*>(Fake::sceneOriginal)));
    vrvd::HgProjectionMatrix outside{};scene(&outside,s.drawResult,s.cameras[0],nullptr);
    require(outside.values[0]==11,"Projection remained overridden outside its draw scope");
    require(s.projectionWrites==0&&s.gos[0]->component->projection==s.builtinDelegate,"Draw binding rewrote the original delegate");
    s.rebuildNative=false;
    require(a.begin_projection(0,testProjection,e)&&s.roots.size()==8,"Next begin failed to release the previous draw root");
    require(s.render(0)&&a.end_projection(0,e)&&s.roots.size()==9,e.c_str());
    require(a.begin_projection(1,testProjection,e),e.c_str());
    require(!a.end_projection(1,e),"An eye with no observed HG preparation was accepted");
    s.finish(a);
}
void cache_retention_and_readback(){
    {
        Fake s;vrvd::HgCameraAdapter a;std::string e;require(a.resolve(&s.api,e,Fake::resolveExport)&&s.prepare(a,0,e)&&s.prepare(a,1,e),e.c_str());
        auto* left=s.histories.at(s.cameras[0]);auto* right=s.histories.at(s.cameras[1]);
        s.cleanUnused();require(s.histories.size()==2&&!left->disposed&&!right->disposed,"Manual private HG caches were disposed before Render");
        require(left->cachePersistent==1&&right->cachePersistent==1&&s.mainHistory->cachePersistent==0,"Cache retention escaped private eyes");
        require(!s.gos[0]->component->persistent&&!s.gos[1]->component->persistent,"Retaining cache accidentally enabled persistent temporal history");
        left->cachePersistent=0;require(s.prepare(a,0,e)&&left->cachePersistent==1,"Existing private cache keepalive was not reverified");
        require(a.begin_projection(0,testProjection,e)&&s.render(0)&&a.end_projection(0,e),e.c_str());
        require(a.begin_projection(1,testProjection,e)&&s.render(1)&&a.end_projection(1,e),e.c_str());
        require(!left->disposed&&!right->disposed&&s.histories.size()==2,"Second eye Render disposed the first eye HG cache");
        s.finish(a);require(left->disposed&&right->disposed,"Destroying private cameras failed to make persistent HG caches collectible");
    }
    for(int mode=0;mode<3;++mode){
        Fake s;vrvd::HgCameraAdapter a;std::string e;require(a.resolve(&s.api,e,Fake::resolveExport),e.c_str());
        if(mode==0)s.ignoreCacheWrite=true;
        if(mode==1)s.corruptFieldRead="isPersistent";
        if(mode<2){require(!s.prepare(a,0,e)&&e.find("isPersistent")!=std::string::npos,"Private cache readback failure was ignored");}
        else {
            require(s.prepare(a,0,e)&&a.begin_projection(0,testProjection,e),e.c_str());
            s.corruptFieldRead="isPersistent";s.render(0);
            require(!a.end_projection(0,e)&&e.find("isPersistent")!=std::string::npos,"Actual draw cache readback failure was ignored");
        }
        s.finish(a);
    }
}
void draw_binding_failures(){
    for(int mode=0;mode<7;++mode){
        Fake s;vrvd::HgCameraAdapter a;std::string e;
        require(a.resolve(&s.api,e,Fake::resolveExport)&&s.prepare(a,0,e)&&s.prepare(a,1,e),e.c_str());
        if(mode==0)s.drawOverride=s.source; // Wrong managed class.
        if(mode==1){s.drawOverride=s.object(s.cls("HGCamera"));s.drawOverride->camera=s.main;}
        if(mode==2){s.drawOverride=s.histories.at(s.cameras[1]);s.drawOverride->camera=s.cameras[0];}
        if(mode==3)s.failRootObject=s.histories.at(s.cameras[0]);
        if(mode==4)s.nativePrepareResult=0;
        if(mode==5)s.wrongOutHG=true;
        if(mode==6)s.wrongOutAdditional=true;
        const auto before=s.roots.size();
        require(a.begin_projection(0,testProjection,e),e.c_str());s.render(0);
        require(!a.end_projection(0,e)&&!e.empty(),"Invalid actual HG binding/preparation was submitted");
        if(mode<4)require(s.roots.size()==before,"Rejected HG identity/root failure retained an extra draw root");
        if(mode==0||mode==1)require(s.drawOverride->cachePersistent==0,"Invalid HG class/camera was mutated");
        s.finish(a);
    }
}

}
int main(){try{reference_setter_contract();happy();absent();contracts();ownership();failures();detailed_field_failures();projection_scope_integration();cache_retention_and_readback();draw_binding_failures();std::cout<<"PASS HG adapter: direct-object versus scalar-buffer ABI, legacy non-null regression, six field diagnostics at both phases, private fullscreen passthrough disabled after copy/reset, preserved delegate, live draw HG replacement/roots, private cache keepalive and teardown, scoped HG projection and private ownership/history (no game/GPU)\n";return 0;}catch(const std::exception& e){std::cerr<<"FAIL HG adapter: "<<e.what()<<'\n';return 1;}}
