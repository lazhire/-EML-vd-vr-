#include "../src/hg_ui_camera.h"
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>

namespace {
int checks=0;
void require(bool value,const char* message){++checks;if(!value)throw std::runtime_error(message);}
struct Class;
struct Type {int kind=0;Class* klass=nullptr;bool byref=false;};
struct Field {Class* parent=nullptr;Type type{};uint32_t flags=0;std::string name;int32_t literal=0;};
struct Class {std::string name;bool isEnum=false;Type base{8};std::map<std::string,Field> fields;};
struct Object {Class* klass=nullptr;Object* go=nullptr;Object* component=nullptr;std::map<std::string,std::array<uint8_t,16>> values;};
struct Box {Class* klass=nullptr;alignas(16) std::array<uint8_t,16> data{};};
struct Fake {
    BE_HostApiV1 api{};
    Class additional{"HGAdditionalCameraData"},boolean{"Boolean"},color{"Color"},camera{"Camera"},gameObject{"GameObject"};
    Class renderPath{"HGRenderPath",true},clearMode{"ClearColorMode",true},aa{"AntialiasingMode",true};
    Object privateGO{&gameObject},privateCamera{&camera,&privateGO},privateData{&additional,&privateGO};
    Object sourceGO{&gameObject},sourceCamera{&camera,&sourceGO},sourceData{&additional,&sourceGO};
    Box boxed;
    std::map<std::string,std::string> methods;
    std::map<uint32_t,void*> roots;
    uint32_t nextRoot=1;int writes=0;
    bool allowOriginal=false;std::string blockedField;
    bool absent=false,wrongOwner=false,silentWrite=false,failRoot=false;
    static Fake* current;
    Fake(){
        current=this;api.context=this;
        auto field=[&](const char* name,int kind,Class& klass){additional.fields.emplace(name,Field{&additional,{kind,&klass},0,name});};
        field("hgRenderPath",17,renderPath);field("clearColorMode",17,clearMode);field("antialiasing",17,aa);field("backgroundColorHDR",17,color);
        for(auto name:{"enableAlpha","clearDepth","allowDynamicResolution","hasPersistentHistory","fullscreenPassthrough"})field(name,2,boolean);
        // Deliberately different from runtime's current numeric constants:
        // production must obtain named values, never hard-code enum ordinals.
        renderPath.fields.emplace("UI",Field{&renderPath,{17,&renderPath},0x50,"UI",7});
        clearMode.fields.emplace("Color",Field{&clearMode,{17,&clearMode},0x50,"Color",5});
        aa.fields.emplace("None",Field{&aa,{17,&aa},0x50,"None",3});
        sourceCamera.component=&sourceData;
        api.resolve_class=[](void* p,const char*,const char*,const char* name,BE_ResolvedClassV1* out){auto& s=*static_cast<Fake*>(p);Class* klass=nullptr;
            for(auto* c:{&s.additional,&s.boolean,&s.color,&s.camera})if(c->name==name)klass=c;
            if(!klass||(s.absent&&klass==&s.additional))return BE_Result_NotFound;
            out->class_info=klass;out->type_object=klass;return BE_Result_Ok;};
        api.resolve_method=[](void* p,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* out){auto& s=*static_cast<Fake*>(p);
            auto& m=s.methods[d->method_name];m=d->method_name;out->method_info=&m;return BE_Result_Ok;};
        api.runtime_invoke=[](void* p,const void* method,void* obj,void** args,void** exception)->void*{auto& s=*static_cast<Fake*>(p);*exception=nullptr;
            const auto& name=*static_cast<const std::string*>(method);auto* object=static_cast<Object*>(obj);
            if(name=="get_gameObject")return s.wrongOwner&&object==&s.privateData?&s.sourceGO:object->go;
            if(name=="GetComponent")return object->component;
            if(name=="AddComponent"){require(object==&s.privateGO,"helper added a component to source game object");s.privateCamera.component=&s.privateData;return &s.privateData;}
            if(name=="op_Equality"){s.boxed.klass=&s.boolean;s.boxed.data.fill(0);s.boxed.data[0]=args[0]==args[1];return &s.boxed;}
            throw std::runtime_error("Unexpected helper method");};
        api.object_unbox=[](void*,void* obj)->void*{return static_cast<Box*>(obj)->data.data();};
        api.field_get_value_object=[](void* p,const void* info,void* obj)->void*{auto& s=*static_cast<Fake*>(p);const auto& f=*static_cast<const Field*>(info);
            s.boxed.klass=f.type.klass;s.boxed.data.fill(0);
            if(obj)s.boxed.data=static_cast<Object*>(obj)->values[f.name];else std::memcpy(s.boxed.data.data(),&f.literal,sizeof f.literal);return &s.boxed;};
        api.gchandle_new=[](void* p,void* obj,int)->uint32_t{auto& s=*static_cast<Fake*>(p);if(s.failRoot)return 0;const auto id=s.nextRoot++;s.roots[id]=obj;return id;};
        api.gchandle_free=[](void* p,uint32_t id){static_cast<Fake*>(p)->roots.erase(id);};
    }
    static void* resolver(const char* name){
#define EXPORT(n,fn) if(std::strcmp(name,n)==0)return reinterpret_cast<void*>(+fn)
        EXPORT("il2cpp_class_get_field_from_name",([](const void* c,const char* n)->const void*{auto& fields=const_cast<Class*>(static_cast<const Class*>(c))->fields;auto found=fields.find(n);return found==fields.end()?nullptr:&found->second;}));
        EXPORT("il2cpp_field_get_type",([](const void* f)->const void*{return &static_cast<const Field*>(f)->type;}));
        EXPORT("il2cpp_field_get_parent",([](const void* f)->const void*{return static_cast<const Field*>(f)->parent;}));
        EXPORT("il2cpp_field_get_flags",([](const void* f)->uint32_t{return static_cast<const Field*>(f)->flags;}));
        EXPORT("il2cpp_type_get_type",([](const void* t)->int{return static_cast<const Type*>(t)->kind;}));
        EXPORT("il2cpp_type_is_byref",([](const void* t)->bool{return static_cast<const Type*>(t)->byref;}));
        EXPORT("il2cpp_class_from_type",([](const void* t)->const void*{return static_cast<const Type*>(t)->klass;}));
        EXPORT("il2cpp_class_is_enum",([](const void* c)->bool{return static_cast<const Class*>(c)->isEnum;}));
        EXPORT("il2cpp_class_enum_basetype",([](const void* c)->const void*{return &static_cast<const Class*>(c)->base;}));
        EXPORT("il2cpp_class_get_name",([](const void* c)->const char*{return static_cast<const Class*>(c)->name.c_str();}));
        EXPORT("il2cpp_object_get_class",([](void* o)->const void*{return *static_cast<Class**>(o);}));
        EXPORT("il2cpp_field_set_value",([](void* o,const void* info,void* value){auto& s=*current;require(o==&s.privateData||(s.allowOriginal&&o==&s.sourceData),"helper wrote source camera data without original UI scope");
            ++s.writes;const auto& f=*static_cast<const Field*>(info);if(s.blockedField==f.name)return;if(s.silentWrite&&f.name=="hgRenderPath")return;
            const size_t bytes=f.type.kind==2?1:f.type.klass==&s.color?16:4;
            std::memcpy(static_cast<Object*>(o)->values[f.name].data(),value,bytes);}));
#undef EXPORT
        return nullptr;
    }
    template<class T>T value(const char* name){T result{};std::memcpy(&result,privateData.values[name].data(),sizeof result);return result;}
};
Fake* Fake::current=nullptr;
void success(){
    Fake f;vrvd::HgUiCamera h;std::string e;
    require(h.resolve(&f.api,Fake::resolver,e),"helper resolve failed");require(h.bind(&f.privateCamera,&f.privateGO,e),"private HG UI bind failed");
    require(h.path()=="hg_ui_camera"&&h.resources_alive(),"helper did not expose owned HG route");
    require(f.value<int32_t>("hgRenderPath")==7&&f.value<int32_t>("clearColorMode")==5&&f.value<int32_t>("antialiasing")==3,"named enums were not obtained from metadata literals");
    require(f.value<uint8_t>("enableAlpha")==1&&f.value<uint8_t>("clearDepth")==1&&f.value<uint8_t>("fullscreenPassthrough")==0,"HG capture booleans wrong");
    const float black[]{0,0,0,0},white[]{1,1,1,1};
    require(h.set_background(black,e),"black HG clear failed");require(h.set_background(white,e),"white HG clear failed");
    require(f.value<std::array<float,4>>("backgroundColorHDR")==std::array<float,4>{1,1,1,1},"HG HDR background did not follow capture pass");
    require(f.sourceData.values.empty(),"source HG camera was modified");
    require(h.bind(&f.privateCamera,&f.privateGO,e)&&f.roots.size()==1,"rebind leaked component roots");
    h.release();h.release();require(!h.resources_alive()&&f.roots.empty(),"helper release leaked roots");
}
void failures(){
    for(int scenario=0;scenario<8;++scenario){Fake f;vrvd::HgUiCamera h;std::string e;
        if(scenario==0)f.additional.fields["hgRenderPath"].flags=0x10;
        if(scenario==1)f.renderPath.fields.erase("UI");
        if(scenario==2)f.renderPath.base.kind=10;
        if(scenario==3)f.additional.fields["enableAlpha"].type.klass=&f.color;
        if(scenario<4){require(!h.resolve(&f.api,Fake::resolver,e)&&!e.empty(),"unsafe HG field contract accepted");require(f.writes==0,"failed field resolve wrote data");continue;}
        require(h.resolve(&f.api,Fake::resolver,e),"valid helper resolve failed");
        if(scenario==4)f.wrongOwner=true;
        if(scenario==5)f.silentWrite=true;
        if(scenario==6)f.failRoot=true;
        if(scenario==7)f.privateCamera.klass=&f.additional;
        require(!h.bind(&f.privateCamera,&f.privateGO,e)&&!e.empty(),"invalid private binding/readback accepted");
        if(scenario!=5)require(f.writes==0,"ownership/root failure wrote HG fields");
        h.release();require(f.roots.empty(),"failed bind leaked GC root");
    }
}
void existing(){
    Fake f;f.allowOriginal=true;vrvd::HgUiCamera h;std::string e;
    int32_t path=7,clear=9;uint8_t alpha=0,pass=1;std::array<float,4> color{.2f,.3f,.4f,1.f};
    auto set=[&](const char* n,const auto& v){std::memcpy(f.sourceData.values[n].data(),&v,sizeof v);};
    set("hgRenderPath",path);set("clearColorMode",clear);set("enableAlpha",alpha);set("fullscreenPassthrough",pass);set("backgroundColorHDR",color);
    const auto original=f.sourceData.values;
    require(h.resolve(&f.api,Fake::resolver,e)&&h.begin_existing(&f.sourceCamera,e),"original UI scope begin");
    require(h.restore_pending()&&f.sourceData.values["hgRenderPath"]==original.at("hgRenderPath"),"must preserve original UI path");
    f.blockedField="enableAlpha";require(!h.restore_existing(e)&&h.restore_pending()&&!f.roots.empty(),"failed restore keeps managed ownership");
    f.blockedField.clear();require(h.restore_existing(e)&&!h.restore_pending()&&f.roots.empty(),"restoration retry");
    require(f.sourceData.values==original,"all original HG UI field values restored");
    f.blockedField="backgroundColorHDR";require(!h.begin_existing(&f.sourceCamera,e)&&h.restore_pending(),"partial begin write failure");
    f.blockedField.clear();require(h.restore_existing(e)&&f.sourceData.values==original,"partial begin rollback");
    path=99;set("hgRenderPath",path);int writes=f.writes;
    require(!h.begin_existing(&f.sourceCamera,e)&&f.writes==writes&&!h.restore_pending(),"reject non-UI render path without mutation");
}
void fallback(){Fake f;f.absent=true;vrvd::HgUiCamera h;std::string e;require(h.resolve(&f.api,nullptr,e),"HG-absent fallback failed");
    require(h.bind(nullptr,nullptr,e)&&h.set_background(nullptr,e)&&h.path()=="standard_canvas_camera","standard Canvas path unavailable without HG");
    require(f.writes==0&&!h.resources_alive(),"HG-absent helper created resources");}
}
int main(){try{success();failures();fallback();existing();std::printf("HG UI helper offline tests passed (%d checks); no game/runtime/GPU\n",checks);return 0;}
catch(const std::exception& e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}}
