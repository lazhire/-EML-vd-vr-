// Isolated public-API integration test. No Unity DLL, game, XR runtime or GPU.
// Build with src/unity_bridge.cpp and -Ivendor/eml (C++17).
#include "../src/unity_bridge.h"
#include <algorithm>
#include <array>
#include <cstring>
#include <deque>
#include <iostream>
#include <map>
#include <memory>
#include <stdexcept>

namespace {
void require(bool condition,const char* message) {
    if(!condition) throw std::runtime_error(message);
}
struct Object {
    std::string kind;
    bool alive=true,created=true;
    int eye=-1,width=0,height=0,format=4,graphicsFormat=8;
    Object* transform=nullptr;
    Object* target=nullptr;
    std::vector<uint8_t> pixels;
    std::array<float,3> position{};
    std::array<float,4> rotation{0,0,0,1};
    std::array<float,16> projection{},view{},nonJittered{},culling{};
    float fov=75,aspect=1;
};
struct Method {std::string klass,name;};
struct FakeHost {
    BE_HostApiV1 api{};
    std::deque<Method> methods;
    std::deque<std::string> classes;
    std::vector<std::unique_ptr<Object>> objects;
    std::map<uint32_t,Object*> roots;
    uint32_t nextRoot=1;
    int graphics=21,rtCount=0,cpuCount=0,readCount=0,destroyCount=0;
    bool failSecondRead=false,failRestore=false,rejectCpuBindings=false;
    int overwriteMode=0;Object* firstRendered=nullptr;int frameCount=1;
    Object *main=nullptr,*original=nullptr,*active=nullptr;
    alignas(16) std::array<unsigned char,128> boxed{};

    Object* make(const std::string& kind) {
        auto object=std::make_unique<Object>();object->kind=kind;
        auto* pointer=object.get();objects.push_back(std::move(object));return pointer;
    }
    template<class T> void* box(const T& value) {
        static_assert(sizeof(T)<=128);std::memcpy(boxed.data(),&value,sizeof(T));return boxed.data();
    }
    static bool same(Object* a,Object* b) {
        if(a&&!a->alive)a=nullptr;if(b&&!b->alive)b=nullptr;return a==b;
    }
    static FakeHost& from(void* context){return *static_cast<FakeHost*>(context);}
    FakeHost() {
        main=make("Camera");main->transform=make("Transform");
        original=make("OriginalActiveRenderTexture");active=original;
        api.abi_version=1;api.context=this;
        api.log=[](void*,const char*,const char*){};
        api.resolve_method=[](void* context,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* out) {
            auto& s=from(context);
            if(s.rejectCpuBindings&&(std::string(d->method_name)=="ReadPixels"||std::string(d->class_name)=="Marshal"))return BE_Result_NotFound;
            s.methods.push_back({d->class_name,d->method_name});out->method_info=&s.methods.back();return BE_Result_Ok;
        };
        api.resolve_field=[](void*,const BE_FieldDescriptorV1* d,BE_ResolvedFieldV1* out) {
            const std::string c=d->class_name,n=d->field_name;
            int index=-1;
            if(c=="Vector3"||c=="Quaternion") {
                const auto found=std::string("xyzw").find(n);if(found!=std::string::npos)index=int(found);
            } else if(c=="Matrix4x4"&&n.size()==3)index=(n[2]-'0')*4+n[1]-'0';
            else if(c=="Rect") {
                const std::array<std::string,4> names{"m_XMin","m_YMin","m_Width","m_Height"};
                const auto found=std::find(names.begin(),names.end(),n);if(found!=names.end())index=int(found-names.begin());
            }
            if(index<0)return BE_Result_NotFound;
            out->field_info=reinterpret_cast<void*>(uintptr_t(1));out->offset=16+index*4;return BE_Result_Ok;
        };
        api.resolve_class=[](void* context,const char*,const char*,const char* name,BE_ResolvedClassV1* out) {
            if(std::string(name)=="HGAdditionalCameraData")return BE_Result_NotFound;
            auto& s=from(context);s.classes.emplace_back(name);out->class_info=&s.classes.back();
            out->type_info=out->class_info;out->type_object=const_cast<void*>(out->class_info);return BE_Result_Ok;
        };
        api.object_new=[](void* context,const void* klass)->void* {
            auto& s=from(context);auto* o=s.make(*static_cast<const std::string*>(klass));
            if(o->kind=="RenderTexture")o->eye=s.rtCount++;
            if(o->kind=="Texture2D")o->eye=s.cpuCount++;
            return o;
        };
        api.string_new=[](void* context,const char*)->void* {return from(context).make("String");};
        api.object_unbox=[](void*,void* object)->void* {return object;};
        api.gchandle_new=[](void* context,void* object,int)->uint32_t {
            auto& s=from(context);if(!object)return 0;const auto handle=s.nextRoot++;
            s.roots[handle]=static_cast<Object*>(object);return handle;
        };
        api.gchandle_free=[](void* context,uint32_t handle){from(context).roots.erase(handle);};
        api.runtime_invoke=[](void* context,const void* method,void* object,void** args,void** exception)->void* {
            return from(context).invoke(*static_cast<const Method*>(method),static_cast<Object*>(object),args,exception);
        };
    }
    void* invoke(const Method& m,Object* object,void** args,void** exception) {
        *exception=nullptr;
        const auto& n=m.name;
        if(n=="get_graphicsDeviceType")return box<int32_t>(graphics);
        if(n=="op_Equality")return box<uint8_t>(same(static_cast<Object*>(args[0]),static_cast<Object*>(args[1]))?1:0);
        if(n=="get_main")return main;
        if(n=="get_transform")return object->transform;
        if(n=="get_position")return box(object==main->transform?std::array<float,3>{0,1,0}:object->position);
        if(n=="get_rotation")return box(object==main->transform?std::array<float,4>{0,0,0,1}:object->rotation);
        if(n=="get_nearClipPlane")return box<float>(0.05f);
        if(n=="get_farClipPlane")return box<float>(100.0f);
        if(n==".ctor") {
            if(object->kind=="RenderTexture"||object->kind=="Texture2D") {
                object->width=*static_cast<int32_t*>(args[0]);object->height=*static_cast<int32_t*>(args[1]);
                if(object->kind=="Texture2D") {
                    object->format=*static_cast<int32_t*>(args[2]);
                    require(*static_cast<uint8_t*>(args[3])==0,"CPU texture unexpectedly has mipmaps");
                    require(*static_cast<uint8_t*>(args[4])==1,"CPU texture is not linear");
                }
            }
            return nullptr;
        }
        if(n=="Create")return box<uint8_t>(1);
        if(n=="get_sRGB"||n=="get_isDataSRGB")return box<uint8_t>(0);
        if(n=="get_format")return box<int32_t>(object->format);
        if(n=="get_mipmapCount")return box<int32_t>(1);
        if(n=="get_graphicsFormat")return box<int32_t>(object->graphicsFormat);
        if(n=="set_graphicsFormat"){object->graphicsFormat=*static_cast<int32_t*>(args[0]);return nullptr;}
        if(n=="GetNativeTexturePtr")return box<intptr_t>(reinterpret_cast<intptr_t>(object));
        if(n=="AddComponent") {
            auto* camera=make("Camera");camera->transform=make("Transform");return camera;
        }
        if(n=="set_targetTexture"){object->target=static_cast<Object*>(args[0]);return nullptr;}
        if(n=="IsCreated")return box<uint8_t>(object->created?1:0);
        if(n=="get_width")return box<int32_t>(object->width);
        if(n=="get_height")return box<int32_t>(object->height);
        if(n=="get_frameCount")return box<int32_t>(frameCount);
        if(n=="get_OutputCamera")return main;
        if(n=="get_targetTexture")return object->target;
        if(n=="CopyFrom") {
            // Model destructive copying of source camera state, not a no-op.
            object->projection.fill(91);object->view.fill(92);
            object->nonJittered.fill(93);object->culling.fill(94);
            object->fov=75;object->aspect=1.777f;return nullptr;
        }
        if(n=="set_fieldOfView"){object->fov=*static_cast<float*>(args[0]);return nullptr;}
        if(n=="set_aspect"){object->aspect=*static_cast<float*>(args[0]);return nullptr;}
        if(n=="set_orthographic"||n=="set_usePhysicalProperties") {
            require(*static_cast<uint8_t*>(args[0])==0,"Eye must use non-physical perspective");return nullptr;
        }
        if(n=="set_position"){std::memcpy(object->position.data(),args[0],12);return nullptr;}
        if(n=="set_rotation"){std::memcpy(object->rotation.data(),args[0],16);return nullptr;}
        if(n=="set_projectionMatrix"){std::memcpy(object->projection.data(),args[0],64);return nullptr;}
        if(n=="set_worldToCameraMatrix"){std::memcpy(object->view.data(),args[0],64);return nullptr;}
        if(n=="set_nonJitteredProjectionMatrix"){std::memcpy(object->nonJittered.data(),args[0],64);return nullptr;}
        if(n=="set_cullingMatrix"){std::memcpy(object->culling.data(),args[0],64);return nullptr;}
        if(n=="get_projectionMatrix")return box(object->projection);
        if(n=="get_worldToCameraMatrix")return box(object->view);
        if(n=="get_nonJitteredProjectionMatrix")return box(object->nonJittered);
        if(n=="get_cullingMatrix")return box(object->culling);
        if(n=="Render") {
            auto* t=object->target;require(t&&t->eye>=0,"Camera did not render its own target");
            if(t->eye==0)firstRendered=object;
            if(overwriteMode==1)object->projection[0]*=1.4f;
            if(overwriteMode==2)object->target=original;
            if(overwriteMode==3&&t->eye==1&&firstRendered)firstRendered->view[12]+=0.5f;
            if(overwriteMode==4)object->nonJittered[5]*=1.5f;
            if(overwriteMode==5)object->transform->position[0]+=0.5f;
            // Deliberately distinct eye/row/channel pattern, in Unity bottom-up order.
            const int b=t->eye*100;
            t->pixels={uint8_t(b+1),11,21,255,uint8_t(b+2),12,22,255,
                       uint8_t(b+3),13,23,255,uint8_t(b+4),14,24,255};
            return nullptr;
        }
        if(n=="get_active")return active;
        if(n=="set_active") {
            auto* target=static_cast<Object*>(args[0]);
            if(failRestore&&target==original){*exception=this;return nullptr;}
            active=target;return nullptr;
        }
        if(n=="ReadPixels") {
            ++readCount;
            require(active&&active->eye==object->eye,"ReadPixels read the wrong eye");
            if(failSecondRead&&object->eye==1){*exception=this;return nullptr;}
            object->pixels=active->pixels;return nullptr;
        }
        if(n=="GetRawTextureData") {auto* bytes=make("ByteArray");bytes->pixels=object->pixels;return bytes;}
        if(n=="get_Length")return box<int32_t>(int32_t(object->pixels.size()));
        if(m.klass=="Marshal"&&n=="Copy") {
            const auto* bytes=static_cast<Object*>(args[0]);const auto start=*static_cast<int32_t*>(args[1]);
            const auto destination=*static_cast<intptr_t*>(args[2]);const auto count=*static_cast<int32_t*>(args[3]);
            require(bytes->kind=="ByteArray"&&start==0&&count==int(bytes->pixels.size()),"Invalid managed byte copy arguments");
            std::memcpy(reinterpret_cast<void*>(destination),bytes->pixels.data(),size_t(count));return nullptr;
        }
        if(n=="Destroy") {
            auto* target=static_cast<Object*>(args[0]);require(target!=active,"Destroyed the still-active RenderTexture");
            target->alive=false;++destroyCount;return nullptr;
        }
        if(n=="set_enabled"||n=="set_hideFlags"||n=="set_antiAliasing"||n=="set_useMipMap"||
           n=="set_autoGenerateMips"||n=="CopyFrom"||n=="set_rect"||n=="set_position"||
           n=="set_rotation"||n=="ResetWorldToCameraMatrix"||n=="set_projectionMatrix"||
           n=="ResetCullingMatrix"||n=="Release")return nullptr;
        throw std::runtime_error("Unexpected fake-host call: "+m.klass+"."+n);
    }
};

void prepare(FakeHost& fake,vrvd::UnityBridge& bridge) {
    std::string error;
    if(!bridge.resolve(&fake.api,error)||!bridge.ensure_targets(2,2,error))throw std::runtime_error(error);
}
void render(vrvd::UnityBridge& bridge) {
    vrvd::Eye eyes[2]{};
    for(auto& e:eyes){e.orientation[3]=1;e.angleLeft=-0.6f;e.angleRight=0.6f;e.angleUp=0.6f;e.angleDown=-0.6f;}
    eyes[0].position[0]=-0.032f;eyes[1].position[0]=0.032f;
    std::string error;if(!bridge.render_eyes(eyes,error))throw std::runtime_error(error);
}
void stereo_success() {
    FakeHost fake;vrvd::UnityBridge bridge;prepare(fake,bridge);render(bridge);
    std::vector<uint8_t> result[2];std::string error;
    if(!bridge.readback_eyes(result,error))throw std::runtime_error(error);
    const std::vector<uint8_t> left{3,13,23,255,4,14,24,255,1,11,21,255,2,12,22,255};
    const std::vector<uint8_t> right{103,13,23,255,104,14,24,255,101,11,21,255,102,12,22,255};
    require(result[0]==left&&result[1]==right,"Stereo channel order, eye identity or vertical orientation is wrong");
    require(fake.active==fake.original,"Success path did not restore active render target");
    require(fake.readCount==2,"Both eyes were not read independently");
    require(!bridge.readback_eyes(result,error),"Same rendered frame was consumed twice");
    bridge.cleanup();require(!bridge.resources_alive()&&fake.roots.empty(),"Successful cleanup leaked roots");
}
void second_eye_failure() {
    FakeHost fake;vrvd::UnityBridge bridge;prepare(fake,bridge);render(bridge);fake.failSecondRead=true;
    std::vector<uint8_t> result[2]{{9,9},{8,8}};std::string error;
    require(!bridge.readback_eyes(result,error),"Second-eye exception was ignored");
    require(result[0]==std::vector<uint8_t>({9,9})&&result[1]==std::vector<uint8_t>({8,8}),"Partial frame replaced caller's buffers");
    require(fake.active==fake.original,"Second-eye exception left RenderTexture.active changed");
    bridge.cleanup();require(!bridge.resources_alive()&&fake.roots.empty(),"Exception cleanup leaked roots");
}
void restoration_retry() {
    FakeHost fake;vrvd::UnityBridge bridge;prepare(fake,bridge);render(bridge);fake.failRestore=true;
    std::vector<uint8_t> result[2]{{9},{8}};std::string error;
    require(!bridge.readback_eyes(result,error),"Active restoration failure was ignored");
    require(result[0]==std::vector<uint8_t>({9})&&result[1]==std::vector<uint8_t>({8}),"Failed restoration exposed a frame");
    require(bridge.resources_alive()&&!fake.roots.empty(),"Failed restore lost ownership of live resources");
    const int before=fake.destroyCount;bridge.cleanup();
    require(fake.destroyCount==before&&bridge.resources_alive(),"Cleanup destroyed resources before active target recovery");
    fake.failRestore=false;bridge.cleanup();
    require(fake.active==fake.original&&!bridge.resources_alive()&&fake.roots.empty(),"Cleanup retry did not restore and release ownership");
}
void d3d11_without_cpu_apis() {
    FakeHost fake;fake.graphics=2;fake.rejectCpuBindings=true;vrvd::UnityBridge bridge;
    prepare(fake,bridge);render(bridge);
    require(bridge.texture(0)&&bridge.texture(1),"D3D11 native textures were lost");
    require(fake.cpuCount==0,"D3D11 unnecessarily created CPU readback textures");
    bridge.cleanup();require(!bridge.resources_alive()&&fake.roots.empty(),"D3D11 cleanup failed");
}
void vulkan_high_resolution_targets() {
    // Exercise the actual target-allocation entry point, not just module config.
    // The fake constructors record both GPU RenderTexture and CPU Texture2D
    // dimensions; this does not allocate real high-resolution GPU/CPU pixels.
    for(const auto dimensions:{std::array<uint32_t,2>{2064,2208},std::array<uint32_t,2>{3072,3072}}) {
        FakeHost fake;vrvd::UnityBridge bridge;std::string error;
        require(bridge.resolve(&fake.api,error),error.c_str());
        require(bridge.ensure_targets(dimensions[0],dimensions[1],error),error.c_str());
        require(fake.rtCount==2&&fake.cpuCount==2,"High resolution did not create independent GPU/CPU targets for both eyes");
        unsigned observed=0;
        for(const auto& object:fake.objects)if(object->kind=="RenderTexture"||object->kind=="Texture2D") {
            require(object->alive&&object->width==int(dimensions[0])&&object->height==int(dimensions[1]),
                    "High-resolution eye target silently used a different size");
            ++observed;
        }
        require(observed==4,"Missing high-resolution GPU/CPU target");
        bool valid=false;
        require(bridge.validate_targets(valid,error)&&valid,"Allocated high-resolution targets failed health validation");
        bridge.cleanup();
        require(!bridge.resources_alive()&&fake.roots.empty(),"High-resolution target cleanup leaked roots");
        for(const auto& object:fake.objects)if(object->kind=="RenderTexture"||object->kind=="Texture2D")
            require(!object->alive,"High-resolution target was not destroyed during cleanup");
    }
}
void vulkan_size_rejection_preserves_targets() {
    for(bool existing:{false,true}) {
        FakeHost fake;vrvd::UnityBridge bridge;std::string error;
        require(bridge.resolve(&fake.api,error),error.c_str());
        if(existing)require(bridge.ensure_targets(2064,2208,error),error.c_str());
        const auto objects=fake.objects.size(),roots=fake.roots.size();
        const auto generation=bridge.diagnostics().targets_generation;
        const int gpu=fake.rtCount,cpu=fake.cpuCount,destroyed=fake.destroyCount;
        for(const auto dimensions:{std::array<uint32_t,2>{3073,2208},std::array<uint32_t,2>{2064,3073}}) {
            require(!bridge.ensure_targets(dimensions[0],dimensions[1],error),"Oversized Vulkan target was accepted");
            require(error.find("3072")!=std::string::npos,"Oversized target reported a stale resolution limit");
            require(fake.objects.size()==objects&&fake.roots.size()==roots&&fake.rtCount==gpu&&fake.cpuCount==cpu&&fake.destroyCount==destroyed,
                    "Rejected resolution allocated or destroyed eye resources");
            require(bridge.diagnostics().targets_generation==generation,"Rejected resolution changed target generation");
            require(fake.active==fake.original,"Rejected resolution changed the game's active render target");
        }
        if(existing) {
            bool valid=false;require(bridge.validate_targets(valid,error)&&valid,"Rejected resolution damaged existing valid targets");
        } else require(!bridge.resources_alive(),"Rejected resolution retained partial resources");
        bridge.cleanup();require(!bridge.resources_alive()&&fake.roots.empty(),"Resolution boundary test leaked resources");
    }
}
}
int main() {
    try {
        stereo_success();second_eye_failure();restoration_retry();d3d11_without_cpu_apis();
        vulkan_high_resolution_targets();vulkan_size_rejection_preserves_targets();
        std::cout<<"PASS: stereo RGBA/top-left, second-eye exception, active restore retry, D3D11 isolation, real allocation bounds at 2064x2208/3072 with atomic 3073 rejection (fake host, no GPU)\n";
        return 0;
    } catch(const std::exception& exception) {std::cerr<<"FAIL: "<<exception.what()<<'\n';return 1;}
}
