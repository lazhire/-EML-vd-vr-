#include "../src/native_menu_capture.h"
#include <map>
#include <stdexcept>
#include <iostream>
using namespace vrvd;
namespace {
std::vector<std::string> methods(1);uintptr_t objectId=100;int boxed=0,width=256,height=256,releases=0,readCount=0;
void* handle=reinterpret_cast<void*>(10);void* current=reinterpret_cast<void*>(88);
bool failRestore=false;int rootFrees=0;
using Done=void(*)(void*,void*,void*);Done completion=nullptr;
void original(void*,void*,void*){}
void require(bool b,const char* why){if(!b)throw std::runtime_error(why);}
BE_Result BE_CALL resolve(void*,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* r){methods.push_back(d->method_name);r->method_info=reinterpret_cast<void*>(methods.size()-1);r->method_pointer=reinterpret_cast<void*>(original);return BE_Result_Ok;}
BE_Result BE_CALL cls(void*,const char*,const char*,const char*,BE_ResolvedClassV1* r){r->class_info=reinterpret_cast<void*>(99);r->type_object=reinterpret_cast<void*>(99);return BE_Result_Ok;}
BE_Result BE_CALL hook(void*,const char*,void*,void* d,void** next){completion=reinterpret_cast<Done>(d);*next=reinterpret_cast<void*>(original);return BE_Result_Ok;}
void* BE_CALL invoke(void*,const void* method,void* obj,void** args,void** ex){
 const auto& n=methods.at(reinterpret_cast<uintptr_t>(method));*ex=nullptr;
 if(n=="GetScreenCapture")return handle;
 if(n=="get_rt")return reinterpret_cast<void*>(11);
 if(n=="Release"){if(obj==handle)++releases;return nullptr;}
 if(n=="get_width"){boxed=1920;return &boxed;}
 if(n=="get_height"){boxed=1080;return &boxed;}
 if(n=="Create"){boxed=1;return &boxed;}
 if(n==".ctor"){width=*static_cast<int*>(args[0]);height=*static_cast<int*>(args[1]);return nullptr;}
 if(n=="get_active")return current;
 if(n=="set_active"){if(failRestore&&args[0]==reinterpret_cast<void*>(88)){*ex=reinterpret_cast<void*>(1);return nullptr;}current=args[0];return nullptr;}
 if(n=="ReadPixels"){++readCount;return nullptr;}
 if(n=="GetRawTextureData")return reinterpret_cast<void*>(13);
 if(n=="get_Length"){boxed=width*height*4;return &boxed;}
 if(n=="Copy"){auto* dst=reinterpret_cast<unsigned char*>(*static_cast<intptr_t*>(args[2]));for(int y=0;y<height;++y)for(int x=0;x<width;++x){size_t p=(size_t(y)*width+x)*4;dst[p]=y;dst[p+1]=x;dst[p+2]=66;dst[p+3]=255;}return nullptr;}
 return nullptr;
}
}
int main(){
 BE_HostApiV1 api{};api.resolve_method=resolve;api.resolve_class=cls;api.create_hook=hook;api.runtime_invoke=invoke;
 api.object_unbox=+[](void*,void* p)->void*{return p;};api.object_new=+[](void*,const void*)->void*{return reinterpret_cast<void*>(++objectId);};
 api.gchandle_new=+[](void*,void*,int)->uint32_t{return 1;};api.gchandle_free=+[](void*,uint32_t){++rootFrees;};
 NativeMenuCapture c;std::string e;std::vector<uint8_t> pixels;bool fresh=false;
 require(c.resolve(&api,e),"resolve");require(c.request(1,e),"request");
 require(c.poll(1,256,256,pixels,fresh,e)&&!fresh&&readCount==0,"must not read before extraction completion");
 completion(nullptr,reinterpret_cast<void*>(999),nullptr);
 require(c.poll(1,256,256,pixels,fresh,e)&&!fresh&&readCount==0,"foreign extraction must not authorize read");
 completion(nullptr,handle,nullptr);require(c.poll(2,256,256,pixels,fresh,e)&&!fresh&&releases==1&&readCount==0,"discard old generation without readback");
 require(c.request(2,e),"second request");completion(nullptr,handle,nullptr);
 require(c.poll(2,256,256,pixels,fresh,e)&&fresh&&releases==2,"completed current generation captured and released");
 require(current==reinterpret_cast<void*>(88),"active RT restored");
 require(pixels.size()==256*256*4&&pixels[3]==255&&pixels[0]==0,"opaque letterbox");
 require(pixels[(56*256)*4]==255&&pixels[(199*256)*4]<4,"bottom-up input flipped once inside aspect-fit panel");
 require(c.request(3,e),"third request");completion(nullptr,handle,nullptr);failRestore=true;
 require(!c.poll(3,256,256,pixels,fresh,e)&&!fresh&&c.pending(),"restore failure retains ownership and refuses frame");
 failRestore=false;require(c.cleanup(e)&&!c.resources_alive()&&current==reinterpret_cast<void*>(88),"game-thread cleanup retries active RT restoration");
 c.hooks_released();require(c.resolve(&api,e)&&c.request(4,e),"module reactivation resolves the completion hook again");completion(nullptr,handle,nullptr);require(c.cleanup(e),"reactivated extraction cleanup");
 int freesBefore=rootFrees;
 {NativeMenuCapture exiting;require(exiting.resolve(&api,e)&&exiting.request(5,e),"pending request before detach");}
 require(rootFrees==freesBefore,"destruction must not call managed helpers under loader lock");
 std::cout<<"PASS: native extraction identity, generation discard, readback orientation/aspect, original RT restoration and cleanup retry; fake managed API only\n";
}
