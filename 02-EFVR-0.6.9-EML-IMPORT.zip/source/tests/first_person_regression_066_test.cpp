#include "../src/ui_route.h"
#include "../../first-person-ui-guard-056/native/vr_ui_pause.h"
#include <cassert>
#include <iostream>
#include "fixtures/gameplay_panels_066.inc"
#include "fixtures/activity_panels_067.inc"
int main(){
 vrvd::UiSignals s;s.valid=true;s.controller="Beyond.Gameplay.View.LevelCameraController";
 for(const auto& panels:samples){
  s.panels=panels;
  assert(vrvd::route_ui(s,{})=="gameplay");
  assert(vrvd::first_person_ui_gate(true,true,vrvd::route_ui(s,{}),true)==1);
  VrUiPause pause;pause.suspended(true,true,false,false);
  assert(pause.released(false,true,false,false));
  assert(!pause.released(false,true,false,false));
  // Future passive HUD names must not recreate the whitelist regression.
  s.panels.push_back({999,3,"FutureCombatHudUnknown",false,999});
  assert(vrvd::route_ui(s,{})=="gameplay");
  assert(vrvd::route_ui(s,{},true)=="menu");
  for(const char* name:{"CharInfo","Watch","Mission","Inventory","AdventureBook"}){
   s.panels.push_back({998,0,name,true,998});
   assert(vrvd::route_ui(s,{})=="menu");
   assert(vrvd::first_person_ui_gate(true,true,vrvd::route_ui(s,{}))==2);
   s.panels.pop_back();
  }
  s.panels.push_back({998,0,"QuickMenu",true,998});assert(vrvd::route_ui(s,{})=="radial");
  assert(vrvd::first_person_ui_gate(true,true,vrvd::route_ui(s,{}))==1);s.panels.pop_back();
  s.loading=true;assert(vrvd::route_ui(s,{})=="loading");s.loading=false;
  s.panels.push_back({998,0,"Dialog",false,998});assert(vrvd::route_ui(s,{})=="dialogue");
 }
 for(const auto& panels:activity_samples){
  s.loading=false;s.panels=panels;assert(vrvd::route_ui(s,{})=="menu");
  assert(vrvd::first_person_ui_gate(true,true,vrvd::route_ui(s,{}))==2);
 }
 for(const char* name:{"ActivityCenter","ActivityCharSignCommon","ActivityPushPopup","ActivityCenterEmptyBottom","Map","MapInfoPopup","CashShop","ShopRecommend","ShopChoicenessBattlePass","DomainMain"}){
  for(bool world:{false,true}){s.panels={{0,0,name,world,0}};assert(vrvd::route_ui(s,{})=="menu");}
 }
 s.panels={{0,0,"ActivityStartReminder",false,0},{0,0,"MapRegionToast",false,0},{0,0,"MiniMap",false,0},{0,0,"ControllerNaviTarget",false,0}};
 assert(vrvd::route_ui(s,{})=="gameplay");
 s.panels.push_back({0,0,"Loading",false,0});assert(vrvd::route_ui(s,{})=="loading");
 std::cout<<"PASS: "<<activity_samples.size()<<" observed activity/map/shop/domain panel sets route flat; passive activity/map HUD stays gameplay\n";
 std::cout<<"PASS: "<<samples.size()<<" real host-log gameplay panel sets restore gate=1; future passive panels safe; known menus/loading/dialogue pause; radial retains first-person; resume intent consumed once\n";
}
