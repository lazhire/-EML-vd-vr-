#include "../src/ui_observer.h"
#include "../../first-person-ui-guard-056/native/vr_ui_pause.h"
#include <map>
#include <iostream>
#include <stdexcept>
using namespace vrvd;
namespace {
void require(bool b,const char* e){if(!b)throw std::runtime_error(e);}
void* ptr(uintptr_t p){return reinterpret_cast<void*>(p);}
std::vector<std::string> methods(1);
std::string controllerName="Beyond.Gameplay.View.LevelCameraController",panelName="GameplayHud";
int frame=1,boxed=0;uint8_t systemScene=0;
bool copyFail=false,nullController=false;int nullBufferCalls=0,realBufferCalls=0;
int BE_CALL copyString(void*,const void* s,char* dst,size_t size){
 // Mirror EngineResolver::CopyManagedString's actual destination contract.
 if(dst&&size)dst[0]=0;
 if(!s||!dst||!size){++nullBufferCalls;return 0;}
 ++realBufferCalls;if(copyFail)return 0;
 const auto& text=*static_cast<const std::string*>(s);
 if(text.size()>=size)return 0;
 std::memcpy(dst,text.c_str(),text.size()+1);return int(text.size());
}
BE_Result BE_CALL resolve(void*,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* m){methods.push_back(d->method_name);m->method_info=ptr(methods.size()-1);return BE_Result_Ok;}
BE_Result BE_CALL field(void*,const BE_FieldDescriptorV1* d,BE_ResolvedFieldV1* f){f->field_info=ptr(std::string(d->field_name)=="s_loader"?2:1);return BE_Result_Ok;}
BE_Result BE_CALL cls(void*,const char*,const char*,const char* n,BE_ResolvedClassV1* c){c->type_object=ptr(std::string(n)=="LuaPanel"?3:4);c->class_info=c->type_object;return BE_Result_Ok;}
void* BE_CALL invoke(void*,const void* mi,void*,void** args,void** ex){
 *ex=nullptr;auto n=methods.at(reinterpret_cast<uintptr_t>(mi));
 if(n=="get_frameCount"){boxed=frame;return &boxed;}
 if(n=="get_curActiveController")return nullController?nullptr:ptr(5);
 if(n=="GetType")return ptr(6);
 if(n=="get_FullName")return &controllerName;
 if(n=="get_isLoading"){boxed=0;return &boxed;}
 if(n=="FindObjectsOfType")return args[0]==ptr(3)?ptr(7):ptr(8);
 if(n=="GetValue")return ptr(9);
 if(n=="get_isActiveAndEnabled"){boxed=1;return &boxed;}
 if(n=="GetInstanceID"||n=="get_panelId"){boxed=10;return &boxed;}
 if(n=="get_panelLevel"||n=="get_IsWorldUI"){boxed=0;return &boxed;}
 if(n=="get_panelName")return &panelName;
 return nullptr;
}
void* BE_CALL runtime(void* ctx,const void* mi,void* obj,void** args,void** ex){
 if(methods.at(reinterpret_cast<uintptr_t>(mi))=="get_Length"){*ex=nullptr;boxed=obj==ptr(7)?1:0;return &boxed;}
 return invoke(ctx,mi,obj,args,ex);
}
}
int main(){
 BE_HostApiV1 api{};api.resolve_method=resolve;api.resolve_field=field;api.resolve_class=cls;api.runtime_invoke=runtime;api.copy_managed_string=copyString;
 api.object_unbox=+[](void*,void* p)->void*{return p;};api.gchandle_new=+[](void*,void*,int)->uint32_t{return 1;};api.gchandle_free=+[](void*,uint32_t){};
 api.field_get_value_object=+[](void*,const void* f,void*)->void*{return f==ptr(2)?ptr(11):&systemScene;};
 require(api.copy_managed_string(nullptr,&controllerName,nullptr,0)==0,"host does not support null-buffer length queries");nullBufferCalls=0;
 UiObserver observer;std::string e;require(observer.resolve(&api,e),"resolve observer");observer.set_manager(ptr(12));observer.refresh();
 require(observer.signals.controller==controllerName&&observer.mode=="gameplay","EML copy contract must yield gameplay controller, not empty special camera");
 require(observer.signals.panels.size()==1&&observer.signals.panels[0].name==panelName,"native panel names copied");
 require(nullBufferCalls==0&&realBufferCalls==2,"production reader must supply a real destination, once per string");
 require(first_person_ui_gate(true,true,observer.mode)==1,"gameplay must retain first-person");
 ++frame;systemScene=1;observer.refresh();require(observer.mode=="menu"&&first_person_ui_gate(true,true,observer.mode)==2,"real system menu still pauses first-person");
 ++frame;nullController=true;observer.refresh();
 require(observer.mode=="menu"&&observer.signals.panels.size()==1,"null gameplay controller in system scene must retain menu and panel enumeration");
 require(first_person_ui_gate(true,true,observer.mode,observer.holds_menu())==2,"role preview remains third person");
 ++frame;systemScene=0;observer.refresh();require(observer.mode=="menu","legitimate null controller still selects flat menu without system-scene flag");
 VrUiPause intent;intent.suspended(true,true,false,false);
 ++frame;nullController=false;copyFail=true;systemScene=0;observer.refresh();
 require(observer.mode=="unknown"&&!observer.signals.valid&&!observer.signals.error.empty(),"copy failure must be unknown with a diagnostic");
 require(first_person_ui_gate(true,true,observer.mode,observer.holds_menu())==2,"unknown during a known menu must not resume first person");
 ++frame;copyFail=false;systemScene=0;observer.refresh();require(observer.mode=="gameplay"&&!observer.holds_menu(),"observation recovers without restart");
 require(intent.released(false,true,false,false),"resume user intent only after confirmed gameplay");
 controllerName.clear();++frame;observer.refresh();require(observer.mode=="unknown"&&first_person_ui_gate(true,true,observer.mode)==0,"empty type never becomes a special menu");
 require(first_person_ui_gate(false,true,"menu")==0&&first_person_ui_gate(true,false,"menu")==0,"VR stopped or observer unavailable must not own standalone first-person");
 std::cout<<"PASS: EML string destination, null-controller system menu, independent panel enumeration, sticky menu pause, confirmed gameplay resume; fake host\n";
}
