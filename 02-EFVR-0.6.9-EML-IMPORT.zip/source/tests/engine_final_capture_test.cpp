#include "../src/engine_final_capture.h"
#include <stdexcept>
#include <iostream>
using namespace vrvd;
namespace {
std::vector<std::string> methods(1),events;uintptr_t objectId=100;int boxed=0,w=256,h=256,tick=10,regs=0,unregs=0;
void* current=(void*)88;void* ui=(void*)21;void* maincam=(void*)22;void* selected=nullptr;
bool written=false,failRestore=false,failRegister=false;int freed=0;
void require(bool b,const char* message){if(!b)throw std::runtime_error(message);}
void original(void*,void*,void*){}
BE_Result BE_CALL resolve(void*,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* r){methods.push_back(std::string(d->class_name)+"."+d->method_name);r->method_info=(void*)(methods.size()-1);r->method_pointer=(void*)original;return BE_Result_Ok;}
BE_Result BE_CALL cls(void*,const char*,const char*,const char*,BE_ResolvedClassV1* r){r->class_info=(void*)99;return BE_Result_Ok;}
BE_Result BE_CALL hook(void*,const char*,void*,void*,void** next){*next=(void*)original;return BE_Result_Ok;}
void* BE_CALL invoke(void*,const void* method,void*,void** a,void** ex){
 const auto& n=methods.at((uintptr_t)method);*ex=nullptr;
 if(n=="CameraManager.get_uiCamera")return ui;
 if(n=="CameraManager.get_mainCamera"||n=="Camera.get_main")return maincam;
 if(n=="HGCamera.GetOrCreate"){selected=a[0];return (void*)31;}
 if(n=="HGCamera.get_finalRTSize"){static int size[]{640,360};return size;}
 if(n=="RTHandles.Alloc")return (void*)32;
 if(n=="HGCamera.RegisterRTExtraction"){require(*(int*)a[0]==3&&*(int*)a[1]==0&&a[2]==(void*)32,"FinalResult persistent contract");++regs;events.push_back("register");if(failRegister)*ex=(void*)1;return nullptr;}
 if(n=="HGCamera.UnRegisterRTExtraction"){++unregs;events.push_back("unregister");return nullptr;}
 if(n=="RTHandle.Release"){events.push_back("release");return nullptr;}
 if(n=="RenderTexture.Create"){boxed=1;return &boxed;}
 if(n=="Texture2D..ctor"){w=*(int*)a[0];h=*(int*)a[1];return nullptr;}
 if(n=="Time.get_frameCount")return &tick;
 if(n=="RenderTexture.get_active")return current;
 if(n=="RenderTexture.set_active"){if(failRestore&&a[0]==(void*)88){*ex=(void*)1;return nullptr;}current=a[0];return nullptr;}
 if(n=="GL.Clear"){written=false;return nullptr;}
 if(n=="Texture2D.GetRawTextureData")return (void*)13;
 if(n=="Array.get_Length"){boxed=w*h*4;return &boxed;}
 if(n=="Marshal.Copy"){auto* dst=(uint8_t*)*(intptr_t*)a[2];for(int y=0;y<h;++y)for(int x=0;x<w;++x){auto i=(size_t(y)*w+x)*4;dst[i]=written?uint8_t(y):44;dst[i+1]=written?uint8_t(x):74;dst[i+2]=written?66:211;dst[i+3]=255;}return nullptr;}
 return nullptr;
}
}
int main(){
 BE_HostApiV1 api{};api.resolve_method=resolve;api.resolve_class=cls;api.create_hook=hook;api.runtime_invoke=invoke;
 api.object_unbox=+[](void*,void* p)->void*{return p;};api.object_new=+[](void*,const void*)->void*{return (void*)++objectId;};
 api.gchandle_new=+[](void*,void*,int)->uint32_t{return 1;};api.gchandle_free=+[](void*,uint32_t){++freed;};
 EngineFinalCapture c;std::string e;std::vector<uint8_t> out;bool fresh;
 require(c.resolve(&api,e),"bindings");
 require(c.poll((void*)1,"auto",256,256,out,fresh,e)&&!fresh&&selected==ui&&regs==1,"automatic UI source; no seed output");
 ++tick;written=true;require(c.poll((void*)1,"auto",256,256,out,fresh,e)&&!fresh,"wait two engine frames");
 ++tick;written=false;require(c.poll((void*)1,"auto",256,256,out,fresh,e)&&!fresh&&out.empty()&&c.seed_rejections==1,"unwritten target rejected");
 written=true;require(c.poll((void*)1,"auto",256,256,out,fresh,e)&&fresh&&c.frames==1,"changed pixels published");
 require(out[(56*256)*4]==255&&out[0]==0&&out[3]==255&&current==(void*)88,"aspect fit orientation and restore");
 require(c.poll((void*)1,"auto",256,256,out,fresh,e)&&regs==1,"persistent extraction does not re-register");
 failRestore=true;require(!c.poll((void*)1,"auto",256,256,out,fresh,e)&&!fresh,"restore failure rejects frame");
 failRestore=false;require(c.cleanup(e)&&!c.resources_alive()&&current==(void*)88,"cleanup retries restoration");
 require(events[events.size()-2]=="unregister"&&events.back()=="release","unregister before releasing wrapper");
 require(c.poll((void*)1,"main",256,256,out,fresh,e)&&selected==maincam,"explicit main camera");
 require(c.cleanup(e),"main cleanup");failRegister=true;
 require(!c.poll((void*)1,"ui",256,256,out,fresh,e)&&!fresh,"registration exception");
 int before=unregs;failRegister=false;require(c.poll((void*)1,"ui",256,256,out,fresh,e)&&unregs==before+1&&!fresh,"failed registration detached before retry");
 require(c.cleanup(e),"final cleanup");
 require(c.poll((void*)1,"ui",3840,2160,out,fresh,e)&&!fresh,"4K target initialization");tick+=2;written=true;require(c.poll((void*)1,"ui",3840,2160,out,fresh,e)&&fresh&&out.size()==3840ull*2160*4,"4K final image accepted");require(out[0]==uint8_t(2159)&&out[3]==255,"fast aspect-matched row flip");require(c.cleanup(e),"4K cleanup");require(!c.poll((void*)1,"ui",4097,2160,out,fresh,e),"oversize rejected");
 int beforeFree=0;{EngineFinalCapture resident;require(resident.resolve(&api,e)&&resident.poll((void*)1,"ui",256,256,out,fresh,e),"resident registration");beforeFree=freed;}
 require(beforeFree==freed,"DLL detach never invokes managed cleanup");
 std::cout<<"PASS: FinalResult enum/ownership, persistent registration, seed rejection, frame delay, orientation/aspect, source selection, active RT restoration, registration failure retry and detach; fake managed API only\n";
}
