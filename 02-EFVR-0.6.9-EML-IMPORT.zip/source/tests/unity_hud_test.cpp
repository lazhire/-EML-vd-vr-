// Public-API fake-host regression tests. No Unity, game, XR runtime or GPU.
// Build with src/unity_hud.cpp, C++17, -Ivendor/eml.
#include "../src/unity_hud.h"
#include <algorithm>
#include <array>
#include <cstring>
#include <deque>
#include <iostream>
#include <map>
#include <memory>
#include <stdexcept>

namespace {
void require(bool ok,const char* message){if(!ok)throw std::runtime_error(message);}
struct Object {
    std::string kind;
    bool alive=true,enabled=true,root=false,rect=false,hidden=false,active=true,renderer=false;
    int layer=0,mode=0,width=0,height=0,graphics=8;
    float distance=100;
    Object *go=nullptr,*transform=nullptr,*canvas=nullptr,*camera=nullptr,*target=nullptr;
    std::vector<Object*> children,items;
    std::vector<uint8_t> bytes;
    std::map<std::string,std::array<float,4>> values;
};
struct Method{std::string klass,name;};
struct FakeHost {
    BE_HostApiV1 api{};
    std::deque<Method> methods;
    std::deque<std::string> classes;
    std::vector<std::unique_ptr<Object>> objects;
    std::vector<Object*> extraCanvases;
    std::map<uint32_t,void*> roots;
    uint32_t rootId=1;
    Object *ui=nullptr,*world=nullptr,*child=nullptr,*originalCamera=nullptr,*originalActive=nullptr,*active=nullptr,*privateCamera=nullptr;
    bool noCanvas=false,failRender=false,failRead=false,failRestore=false,badShader=false,callbackGeometry=false,silentActive=false,restoreCallbackActive=false,emptyHud=false;
    bool noRenderWrites=false,identicalBlack=false;int nativeAlpha=0;
    int expectedLayer=31;
    int renderCount=0,readCount=0,destroyCount=0;
    alignas(16) unsigned char boxed[128]{};
    Object* make(const std::string& name){auto o=std::make_unique<Object>();o->kind=name;auto* p=o.get();objects.push_back(std::move(o));return p;}
    Object* gameObject(int layer,bool rect){auto* go=make("GameObject");go->layer=layer;auto* t=make("Transform");go->transform=t;t->go=go;t->rect=rect;
        t->values={{"localPosition",{11,12,13,0}},{"localRotation",{0,0,0,1}},{"localScale",{1,2,3,0}},
          {"anchorMin",{.1f,.2f,0,0}},{"anchorMax",{.8f,.9f,0,0}},{"anchoredPosition",{20,30,0,0}},
          {"sizeDelta",{400,300,0,0}},{"pivot",{.5f,.5f,0,0}}};return go;}
    Object* canvas(int mode,int layer){auto* c=make("Canvas");c->mode=mode;c->root=true;c->go=gameObject(layer,true);c->transform=c->go->transform;c->transform->canvas=c;return c;}
    template<class T>void* box(T value){std::memcpy(boxed,&value,sizeof(value));return boxed;}
    static FakeHost& get(void* p){return *static_cast<FakeHost*>(p);}
    FakeHost(){
        originalCamera=make("Camera");originalActive=make("OriginalRT");active=originalActive;
        ui=canvas(0,5);ui->camera=originalCamera;world=canvas(2,6);world->camera=originalCamera;
        child=gameObject(5,true);ui->transform->children.push_back(child->transform);gameObject(0,false);
        api.abi_version=1;api.context=this;api.log=[](void*,const char*,const char*){};
        api.resolve_method=[](void* p,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* r){auto& s=get(p);s.methods.push_back({d->class_name,d->method_name});r->method_info=&s.methods.back();return BE_Result_Ok;};
        api.resolve_class=[](void* p,const char*,const char*,const char* name,BE_ResolvedClassV1* r){if(std::string(name)=="HGAdditionalCameraData")return BE_Result_NotFound;auto& s=get(p);s.classes.emplace_back(name);r->class_info=&s.classes.back();r->type_info=r->class_info;r->type_object=const_cast<void*>(r->class_info);return BE_Result_Ok;};
        api.resolve_field=[](void*,const BE_FieldDescriptorV1* d,BE_ResolvedFieldV1* r){std::string name=d->field_name,klass=d->class_name;int offset=-1;
            if(klass=="Color")offset=int(std::string("rgba").find(name));
            else if(klass=="Rect"){std::array<std::string,4> n{"m_XMin","m_YMin","m_Width","m_Height"};auto i=std::find(n.begin(),n.end(),name);if(i!=n.end())offset=int(i-n.begin());}
            else offset=int(std::string("xyzw").find(name));if(offset<0||offset>3)return BE_Result_NotFound;
            r->field_info=reinterpret_cast<void*>(uintptr_t(1));r->offset=16+offset*4;return BE_Result_Ok;};
        api.object_new=[](void* p,const void* type)->void*{return get(p).make(*static_cast<const std::string*>(type));};
        api.string_new=[](void* p,const char*)->void*{return get(p).make("String");};
        api.object_unbox=[](void*,void* p)->void*{return p;};
        api.gchandle_new=[](void* p,void* object,int)->uint32_t{auto& s=get(p);uint32_t id=s.rootId++;s.roots[id]=object;return id;};
        api.gchandle_free=[](void* p,uint32_t id){get(p).roots.erase(id);};
        api.runtime_invoke=[](void* p,const void* method,void* object,void** args,void** ex)->void*{return get(p).invoke(*static_cast<const Method*>(method),static_cast<Object*>(object),args,ex);};
    }
    void* invoke(const Method& m,Object* o,void** a,void** ex){
        *ex=nullptr;const auto& n=m.name;
        auto integer=[&](int i=0){return *static_cast<int32_t*>(a[i]);};
        if(n=="op_Equality"){auto* l=static_cast<Object*>(a[0]);auto* r=static_cast<Object*>(a[1]);if(l&&!l->alive)l=nullptr;if(r&&!r->alive)r=nullptr;return box<uint8_t>(l==r);}
        if(n=="FindObjectsOfType"||n=="FindObjectsOfTypeAll"){
            auto* list=make("Array");auto type=*static_cast<std::string*>(a[0]);
            if(type=="Canvas"){if(!noCanvas)list->items={ui,world};else list->items={world};list->items.insert(list->items.end(),extraCanvases.begin(),extraCanvases.end());}
            else if(type=="GameObject"){for(auto& item:objects)if(item->kind=="GameObject"&&(n=="FindObjectsOfTypeAll"||!item->hidden))list->items.push_back(item.get());}
            else throw std::runtime_error("Unexpected enumeration");return list;
        }
        if(n=="get_Length")return box<int32_t>(o->kind=="Array"?int(o->items.size()):int(o->bytes.size()));
        if(n=="GetValue")return o->items.at(size_t(integer()));
        if(n=="get_gameObject")return o->go;
        if(n=="get_transform")return o->transform;
        if(n=="get_layer")return box<int32_t>(o->layer);
        if(n=="set_layer"){
            if(failRestore&&o==ui->go&&integer()==5){*ex=this;return nullptr;}
            o->layer=integer();return nullptr;
        }
        if(n=="get_activeInHierarchy")return box<uint8_t>(o->active);
        if(n=="get_isActiveAndEnabled")return box<uint8_t>(o->enabled);
        if(n=="get_isRootCanvas")return box<uint8_t>(o->root);
        if(n=="get_renderMode")return box<int32_t>(o->mode);
        if(n=="set_renderMode"){o->mode=integer();o->transform->values["localPosition"]={99,98,97,0};return nullptr;}
        if(n=="get_worldCamera")return o->camera;
        if(n=="set_worldCamera"){o->camera=static_cast<Object*>(a[0]);return nullptr;}
        if(n=="get_planeDistance")return box(o->distance);
        if(n=="set_planeDistance"){o->distance=*static_cast<float*>(a[0]);return nullptr;}
        if(n=="get_childCount")return box<int32_t>(int(o->children.size()));
        if(n=="GetChild")return o->children.at(size_t(integer()));
        if(n=="GetComponent"){auto type=*static_cast<std::string*>(a[0]);
            if(type=="Canvas")return o->canvas;if(type=="Renderer")return o->go->renderer?o->go:nullptr;
            return o->rect?o:nullptr;}
        if(n.rfind("get_",0)==0&&o&&o->values.count(n.substr(4)))return box(o->values[n.substr(4)]);
        if(n.rfind("set_",0)==0&&o&&o->values.count(n.substr(4))){auto& value=o->values[n.substr(4)];size_t count=m.klass=="RectTransform"?2:(n=="set_localRotation"?4:3);std::memcpy(value.data(),a[0],count*4);return nullptr;}
        if(n==".ctor"){
            if(o->kind=="RenderTexture"||o->kind=="Texture2D"){o->width=integer();o->height=integer(1);}
            if(o->kind=="GameObject"){o->transform=make("Transform");o->transform->go=o;}
            return nullptr;
        }
        if(n=="Create")return box<uint8_t>(1);
        if(n=="get_sRGB"||n=="get_isDataSRGB")return box<uint8_t>(0);
        if(n=="get_graphicsFormat")return box<int32_t>(o->graphics);
        if(n=="set_graphicsFormat"){o->graphics=integer();return nullptr;}
        if(n=="get_format")return box<int32_t>(4);
        if(n=="get_mipmapCount")return box<int32_t>(1);
        if(n=="AddComponent"){privateCamera=make("Camera");privateCamera->go=o;return privateCamera;}
        if(n=="set_enabled"){o->enabled=*static_cast<uint8_t*>(a[0])!=0;return nullptr;}
        if(n=="set_hideFlags"){o->hidden=true;return nullptr;}
        if(n=="set_targetTexture"){o->target=static_cast<Object*>(a[0]);return nullptr;}
        if(n=="set_backgroundColor"){std::array<float,4> c{};std::memcpy(c.data(),a[0],16);o->values["background"]=c;return nullptr;}
        if(n=="set_cullingMask"){o->layer=integer();return nullptr;}
        if(n=="Clear"){
            require(active==privateCamera->target,"Preclear touched a game render target");
            auto color=static_cast<float*>(a[2]);active->bytes.resize(size_t(active->width)*active->height*4);
            for(size_t i=0;i<active->bytes.size();++i)active->bytes[i]=uint8_t(color[i%4]*255);
            return nullptr;
        }
        if(n=="Render"){
            ++renderCount;active=o->target; // Exercise restoration when Render changes global state.
            require(o==privateCamera&&!o->enabled,"HUD used a game/enabled camera");
            require(ui->go->layer==expectedLayer&&child->layer==expectedLayer&&uint32_t(o->layer)==(uint32_t(1)<<expectedLayer),"HUD layer isolation failed");
            require(world->go->layer==6&&world->mode==2&&world->camera==originalCamera,"World-space Canvas was modified");
            require(ui->mode==1&&ui->camera==o&&ui->distance==1,"HUD Canvas was not bound to private camera");
            if(failRender){*ex=this;return nullptr;}
            if(noRenderWrites)return nullptr;
            if(identicalBlack){o->target->bytes.assign(size_t(o->target->width)*o->target->height*4,0);return nullptr;}
            if(callbackGeometry)gameObject(expectedLayer,false);
            const bool white=o->values["background"][0]==1;
            // Bottom-up rows, untrustworthy RT alpha intentionally set to 1.
            o->target->bytes=white?std::vector<uint8_t>{223,207,199,1,255,255,255,1,227,177,152,1,200,10,20,1}:
                std::vector<uint8_t>{32,16,8,1,0,0,0,1,100,50,25,1,200,10,20,1};
            if(nativeAlpha){
                o->target->bytes={32,16,8,64,0,0,0,0,100,50,25,128,200,10,20,255};
                if(nativeAlpha==2)for(size_t i=3;i<16;i+=4)o->target->bytes[i]=255;
                if(nativeAlpha==3)o->target->bytes[3]=1;
                if(nativeAlpha==4&&white)o->target->bytes[0]+=10;
            }
            if(badShader&&white)o->target->bytes[0]=0;
            if(emptyHud)for(size_t i=0;i<o->target->bytes.size();++i)o->target->bytes[i]=(i%4==3?255:white?255:0);
            const size_t wanted=size_t(o->target->width)*o->target->height*4;
            if(wanted!=16){const auto pattern=o->target->bytes;o->target->bytes.resize(wanted);for(size_t i=0;i<wanted;++i)o->target->bytes[i]=pattern[i%pattern.size()];}
            return nullptr;
        }
        if(n=="get_active")return active;
        if(n=="set_active"){active=(silentActive&&a[0]!=originalActive)?originalActive:static_cast<Object*>(a[0]);return nullptr;}
        if(n=="ReadPixels"){++readCount;if(failRead&&readCount==2){*ex=this;return nullptr;}o->bytes=active->bytes;return nullptr;}
        if(n=="GetRawTextureData"){auto* bytes=make("ByteArray");bytes->bytes=o->bytes;return bytes;}
        if(n=="Copy"){auto* array=static_cast<Object*>(a[0]);require(integer(1)==0&&integer(3)==int(array->bytes.size()),"Invalid HUD Marshal.Copy");auto dst=*static_cast<intptr_t*>(a[2]);std::memcpy(reinterpret_cast<void*>(dst),array->bytes.data(),array->bytes.size());return nullptr;}
        if(n=="Destroy"){auto* obj=static_cast<Object*>(a[0]);require(obj!=active,"Destroyed active HUD RenderTexture");require(ui->mode==0&&ui->go->layer==5,"Destroyed HUD before restoring Canvas");obj->alive=false;++destroyCount;return nullptr;}
        if(n=="ForceUpdateCanvases"){
            if(!world->root&&ui->mode==1)world->transform->values["localPosition"]={90,91,92,0};
            if(restoreCallbackActive&&ui->mode==0)active=privateCamera->target;return nullptr;
        }
        if(n=="Release"||n=="set_clearFlags"||n=="set_orthographic"||n=="set_orthographicSize"||
           n=="set_aspect"||n=="set_nearClipPlane"||n=="set_farClipPlane"||n=="set_allowHDR"||n=="set_allowMSAA"||
           n=="set_useOcclusionCulling"||n=="set_antiAliasing"||n=="set_useMipMap"||n=="set_autoGenerateMips")return nullptr;
        throw std::runtime_error("Unexpected HUD fake-host call: "+m.klass+"."+n);
    }
    void restored(){
        require(ui->mode==0&&ui->camera==originalCamera&&ui->distance==100,"Canvas state was not restored");
        require(ui->go->layer==5&&child->layer==5,"UI layers were not restored");
        require(ui->transform->values["localPosition"]==std::array<float,4>{11,12,13,0},"Root RectTransform was not restored");
        require(active==originalActive,"RenderTexture.active was not restored");
    }
};
void bind(FakeHost& host,vrvd::UnityHud& hud){std::string e;if(!hud.resolve(&host.api,e))throw std::runtime_error(e);}
void success(){
    FakeHost f;vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out;std::string e;
    if(!hud.capture(2,2,out,e))throw std::runtime_error(e);
    const std::vector<uint8_t> expected{100,50,25,128,200,10,20,255,32,16,8,64,0,0,0,0};
    require(out==expected,"HUD premultiplied/top-left result is wrong");require(hud.count()==1,"Wrong captured Canvas count");
    require(!hud.restore_pending(),"Successful HUD capture left restore pending");f.restored();hud.cleanup();
    require(!hud.resources_alive()&&f.roots.empty(),"HUD cleanup leaked roots/resources");
}
void read_failure(){
    FakeHost f;f.failRead=true;vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out{7,8,9};std::string e;
    require(!hud.capture(2,2,out,e),"Second read failure was ignored");require(out==std::vector<uint8_t>({7,8,9}),"Failure committed stale HUD");
    require(hud.count()==0&&!hud.restore_pending(),"Read failure left invalid capture status");f.restored();hud.cleanup();require(f.roots.empty(),"Read failure leaked roots");
}
void render_failure(){
    FakeHost f;f.failRender=true;vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out;std::string e;
    require(!hud.capture(2,2,out,e),"Render exception was ignored");f.restored();hud.cleanup();require(f.roots.empty(),"Render failure leaked roots");
}
void restore_retry(){
    FakeHost f;f.failRestore=true;f.restoreCallbackActive=true;vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out{42};std::string e;
    require(!hud.capture(2,2,out,e),"Restore failure was ignored");require(hud.restore_pending()&&hud.resources_alive(),"Restore failure did not retain state");
    require(out==std::vector<uint8_t>({42}),"Failed restore committed HUD");hud.cleanup();require(f.destroyCount==0,"Cleanup destroyed resources while restore was pending");
    f.failRestore=false;hud.cleanup();f.restored();require(!hud.resources_alive()&&!hud.restore_pending()&&f.roots.empty(),"Cleanup retry did not restore/free resources");
}
void missing_or_unsupported(){
    for(int scenario=0;scenario<6;++scenario){FakeHost f;vrvd::UnityHud hud;bind(f,hud);
        if(scenario==0)f.noCanvas=true;
        if(scenario==1)f.badShader=true;
        if(scenario==2)for(int layer=8;layer<32;++layer)f.gameObject(layer,false);
        if(scenario==3)f.child->renderer=true;
        if(scenario==4)f.callbackGeometry=true;
        if(scenario==5)f.silentActive=true;
        std::vector<uint8_t> out;std::string e;require(!hud.capture(2,2,out,e,vrvd::HudComposition::Transparent),"Unsupported HUD was accepted");
        require(!e.empty()&&!hud.restore_pending(),"Unsupported HUD failed without diagnosis/rollback");f.restored();hud.cleanup();require(f.roots.empty(),"Unsupported HUD leaked roots");
    }
}
void hidden_geometry(){
    FakeHost f;auto* hidden=f.gameObject(31,false);hidden->hidden=true;hidden->renderer=true;f.expectedLayer=30;
    vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out;std::string e;
    if(!hud.capture(2,2,out,e))throw std::runtime_error(e);
    require(hidden->layer==31,"Hidden world geometry was altered");f.restored();hud.cleanup();require(f.roots.empty(),"Hidden-layer capture leaked roots");
}
void restore_callback(){
    FakeHost f;f.restoreCallbackActive=true;vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out;std::string e;
    if(!hud.capture(2,2,out,e))throw std::runtime_error(e);
    f.restored();hud.cleanup();require(f.roots.empty(),"Restore callback leaked roots");
}
void partial_roots(){
    FakeHost f;auto* incompatible=f.canvas(0,7);incompatible->go->renderer=true;incompatible->camera=f.originalCamera;f.extraCanvases.push_back(incompatible);
    vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out;std::string e;
    if(!hud.capture(2,2,out,e))throw std::runtime_error(e);
    require(hud.count()==1&&hud.skipped_count()==1&&!hud.warning().empty(),"Compatible Canvas was lost with an incompatible sibling root");
    require(incompatible->mode==0&&incompatible->camera==f.originalCamera&&incompatible->go->layer==7,"Skipped Canvas was mutated");
    f.restored();hud.cleanup();require(f.roots.empty(),"Skipped root snapshot leaked GC references");
}
void opaque_fallback(){
    FakeHost f;f.badShader=true;vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out;std::string e;
    require(!hud.capture(2,2,out,e,vrvd::HudComposition::Auto)&&!hud.opaque()&&out.empty(),"Unsupported alpha automatically became an obstructing opaque panel");
    f.restored();hud.cleanup();require(f.roots.empty(),"Rejected auto capture leaked roots");
}
void unrendered_black(){
    for(int kind=0;kind<3;++kind){FakeHost f;f.noRenderWrites=kind==0;f.identicalBlack=kind!=0;
        vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out{99};std::string e;
        require(!hud.capture(2,2,out,e,kind==2?vrvd::HudComposition::Opaque:vrvd::HudComposition::Transparent),"Unrendered/flat-black HUD was accepted");
        require(out==std::vector<uint8_t>{99},"Invalid black capture replaced published output");f.restored();hud.cleanup();require(f.roots.empty(),"Black rejection leaked state");
    }
}
void opaque_single_pass(){
    FakeHost f;vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out;std::string e;
    if(!hud.capture(2,2,out,e,vrvd::HudComposition::Opaque))throw std::runtime_error(e);
    require(f.renderCount==1&&f.readCount==1&&hud.opaque(),"Explicit opaque panel did not use one isolated pass");
    for(size_t i=3;i<out.size();i+=4)require(out[i]==255,"Opaque panel retained nonopaque alpha");
    f.restored();hud.cleanup();require(f.roots.empty(),"Single-pass panel leaked roots");
}
void empty_auto(){
    FakeHost f;f.emptyHud=true;vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out{42};std::string e;
    require(!hud.capture(2,2,out,e,vrvd::HudComposition::Auto)&&e.find("empty")!=std::string::npos,"Empty transparent render was silently replaced by a black panel");
    require(!hud.opaque()&&out==std::vector<uint8_t>{42},"Empty render published content");f.restored();hud.cleanup();require(f.roots.empty(),"Empty render leaked roots");
}
void high_resolution(){
    FakeHost f;vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out;std::string e;
    if(!hud.capture(2048,1152,out,e))throw std::runtime_error(e);
    require(f.privateCamera->target->width==2048&&f.privateCamera->target->height==1152,"High-resolution HUD did not allocate actual target dimensions");
    require(out.size()==size_t(2048)*1152*4,"High-resolution HUD returned wrong byte count");
    require(hud.capture_path()=="standard_canvas_camera","Capture path does not describe the resolved provider");
    require(!hud.capture(2049,1152,out,e),"HUD dimension bound was not enforced");f.restored();hud.cleanup();require(f.roots.empty(),"High-resolution HUD leaked roots");
}
void mixed_world_subtree(){
    for(int fail=0;fail<2;++fail){FakeHost f;
        f.world->root=false;f.world->go->renderer=true;
        auto* descendant=f.gameObject(6,true);descendant->renderer=true;
        f.world->transform->children.push_back(descendant->transform);
        f.ui->transform->children.push_back(f.world->transform);
        const auto original=f.world->transform->values;
        vrvd::UnityHud hud;bind(f,hud);f.failRead=fail!=0;
        std::vector<uint8_t> out;std::string e;
        const bool ok=hud.capture(2,2,out,e);
        require(ok==(fail==0),"Mixed screen/world hierarchy result incorrect");
        require(f.world->go->layer==6&&descendant->layer==6&&f.world->mode==2&&f.world->camera==f.originalCamera,"Excluded world subtree was rebound");
        require(f.world->transform->values==original,"World layout not restored");
        if(ok)require(hud.count()==1&&hud.skipped_count()==0&&hud.warning().find("subtree")!=std::string::npos,"Screen sibling lost with nested world Canvas");
        f.restored();hud.cleanup();require(f.roots.empty(),"Mixed subtree leaked snapshots");
    }
}
void native_alpha(){
    for(int mode=1;mode<=4;++mode){FakeHost f;f.nativeAlpha=mode;
        vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out{42};std::string e;
        const bool ok=hud.capture(2,2,out,e,vrvd::HudComposition::Transparent);
        require(ok==(mode==1),"Native alpha validation result incorrect");
        if(ok){require(!hud.opaque()&&out.size()==16&&out[3]==128&&out[11]==64&&out[15]==0,"Native alpha flip or premultiplication incorrect");
            require(hud.warning().find("native alpha")!=std::string::npos,"Native alpha path missing diagnostics");}
        else require(out==std::vector<uint8_t>{42},"Invalid native alpha published output");
        f.restored();hud.cleanup();require(f.roots.empty(),"Native alpha leaked state");
    }
}

void game_ui_menus(){
    for(int kind=0;kind<7;++kind){FakeHost f;
        if(kind>=1&&kind<=4)f.nativeAlpha=kind;
        if(kind==5)f.identicalBlack=true;
        if(kind==6)f.noRenderWrites=true;
        vrvd::UnityHud hud;bind(f,hud);std::vector<uint8_t> out{42};std::string e;
        const bool ok=hud.capture(2,2,out,e,vrvd::HudComposition::GameUi);
        require(ok==(kind<=2),"Native game UI menu acceptance mismatch");
        if(ok)require(hud.opaque()==(kind==2),"Transparent HUD / opaque menu classification wrong");
        else require(out==std::vector<uint8_t>{42},"Invalid menu output was published");
        if(kind==2){for(size_t i=3;i<out.size();i+=4)require(out[i]==255,"Opaque menu alpha was lost");
            f.nativeAlpha=0;require(hud.capture(2,2,out,e,vrvd::HudComposition::GameUi)&&!hud.opaque(),"Closing menu did not restore transparent HUD");}
        f.restored();hud.cleanup();require(f.roots.empty(),"Game UI capture leaked roots");
    }
}

}
int main(){try{game_ui_menus();mixed_world_subtree();native_alpha();success();read_failure();render_failure();restore_retry();missing_or_unsupported();hidden_geometry();restore_callback();partial_roots();opaque_fallback();opaque_single_pass();empty_auto();high_resolution();unrendered_black();std::cout<<"Unity HUD fake-host tests passed (33 scenarios)\n";return 0;}
catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}}
