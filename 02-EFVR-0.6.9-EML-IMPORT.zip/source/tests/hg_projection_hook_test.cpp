// Calls the production explicit-sret callbacks using a fake EML hook host.
// No game, managed invocation, OpenXR runtime, or GPU is used.
#include "../src/hg_projection_hook.h"
#include <cmath>
#include <cstring>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <functional>
#include <thread>

namespace {
void require(bool ok,const char* message){if(!ok)throw std::runtime_error(message);}
using Matrix=vrvd::HgProjectionMatrix;using Native=vrvd::HgProjectionNative;
struct Fake {
    inline static Fake* current=nullptr;
    BE_HostApiV1 api{};vrvd::HgProjectionHook* hook=nullptr;
    Native detours[2]{};int resolves=0,creates=0,releases=0,originalCalls[2]{};
    bool failSecond=false,missingMethod=false,nullOriginal=false;
    vrvd::HgFrameParametersNative prepareDetour=nullptr;
    vrvd::HgGetOrCreateNative getDetour=nullptr;
    bool getAvailable=false,failGetInstall=false,nullGetOriginal=false;
    std::function<void()> prepareAction;
    int getOriginalCalls=0;void* getSeenCamera=nullptr;int32_t getSeenMultipass=0;const void* getSeenMethod=nullptr;
    bool prepareAvailable=false,failPrepareInstall=false,nullPrepareOriginal=false,throwPrepare=false,clearDuringPrepare=false;
    bool probeOldDuringCreate=false;int oldCallbackProbes=0;
    Native oldDetours[2]{};vrvd::HgFrameParametersNative oldPrepareDetour=nullptr;vrvd::HgGetOrCreateNative oldGetDetour=nullptr;
    uint8_t prepareResult=1;int prepareOriginalCalls=0;
    void* nextHg=nullptr;void* nextAdditional=nullptr;
    void* seenPipeline=nullptr;void** seenAdditionalOut=nullptr;void** seenHgOut=nullptr;void* seenCulling=nullptr;
    void* seenInstance=nullptr;void* seenCamera=nullptr;const void* seenMethod=nullptr;Matrix* seenOutput=nullptr;
    int methods[4]{};
    static Matrix* original(unsigned i,Matrix* out,void* instance,void* camera,const void* method) {
        auto& s=*current;++s.originalCalls[i];s.seenInstance=instance;s.seenCamera=camera;s.seenMethod=method;s.seenOutput=out;
        // Re-entering snapshot here would deadlock if route held its mutex
        // while calling original HG code.
        if(s.hook)s.hook->snapshot();
        for(unsigned j=0;j<16;++j)out->values[j]=1000.f+100.f*i+float(j);
        return out;
    }
    static Matrix* build(Matrix* out,void* hg,void* camera,const void* method){return original(0,out,hg,camera,method);}
    static Matrix* nonOblique(Matrix* out,void* data,void* camera,const void* method){return original(1,out,data,camera,method);}
    static uint8_t prepare(void* pipeline,void* camera,void** additional,void** hg,void* culling,const void* method) {
        auto& s=*current;++s.prepareOriginalCalls;s.seenPipeline=pipeline;s.seenCamera=camera;s.seenAdditionalOut=additional;
        s.seenHgOut=hg;s.seenCulling=culling;s.seenMethod=method;
        if(s.hook)s.hook->snapshot(); // Original code must execute without the route lock.
        if(s.throwPrepare)throw std::runtime_error("prepare original failure");
        if(s.clearDuringPrepare&&s.hook)s.hook->clear();
        const auto action=s.prepareAction;if(action)action();
        if(s.prepareResult==1){if(additional)*additional=s.nextAdditional;if(hg)*hg=s.nextHg;}
        if(culling)*static_cast<unsigned*>(culling)=0x178ea;
        return s.prepareResult;
    }
    static void* get(void* camera,int32_t multipass,const void* method) {
        auto& s=*current;++s.getOriginalCalls;s.getSeenCamera=camera;s.getSeenMultipass=multipass;s.getSeenMethod=method;
        if(s.hook)s.hook->snapshot();return s.nextHg;
    }
    Fake(){current=this;api.abi_version=1;api.context=this;
        api.release_module_hooks=[](void* ctx,const char*){++static_cast<Fake*>(ctx)->releases;return BE_Result_Ok;};
        api.resolve_method=[](void* ctx,const BE_MethodDescriptorV1* d,BE_ResolvedMethodV1* out){
            auto& s=*static_cast<Fake*>(ctx);++s.resolves;
            require(std::string(d->assembly_name)=="HG.RenderPipelines.Runtime.dll"&&std::string(d->namespace_name)=="HG.Rendering.Runtime","Wrong method namespace");
            if(std::string(d->method_name)=="TryCalculateFrameParameters") {
                require(std::string(d->class_name)=="HGRenderPipeline"&&d->parameter_count==4&&std::string(d->return_type)=="System.Boolean"&&
                    std::string(d->parameter_types)=="UnityEngine.Camera|HG.Rendering.Runtime.HGAdditionalCameraData&|HG.Rendering.Runtime.HGCamera&|UnityEngine.Rendering.ScriptableCullingParameters&",
                    "Wrong frame-parameters method signature");
                if(!s.prepareAvailable)return BE_Result_NotFound;
                out->method_info=&s.methods[2];out->method_pointer=reinterpret_cast<void*>(prepare);return BE_Result_Ok;
            }
            if(std::string(d->method_name)=="GetOrCreate") {
                require(std::string(d->class_name)=="HGCamera"&&d->parameter_count==2&&
                    std::string(d->parameter_types)=="UnityEngine.Camera|System.Int32"&&std::string(d->return_type)=="HG.Rendering.Runtime.HGCamera",
                    "Wrong GetOrCreate method signature");
                if(!s.getAvailable)return BE_Result_NotFound;
                out->method_info=&s.methods[3];out->method_pointer=reinterpret_cast<void*>(get);return BE_Result_Ok;
            }
            require(d->parameter_count==1&&std::string(d->parameter_types)=="UnityEngine.Camera"&&std::string(d->return_type)=="UnityEngine.Matrix4x4","Wrong matrix method signature");
            const bool b=std::string(d->method_name)=="BuildSceneRTAspectProjection";
            require(std::string(d->class_name)==(b?"HGCamera":"HGAdditionalCameraData"),"Wrong HG class");
            if(s.missingMethod&&!b)return BE_Result_NotFound;
            out->method_info=&s.methods[b?0:1];out->method_pointer=reinterpret_cast<void*>(b?build:nonOblique);return BE_Result_Ok;
        };
        api.create_hook=[](void* ctx,const char* owner,void* target,void* replacement,void** next){
            auto& s=*static_cast<Fake*>(ctx);++s.creates;require(std::string(owner)=="quest3.vrvd","Hook has wrong module owner");
            if(s.probeOldDuringCreate) {
                // Deterministically enter the previous installation's callbacks
                // after install resets its registry, before this host republishes
                // any original slot. release_module_hooks does not quiesce them.
                int instance=0,camera=0,method=0;Matrix result{};
                require(s.oldDetours[0](&result,&instance,&camera,&method)==&result&&result.values[0]==1000,
                    "Reinstall cleared the old Build trampoline before host republishing");
                require(s.seenInstance==&instance&&s.seenCamera==&camera&&s.seenMethod==&method,
                    "Old Build callback parameters changed during reinstall");
                require(s.oldDetours[1](&result,&instance,&camera,&method)==&result&&result.values[0]==1100,
                    "Reinstall cleared the old non-oblique trampoline before host republishing");
                unsigned culling=0;void* additional=nullptr;void* hg=nullptr;
                require(s.oldPrepareDetour(&instance,&camera,&additional,&hg,&culling,&method)==s.prepareResult&&
                    additional==s.nextAdditional&&hg==s.nextHg&&culling==0x178ea,
                    "Reinstall lost the old observer trampoline or changed its original result");
                require(s.seenPipeline==&instance&&s.seenCamera==&camera&&s.seenAdditionalOut==&additional&&s.seenHgOut==&hg&&
                    s.seenCulling==&culling&&s.seenMethod==&method,"Old observer arguments changed during reinstall");
                if(s.oldGetDetour) {
                    require(s.oldGetDetour(&camera,7,&method)==s.nextHg&&s.getSeenCamera==&camera&&s.getSeenMultipass==7&&s.getSeenMethod==&method,
                        "Reinstall cleared or changed the old GetOrCreate trampoline");
                }
                ++s.oldCallbackProbes;
            }
            if(target==reinterpret_cast<void*>(prepare)) {
                if(s.failPrepareInstall)return BE_Result_Failed;
                *next=s.nullPrepareOriginal?nullptr:target;s.prepareDetour=reinterpret_cast<vrvd::HgFrameParametersNative>(replacement);return BE_Result_Ok;
            }
            if(target==reinterpret_cast<void*>(get)) {
                if(s.failGetInstall)return BE_Result_Failed;
                *next=s.nullGetOriginal?nullptr:target;s.getDetour=reinterpret_cast<vrvd::HgGetOrCreateNative>(replacement);return BE_Result_Ok;
            }
            const unsigned i=target==reinterpret_cast<void*>(build)?0:1;
            require(target==reinterpret_cast<void*>(i?nonOblique:build),"Unknown hook target");
            if(i&&s.failSecond)return BE_Result_Failed;
            *next=s.nullOriginal?nullptr:target;s.detours[i]=reinterpret_cast<Native>(replacement);return BE_Result_Ok;
        };
    }
};
struct Fixture {
    Fake host;vrvd::HgProjectionHook hook;int ids[8]{};Matrix eyes[2]{};
    Fixture(bool observePrepare=false){host.hook=&hook;host.prepareAvailable=observePrepare;std::string e;require(hook.install(&host.api,e),e.c_str());
        for(unsigned i=0;i<2;++i){for(unsigned j=0;j<16;++j)eyes[i].values[j]=float(10*i+j)/31.f;eyes[i].values[8]=i?-.23f:.17f;
            require(hook.set_eye(i,hg(i),camera(i),data(i),eyes[i].values,e),e.c_str());}
    }
    void* hg(unsigned i){return &ids[i*3];}void* camera(unsigned i){return &ids[i*3+1];}void* data(unsigned i){return &ids[i*3+2];}
    Matrix* call(unsigned fn,Matrix* out,void* instance,void* camera,const void* method){return host.detours[fn](out,instance,camera,method);}
};
void routing_and_sret(){
    Fixture f;std::string e;const void* method=&f.ids[7];Matrix ordinary{};
    require(f.call(0,&ordinary,f.hg(0),f.camera(0),method)==&ordinary&&ordinary.values[0]==1000,"Out-of-scope private build did not pass through");
    require(f.host.seenInstance==f.hg(0)&&f.host.seenCamera==f.camera(0)&&f.host.seenMethod==method&&f.host.seenOutput==&ordinary,"Original arguments changed");
    for(unsigned i=0;i<2;++i){
        require(f.hook.begin_eye(i,e),e.c_str());
        struct Guarded {uint64_t before[2]{0x12345678,0x11112222};Matrix matrix{};uint64_t after[2]{0x87654321,0x33334444};} out;
        for(unsigned fn=0;fn<2;++fn){
            const int previous=f.host.originalCalls[fn];
            require(f.call(fn,&out.matrix,fn?f.data(i):f.hg(i),f.camera(i),method)==&out.matrix,"Explicit sret did not return the provided result buffer");
            require(std::memcmp(&out.matrix,&f.eyes[i],64)==0,"Projection bytes changed/transposed or crossed eyes");
            require(f.host.originalCalls[fn]==previous,"Owned eye called the original projection builder");
            require(out.before[0]==0x12345678&&out.before[1]==0x11112222&&out.after[0]==0x87654321&&out.after[1]==0x33334444,"64-byte return overwrote an adjacent object");
            f.call(fn,&ordinary,&f.ids[6],f.camera(i),method);
            require(f.host.originalCalls[fn]==previous+1&&f.host.seenInstance==&f.ids[6],"Wrong HG/additional identity was intercepted");
            f.call(fn,&ordinary,fn?f.data(i):f.hg(i),&f.ids[6],method);
            require(f.host.originalCalls[fn]==previous+2&&f.host.seenCamera==&f.ids[6],"Wrong camera identity was intercepted");
            f.call(fn,&ordinary,fn?f.data(i^1):f.hg(i^1),f.camera(i^1),method);
            require(f.host.originalCalls[fn]==previous+3,"Inactive eye was intercepted inside the other eye's scope");
        }
        require(f.hook.end_eye(i,e),e.c_str());
    }
    const auto s=f.hook.snapshot();require(s.build_hits==2&&s.non_oblique_hits==2&&!s.scope_active,"Incorrect scoped hit counters");
    require(s.frame_build_hits[0]==1&&s.frame_build_hits[1]==1&&s.frame_non_oblique_hits[0]==1&&s.frame_non_oblique_hits[1]==1,"Frame counters crossed eye boundaries");
}
void missing_hit_and_clear(){
    Fixture f;std::string e;Matrix out{};
    require(f.hook.begin_eye(0,e),e.c_str());f.call(1,&out,f.data(0),f.camera(0),nullptr);
    require(!f.hook.end_eye(0,e)&&e.find("no Build entries during eye Render")!=std::string::npos,"A non-oblique hit alone incorrectly certified the draw projection");
    require(!f.hook.snapshot().scope_active,"Failed scope remained active");
    require(f.hook.begin_eye(0,e),e.c_str());
    require(!f.hook.begin_eye(1,e),"Overlapping eye scopes allowed");
    require(!f.hook.set_eye(0,f.hg(0),f.camera(0),f.data(0),f.eyes[0].values,e),"Live render matrix was rebound");
    f.hook.clear_eye(0);f.call(0,&out,f.hg(0),f.camera(0),nullptr);
    require(out.values[0]==1000&&!f.hook.begin_eye(0,e),"Cleared eye continued to override");
    require(f.hook.begin_eye(1,e),e.c_str());f.hook.clear();f.call(1,&out,f.data(1),f.camera(1),nullptr);
    require(out.values[0]==1100&&!f.hook.snapshot().scope_active&&!f.hook.begin_eye(1,e),"Full clear left a live identity or scope");
}
void contracts_and_partial_install(){
    {Fake host;vrvd::HgProjectionHook hook;std::string e;host.api.release_module_hooks=nullptr;
        require(!hook.install(&host.api,e)&&host.resolves==0&&host.creates==0,"Host without hook cleanup was accepted");}
    for(unsigned test=0;test<3;++test){Fake host;vrvd::HgProjectionHook hook;host.hook=&hook;
        host.missingMethod=test==0;host.failSecond=test==1;host.nullOriginal=test==2;
        std::string e;require(!hook.install(&host.api,e)&&!hook.snapshot().installed,"Incomplete hook install was accepted");
        require(host.releases==0,"Helper failure released unrelated module hooks");
        require(test||host.creates==0,"Hook mutated before all method contracts resolved");
        if(test==1){Matrix result{};int a=0,b=0,m=0;require(host.detours[0](&result,&a,&b,&m)==&result&&result.values[0]==1000,"Partially installed hook failed to pass through");}
    }
    Fixture f;std::string e;auto invalid=f.eyes[0];invalid.values[8]=std::numeric_limits<float>::quiet_NaN();
    require(!f.hook.set_eye(0,f.hg(0),f.camera(0),f.data(0),invalid.values,e),"Nonfinite projection accepted");
    require(!f.hook.set_eye(0,f.hg(1),f.camera(0),f.data(0),f.eyes[0].values,e),"Shared HG identity accepted");
    require(!f.hook.set_eye(0,f.hg(0),f.camera(1),f.data(0),f.eyes[0].values,e),"Shared camera identity accepted");
    require(!f.hook.set_eye(0,f.hg(0),f.camera(0),f.data(1),f.eyes[0].values,e),"Shared additional data accepted");
    require(!f.hook.set_eye(2,f.hg(0),f.camera(0),f.data(0),f.eyes[0].values,e),"Invalid eye index accepted");
}
void asymmetric_fov_keeps_forward_rays_aligned(){
    Fixture f;std::string error;
    // OpenXR angle bounds are physical eye rays, not a centered desktop FOV.
    // Use deliberately asymmetric horizontal AND vertical bounds in radians.
    const double bounds[2][4]{{-.9,.5,-.4,.7},{-.5,.9,-.7,.4}};
    double oldHorizontal[2]{},correctedHorizontal[2]{};
    const auto forwardNdc=[](const Matrix& p){
        // Project the same camera-space forward point (0,0,-5,1) with
        // column-major matrix multiplication, independent of the hook routing.
        const double w=-5.0*p.values[11]+p.values[15];
        require(w>0,"Forward ray projected behind the eye");
        return std::array<double,2>{(-5.0*p.values[8]+p.values[12])/w,
                                    (-5.0*p.values[9]+p.values[13])/w};
    };
    const auto displayedAngle=[](double ndc,double minimum,double maximum){
        // Recover the ray the XR compositor assigns to a pixel by linearly
        // interpolating its tangent-angle bounds, then convert to degrees.
        const double tangent=std::tan(minimum)+(ndc+1.0)*.5*(std::tan(maximum)-std::tan(minimum));
        return std::atan(tangent)*180.0/3.14159265358979323846;
    };
    for(unsigned eye=0;eye<2;++eye){
        const auto& a=bounds[eye];const double l=std::tan(a[0]),r=std::tan(a[1]),b=std::tan(a[2]),t=std::tan(a[3]);
        Matrix desired{};
        desired.values[0]=float(2.0/(r-l));desired.values[5]=float(2.0/(t-b));
        desired.values[8]=float((r+l)/(r-l));desired.values[9]=float((t+b)/(t-b));
        desired.values[10]=float(-(100.0+.05)/(100.0-.05));desired.values[11]=-1.f;
        desired.values[14]=float(-2.0*100.0*.05/(100.0-.05));
        Matrix legacy=desired;legacy.values[8]=legacy.values[9]=0;
        const auto legacyPixel=forwardNdc(legacy);
        require(legacyPixel[0]==0&&legacyPixel[1]==0,"Centered projection did not put forward at the texture center");
        oldHorizontal[eye]=displayedAngle(legacyPixel[0],a[0],a[1]);
        require(std::abs(oldHorizontal[eye]-(eye?19.64:-19.64))<.05,"Centered projection did not reproduce the roughly 19.64-degree wrong-eye direction");
        require(std::abs(displayedAngle(legacyPixel[1],a[2],a[3]))>10,"Vertical asymmetry did not reproduce a misplaced forward ray");

        require(f.hook.set_eye(eye,f.hg(eye),f.camera(eye),f.data(eye),desired.values,error),error.c_str());
        require(f.hook.begin_eye(eye,error),error.c_str());
        for(unsigned route=0;route<2;++route){
            Matrix actual{};f.call(route,&actual,route?f.data(eye):f.hg(eye),f.camera(eye),nullptr);
            const auto pixel=forwardNdc(actual);
            const double x=displayedAngle(pixel[0],a[0],a[1]),y=displayedAngle(pixel[1],a[2],a[3]);
            require(std::abs(x)<.0001&&std::abs(y)<.0001,"HG hook output lost the off-center terms: XR displays a forward point in the wrong direction");
            if(!route)correctedHorizontal[eye]=x;
        }
        require(f.hook.end_eye(eye,error),error.c_str());
    }
    require(oldHorizontal[1]-oldHorizontal[0]>39,"Legacy centered eyes did not reproduce divergent displayed directions");
    require(std::abs(correctedHorizontal[1]-correctedHorizontal[0])<.0001,"Corrected eyes still disagree on the forward ray");
}
void diagnostic_classification_and_reset(){
    Fixture f;std::string error;Matrix out{};const void* method=&f.ids[7];
    for(unsigned route=0;route<2;++route){
        f.call(route,&out,route?f.data(0):f.hg(0),f.camera(0),method);
        require(out.values[0]==1000.f+100.f*route,"Observed outside-scope private call changed the original matrix");
        f.call(route,&out,&f.ids[6],&f.ids[7],method);
    }
    auto snapshot=f.hook.snapshot();
    require(snapshot.build_calls.entries==2&&snapshot.non_oblique_calls.entries==2,"Global route entry counts omitted ordinary calls");
    require(snapshot.build_calls.outside_scope_private[0]==1&&snapshot.non_oblique_calls.outside_scope_private[0]==1,
            "Exact private calls outside scope were not distinguished");
    require(snapshot.build_calls.scope_entries[0]==0&&snapshot.build_calls.scope_entries[1]==0,"Unscoped calls were attributed to an eye render");
    require(f.hook.begin_eye(0,error),error.c_str());
    for(unsigned route=0;route<2;++route){
        const auto passthrough=[&](void* instance,void* camera){
            const int count=f.host.originalCalls[route];f.call(route,&out,instance,camera,method);
            require(f.host.originalCalls[route]==count+1&&out.values[0]==1000.f+100.f*route,
                    "Diagnostic mismatch observation intercepted a nonmatching call");
            require(f.host.seenInstance==instance&&f.host.seenCamera==camera&&f.host.seenMethod==method&&f.host.seenOutput==&out,
                    "Diagnostic mismatch observation changed native arguments");
        };
        passthrough(&f.ids[6],f.camera(0)); // Right Camera, wrong HG/additional.
        passthrough(route?f.data(0):f.hg(0),&f.ids[6]); // Right instance, wrong Camera.
        passthrough(&f.ids[6],&f.ids[7]); // Entirely unrelated camera pipeline.
        passthrough(route?f.data(1):f.hg(1),f.camera(1)); // Private right eye while left scope is active.
    }
    f.call(1,&out,f.data(0),f.camera(0),method); // Non-oblique hit must not qualify the draw.
    require(!f.hook.end_eye(0,error),"Observed mismatches accidentally accepted the frame");
    require(error.find("Build identity mismatch")!=std::string::npos&&error.find("scope=4")!=std::string::npos&&
            error.find("wrongHG=1")!=std::string::npos&&error.find("wrongCamera=1")!=std::string::npos&&
            error.find("NonOblique scope=5 hits=1")!=std::string::npos,"Missing-hit error did not expose the observed classification");
    snapshot=f.hook.snapshot();
    for(const auto* calls:{&snapshot.build_calls,&snapshot.non_oblique_calls}) {
        require(calls->same_camera_wrong_instance[0]==1&&calls->same_instance_wrong_camera[0]==1,
                "Lifetime identity classifications were not exclusive");
        require(calls->frame_same_camera_wrong_instance[0]==1&&calls->frame_same_instance_wrong_camera[0]==1,
                "Frame identity classifications were not recorded");
        require(calls->outside_scope_private[0]==1&&calls->outside_scope_private[1]==1,
                "Other-eye exact call was not classified outside its own scope");
        require(calls->scope_entries[1]==0&&calls->frame_scope_entries[1]==0,
                "Active-left entries contaminated right scope counts");
    }
    require(snapshot.build_calls.entries==6&&snapshot.build_calls.scope_entries[0]==4&&snapshot.build_calls.frame_scope_entries[0]==4&&
            snapshot.non_oblique_calls.entries==7&&snapshot.non_oblique_calls.scope_entries[0]==5,
            "Entry totals or per-eye scope accounting changed");
    require(f.hook.begin_eye(1,error),error.c_str());
    f.call(0,&out,f.hg(1),f.camera(1),method);f.call(1,&out,f.data(1),f.camera(1),method);
    require(f.hook.end_eye(1,error),error.c_str());
    require(f.hook.begin_eye(0,error),error.c_str());snapshot=f.hook.snapshot();
    for(const auto* calls:{&snapshot.build_calls,&snapshot.non_oblique_calls}) {
        require(calls->frame_scope_entries[0]==0&&calls->frame_same_camera_wrong_instance[0]==0&&calls->frame_same_instance_wrong_camera[0]==0,
                "New eye scope retained stale frame diagnostics");
        require(calls->frame_scope_entries[1]==1&&calls->same_camera_wrong_instance[0]==1&&calls->outside_scope_private[0]==1,
                "New eye scope reset the other eye or lifetime evidence");
    }
    require(!f.hook.end_eye(0,error)&&error.find("no Build entries during eye Render")!=std::string::npos,
            "Earlier calls hid the absence of Build entries in this frame");
    require(f.hook.begin_eye(0,error),error.c_str());f.call(0,&out,&f.ids[6],&f.ids[7],method);
    require(!f.hook.end_eye(0,error)&&error.find("none matched this private eye")!=std::string::npos,
            "An unrelated entry was incorrectly diagnosed as a matching-identity failure");
    snapshot=f.hook.snapshot();const auto previousEntries=snapshot.build_calls.entries;
    f.hook.clear();f.call(0,&out,f.hg(0),f.camera(0),method);
    snapshot=f.hook.snapshot();require(out.values[0]==1000&&snapshot.build_calls.entries==previousEntries+1&&
        snapshot.build_calls.outside_scope_private[0]==1,"Clear lost total evidence or retained a stale private identity");
    f.host.api.release_module_hooks(f.host.api.context,"quest3.vrvd");
    require(f.hook.install(&f.host.api,error),error.c_str());snapshot=f.hook.snapshot();
    require(snapshot.build_calls.entries==0&&snapshot.non_oblique_calls.entries==0&&snapshot.build_calls.outside_scope_private[0]==0&&
            snapshot.build_calls.same_camera_wrong_instance[0]==0&&snapshot.build_calls.frame_scope_entries[0]==0,
            "Reinstallation retained counters from the previous hook lifetime");
}
void frame_parameters_observation(){
    Fixture f(true);std::string error;unsigned culling=0;void* additional=nullptr;void* hg=nullptr;
    void* pipeline=&f.ids[6];const void* method=&f.ids[7];
    require(f.hook.snapshot().frame_parameters_observer&&f.hook.snapshot().frame_parameters_status=="installed","Optional pipeline observer not installed");
    f.host.nextAdditional=f.data(0);f.host.nextHg=f.hg(0);
    const auto invoke=[&](void* camera,void** dataOut,void** hgOut) {
        const uint8_t result=f.host.prepareDetour(pipeline,camera,dataOut,hgOut,&culling,method);
        require(f.host.seenPipeline==pipeline&&f.host.seenCamera==camera&&f.host.seenAdditionalOut==dataOut&&f.host.seenHgOut==hgOut&&
            f.host.seenCulling==&culling&&f.host.seenMethod==method,"Observer altered native parameters");
        require(culling==0x178ea,"Observer suppressed an original culling output");return result;
    };
    require(invoke(f.camera(0),&additional,&hg)==1&&additional==f.data(0)&&hg==f.hg(0),"Observer changed original Boolean or byref outputs");
    auto stats=f.hook.snapshot();require(stats.prepare_entries==1&&stats.prepare_calls[0]==1&&stats.frame_prepare_calls[0]==0,
        "Outside-scope preparation was wrongly counted as current Render work");
    require(f.hook.begin_eye(0,error),error.c_str());
    require(invoke(&f.ids[7],&additional,&hg)==1,"Unrelated prepare result changed");
    stats=f.hook.snapshot();require(stats.prepare_entries==2&&stats.prepare_calls[0]==1&&stats.frame_prepare_calls[0]==0,
        "Unrelated camera affected eye preparation counters");
    require(invoke(f.camera(0),&additional,&hg)==1,"Matching prepare result changed");
    stats=f.hook.snapshot();require(stats.frame_prepare_calls[0]==1&&stats.frame_prepare_successes[0]==1&&
        stats.frame_prepare_hg_mismatch[0]==0&&stats.frame_prepare_additional_mismatch[0]==0,"Matching output identities counted as mismatches");
    f.host.nextHg=&f.ids[6];require(invoke(f.camera(0),&additional,&hg)==1&&hg==&f.ids[6],"Observer rewrote the HG output identity");
    f.host.nextHg=f.hg(0);f.host.nextAdditional=&f.ids[7];
    require(invoke(f.camera(0),&additional,&hg)==1&&additional==&f.ids[7],"Observer rewrote the additional-data output identity");
    stats=f.hook.snapshot();require(stats.frame_prepare_successes[0]==3&&stats.frame_prepare_hg_mismatch[0]==1&&stats.frame_prepare_additional_mismatch[0]==1,
        "Separate out-object identity mismatches were not observed");
    f.host.prepareResult=0;
    auto* inaccessible=reinterpret_cast<void**>(uintptr_t(1));
    require(invoke(f.camera(0),inaccessible,inaccessible)==0,"False pipeline result changed");
    f.host.throwPrepare=true;bool propagated=false;
    try{invoke(f.camera(0),inaccessible,inaccessible);}catch(const std::runtime_error& ex){propagated=std::string(ex.what())=="prepare original failure";}
    require(propagated,"Observer swallowed or replaced an original exception");f.host.throwPrepare=false;
    stats=f.hook.snapshot();require(stats.frame_prepare_calls[0]==5&&stats.frame_prepare_successes[0]==3&&
        stats.frame_prepare_hg_mismatch[0]==1&&stats.frame_prepare_additional_mismatch[0]==1,"False/exception path examined uninitialized out parameters");
    require(!f.hook.end_eye(0,error)&&error.find("Prepare installed calls=5 true=3 wrongHG=1 wrongAdditional=1")!=std::string::npos,
        "Pipeline observation loosened Build acceptance or omitted useful failure evidence");
    require(f.hook.begin_eye(1,error),error.c_str());
    f.host.prepareResult=1;f.host.nextHg=f.hg(1);f.host.nextAdditional=f.data(1);
    require(invoke(f.camera(1),&additional,&hg)==1,"Right-eye pipeline result changed");Matrix matrix{};
    f.call(0,&matrix,f.hg(1),f.camera(1),method);require(f.hook.end_eye(1,error),error.c_str());
    require(f.hook.begin_eye(0,error),error.c_str());stats=f.hook.snapshot();
    require(stats.frame_prepare_calls[0]==0&&stats.frame_prepare_successes[0]==0&&stats.frame_prepare_hg_mismatch[0]==0&&
        stats.frame_prepare_additional_mismatch[0]==0&&stats.frame_prepare_calls[1]==1,"Prepare frame counters did not reset independently");
    f.host.clearDuringPrepare=true;
    require(invoke(f.camera(0),&additional,&hg)==1,"Clearing a scope during original prepare changed its result");
    stats=f.hook.snapshot();require(!stats.scope_active&&stats.frame_prepare_calls[0]==1&&stats.frame_prepare_successes[0]==0,
        "Late preparation completion was attributed to a closed scope");
}
void optional_frame_parameters_contracts(){
    {Fixture f;const auto s=f.hook.snapshot();require(s.installed&&!s.frame_parameters_observer&&s.frame_parameters_status=="method_unavailable",
        "Missing optional pipeline method disabled mandatory projection hooks");}
    {Fake host;host.prepareAvailable=true;host.failPrepareInstall=true;vrvd::HgProjectionHook hook;host.hook=&hook;std::string error;
        require(hook.install(&host.api,error)&&hook.snapshot().installed&&!hook.snapshot().frame_parameters_observer&&
            hook.snapshot().frame_parameters_status=="hook_installation_failed","Unavailable optional hook caused extra startup failure");}
    {Fake host;host.prepareAvailable=true;host.nullPrepareOriginal=true;vrvd::HgProjectionHook hook;host.hook=&hook;std::string error;
        require(!hook.install(&host.api,error)&&!hook.snapshot().installed&&hook.snapshot().frame_parameters_status=="host_missing_original",
            "Host falsely claiming observer installation without original was accepted");
        bool threw=false;try{host.prepareDetour(nullptr,nullptr,nullptr,nullptr,nullptr,nullptr);}catch(const std::runtime_error&){threw=true;}
        require(threw&&host.prepareOriginalCalls==0,"Missing observer original fabricated a Boolean result");
        require(host.releases==0,"Observer contract failure released unrelated module hooks");}
}
void reinstall_preserves_inflight_originals(){
    Fixture f(true);std::string error;
    f.host.oldDetours[0]=f.host.detours[0];f.host.oldDetours[1]=f.host.detours[1];f.host.oldPrepareDetour=f.host.prepareDetour;
    f.host.nextHg=f.hg(0);f.host.nextAdditional=f.data(0);f.host.probeOldDuringCreate=true;
    require(f.host.api.release_module_hooks(f.host.api.context,"quest3.vrvd")==BE_Result_Ok,"Fake host could not retire its previous nodes");
    require(f.hook.install(&f.host.api,error),error.c_str());
    require(f.host.oldCallbackProbes==3&&f.hook.snapshot().installed&&f.hook.snapshot().frame_parameters_observer,
        "Reinstall did not preserve callbacks throughout all three hook creation windows");
    // A host explicitly overwriting an original with null remains an error;
    // retaining old slots must not mask a false success from create_hook.
    f.host.probeOldDuringCreate=false;f.host.nullPrepareOriginal=true;
    f.host.api.release_module_hooks(f.host.api.context,"quest3.vrvd");
    require(!f.hook.install(&f.host.api,error)&&f.hook.snapshot().frame_parameters_status=="host_missing_original",
        "Persistent slots masked a host publishing a null original");
}
struct DrawFixture {
    Fake host;vrvd::HgProjectionHook hook;int ids[12]{};Matrix eyes[2]{},rendered[2]{};
    int validations=0;bool accept=true,clearDuringValidation=false;
    DrawFixture(){host.hook=&hook;host.prepareAvailable=host.getAvailable=true;std::string e;
        require(hook.install(&host.api,e,validate,this),e.c_str());
        for(unsigned i=0;i<2;++i){eyes[i].values[0]=1.3f+float(i);eyes[i].values[5]=1.1f;eyes[i].values[8]=i?-.17f:.23f;
            require(hook.set_eye(i,predicted(i),camera(i),data(i),eyes[i].values,e),e.c_str());}
    }
    void* predicted(unsigned i){return &ids[i*4];}void* actual(unsigned i){return &ids[i*4+1];}
    void* camera(unsigned i){return &ids[i*4+2];}void* data(unsigned i){return &ids[i*4+3];}
    static bool validate(void* context,unsigned eye,void* hg,void* camera,void* additional,std::string& error) {
        auto& f=*static_cast<DrawFixture*>(context);++f.validations;f.hook.snapshot();
        if(f.clearDuringValidation)f.hook.clear();
        if(!f.accept||hg!=f.actual(eye)||camera!=f.camera(eye)||additional!=f.data(eye)) {error="fake adapter rejected HG ownership";return false;}
        return true;
    }
    void draw(unsigned eye,int32_t multipass=0) {
        void* selected=host.getDetour(camera(eye),multipass,&ids[11]);
        require(selected==host.nextHg&&host.getSeenCamera==camera(eye)&&host.getSeenMultipass==multipass&&host.getSeenMethod==&ids[11],
            "GetOrCreate changed its original result/arguments");
        host.detours[0](&rendered[eye],selected,camera(eye),&ids[11]);
    }
    uint8_t prepare(unsigned eye,void** additional=nullptr,void** hg=nullptr) {
        void* dataOut=nullptr;void* hgOut=nullptr;unsigned culling=0;
        return host.prepareDetour(&ids[10],camera(eye),additional?additional:&dataOut,hg?hg:&hgOut,&culling,&ids[11]);
    }
    void setup(unsigned eye) {host.nextHg=actual(eye);host.nextAdditional=data(eye);host.prepareAction=[&,eye]{draw(eye);};}
};
void draw_binding_replaces_stale_cached_identity(){
    DrawFixture f;std::string e;
    require(f.hook.snapshot().draw_binding_required&&f.hook.snapshot().get_or_create_hook,"Dynamic binding hooks not installed");
    for(unsigned i=0;i<2;++i) {
        f.setup(i);require(f.hook.begin_eye(i,e),e.c_str());
        require(f.prepare(i)==1&&std::memcmp(&f.rendered[i],&f.eyes[i],64)==0,"Stale cached HG did not rebind before real Build");
        require(f.hook.end_eye(i,e),e.c_str());const auto stats=f.hook.snapshot();
        require(stats.frame_draw_bindings[i]==1&&stats.frame_draw_binding_changed[i]==1&&stats.frame_build_hits[i]==1&&
            stats.frame_prepare_hg_mismatch[i]==0&&stats.frame_prepare_validation_failures[i]==0,"Dynamic draw binding diagnostics incorrect");
        Matrix outside{};f.host.detours[0](&outside,f.actual(i),f.camera(i),nullptr);
        require(outside.values[0]==1000,"Actual HG remained overridden outside its eye scope");
    }
    require(f.validations==2,"Validated returned HG more than once per bound eye");
    require(f.hook.begin_eye(0,e),e.c_str());
    Matrix stale{};f.host.detours[0](&stale,f.actual(0),f.camera(0),nullptr);
    require(stale.values[0]==1000&&!f.hook.end_eye(0,e),"Previous frame binding leaked into a new eye scope");
}
void draw_binding_rejects_after_hits(){
    for(unsigned failure=0;failure<9;++failure) {
        DrawFixture f;std::string e;f.setup(0);require(f.hook.begin_eye(0,e),e.c_str());
        f.host.prepareAction=[&]{
            f.draw(0);
            require(std::memcmp(&f.rendered[0],&f.eyes[0],64)==0,"Initial valid Build did not route");
            if(failure==0)f.host.nextHg=&f.ids[9];
            if(failure==1)f.host.nextAdditional=&f.ids[9];
            if(failure==2)f.host.prepareResult=0;
            if(failure==3)throw std::runtime_error("original throws after Build");
            if(failure==4){f.host.nextHg=&f.ids[9];f.host.getDetour(f.camera(0),0,nullptr);f.host.nextHg=f.actual(0);}
            if(failure==5){Matrix bad{};f.host.detours[0](&bad,f.predicted(0),f.camera(0),nullptr);}
            if(failure==6){f.host.nextHg=f.actual(1);f.host.getDetour(f.camera(0),0,nullptr);f.host.nextHg=f.actual(0);}
            if(failure==7){std::thread t([&]{Matrix bad{};f.host.detours[0](&bad,f.actual(0),f.camera(0),nullptr);require(bad.values[0]==1000,"Worker projection was intercepted");});t.join();}
            if(failure==8){Matrix bad{};f.host.detours[0](&bad,f.actual(0),&f.ids[9],nullptr);require(bad.values[0]==1000,"Private HG was intercepted for a different Camera");}
        };
        bool threw=false;try{f.prepare(0);}catch(const std::runtime_error& ex){threw=std::string(ex.what())=="original throws after Build";}
        require(threw==(failure==3),"Original Prepare exception changed");
        require(f.hook.snapshot().frame_build_hits[0]==1&&!f.hook.end_eye(0,e)&&e.find("draw binding rejected")!=std::string::npos,
            "A hit concealed failed Prepare/output/rebinding validation");
    }
    DrawFixture f;std::string e;f.setup(0);require(f.hook.begin_eye(0,e),e.c_str());
    f.host.prepareResult=0;f.host.prepareAction={};
    auto* inaccessible=reinterpret_cast<void**>(uintptr_t(1));
    require(f.prepare(0,inaccessible,inaccessible)==0,"False result changed");
    f.host.prepareResult=1;f.setup(0);f.prepare(0);
    require(!f.hook.end_eye(0,e),"Later success cleared an earlier sticky Prepare failure");
}
void draw_binding_scope_and_validator_guards(){
    for(unsigned failure=0;failure<5;++failure) {
        DrawFixture f;std::string e;f.setup(0);require(f.hook.begin_eye(0,e),e.c_str());
        if(failure==0)f.accept=false;
        if(failure==1)f.clearDuringValidation=true;
        if(failure==2)f.host.nextHg=f.predicted(1); // Other eye must be rejected before validator.
        if(failure==3)f.host.prepareAction=[&]{std::thread t([&]{f.draw(0);});t.join();};
        if(failure==4)f.host.prepareAction=[&]{
            auto saved=f.host.prepareAction;f.host.prepareAction=[&]{f.draw(0);};
            unsigned culling=0;void* a=nullptr;void* h=nullptr;
            f.host.prepareDetour(&f.ids[10],&f.ids[9],&a,&h,&culling,nullptr);
            f.host.prepareAction=saved;
        };
        f.prepare(0);auto stats=f.hook.snapshot();
        require(stats.frame_build_hits[0]==0&&!f.hook.end_eye(0,e),"Wrong-thread/context/ownership validation certified a draw");
        require(f.rendered[0].values[0]==1000,"Invalid draw binding intercepted the original projection");
        if(failure>=2)require(f.validations==0,"Unrelated scope or other-eye HG reached the adapter validator");
    }
    DrawFixture f;std::string e;f.setup(0);
    // A direct GetOrCreate outside TryCalculate must not grant draw authority.
    require(f.hook.begin_eye(0,e),e.c_str());f.draw(0);
    require(f.validations==0&&f.hook.snapshot().frame_build_hits[0]==0&&!f.hook.end_eye(0,e),"Unscoped GetOrCreate bound the eye");
    // An exception must restore TLS; subsequent calls outside Prepare cannot bind.
    require(f.hook.begin_eye(0,e),e.c_str());f.host.throwPrepare=true;
    try{f.prepare(0);}catch(const std::runtime_error&){}f.host.throwPrepare=false;f.draw(0);
    require(f.validations==0&&!f.hook.end_eye(0,e),"Prepare exception leaked thread-local binding context");
}
void dynamic_reinstall_and_repeat_get(){
    DrawFixture f;std::string error;
    f.setup(0);require(f.hook.begin_eye(0,error),error.c_str());
    f.host.prepareAction=[&]{f.draw(0);f.draw(0);};
    f.prepare(0);require(f.hook.end_eye(0,error),error.c_str());
    require(f.validations==1&&f.hook.snapshot().frame_build_hits[0]==2,"Repeated same HG selection was not reused safely");
    f.host.prepareAction={};f.host.oldDetours[0]=f.host.detours[0];f.host.oldDetours[1]=f.host.detours[1];
    f.host.oldPrepareDetour=f.host.prepareDetour;f.host.oldGetDetour=f.host.getDetour;f.host.probeOldDuringCreate=true;
    f.host.api.release_module_hooks(f.host.api.context,"quest3.vrvd");
    require(f.hook.install(&f.host.api,error,DrawFixture::validate,&f),error.c_str());
    require(f.host.oldCallbackProbes==4&&f.hook.snapshot().get_or_create_hook,"Dynamic reinstall lost old callbacks in one of four publication windows");
    require(f.hook.snapshot().frame_draw_bindings[0]==0,"Reinstall retained previous draw authorization");
}
void required_draw_binding_contracts(){
    for(unsigned fault=0;fault<4;++fault) {
        Fake host;vrvd::HgProjectionHook hook;std::string e;host.prepareAvailable=fault!=0;host.getAvailable=fault!=1;
        host.failGetInstall=fault==2;host.nullGetOriginal=fault==3;
        require(!hook.install(&host.api,e,DrawFixture::validate,nullptr)&&!hook.snapshot().installed,
            "Incomplete required dynamic binding hooks were accepted");
        require(host.releases==0,"Draw binding failure released unrelated hooks");
    }
}
}
int main(){try{routing_and_sret();missing_hit_and_clear();contracts_and_partial_install();asymmetric_fov_keeps_forward_rays_aligned();diagnostic_classification_and_reset();frame_parameters_observation();optional_frame_parameters_contracts();reinstall_preserves_inflight_originals();draw_binding_replaces_stale_cached_identity();draw_binding_rejects_after_hits();draw_binding_scope_and_validator_guards();dynamic_reinstall_and_repeat_get();required_draw_binding_contracts();std::cout<<"PASS HG projection hooks: actual draw HG binding with output/ownership/thread/generation/sticky-failure guards, stable originals across reinstall, observer passthrough/Boolean/byref/exception contracts, entry/scope/identity diagnostics, asymmetric FOV alignment, explicit sret ABI, strict draw rejection and partial install (no game/GPU)\n";return 0;}catch(const std::exception& e){std::cerr<<"FAIL HG projection hooks: "<<e.what()<<'\n';return 1;}}
