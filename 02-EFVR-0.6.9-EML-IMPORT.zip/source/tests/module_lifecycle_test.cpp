// Executes the production module state machine with empty real XR backends.
// No Unity host is resolved, no game DLL is loaded, and no XR session/device is created.
#include "../src/module.cpp"
#include <cstdio>
#include <cstdlib>

namespace {
void check(bool condition,const char* text) {
    if(!condition) {std::fprintf(stderr,"FAIL: %s\n",text);std::exit(1);}
}
struct TextureStub final : ID3D11Texture2D {
    ULONG refs=1, releases=0;
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID,void** out) override {
        if(out)*out=nullptr; return E_NOINTERFACE;
    }
    ULONG STDMETHODCALLTYPE AddRef() override {return ++refs;}
    ULONG STDMETHODCALLTYPE Release() override {++releases;return --refs;}
    void STDMETHODCALLTYPE GetDevice(ID3D11Device** out) override {
        if(out)*out=nullptr;check(false,"lifecycle test must not use a graphics device");
    }
    HRESULT STDMETHODCALLTYPE GetPrivateData(REFGUID,UINT*,void*) override {return E_NOTIMPL;}
    HRESULT STDMETHODCALLTYPE SetPrivateData(REFGUID,UINT,const void*) override {return E_NOTIMPL;}
    HRESULT STDMETHODCALLTYPE SetPrivateDataInterface(REFGUID,const IUnknown*) override {return E_NOTIMPL;}
    void STDMETHODCALLTYPE GetType(D3D11_RESOURCE_DIMENSION* out) override {*out=D3D11_RESOURCE_DIMENSION_TEXTURE2D;}
    void STDMETHODCALLTYPE SetEvictionPriority(UINT) override {}
    UINT STDMETHODCALLTYPE GetEvictionPriority() override {return 0;}
    void STDMETHODCALLTYPE GetDesc(D3D11_TEXTURE2D_DESC*) override {
        check(false,"lifecycle test must not initialize a graphics backend");
    }
};
json last_reply;
BE_Result BE_CALL reply_stub(void*,const char*,BE_Result,const char* text) {
    last_reply=json::parse(text);return BE_Result_Ok;
}
void reset_case() {
    first_person_ready_callback.store(nullptr);desktop_only=false;desktop_install_attempted=false;desktop_mark_error.clear();
    check(desktop_filter.clear(),"empty desktop filter clears without game calls");
    failure_context=json::object();
    check(!pending_eyes[0]&&!pending_eyes[1],"previous test leaked its fake COM references");
    check(!unity.resources_alive()&&!hud.resources_alive()&&!gpu_probe.resources_alive(),"tests must have no Unity allocations");
    // These real backend objects were never initialized. Their close methods
    // therefore issue no OpenXR/OpenVR calls and load no runtime.
    xr.shutdown();check(vk.shutdown(),"empty Vulkan backend closes");check(ovr.shutdown(),"empty OpenVR backend closes");use_openvr=false;
    host={};host.reply=reply_stub;api=nullptr;next_push=nullptr;
    live=true;stop_bootstrap=false;requested=false;closing=false;hooks_ready=true;
    targets=xr_initialized=restart_required=teardown_pending=recovery_pending=false;
    pending=0;graphics=0;submitted=session_submitted=recoveries=source_generation=0;
    pending_since=last_camera_tick=last_accepted_frame=last_submission={};
    width=height=1440;vulkan_width=vulkan_height=1024;quality_preset="custom";
    hud_capture_width=1280;hud_capture_height=720;hud_refresh_hz=10;
    hud_composition="game_ui";
    hud_distance=1.5f;hud_width=1.8f;hud_offset=0.f;
    swap_eyes=false;hud_enabled=true;hud_blocked=false;hud_error.clear();
    gpu_probe_requested=gpu_probe_cleanup=gpu_probe_resolved=false;
    recovery_reason.clear();error.clear();state="ready_disabled";
    clear_frame_observations();last_reply={};
    wchar_t self[32768]{};check(GetModuleFileNameW(nullptr,self,32768)>0,"get test executable path");
    // Start validates existence only; tests never reach backend initialization.
    loader=self;openvr_loader=self;
}
void retain_pair(TextureStub& left,TextureStub& right) {
    left.AddRef();right.AddRef();pending_eyes[0]=&left;pending_eyes[1]=&right;
    pending=2;pending_since=Clock::now();graphics=2;xr_initialized=true;
}
void command(const char* body) {
    check(on_message("lifecycle-test",body)==BE_Result_Ok,"module command accepted");
}
}

int main() {
    reset_case();
    {
        TextureStub left,right;retain_pair(left,right);requested=true;
        command("{\"action\":\"stop\"}");
        check(teardown_pending&&!requested&&left.refs==2&&right.refs==2,"stop queues cleanup without releasing pending textures");
        command("{\"action\":\"start\",\"first_person_confirmed\":true}");
        check(requested&&teardown_pending&&state=="start_queued_until_cleanup","start cannot bypass queued stop");
        render_event(1);
        check(pending==2&&left.refs==2,"wrong event cannot consume captured resources");
        render_event(2);
        check(!pending&&!xr_initialized&&teardown_pending&&submitted==0,"old submit event closes instead of submitting after queued restart");
        check(left.refs==1&&right.refs==1&&left.releases==1&&right.releases==1,"callback releases each captured reference exactly once");
        check(teardown_on_game_thread()==0&&!teardown_pending&&requested&&state=="waiting_game_camera","restart waits for game-thread cleanup completion");
    }
    reset_case();
    {
        graphics=2;xr_initialized=true;queue_teardown("lost targets",true);requested=true;
        check(teardown_on_game_thread()==3&&pending==3&&xr_initialized,"D3D recovery queues graphics-thread close");
        render_event(3);
        check(!pending&&!xr_initialized&&teardown_pending,"close callback does not perform Unity cleanup");
        check(teardown_on_game_thread()==0&&!teardown_pending&&recoveries==1,"subsequent game thread finishes recovery");
    }
    reset_case();
    {
        TextureStub left,right;retain_pair(left,right);requested=true;
        // Actual UnityBridge::schedule rejects its unresolved host. This exercises
        // production dispatch failure handling, not a copy of that algorithm.
        dispatch_render_event(2);
        check(restart_required&&teardown_pending&&!requested&&pending==2,"dispatch failure retains ambiguous pending callback");
        check(left.refs==2&&right.refs==2,"dispatch failure cannot release potentially queued resources");
        render_event(2); // A late callback remains safe if one does arrive.
        check(!pending&&left.refs==1&&right.refs==1,"late callback drains retained pair");
    }
    reset_case();
    {
        graphics=2;xr_initialized=true;requested=true;
        shutdown(); // No game frame is supplied; bounded worker wait expires.
        check(!live&&restart_required&&xr_initialized,"worker cannot force-close a backend when no game/render frame arrives");
        check(state=="restart_required","incomplete worker shutdown is reported");
    }
    reset_case();
    {
        TextureStub left,right;retain_pair(left,right);requested=true;
        shutdown();
        check(restart_required&&pending==2&&left.refs==2&&right.refs==2,"worker preserves an in-flight pair");
        render_event(2);
        check(!pending&&!xr_initialized&&left.refs==1&&right.refs==1,"callback may safely finish after module shutdown");
    }
    reset_case();
    {
        requested=true;state="submitting_experimental_frames";
        frame_metrics.submitted(100);frame_metrics.submitted(116);frame_metrics.submitted(132);
        last_camera_tick=last_accepted_frame=Clock::now();last_submission=Clock::now()-std::chrono::seconds(4);
        auto snapshot=status();
        check(snapshot["state"]=="waiting_fresh_frame","stalled submission must not report active frame delivery");
        check(snapshot["performance"]["application_stereo_pairs_hz"]==0&&
              snapshot["performance"]["application_metrics_fresh"]==false,"stale throughput is not advertised as current");
        check(snapshot["camera_adapter"].is_object(),"cached camera diagnostics exposed without calling Unity");
    }
    reset_case();
    {
        graphics=21;vulkan_width=2064;vulkan_height=2208;requested=true;
        fail("test: no matching HG projection");
        check(teardown_pending&&!requested,"render failure queues cleanup");
        teardown_on_game_thread();
        auto snapshot=status();
        check(snapshot["graphics_api"]==0,"cleanup clears active graphics resources");
        const auto saved=snapshot["last_failure_context"];
        check(saved["graphics_api"]==21&&saved["requested_eye_width"]==2064&&saved["requested_eye_height"]==2208&&
              saved["error"]=="test: no matching HG projection","failure API and requested size survive resource cleanup");
    }

    reset_case();
    {
        std::string why;
        check(configure("{\"vulkan_eye_width\":768,\"vulkan_eye_height\":768,\"runtime_backend\":\"openxr\"}",why),
            "legacy config without quality preset accepted");
        check(quality_preset=="custom"&&vulkan_width==768&&vulkan_height==768&&width==1440&&height==1440,
            "legacy dimensions are preserved without silently enabling maximum quality");
        check(!use_openvr,"legacy configuration preserves explicit working OpenXR backend");
        check(hud_enabled&&hud_capture_width==1280&&hud_capture_height==720&&hud_refresh_hz==10&&hud_composition=="game_ui"&&
            hud_distance==1.5f&&hud_width==1.8f&&hud_offset==0.f,
            "native HUD defaults to a centered transparent panel at 1280x720 and 10 Hz");
        check(configure("{}",why)&&width==1440&&height==1440&&vulkan_width==1024&&vulkan_height==1024&&!desktop_only,
            "empty EML configuration matches the conservative manifest defaults");
        check(configure("{\"quality_preset\":\"maximum\"}",why)&&vulkan_width==3072&&width==2560,
            "explicit maximum configuration remains supported");
        check(configure("{\"quality_preset\":\"custom\",\"vulkan_eye_width\":2064,\"vulkan_eye_height\":2208,\"eye_width\":1200,\"eye_height\":1400}",why),
            "custom quality accepted");
        check(quality_preset=="custom"&&vulkan_width==2064&&vulkan_height==2208&&width==1200&&height==1400,
            "custom quality uses actual requested sizes instead of maximum preset");
        auto snapshot=status();
        check(snapshot["quality_preset"]=="custom"&&snapshot["hud_capture_width"]==1280&&
            snapshot["hud_capture_height"]==720&&snapshot["hud_refresh_hz"]==10,
            "quality and HUD capture settings exposed in cached status");
        check(snapshot["hud_mode"]=="head_locked"&&snapshot["hud_distance_m"]==1.5f&&
            snapshot["hud_width_m"]==1.8f&&snapshot["hud_offset_y_m"]==0.f,
            "cached status reports the actual configured front HUD pose");
        check(configure("{\"hud_mode\":\"off\"}",why)&&!hud_enabled&&status()["hud_status"]=="off",
            "explicitly disabled HUD stays off despite the new default");
        check(configure("{}",why)&&hud_enabled,"empty configuration re-enables the requested default HUD");
    }
    reset_case();
    {
        std::string why;
        const json base={{"quality_preset","custom"},{"vulkan_eye_width",1440},{"vulkan_eye_height",1600},
            {"hud_capture_width",1024},{"hud_capture_height",576},{"hud_refresh_hz",15},
            {"hud_composition","opaque"},{"swap_eyes",true}};
        check(configure(base.dump().c_str(),why),"custom quality and HUD baseline accepted");
        for(const auto& invalid:std::vector<json>{
                {{"quality_preset","low"}},{{"quality_preset",true}},
                {{"hud_capture_width",255}},{{"hud_capture_height",2049}},
                {{"hud_capture_width","wide"}},{{"hud_refresh_hz",4}},
                {{"hud_refresh_hz",31}},{{"hud_refresh_hz","fast"}},
                {{"hud_composition","keyed"}},{{"hud_composition",false}},
                {{"quality_preset","maximum"},{"vulkan_eye_height",3073}}}) {
            auto proposal=base;proposal.update(invalid);proposal["swap_eyes"]=false;
            check(!configure(proposal.dump().c_str(),why)&&!why.empty(),"invalid quality/HUD config rejected");
            check(quality_preset=="custom"&&vulkan_width==1440&&vulkan_height==1600&&
                hud_capture_width==1024&&hud_capture_height==576&&hud_refresh_hz==15&&swap_eyes,
                "quality/HUD rejection leaves all previously accepted settings unchanged");
            check(status()["hud_composition_requested"]=="opaque","rejected composition preserves selected mode");
        }
        check(configure("{\"hud_capture_width\":256,\"hud_capture_height\":2048,\"hud_refresh_hz\":5}",why),
            "HUD lower width and refresh bounds accepted");
        check(hud_capture_width==256&&hud_capture_height==2048&&hud_refresh_hz==5,"HUD lower bounds applied");
        check(configure("{\"hud_capture_width\":2048,\"hud_capture_height\":256,\"hud_refresh_hz\":30}",why),
            "HUD upper width and refresh bounds accepted");
        check(hud_capture_width==2048&&hud_capture_height==256&&hud_refresh_hz==30,"HUD upper bounds applied");
    }
    reset_case();
    {
        std::string why;
        check(configure("{}",why)&&!use_openvr,"default runtime remains OpenXR");
        const json base={{"runtime_backend","steamvr_openvr"},
            {"openxr_loader_path","C:/vr-test/openxr_loader.dll"},
            {"openvr_loader_path","C:/vr-test/openvr_api.dll"}, {"swap_eyes",true}};
        check(configure(base.dump().c_str(),why)&&use_openvr,"SteamVR OpenVR runtime option accepted without starting it");
        const auto xr_path=loader,vr_path=openvr_loader;
        for (const auto& invalid : std::vector<json>{
                {{"runtime_backend","vrchat"}},{{"runtime_backend",true}},
                {{"runtime_backend",7}},{{"openvr_loader_path",false}},
                {{"openvr_loader_path","relative/openvr_api.dll"}}}) {
            auto proposal=base;proposal.update(invalid);proposal["swap_eyes"]=false;
            check(!configure(proposal.dump().c_str(),why)&&!why.empty(),"invalid runtime option rejected");
            check(use_openvr&&loader==xr_path&&openvr_loader==vr_path&&swap_eyes,
                "invalid runtime config leaves previous settings untouched");
        }
        check(status()["runtime_backend"]=="steamvr_openvr","status exposes configured runtime without a session");
        check(configure("{}",why)&&!use_openvr,"stopped runtime can switch back to OpenXR");
    }
    // These states can retain or begin using a backend. None may permit a
    // loader/backend change, even when no frame is currently being submitted.
    for (int active=0;active<6;++active) {
        reset_case();
        std::string why;
        const json base={{"runtime_backend","openxr"},
            {"quality_preset","custom"},{"eye_width",2560},{"eye_height",2560},
            {"vulkan_eye_width",3072},{"vulkan_eye_height",3072},
            {"hud_capture_width",2048},{"hud_capture_height",1152},{"hud_refresh_hz",20},
            {"openxr_loader_path","C:/vr-test/openxr_loader.dll"},
            {"openvr_loader_path","C:/vr-test/openvr_api.dll"}, {"swap_eyes",true}};
        check(configure(base.dump().c_str(),why),"inactive baseline config accepted");
        bool* flags[]={&requested,&targets,&xr_initialized,nullptr,&teardown_pending,&restart_required};
        if(active==3)pending=3;else *flags[active]=true;
        const auto xr_path=loader,vr_path=openvr_loader;
        for (const auto& change : std::vector<json>{
                {{"runtime_backend","steamvr_openvr"}},
                {{"openvr_loader_path","C:/vr-test/other_openvr.dll"}},
                {{"openxr_loader_path","C:/vr-test/other_openxr.dll"}},
                {{"quality_preset","maximum"}},
                {{"hud_capture_width",1024}},{{"hud_capture_height",576}}}) {
            auto proposal=base;proposal.update(change);proposal["swap_eyes"]=false;
            check(!configure(proposal.dump().c_str(),why),"active runtime/backend path switch rejected");
            check(!use_openvr&&loader==xr_path&&openvr_loader==vr_path&&swap_eyes&&
                quality_preset=="custom"&&hud_capture_width==2048&&hud_capture_height==1152&&hud_refresh_hz==20,
                "active switch rejection is atomic");
        }
        auto hot=base;hot["hud_refresh_hz"]=30;hot["hud_composition"]="transparent";
        check(configure(hot.dump().c_str(),why)&&hud_refresh_hz==30,
            "HUD refresh rate hot change preserves active render targets and runtime");
        check(status()["hud_composition_requested"]=="transparent",
            "HUD composition mode may change without reallocating active render targets");
        if(active==3)pending=0;else *flags[active]=false;
    }
    reset_case();
    {
        // This backend was never initialized: only production ownership routing
        // runs, with no OpenVR init, GPU allocation or compositor call.
        graphics=21;use_openvr=true;xr_initialized=true;requested=true;
        command("{\"action\":\"stop\"}");
        check(teardown_pending&&!requested,"OpenVR stop queues game-thread cleanup");
        check(teardown_on_game_thread()==0&&!pending&&!xr_initialized&&!teardown_pending,
            "game-thread owned OpenVR closes without a D3D render callback");
        check(!restart_required,"empty OpenVR shutdown requires no restart");
    }
    reset_case();
    {
        graphics=21;use_openvr=true;xr_initialized=true;
        queue_teardown("OpenVR lost targets",true);requested=true;
        check(teardown_on_game_thread()==0&&!pending&&!xr_initialized&&!teardown_pending,
            "OpenVR recovery drains ownership on game thread");
        check(recoveries==1&&requested&&state=="waiting_game_camera",
            "OpenVR recovery returns to waiting state without a D3D callback");
    }

    reset_case();
    {
        graphics=21;use_openvr=true;requested=true;xr_initialized=false;
        fail("OpenVR initialization rejected before session ready");
        check(teardown_pending&&!requested,"OpenVR initialization failure still queues owned cleanup");
        check(teardown_on_game_thread()==0&&!pending&&!xr_initialized&&!teardown_pending,
            "failed initialization cleanup needs no D3D callback");
        const auto saved=status()["last_failure_context"];
        check(saved["runtime_backend"]=="steamvr_openvr"&&saved["graphics_api"]==21,
            "failed runtime selection survives cleanup for diagnostics");
    }
    reset_case();
    {
        requested=true;first_person_ready_callback.store(+[](){return false;});
        camera_tick(nullptr,nullptr,nullptr);
        check(requested&&!targets&&!xr_initialized&&state=="waiting_first_person"&&error.empty(),"VR waits for an actual recent integrated first-person patch before using Unity");
        check(!vk.focused(),"empty OpenXR runtime cannot authorize desktop filtering");
    }
    reset_case();
    {
        check(first_person_ready_callback.load()==nullptr,"EML does not require standalone first-person callback");
        check(on_message("manual-confirm", "{\"action\":\"start\"}")==BE_Result_InvalidArgument&&!requested,
            "EML still requires manual first-person confirmation");
        command("{\"action\":\"start\",\"first_person_confirmed\":true}");
        check(requested,"manual first-person confirmation starts EML path without standalone host");
        camera_tick(nullptr,nullptr,nullptr);
        check(state!="waiting_first_person"&&!requested&&teardown_pending&&!error.empty(),
            "EML reaches unresolved Unity adapter, not an absent integrated-first-person gate");
    }
    reset_case();
    {
        BE_HostApiV1 fake_api{};api=&fake_api;
        ensure_optional_desktop_filter();
        check(!desktop_install_attempted&&!desktop_filter.snapshot().installed&&desktop_mark_error.empty(),
            "normal EML path does not resolve or install the optional Render hook");
        std::string why;
        check(configure("{\"desktop_render_mode\":\"headset_only\"}",why),"optional filter opt-in accepted");
        ensure_optional_desktop_filter();
        check(desktop_install_attempted&&!desktop_filter.snapshot().installed&&!desktop_mark_error.empty(),
            "optional filter failure stays on normal rendering with a diagnostic");
        desktop_mark_error="prior attempted diagnostic";
        ensure_optional_desktop_filter();
        check(desktop_mark_error=="prior attempted diagnostic","failed optional hook is not retried every frame");
        check(configure("{}",why)&&configure("{\"desktop_render_mode\":\"headset_only\"}",why)&&!desktop_install_attempted,
            "explicit mode switch permits retrying an unavailable optional hook");
        ensure_optional_desktop_filter();
        check(desktop_install_attempted&&desktop_mark_error!="prior attempted diagnostic","explicit retry records the current failure");
        api=nullptr;
    }
    reset_case();live=false;hooks_ready=false;
    std::puts("PASS: module lifecycle (22 cases), manual EML entry, lazy optional desktop hook, quality/HUD configuration and ownership; no game/Unity host/OpenXR or OpenVR session/GPU device");
    return 0;
}
