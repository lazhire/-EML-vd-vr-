# Source and licenses

This module is provided under AGPL-3.0-only; see LICENSE. It is an independent experimental EML module, not an official EML, Hypergryph, Meta or Virtual Desktop product.

- E Mod Loader ABI headers in `vendor/eml`: Dr-hydra/Endfield-Mod-Loader, commit `113405816cf8f7628e03dfe68d7f6ea6866ccf9a`, AGPL-3.0-only. Source: https://github.com/Dr-hydra/Endfield-Mod-Loader/tree/113405816cf8f7628e03dfe68d7f6ea6866ccf9a . The module entry and Cinemachine method descriptors follow the documented SDK and first-person example. The combined 0.6.9 bundle also includes a modified first-person example, with corresponding source and AGPL license.
- OpenXR headers in `vendor/openxr`: KhronosGroup/OpenXR-SDK, tag `release-1.1.49`, Apache-2.0 / MIT as described in the upstream files. See `vendor/openxr/LICENSE`. Source: https://github.com/KhronosGroup/OpenXR-SDK/tree/release-1.1.49 . An installed OpenXR loader is used at runtime and is not redistributed here.
- OpenVR SDK header in `vendor/openvr/headers/openvr.h`: ValveSoftware/openvr, release `v2.5.1`, commit `ae46a8dd0172580648c8922658a100439115d3eb`, BSD-3-Clause. Copyright (c) 2015, Valve Corporation. The unmodified upstream license is included in `vendor/openvr/LICENSE`, with provenance in `vendor/openvr/PROVENANCE.md`. Source: https://github.com/ValveSoftware/openvr/tree/ae46a8dd0172580648c8922658a100439115d3eb . The OpenVR runtime API DLL is loaded from the user's installed SteamVR and is not redistributed.
- nlohmann/json 3.11.3, Niels Lohmann and contributors, MIT. Copyright and full MIT license are embedded at the beginning of `vendor/nlohmann/json.hpp`. Source: https://github.com/nlohmann/json/tree/v3.11.3 .
- Vulkan C headers in `vendor/vulkan`: KhronosGroup/Vulkan-Headers, tag `v1.3.275`, Apache-2.0 / MIT as specified in the file headers and bundled license. Source: https://github.com/KhronosGroup/Vulkan-Headers/tree/v1.3.275 . The Vulkan loader and GPU driver are loaded from Windows and are not redistributed.
- Build compiler: Zig 0.13.0 (not bundled). https://ziglang.org/ .

The release ZIP includes the complete corresponding module source in `source/`, including the referenced headers and build scripts. No game files, game assets, EML host binaries, VRChat client code, SteamVR/OpenVR runtime binaries or Virtual Desktop binaries are included. Use of the public OpenVR SDK does not imply an endorsement by Valve or a port of VRChat's client rendering pipeline.

0.5.6 changes: semantic UI observation/routing, paired first-person pause intent, game-native RT extraction and menu-only XR composition. This is a modified experimental build, not an upstream official release.

0.5.7 changes: experimental original UI-camera replay and native gamepad menu overlay. The paired first-person module remains the 0.5.6 guard build. Titanfall 2 VR RUI source was reviewed as a design reference only; no upstream HUD code or binary addresses were copied.

0.5.8 changes: native complete-menu focus presentation, independently implemented separable Gaussian backdrop, premultiplied feathered panel, and shared-atlas OpenXR VIEW quad composition. First-person guard remains version 0.1.0-vr-ui-guard-056. No game assets or upstream Titanfall HUD code were copied.

0.5.9 changes: fix EML managed-string destination contract.

0.6.0 changes: distinguish null gameplay controller from read failure, retain menu suspension through unknown transitions, and capture the game window using Windows.Graphics.Capture for full menus and explicitly labeled opaque HUD edge crops. Minimal WinRT ABI declarations were checked against Microsoft windows-rs public interfaces: https://github.com/microsoft/windows-rs/blob/master/crates/libs/windows/src/Windows/Graphics/Capture/mod.rs . No Windows runtime binaries are redistributed.

0.6.9: exact observed menu/dialogue routing, independent main-thread clock fallback, same-page image retention, visible capture-wait panel and diagnostics. General display/pacing principles reviewed in kyus2001/titanfall2vr at 8c50a7d491d9a275103cfc659430e4bc1b75a608; no code or binary offsets copied. See TTF2-MENU-REFERENCE.md.
